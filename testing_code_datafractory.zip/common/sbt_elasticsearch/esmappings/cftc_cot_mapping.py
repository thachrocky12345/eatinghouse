from elasticsearch_dsl import Mapping, Completion
from es_default_text import ESDefaultText


class CFTCCOTMapping(Mapping):
    def __init__(self, name):
        super().__init__(name)
        self.field('entity_name_suggest', Completion())
        self.field('entity_name', ESDefaultText())
