from elasticsearch_dsl import Mapping, Completion, Text, Keyword, \
  InnerObjectWrapper, Nested
from utils.es_default_text import ESDefaultText
from utils.custom_analyzers import autocomplete


class Category(InnerObjectWrapper):
  pass


class SuggestionMapping(Mapping):
  def __init__(self, name):
    super().__init__(name)
    self.field('exchange', ESDefaultText())
    self.field('symbol', Text(
      fields={"keyword": Keyword(ignore_above=256),
              "autocomplete": Text(analyzer=autocomplete,
                                   search_analyzer="standard")}))
    self.field('entity_name', Text(
      fields={"keyword": Keyword(ignore_above=256),
              "autocomplete": Text(analyzer=autocomplete,
                                   search_analyzer="standard")}))
    self.field('category', Nested(
      doc_class=Category,
      properties={'category': ESDefaultText(), 'sub_category': ESDefaultText(),
                  'data_type': ESDefaultText()}
    ))
    self.field('tags', ESDefaultText())  # elastic search stores an array of strings as a string (now text) object
    self.field('entity_description', ESDefaultText())