from elasticsearch_dsl import analyzer, token_filter


autocomplete_filter = token_filter("autocomplete_filter", "edge_ngram",
                                   min_gram=1, max_gram=20)

autocomplete = analyzer("autocomplete", tokenizer="standard",
                        filter=["lowercase", autocomplete_filter])
