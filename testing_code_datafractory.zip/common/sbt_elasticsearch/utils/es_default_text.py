from elasticsearch_dsl import Text, Keyword


class ESDefaultText(Text):

    def __init__(self):
        super().__init__(fields={"keyword": Keyword(ignore_above=256)})
