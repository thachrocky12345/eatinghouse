from elasticsearch_dsl import Index
from estypes.suggestion import Suggestion
from utils.custom_analyzers import autocomplete


class SuggestionIndex(Index):

  def __init__(self, using='default'):
    super().__init__('suggestions', using)
    self.analyzer(autocomplete)
    self.doc_type(Suggestion)

