from bottle import response
from elasticsearch import ElasticsearchException
from elasticsearch_dsl import DocType, InnerObjectWrapper
from elasticsearch_dsl import Q
from article_utils import ArticleQueryHelper
from sbt_common import SbtCommon

sbt_common = SbtCommon()
logger = sbt_common.get_logger()
article_query_helper = ArticleQueryHelper()

def normalize_article(dynamodb_json):
    article_json = []
    for data in dynamodb_json:
        article = {
            'source': data['source'],
            'id': data['uuid'],
            'createdAt': data['created_at'],
            'modifiedAt': data['updated_at'],
            'external_id': data['external_id'],
            'publishedAt': data['published_at']
        }

        if 'title' in data.keys():
            article['title'] = data['title']

        if 'description' in data.keys():
            article['excerpt'] = data['description']

        if 'ticker' in data.keys():
            article['ticker'] = data['ticker']

        if 'author' in data.keys():
            article['author'] = data['author']

        if 'content' in data.keys():
            article['content'] = data['content']

        if 'article_url' in data.keys():
            article['url'] = data['article_url']

        if 'authors' in data.keys():
            article['authors'] = data['authors']

        if 'tickers' in data.keys():
            article['tickers'] = data['tickers']

        if 'channels' in data.keys():
            article['channels'] = data['channels']

        article_json.append(article)
    return article_json


class Paragraph(InnerObjectWrapper):
    pass


class Symbol(InnerObjectWrapper):
    pass


class ExternalArticle(DocType):
    class Meta:
        index = 'external_articles'
        doc_type = '_doc'

    @staticmethod
    def counts(filters):
      filter = Q('terms', **filters)
      query = Q('bool',
                filter=filter
                )

      count = ExternalArticle.search().query(query)
      try:
          counts = count.count()
          return counts
      except ElasticsearchException as e:
          logger.exception("ElasticSearch exception: " + str(e))
          response.status = 400
          return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def find(symbols=[], paging={}, channels=[], authors=[], type=None, text=None):
        """
        Search for articles based on core parameters
        :param paging: dict of paging data
        :param symbols: array of ticker symbols
        :param authors: array of article authors
        :param channels: array of article channels
        :rtype: list
        :return:
        """
        # TODO: Steve Finish method documentation
        filter_queries = []

        # Add symbols filter
        if len(symbols) > 0:
            filter_queries.append(Q('terms', **{'tickers.keyword': symbols}))

        # Add publications filter
        if len(channels) > 0:
            filter_queries.append(Q('terms', **{
                'channels.keyword': channels}))

        if len(authors) > 0:
            filter_queries.append(Q('terms', **{
                'authors.keyword': authors}))

        if type is not None and type.strip() != '':
            filter_queries.append(Q('term', **{
                'source': type.strip()}))

        if text is not None and text.strip() != '':
            query = Q('bool',
                      must=[
                          Q('match',
                            **{'extracted_paragraphs': text.strip()}
                            )
                      ],
                      filter=filter_queries
                      )
        else:
            query = Q('bool',
                      filter=filter_queries
                      )

        search = ExternalArticle.search().query(query)
        search = search.sort("-published_at")
        search = search[paging['start']:paging['end']]

        try:
            items = search.execute()
            return ExternalArticle.response(items)

        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def find_by(term_details=[]):
        filter_queries = []

        for term_detail in term_details:
            filter_queries.append(Q('term', **term_detail))

        query = Q('bool',
                  # TODO: codesmell
                  filter=filter_queries
                  )

        search = ExternalArticle.search().query(query)
        search = search.sort("-published_at")

        try:
            items = search.execute()
            return ExternalArticle.response(items)

        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def find_by_id(uuid):
        try:
            item = ExternalArticle.get(uuid)
            return ExternalArticle.response([item])

        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: ", e)
            response.status = 400
            return {"success": False, "error": "An error has occurred."}


    @staticmethod
    def response(articles):
        """
        Return a response dictionary to be used by CherryPy
        :param articles: The response from an Elasticsearch DSL search
        :type articles: elasticsearch_dsl.response.Response
        :return: A dictionary with articles indicating a successful response
        from CherryPy
        :rtype: dict
        """
        articles_list = []
        [articles_list.append(article.__dict__['_d_']) for article in articles]
        return {"success": True,
                "articles": normalize_article(articles_list)}
