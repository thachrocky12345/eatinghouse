import math
import requests
import time

from elasticsearch_dsl import DocType, Date, Nested, Long, Object, Boolean, \
  InnerObjectWrapper
from elasticsearch import ElasticsearchException
from requests import request

from es_default_text import ESDefaultText
from elasticsearch_dsl import Q
from elasticsearch_dsl import A
# from elasticsearch_dsl import Document

import traceback
from datetime import datetime
from bottle import response
from sbt_common import SbtCommon
from article_utils import ArticleHelper, ArticleQueryHelper
import simplejson as json
from bs4 import BeautifulSoup
from up_accessor import UserProfileType

sbt_common = SbtCommon()
logger = sbt_common.get_logger()

article_query_helper = ArticleQueryHelper()


class Paragraph(InnerObjectWrapper):
  pass


class Symbol(InnerObjectWrapper):
  pass


class Educational(DocType):
  analysts = ESDefaultText()
  categories = ESDefaultText()
  content = ESDefaultText()
  contentText = ESDefaultText()
  createdAt = Date()
  createdAtWeekday = Long()
  defaultAnalyst = ESDefaultText()
  defaultCategory = ESDefaultText()
  defaultPublication = Object(properties={'level': Long(),
                                          'publicationCode': ESDefaultText()})
  excerpt = ESDefaultText()
  extraFeature = Boolean()
  imageUrl = ESDefaultText()
  long_description = ESDefaultText()
  oid = ESDefaultText()
  order = Long()
  modifiedAt = Date()
  base_type = ESDefaultText()
  sub_types = ESDefaultText()
  paragraphs = Nested(
    doc_class=Paragraph,
    properties={'content': ESDefaultText(), 'contentText': ESDefaultText(),
                'tickers': ESDefaultText()}
  )
  pdfOnly = Boolean()
  pdfUrl = ESDefaultText()
  public = Boolean()
  publications = Object(properties={'level': Long(),
                                    'publicationCode': ESDefaultText()})
  short_description = ESDefaultText()
  slug = ESDefaultText()
  stansberry_action = ESDefaultText()
  status = ESDefaultText()
  symbols = Nested(
    doc_class=Symbol,
    properties={'symbol': ESDefaultText(), 'analysis': ESDefaultText(),
                'top_recommended': Boolean(), 'best_buy': Boolean(),
                'initiated': Boolean(), 'closed': Boolean()})
  tickers = ESDefaultText()
  tickersText = ESDefaultText()
  title = ESDefaultText()
  type = ESDefaultText()
  wordpressId = Long()

  class Meta:
    index = 'educational'
    doc_type = '_doc'

  @staticmethod
  def valid_status(article):
    """
      Checks whether a 'status' key is present in an article and if it is,
      its value is not set to "trash" or "draft"
      :type article: JSON
      :param article: The article to check
      :rtype: bool
      :return: True if 'status' key is in not in the article. If it is, then
      its value is not set to 'trash'
      """
    invalid_statuses = ["trash"]
    if 'status' in article:
      return article['status'] not in invalid_statuses
    return True

  @staticmethod
  def is_newswire(article):
    publication = article.get('defaultPublication', {})

    if isinstance(publication, dict) \
      and publication.get('publicationCode', '') == 'new':
        return True
    else:
      return False

  @staticmethod
  def is_newsletter(article):
    category = article.get('defaultCategory', '')

    if category in ['newsletters_weekly', 'newsletters_monthly',
                    'newsletters_daily', 'updates']:
                      return True
    else:
      return False


  @staticmethod
  def valid_article(article):
    """
    A helper function to determine whether an article should be indexed into
    Elasticsearch. This function follows on from the helper validity checking
    in the sbcontent_manager
    :type article: JSON
    :param article: The article that will be checked
    :rtype: bool
    :return: True if the 'status' field is not set to 'draft'.
    """
    logger.info(
      "Checking whether the article is valid or invalid for insertion into "
      "Elasticsearch")
    invalid_statues = ['draft', 'trash']
    if 'status' in article and article['status'] in invalid_statues:
      logger.info(
        "The article is invalid for insertion into Elasticsearch. Its status is"
        " {0}.".format(article['status']))
      return False
    logger.info("The article is valid for insertion into Elasticsearch.")
    return True

  @staticmethod
  def get_standard_content(article):
    """
    Return the relevant fields that will be needed for the Front-end
    :param article: The article from which the field values will be taken
    :type article: Union[elasticsearch_dsl.response.hit.Hit, dict]
    :return: The dictionary of fields that will be needed for display on the
     Front-end
    :rtype: dict
    """
    item = {'analysts': list(article.analysts) if
            hasattr(article, 'analysts') else [],
            'content': getattr(article, 'content', ''),
            # 'contentText': getattr(article, 'contentText', ''),
            'contentText': '',
            'excerpt': getattr(article, 'excerpt', ''),
            'createdAt': getattr(article, 'createdAt', ''),
            'modifiedAt': getattr(article, 'modifiedAt', ''),
            'title': getattr(article, 'title', ''),
            'wordpressId': getattr(article, 'wordpressId'),
            'category': getattr(article, 'defaultCategory', ''),
            'pdfOnly': getattr(article, 'pdfOnly', False),
            'pdfUrl': getattr(article, 'pdfUrl', ''),
            'publication': article.defaultPublication.to_dict() if
            hasattr(article, 'defaultPublication') else {},
            'symbols': [],
            'tickers': list(article.tickers) if
            hasattr(article, 'tickers') else []}
    epoch = datetime.utcfromtimestamp(0)
    item['modifiedAt'] = (item['modifiedAt'] - epoch).total_seconds() * 1000.0
    item['createdAt']  = (item['createdAt']  - epoch).total_seconds() * 1000.0

    # populate the symbols array
    if hasattr(article, 'symbols'):
      for symbol in article.symbols:
        sdict = symbol if isinstance(symbol, dict) else symbol.to_dict()
        item['symbols'].append(sdict)
    else:
      logger.debug('No symbols present on ES article')

    return item

  @staticmethod
  def get_standard_content_from_dict(article):
    """
    Return the relevant fields that will be needed for the Front-end
    :param article: The article from which the field values will be taken
    :type article: Union[elasticsearch_dsl.response.hit.Hit, dict]
    :return: The dictionary of fields that will be needed for display on the
     Front-end
    :rtype: dict
    """
    item = {'analysts' : article.get('analysts', []),
            'symbols' : article.get('symbols', []),
            'content': article.get('content'),
            # 'contentText': article.get('contentText'),
            'contentText': '',
            'excerpt': article.get('excerpt'),
            'createdAt': article.get('createdAt'),
            'modifiedAt': article.get('modifiedAt'),
            'title': article.get('title'),
            'wordpressId': article.get('wordpressId'),
            'category': article.get('defaultCategory'),
            'pdfOnly': article.get('pdfOnly'),
            'pdfUrl': article.get('pdfUrl'),
            'publication': article.get('defaultPublication'),
            'tickers': article.get('tickers')}
    return item

  @staticmethod
  def get_description(article):
    return {'short_description': getattr(article, 'short_description', ''),
            'long_description': getattr(article, 'long_description', ''),
            'title': getattr(article, 'title', ''),
            'stansberry_action': getattr(article, 'stansberry_action', ''),
            'statistics': getattr(article, 'statistics', ''),
            'chart': getattr(article, 'chart', ''),
            'profile_type': getattr(article, 'profile_type', ''),
            'original_recommendation_url': getattr(article,
                                                   'original_recommendation_url'
                                                   , ''),
            'snapshot': getattr(article, 'snapshot', '')}

  @staticmethod
  def get_bullets(article):
    bullets = getattr(article, 'contentText', '').splitlines()
    bullets = list(filter(None, bullets))

    return {'bullets_html': getattr(article, 'content', ''),
            'bullets_list': bullets}


  @staticmethod
  def response(articles):
    """
    Return a response dictionary to be used by CherryPy
    :param articles: The response from an Elasticsearch DSL search
    :type articles: elasticsearch_dsl.response.Response
    :return: A dictionary with articles indicating a successful response
    from CherryPy
    :rtype: dict
    """
    return {"success": True, "articles":
            Educational.process_standard_articles(articles)}

  @staticmethod
  def response_from_dict(article):
    return {"success": True, "article":
            Educational.get_standard_content_from_dict(article)}

  @staticmethod
  def process_standard_articles(articles):
    return [Educational.get_standard_content(article) for article in articles]

  @staticmethod
  def process_description_articles(articles):
    return [Educational.get_description(article) for article in articles]

  @staticmethod
  def process_bullet_articles(articles):
    res = []
    for article in articles:
      item = Educational.get_bullets(article)
      res.append(item)
    return res

  @staticmethod
  def paragraphs_response(articles):
    res = []
    base_url = "https://members.stansberryresearch.com/post/"
    logger.info("Length of articles:" + str(len(articles)))

    for i in range(len(articles)):
      article = articles[i]
      try:
        article_id = str(article.wordpressId)
      except AttributeError:
        logger.warning(
          "SBContentManager: Article is missing a wordpressId: " +
          repr(article))
        continue
      logger.info(
        "SBContentManager: Retrieving paragraphs for article with ID {0}."
        .format(article_id))
      article_url = base_url + article_id
      item = {'title': getattr(article, 'title', ''), 'url': article_url,
              'createdAt': getattr(article, 'createdAt', ''),
              'modifiedAt': getattr(article, 'modifiedAt', ''),
              'paragraphs': [], 'wordpressId': article_id,
              'excerpt': getattr(article, 'excerpt', ''),
              'category': getattr(article, 'defaultCategory', ''),
              'pdfOnly': getattr(article, 'pdfOnly', False),
              'pdfUrl': getattr(article, 'pdfUrl', ''),
              'publication': article.defaultPublication.to_dict() if
              hasattr(article, 'defaultPublication') else {},
              'tickers': list(article.tickers) if
              hasattr(article, 'tickers') else []}
      epoch = datetime.utcfromtimestamp(0)
      item['modifiedAt'] = (item['modifiedAt'] - epoch).total_seconds() * 1000.0
      item['createdAt']  = (item['createdAt']  - epoch).total_seconds() * 1000.0
      for paragraph in article.meta.inner_hits.paragraphs:
        item['paragraphs'].append(paragraph.to_dict())

      res.append(item)
    return {"success": True, "articles": res}

  @staticmethod
  def find(user_entitlements=[], paging={}, analysts=[], publications=[],
           symbols=[], types=[], start_date_epoch=0):
    """
    Search for articles based on core parameters
    :param user_entitlements: array of level-pubcode slugs i.e. 100-dig
    :param paging: dict of paging data
    :param analysts: array of analyst slugs
    :param publications: array of publication codes
    :param symbols: array of ticker symbols
    :param types: array of article types
    :param start_date_epoch: integer
    :rtype: list
    :return:
    """
    # TODO: Steve Finish method documentation
    filter_queries = []

    if start_date_epoch > 0:
      start_date_epoch_ms = start_date_epoch * 1000
      print(start_date_epoch_ms)
      filter_queries.append(Q("range",
                              createdAt={"gte": start_date_epoch_ms,
                                         "format": "epoch_millis"}))

    if len(types) > 0:
      filter_queries.append(Q('terms', base_type=types))
    else:
      filter_queries.append(Q('terms', base_type=['newswire',
                                                  'newsletter']))

    # Add user entitlements filter query
    ArticleQueryHelper.add_entitlements_filter(filter_queries,
                                               user_entitlements)

    # Add analysts filter
    if len(analysts) > 0:
      filter_queries.append(Q('terms', **{'analysts': analysts}))

    # Add symbols filter
    if len(symbols) > 0:
      filter_queries.append(Q('terms', **{'tickers': symbols}))

    # Add publications filter
    if len(publications) > 0:
      filter_queries.append(Q('terms',
                              **{'defaultPublication.publicationCode':
                                 publications}))

    query = Q('bool',
              #TODO: codesmell
              must_not=[Q('match', **{
                'defaultPublication.publicationCode': 'XXX'})],
              filter=filter_queries)

    search = Educational.search().query(query)
    search = search.sort("-createdAt")
    search = search[paging['start']:paging['end']]

    try:
      items = search.execute()
      return Educational.response(items)
    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}

  # NOT IN USE
  # TODO: add to api gateway
  def get_by_wordpress_id(user_entitlements=[], wordpress_id=0):
    logger.info("get_by_wordpress_id called with wordpress_id({0})".format(wordpress_id))
    wordpress_id = str(wordpress_id)
    filter_query_list = [Q('term', **{'wordpressId': wordpress_id})]

    # Add user entitlements filter query
    ArticleQueryHelper.add_entitlements_filter(filter_query_list,
                                               user_entitlements)
    #TODO: remove fake filter
    exclude_newswire = 'xxx'
    query = Q('bool',
              must_not=[Q('term', **{
                'defaultPublication.publicationCode.keyword': exclude_newswire})
              ], filter=filter_query_list)
    search = Educational.search().query(query)
    search = search[0:1]

    try:
      items = search.execute()
      return Educational.response(items)
    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}


  @staticmethod
  def get_newsletters(user_entitlements=[], symbol=None, count=None, start_date=None):
    logger.info("get_newsletters called with symbol({0}), "
                "count({1}) and start_date({2})".format(symbol, count,
                                                        start_date))
    filter_query_list = []
    article_query_helper.add_symbol_filter(filter_query_list, symbol)
    article_query_helper.add_start_date_filter(filter_query_list, start_date)
    article_query_helper.add_newsletter_filter(filter_query_list)
    article_query_helper.add_entitlements_filter(filter_query_list,
                                               user_entitlements)
    # default
    # if symbol:
      # filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
    # if start_date:
      # filter_query_list.append(Q("range", createdAt={"gte": start_date,
                                                     # "format": "epoch_millis"}))
    exclude_newswire = 'new'
    query = Q('bool',
              must_not=[Q('term', **{
                'defaultPublication.publicationCode.keyword': exclude_newswire})
              ], filter=filter_query_list)
    search = Educational.search().query(query)
    search = search.sort("-createdAt")
    if count and isinstance(count, int):
      search = search[0:count]
    try:
      items = search.execute()
      return Educational.response(items)
    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}

  @staticmethod
  def get_articles(user_entitlements=[], symbol=None,
                   count=None, start_date=None, category=None):

    filter_query_list = []
    ArticleQueryHelper.add_article_categories_filter()
    ArticleQueryHelper.add_entitlements_filter(filter_query_list,
                                               user_entitlements)

    if symbol:
      filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
    if category:
      filter_query_list.append(Q('term', **{'defaultCategory.keyword': category
                                            }))
    if start_date:
      filter_query_list.append(Q("range", createdAt={"gte": start_date,
                                                     "format": "epoch_millis"}))
    query = Q('bool', filter=filter_query_list)
    search = Educational.search().query(query)
    search = search.sort("-createdAt")
    if count:
      search = search[0:count]
    try:
      items = search.execute()
      return Educational.response(items)
    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}

  @staticmethod
  def get_analyzed_newsletters(user_entitlements=[], symbol=None, res_count=5):
    """
    Searches for articles containing the symbols analysis field and or
    symbols top_recommended field
    :param user_entitlements: array of level-pubcode slugs i.e. 100-dig
    :param symbol: ticker symbol (i.e AAPL)
    :param res_count: total articles to return to the client
    :rtype: dict
    :return: response dictionary to be used by CherryPy
    """
    filter_query_list = []
    ArticleQueryHelper.add_newsletter_filter(filter_query_list)
    ArticleQueryHelper.add_entitlements_filter(filter_query_list,
                                               user_entitlements)

    # create clone of filters list for backup query
    backup_filter_list = filter_query_list.copy()
    backup_filter_list.append(Q('term', tickers__keyword=symbol))

    ### Backup queries (in case there's no results from the main query)
    backup_queries = [
      Q('bool',
        must_not=[Q('match', defaultPublication__publicationCode='TTT')],
        filter=backup_filter_list)
    ]

    ### Sorting order
    # (list of tuples => (symbols.analysis, symbols.top_recommended))
    sorting = [('recommended', True),
               ('recommended', False),
               ('analyzed', False),
               ('mentioned', False)]

    ### Main query
    # nested query for "symbols"
    q_list = [Q("match", symbols__symbol=symbol)]
    q = Q("bool", must=q_list)
    nested_query = Q("nested", path="symbols", query=q)
    # now filter results out by "categories"
    query = Q("bool", must=nested_query,
              filter=filter_query_list)
    try:
      # create search instance
      search = Educational.search().query(query)
      # sorting by time (the results will be sorted
      # by time within each sorting category listed
      # in the sorting list)
      search = search.sort("-createdAt")
      # return at most 1000 docs
      search = search[0:1000]
      # execute the search
      items = search.execute()

      # if the main query returns empty, run backup queries
      # as defined in the backup queries list
      counter = 0
      while len(items.hits.hits) < 5 and counter < len(backup_queries):
        logger.info("Running backup queries...")
        response = [Educational.search().query(q).execute()
                    for q in backup_queries][0]
        items.hits.hits.extend(response.hits.hits)
        counter += 1

      if len(items.hits.hits):
        res = []
        sorted_res = []
        # create a custom object to extract
        # info that will be used in the sorting process
        [[res.append({y.symbol: y.analysis,
                      'top_rec': y.top_recommended,
                      'doc': x})
          for y in x.symbols if y.symbol == symbol] for x in items]
        # sorting by the order that is defined in the sorting list
        [[sorted_res.append(x['doc']) for x in res if
          x[symbol] == r[0] and x['top_rec'] is r[1]] for r in sorting]
        result = Educational.response(sorted_res[0:res_count])
      else:
        # what to return in case we have no results?
        result = {"success": False, "error": "No results found."}

      return result

    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400

      return {"success": False, "error": "An error has occurred."}


  @staticmethod
  def get_paragraphs(symbol, start_date):
    query = Q('bool', filter=[Q("nested", path="paragraphs",
              query=Q("term", **{'paragraphs.tickers.keyword': symbol}),
              inner_hits={}), Q("range", createdAt={"gte": start_date,
                                                    "format": "epoch_millis"})])
    search = Educational.search().query(query)
    search = search.sort("-createdAt")
    try:
      items = search.execute()
      return Educational.paragraphs_response(items)

    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}

  @staticmethod
  def get_by_publication(user_entitlements, publication, symbol=None, count=None,
                         start_date=None):
    logger.info("get_by_publication called with publication({0}), symbol({1}), "
                "count({2}) and start_date({3})".format(publication, symbol,
                                                        count, start_date))

    article_categories = ArticleHelper.article_categories()
    filter_query_list = [Q('terms', categories=list(article_categories))]
    filter_query_list.append(Q('term', **{
                'defaultPublication.publicationCode.keyword': publication}))

    # Add user entitlements filter query
    ArticleQueryHelper.add_entitlements_filter(filter_query_list,
                                               user_entitlements)

    if symbol:
      filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
    if start_date:
      filter_query_list.append(Q("range", createdAt={"gte": start_date,
                                                     "format": "epoch_millis"}))
    query = Q('bool', filter=filter_query_list)
    search = Educational.search().query(query)
    search = search.sort("-createdAt")
    if count:
      search = search[0:count]
    logger.info(" FINAL QUERY: {}".format(search.to_dict()))
    try:
      items = search.execute()
      return Educational.response(items)
    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}

  @staticmethod
  def get_by_category(user_entitlements, symbol, category, start_date):
    article_categories = ArticleHelper.article_categories()

    # Return if not a valid article category
    if category not in article_categories:
      logger.info("SBContentManager: Invalid category '{0}' for article."
                  .format(category))
      return Educational.response([])

    filter_query_list = []

    # Add user entitlements filter query
    ArticleQueryHelper.add_entitlements_filter(filter_query_list,
                                               user_entitlements)

    filter_query_list.append(Q('terms', categories=article_categories))
    filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
    filter_query_list.append(Q('range',
                               createdAt={"gte": start_date,
                                          "format": "epoch_millis"}))

    query = Q('bool',filter=filter_query_list)
    search = Educational.search().query(query)
    search = search.sort("-createdAt")
    try:
      items = search.execute()
      return Educational.response(items)
    except ElasticsearchException as e:
      logger.exception("ElasticSearch exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}

  @staticmethod
  def get_relevant_results(req):
    if len(req['terms']) > 0:
      # fields to be used in the query
      fields_to_be_queried = ["title", "content", "contentText"]
      syn_list = ['recent', 'current', 'latest']
      terms = req['terms']
      terms_str = terms[0]
      # the page number the user's in
      page_number = req['pageNumber'] if 'pageNumber' in req else 1
      # number of results to display per page (default = 10)
      hits_per_page = req['resultsPerPage'] if 'resultsPerPage' in req else 10
      # determine the first and last indices to be returned
      start = (page_number - 1) * hits_per_page
      end = page_number * hits_per_page
      # flag to sort by date or set sort_by_date = False
      sort_by_date = req['sortByDate'] if 'sortByDate' in req else False
      sorting_message = "SORT BY DATE: {}"
      if not sort_by_date:
        sort_by_date = True \
          if sum([terms_str.lower().count(x.lower()) for x in syn_list]) > 0 \
          else False
        sorting_message = "SORT BY DATE (DETECTED KEYWORD IN SEARCH TERM): {}" \
          if sort_by_date else sorting_message
        # removing useless terms
        terms_str = " ".join([x for x in terms_str.lower().split()
                              if x not in syn_list])
        terms = [terms_str]
      logger.info(sorting_message.format(sort_by_date))
      # filter by authors or set authors = None
      authors = req['filterByAuthors'] \
        if ('filterByAuthors' in req and len(req['filterByAuthors']) > 0) \
        else None
      # filter by publications or ser publications = None
      publications = req['filterByPubs'] \
        if ('filterByPubs' in req and len(req['filterByPubs']) > 0) \
        else None

      ###
      # BUILD ES QUERY
      ###
      must_list = []
      should_list = []
      filter_must_list = []
      filter_should_list = []

      # compound query components
      # MUST
      must_list.append(Q("multi_match",
                          query=terms[0],
                          fields=fields_to_be_queried))

      # SHOULD
      should_list.append(Q("multi_match",
                           query=terms[0],
                           fields=fields_to_be_queried,
                           type="phrase", boost=10, slop=10))
      should_list.append(Q("multi_match",
                           query=terms[0],
                           fields=fields_to_be_queried,
                           operator="and", boost=4))

      # FILTER
      if authors:
        # filter by authors
        filter_must_list.append(Q("terms", analysts=authors))

      # add entitlements filter
      # ArticleQueryHelper.add_entitlements_filter(filter_must_list,
      #                                            user_entitlements)

      # # apply time restriction for free users
      # if user_profile['user_profile_type_id'] != UserProfileType.STANSBERRY_USER.value:
      #   ArticleQueryHelper.add_date_restriction_filter(filter_must_list)

      if publications:
        # filter by publications
        # (using SHOULD because we have to search multiple fields for this)
        filter_should_list.append(Q("terms", categories=publications))
        filter_should_list.append(
                Q("terms", publications__publicationCode__keyword=publications))

      filter_list = Q('bool', must=filter_must_list, should=filter_should_list)


      ###
      # BUILD COMPOUND QUERY
      ###
      query = Q('bool', must=must_list, should=should_list, filter=filter_list)

      # add pagination
      # give 'em only what's needed
      list_of_attributes = req['requiredFields'] \
        if 'requiredFields' in req and len(req['requiredFields']) > 0 else ['*']
      s = Educational.search().source(fields=list_of_attributes)[start:end]
      # add query to search instance
      s = s.query(query)

      # SORT by date or relevance
      s = s.sort('-createdAt') if sort_by_date else s

      # HIGHLIGHT the occurrences of the terms in the query
      # rank the results by relevance and apply custom tag for highlighting
      s = s.highlight_options(order='score')
      # fragment_size = 0 makes sure we are not spliting sentence
      # number_of_fragmanets = 5 gives us the top 5 most relevant paragraphs
      s = s.highlight('content',
                      fragment_size=0,
                      number_of_fragments=5,
                      pre_tags=[""],
                      post_tags=[""])
      s = s.highlight('contentText',
                      fragment_size=0,
                      number_of_fragments=5,
                      pre_tags=["<div class=\"highlight_spl_style\""],
                      post_tags=["</div>"])

      logger.info("FINAL QUERY: {}".format(s.to_dict()))

      # execute the query
      items = s.execute()

      try:
        # serializing response object into dict
        hits = items.to_dict()['hits']
        # this fixes JSON serialization issues with
        # custom types created by the Articles class
        # (e.g. InnerObjectWrapper, Paragraphs)
        items_to_serialize = ['publications', 'paragraphs', 'symbols']
        for item in items_to_serialize:
          for i, x in enumerate(hits['hits']):
            if item in x['_source']:
              for j, y in enumerate(x['_source'][item]):
                hits['hits'][i]['_source'][item][j] = y
        # serialize dict into JSON object
        rval = json.loads(json.dumps(hits))
        logger.info('TOTAL HITS: {}'.format(rval['total']))
        # return JSON object to the caller
        return rval

      except ElasticsearchException as e:
        logger.exception("Search exception: " + str(e))
        response.status = 400
        return {"success": False, "error": "An error has occurred."}
    else:
      return {"success": False, "error": "No search term has been provided."}

  @staticmethod
  def sort_paragraphs(req):
    pass

  @staticmethod
  def get_relevant_results_for_suggestions(req):
    terms = req['terms']
    # build ES query
    query_list = []
    [query_list.append(Q("match", contentText=term)) for term in terms]
    query = Q('bool', must=query_list)
    # execute ES query
    items = Educational.search().query(query).execute()
    try:
      # serializing response object into dict
      hits = items.to_dict()['hits']
      # this fixes JSON serialization issues with
      # custom types created by the elasticsearch_dsl lib
      # (e.g. InnerObject, Paragraphs)
      items_to_serialize = ['publications', 'paragraphs']
      for item in items_to_serialize:
        for i, x in enumerate(hits['hits']):
          if item in x['_source']:
            for j, y in enumerate(x['_source'][item]):
              hits['hits'][i]['_source'][item][j] = y
      # serialize dict into JSON object
      rval = json.loads(json.dumps(hits))
      logger.info(rval)
      # return JSON object to the caller
      return rval

    except ElasticsearchException as e:
      logger.exception("Search exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}


  @staticmethod
  def get_categories_for_educational():

    category_sequence = ['Investing Basics', 'Retirement Planning', 'Long-Term Investing', 'Income Investing',
                         'Risk Management', 'Speculating & Trading', 'Personal Finance']
    '''
    If categories are added, add them to this list ^. Reason: order had to be hard coded somewhere. Whether UI, ES
    documents attributes, or here. 
    '''
    category_map = list(range(len(category_sequence)))
    category_map_dict = dict()
    [category_map_dict.update({k: v}) for k, v in zip(category_sequence, category_map)]
    #category_map_dict = dict(zip(category_sequence, category_map)]
    required_fields = ['title', 'analysts', 'duplex']

    # field to be used as categories (aggs field)
    categories_field = "difficulty.keyword"
    # query categories (aggs) and return at most 100 top_hits for each bucket
    s = Educational.search()
    a = A('terms', field=categories_field, order={"_key": "asc"})
    b = A('top_hits', _source=required_fields, size=100)
    s.aggs.bucket('categories', a).bucket('documents', b)
    items = s.execute()
    try:
      '''
      rval = json.loads(json.dumps(
              [{x['key'].capitalize(): [y.to_dict()
                            for y in x['documents']['hits']['hits']]}
               for x in items.aggs['categories'].buckets]
      )) 
      '''
      data = []
      y=0
      for x in items.aggs['categories'].buckets:
         # DO NOT REMOVE data.append(x.to_dict())
         #!!! dict = {'key':x.key}

         data.append(x.to_dict()['documents']['hits'])
         #data.append(x.to_dict())

         data[y]['difficulty'] = x.key
         data[y]['sequence'] = category_map_dict.get(x.key)


        # data.insert(y, 'dict' data[y]['sequence'] = category_map_dict.get(x.key))
        #y+=1
         #y = category_map_dict.get(x.key)

         my_dict = {'key':x.key}
         #data.append(x.to_dict()['documents']['hits'])
         #data.append(x.to_dict())
         data[y]['difficulty'] = x.key
         #data.insert(y, 'dict')
         y+=1

      rval = json.loads(json.dumps(data))

      return rval
      # logger.info(rval)
    except ElasticsearchException as e:
      logger.exception("Search exception: " + str(e))
      response.status = 400
      return {"success": False, "error": "An error has occurred."}

  @staticmethod
  def get_docs_by_category(category):
    # field to be used as categories (aggs field)
    categories_field = "duplex.category.keyword"
    # query categories (aggs) and return at most 100 top_hits for each bucket
    #query = Q("match", **{categories_field: category})

    #now we are being fed a list

    # if len(category)==2: query = Q('bool', must=[Q('match', difficulty=category[0]),
    #                                              Q('match', difficulty=category[1])])
    # else: query = Q('bool', must=[Q('match', difficulty=category[0]),
    #                               Q('match', difficulty=category[1]),
    #                               Q('match', difficulty=category[2])])

    ###
    # TODO: fix the way we index the field in ES
    #
    category = ['Long-Term Investing' if 'Long' in category else x for x in category]
    category = [x if x != 'Speculating' else 'Speculating &' for x in category]

    category = list(set(category)) if 'Long-Term Investing' in category else category

    must_list = Q("match", **{categories_field: ' '.join(category)})
    query = Q('bool', must=must_list)

    s = Educational.search()[0:1000].query(query)
    items = s.execute()
    try:
      rval = json.loads(json.dumps(
              [x.to_dict() for x in items['hits']['hits']]
      ))
    except ElasticsearchException as e:
      logger.exception("Search exception: " + str(e))
      response.status = 400
      rval = {"success": False, "error": "An error has occurred."}

    return rval


  @staticmethod
  def get_doc(doc_id):
    doc = Educational.get(doc_id)
    rval = json.loads(json.dumps(doc.to_dict()))
    # logger.info(rval)
    return rval



