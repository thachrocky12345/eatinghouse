from elasticsearch_dsl import DocType
from elasticsearch import ElasticsearchException
from suggestion_mapping import SuggestionMapping
from bottle import response
from elasticsearch_dsl import Q
from sbt_common import SbtCommon
import traceback


class Suggestion(DocType):
    _usa_stock_exchanges = ['AMEX', 'BATS', 'ETF', 'NYSE', 'NSDQ',
                            'NSDQCM', 'NYSEARCA', 'OTC', 'OBB']
    separator = " - "
    sbt_common = SbtCommon()

    class Meta:
        index = 'suggestions'
        doc_type = 'suggestions'
        # mapping = SuggestionMapping(doc_type)

    @staticmethod
    def _response(records):
        return {"success": True, "result": Suggestion._process_standard_search(
            records)}

    @staticmethod
    def _responsetags(records):
        return {"success": True, "data": Suggestion._process_standard_search(
            records)}

    @staticmethod
    def _error_response(reason):
        return {"success": True, "error": reason}

    @staticmethod
    def get_suggestions(request_json):
        # minimum score to return
        min_score = 11
        # list of US exchanges
        us_exchange_list = ["NYSE", "NSDQ", "AMEX",
                            "BOX", "CBOE", "CBOT",
                            "CCX", "CME", "CHX",
                            "ICE", "MGEX", "NSX",
                            "NYMEX", "OCX", "PHLX",
                            "USFE", "BATS", "ETF",
                            "NSDQCM", "NYSEARCA", "BATS"
                            ]

        search = Suggestion.search()
        search_text = request_json.get("text", "").strip()
        search_exchange = request_json.get("exchange", "").strip()

        if not search_text:
            return Suggestion._error_response("Empty string passed.")

        query1 = Q("dis_max", queries=[
            Q("match", **{"entity_name.autocomplete": {"query": search_text,
                                                       "boost": 4}}),
            Q("match", **{"symbol.keyword": {"query": search_text, "boost": 10,
                                             "fuzziness": 1}}),
            Q("match",
              **{"symbol.autocomplete": {"query": search_text, "boost": 5}})
            # Q("match", **{"symbol_suggest": {"query": search_text, "boost": 2}})
        ])

        # prioritize US exchanges
        query2 = Q("terms",
                   **{"exchange.keyword": us_exchange_list, "boost": 10})

        # boost preferred stocks (if present)
        query3 = Q("wildcard", **{"symbol.keyword":
                                      {"value": "{}.PR*".format(search_text),
                                       "boost": 20}
                                  })

        filter1 = Q("term", **{"exchange.keyword": search_exchange})

        # concatenate queries
        should_list = [query1, query2, query3]
        filter_list = []

        # add exchange filter if needed
        if search_exchange:
            filter_list.append(filter1)

        query = Q("bool", should=should_list, filter=filter_list)

        search = search.query(query)
        # set minimum score value
        search = search.extra(min_score=min_score)
        if 'size' in request_json and request_json['size']:
            search = search[0:request_json['size']]

        try:
            items = search.execute()
            return Suggestion._response(items)
        except ElasticsearchException:
            response.status = 400
            return {"success": False, "error": traceback.format_exc()}

    @staticmethod
    def get_new_suggestions(request_json):
        # minimum score to return
        min_score = 11
        # list of US exchanges
        us_exchange_list = ["NYSE", "NSDQ", "AMEX",
                            "BOX", "CBOE", "CBOT",
                            "CCX", "CME", "CHX",
                            "ICE", "MGEX", "NSX",
                            "NYMEX", "OCX", "PHLX",
                            "USFE", "BATS", "ETF",
                            "NSDQCM", "NYSEARCA", "BATS"
                            ]

        search = Suggestion.search(index='test_new_suggestions_schema')
        search_text = request_json.get("text", "").strip().upper()
        search_exchange = request_json.get("exchange", "").strip()

        # return options only? (default: False)
        options_only = request_json.get("options_only", False)
        # include options in the results? (default: False)
        include_options = request_json.get("include_options", False)
        # additional support for options only
        side = request_json.get("side", False)
        expiration_date = request_json.get("expiration_date", False)
        strike_price = request_json.get("strike_price", False)

        if not search_text:
            return Suggestion._error_response("Empty string passed.")

        query1 = Q("dis_max", queries=[
            Q("match", **{"entity_name.autocomplete": {"query": search_text,
                                                       "boost": 4}}),
            Q("match", **{"symbol.keyword": {"query": search_text, "boost": 10,
                                             "fuzziness": 1}}),
            Q("match",
              **{"symbol.autocomplete": {"query": search_text, "boost": 5}}),
            # Q("match", **{"symbol_suggest": {"query": search_text, "boost": 2}})
        ])

        # prioritize US exchanges
        query2 = Q("terms",
                   **{"exchange.keyword": us_exchange_list, "boost": 10})

        # boost preferred stocks (if present)
        query3 = Q("wildcard", **{"symbol.keyword":
                                      {"value": "{}.PR*".format(search_text),
                                       "boost": 20}
                                  })

        # boost primary exchanges
        query4 = Q("match", **{"is_primary_exchange" :
                                   {"query": True,
                                    "boost": 5}
                               })

        filter_exchange = Q("term", **{"exchange.keyword": search_exchange})

        # concatenate queries
        should_list = [query1, query2, query3, query4]
        filter_list = []

        if not include_options:
            if options_only:
                # return options only
                must_list = [Q("match", **{"is_option": True})]

                # additional parameters valid for options only
                if side:
                    must_list.append(Q("match", **{"side.keyword": side.lower()}))
                if expiration_date:
                    must_list.append(Q("range",
                                       **{"expiration_date": {
                                           "gte": expiration_date.get("from"),
                                           "lte": expiration_date.get("to")
                                       }}))
                if strike_price:
                    must_list.append(Q("range",
                                       **{"strike_price": {
                                           "gte": strike_price.get("from"),
                                           "lte": strike_price.get("to")
                                       }}))
            else:
                # default: return stocks only (~Q() => must_not)
                must_list = [~Q("match", **{"is_option": True})]
        else:
            # no filtering at all (return both)
            must_list = []

        # # exclude options using query negation: ~Q() => must_not
        # must_list = [Q("match", **{"is_option": True})] \
        #     if options_only else \
        #     [~Q("match", **{"is_option": True})]

        # add exchange filter if needed
        if search_exchange:
            filter_list.append(filter_exchange)

        query = Q("bool", should=should_list, filter=filter_list, must=must_list)

        search = search.query(query)
        # set minimum score value
        search = search.extra(min_score=min_score)
        # limit search results to a maximum of 50 items
        if 'size' in request_json and request_json['size'] <= 50:
            search = search[0:request_json['size']]

        try:
            items = search.execute()
            # parse to dict
            result_list = [x.get('_source')
                           for x in items.to_dict().get('hits').get('hits')]
            return {"success": True, "result": result_list}
        except ElasticsearchException:
            response.status = 400
            return {"success": False, "error": traceback.format_exc()}

    @staticmethod
    def get_suggestions_tags(taglst, text, size=None):
        search = Suggestion.search()
        filter = False
        no_text = False
        if not text:
            query = Q("dis_max", queries=[Q("terms", **{'tags': taglst})])
            no_text = True
        elif len(taglst[0]) == 0:
            query = Q('dis_max', queries=[
                Q("match", **{'entity_name.autocomplete': text}),
                Q("match_phrase", **{'symbol.autocomplete': text}),
                Q("match", **{'symbol.keyword': text})])
        else:
            query = Q('dis_max', queries=[
                Q("match", **{'entity_name.autocomplete': text}),
                Q("match_phrase", **{'symbol.autocomplete': text}),
                Q("match", **{'symbol.keyword': text})])
            filter = True

        # if no_text:
        #   search = search.query(query).sort("entity_name", {'order': "desc"})
        # else:
        search = search.query(query)
        search = search[0:10000] if size is None else search[0:size]

        if filter:
            search = search.filter("terms", tags=taglst)

        # if 'size' in request_json and request_json['size']:
        #     search = search[0:request_json['size']]

        try:
            items = search.execute()
            responsetags = Suggestion._responsetags(items)
            if no_text:
                newlist = sorted(responsetags['data'], key=lambda k: k['text'])
                return {"success": responsetags['success'], 'data': newlist}
            else:
                return responsetags
        except ElasticsearchException as e:
            response.status = 400
            print(e)
            return {"success": False, "error": "Error Accessing Elasticsearch"}

    @staticmethod
    def get_new_suggestions_tags(taglst, text=None, size=None):
        search = Suggestion.search(index='test_new_suggestions_schema')
        filter = False
        if not text:
            query = Q("dis_max", queries=[Q("terms", **{'tags': taglst})])
        elif len(taglst[0]) == 0:
            query = Q('dis_max',
                      queries=[
                          Q("match", **{'entity_name.autocomplete': text}),
                          Q("match_phrase",
                            **{'symbol.autocomplete': text}),
                          Q("match", **{'symbol.keyword': text})])
        else:
            query = Q('dis_max',
                      queries=[
                          Q("match", **{'entity_name.autocomplete': text}),
                          Q("match_phrase",
                            **{'symbol.autocomplete': text}),
                          Q("match", **{'symbol.keyword': text})])
            filter = True

        # if no_text:
        #   search = search.query(query).sort("entity_name", {'order': "desc"})
        # else:
        search = search.query(query)
        search = search[0:10000] if size is None else search[0:size]

        if filter:
            search = search.filter("terms", tags=taglst)

        # if 'size' in request_json and request_json['size']:
        #     search = search[0:request_json['size']]

        try:
            items = search.execute()
            responsetags = [x.get('_source')
                            for x in items.to_dict().get('hits').get('hits')]
            # if no_text:
            newlist = sorted(responsetags, key=lambda k: k['entity_name'])
            return {"success": True, 'data': newlist}
            # else:
            #     return responsetags
        except ElasticsearchException as e:
            response.status = 400
            print(e)
            return {"success": False, "error": "Error Accessing Elasticsearch"}

    @staticmethod
    def _process_standard_search(records):
        res = []
        for record in records:
            try:
                res.append(Suggestion._get_standard_content(record))
            except AttributeError:
                Suggestion.sbt_common.logger.exception(
                    "Record is missing an expected attribute: " + str(record))

        return res

    @staticmethod
    def _get_standard_content(record):
        # try:
        #     tags = list(getattr(record, "tags"))
        # except:
        #     tags = ''
        item = {"text": getattr(record, "entity_name"),
                "id": getattr(getattr(record, "meta", ), "id"),
                "symbol": getattr(record, "symbol_suggest"),
                "category_guid": getattr(record, "category")[0]["guid"],
                "exchange": getattr(record, "exchange"),
                "guid": getattr(record, "guid"),
                "globalid": getattr(record,
                                    "globalid") if 'globalid' in record else '',
                "tags": list(
                    getattr(record, "tags")) if 'tags' in record else '',
                "entity_description": getattr(record, "entity_description")
                if 'entity_description' in record else '',
                "exchange_type": getattr(record, "exchange_type"),
                "source": getattr(record, "source")}

        # JIRA-3629 Need to add this for UI to filter out symbols
        # for MW that cannot be streamed.  If we add exchange country to
        # to the return object this can be made simpler/cleaner.
        if item.get('exchange_type', 'N/A').upper() == 'STOCK':
            if item.get('exchange', 'N/A') in Suggestion._usa_stock_exchanges:
                item['supports_streaming'] = True
            else:
                item['supports_streaming'] = False

        return item

    @staticmethod
    def _create_context(request_json):
        contexts = dict()
        if 'category' in request_json and request_json['category']:
            contexts["category"] = request_json['category']
            if 'sub_category' in request_json and request_json['sub_category']:
                contexts["category"] = contexts.get('category', "") + \
                                       Suggestion.separator + \
                                       request_json['sub_category']
            if 'data_type' in request_json and request_json['data_type']:
                contexts["category"] = contexts.get('category', "") + \
                                       Suggestion.separator + \
                                       request_json['data_type']
        return contexts

    # @staticmethod
    # def get_unique_item_by_symbol_exchange(symbol, exchange):
    #     search = Suggestion.search(index='test_new_suggestions_schema')
    #     query = [
    #         Q("match", **{"symbol.keyword": symbol}),
    #         Q("multi_match", **{
    #             "query": exchange,
    #             "fields": ["exchange.keyword", "exchange_id.keyword"]
    #         })
    #     ]
    #     query = Q("bool", must=query)
    #     search = search.query(query)
    #     try:
    #         items = search.execute()
    #         # parse to dict
    #         result_list = [x.get('_source')
    #                        for x in items.to_dict().get('hits').get('hits')]
    #         return {"success": True, "result": result_list}
    #     except ElasticsearchException:
    #         response.status = 400
    #         return {"success": False, "error": traceback.format_exc()}

    @staticmethod
    def get_unique_item(symbol=None, exchange=None, trading_item_id=None, options_only=False):
        search = Suggestion.search(index='test_new_suggestions_schema')
        should_query = []
        if trading_item_id is not None:
            query = [
                Q("match", **{"trading_item_id": trading_item_id})
            ]
        else:
            if exchange is None:
                # search by SYM and boost US-based or primary exchanges results
                # (excluding options)
                query = [
                    Q("multi_match", **{
                        "query": symbol,
                        "fields": ["symbol.keyword", "symbol_alias.keyword"]
                    })
                ]
                if options_only:
                    # return options only
                    query.append(Q("match", **{"is_option": True}))
                else:
                    # default: return stocks only (~Q() => must_not)
                    query.append(~Q("match", **{"is_option": True}))
                should_query.extend([
                    Q("match", **{"exchange_country.keyword":
                        {
                            "query": "USA",
                            "boost": 10
                        }
                    }),
                    Q("match", **{"is_primary_exchange":
                        {
                            "query": True,
                            "boost": 2
                        }
                    })
                ])
            else:
                # search by SYM+EXC
                query = [
                    Q("multi_match", **{
                        "query": symbol,
                        "fields": ["symbol.keyword", "symbol_alias.keyword"]
                    }),
                    Q("multi_match", **{
                        "query": exchange,
                        "fields": ["exchange.keyword",
                                   "exchange_id.keyword",
                                   "exchange_alias.keyword"]
                    })
                ]
        query = Q("bool", must=query, should=should_query)
        search = search.query(query)
        try:
            items = search.execute()
            # parse to dict
            result_list = [x.get('_source')
                           for x in items.to_dict().get('hits').get('hits')]
            # return only a single item (most relevant result)
            result_list = result_list[0] if len(result_list) >= 1 else []
            return {"success": True, "result": result_list}
        except ElasticsearchException:
            response.status = 400
            return {"success": False, "error": traceback.format_exc()}

    @staticmethod
    def get_primary_exchange_by_symbol(symbol):
        search = Suggestion.search(index='test_new_suggestions_schema')
        supported_country_list = ['USA', 'CAN']
        must_query = [
            Q("match", **{"symbol.keyword": symbol}),
            Q("match", **{"is_primary_exchange": True}),
            Q("terms", **{"exchange_country.keyword": supported_country_list})
        ]
        should_query = [
            Q("match", **{"exchange_country.keyword":
                {
                    "query": "USA",
                    "boost": 100
                }
            })
        ]
        query = Q("bool", must=must_query, should=should_query)
        search = search.query(query)
        try:
            items = search.execute()
            # parse to dict
            result_list = [x.get('_source')
                           for x in items.to_dict().get('hits').get('hits')]
            # return only the most relevant result as a list
            result_list = result_list[0]
            return {"success": True, "result": result_list}
        except ElasticsearchException:
            response.status = 400
            return {"success": False, "error": traceback.format_exc()}

    @staticmethod
    def get_items_by_company_id(company_id):
        search = Suggestion.search(index='test_new_suggestions_schema')
        query = [
            Q("match", **{"company_id": company_id})
        ]
        query = Q("bool", must=query)
        search = search.query(query)
        try:
            items = search.execute()
            # parse to dict
            result_list = [x.get('_source')
                           for x in items.to_dict().get('hits').get('hits')]
            return {"success": True, "result": result_list}
        except ElasticsearchException:
            response.status = 400
            return {"success": False, "error": traceback.format_exc()}
