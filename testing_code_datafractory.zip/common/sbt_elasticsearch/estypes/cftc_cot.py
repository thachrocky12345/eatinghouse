from elasticsearch_dsl import DocType
from elasticsearch import ElasticsearchException
from cftc_cot_mapping import CFTCCOTMapping
from bottle import response
from sbt_common import SbtCommon
import traceback


class CFTCCOT(DocType):
  sbtcommon = SbtCommon()

  class Meta:
    index = 'cftc'
    doc_type = 'cftc_cot'
    mapping = CFTCCOTMapping(doc_type)

  @staticmethod
  def response(records):
    return {"success": True, "suggestions":
            CFTCCOT.process_suggestions(records)}

  @staticmethod
  def process_suggestions(records):
    res = []
    suggestions = records.suggest.entity_name_suggestion
    for suggestion in suggestions:
      for option in suggestion.options:
        res.append({'text': option._source.entity_name, "id": option._id})
    return res

  @staticmethod
  def get_suggestions(text, category=None, sub_category=None, data_type=None,
                      size=None):
    contexts = dict()
    completion_dict = {'field': 'entity_name_suggest'}
    if category:
      contexts["category"] = category
    if sub_category:
      contexts["sub_category"] = sub_category
    if data_type:
      contexts["data_type"] = data_type
    if contexts:
      completion_dict["contexts"] = contexts
    if size:
      completion_dict["size"] = size
    search = CFTCCOT.search()
    search = search.suggest('entity_name_suggestion', text=text,
                            completion=completion_dict)
    print(search.to_dict())
    try:
      items = search.execute()
      return CFTCCOT.response(items)
    except ElasticsearchException:
      response.status = 400
      return {"success": False, "error": traceback.format_exc()}
