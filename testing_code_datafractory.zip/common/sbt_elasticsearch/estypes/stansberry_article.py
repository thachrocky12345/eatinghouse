from datetime import datetime

import simplejson as json
from bottle import response
from elasticsearch import ElasticsearchException
from elasticsearch_dsl import DocType, Date, Nested, Long, Object, Boolean, \
    InnerObjectWrapper
from elasticsearch_dsl import Q

from article_utils import ArticleHelper, ArticleQueryHelper
from es_default_text import ESDefaultText
from sbt_common import SbtCommon
from up_accessor import UserProfileType

sbt_common = SbtCommon()
logger = sbt_common.get_logger()

article_query_helper = ArticleQueryHelper()

# List of archived publications:
# Advanced Income: "btr"
# Bear Market Survival Program: "bsg"
# Bear Market Trader: "bmt"
# Global Contrarian: "glc"
# Income Alliance: "income-alliance"
# Phase 1 Investor: "p1i"
# Professional Speculator: "sps"
# Small Stock Specialist: "pst"
# Stansberry Alpha: "sal"
# Stansberry International: "sil"
# Stansberry Pro Trader: "pro"
# Stansberry Radio Premium: "srp"
# Stansberry Research Pro Trader: "shr"
# Stansberry Strategy Group: "ssg"
# The 12% Letter: "twp"
# The Crux: "crux"
# The Sunday Refresh: "tsr"
# True Income: "tin"
ARCHIVED_PUBLICATIONS = [
    "btr", "bsg", "bmt", "glc", "income-alliance", "p1i", "sps", "pst",
    "sal", "sil", "pro", "srp", "shr", "ssg", "twp", "crux", "tsr", "tin"
]


class Paragraph(InnerObjectWrapper):
    pass


class Symbol(InnerObjectWrapper):
    pass


class Article(DocType):
    analysts = ESDefaultText()
    categories = ESDefaultText()
    content = ESDefaultText()
    contentText = ESDefaultText()
    canonicalUrl = ESDefaultText()
    createdAt = Date()
    createdAtWeekday = Long()
    defaultAnalyst = ESDefaultText()
    defaultCategory = ESDefaultText()
    defaultPublication = Object(
        properties={
            'level': Long(),
            'publicationCode': ESDefaultText()
        }
    )
    excerpt = ESDefaultText()
    extraFeature = Boolean()
    imageUrl = ESDefaultText()
    long_description = ESDefaultText()
    oid = ESDefaultText()
    order = Long()
    modifiedAt = Date()
    base_type = ESDefaultText()
    sub_types = ESDefaultText()
    paragraphs = Nested(
        doc_class=Paragraph,
        properties={
            'content': ESDefaultText(),
            'contentText': ESDefaultText(),
            'tickers': ESDefaultText()}
    )
    pdfOnly = Boolean()
    pdfUrl = ESDefaultText()
    public = Boolean()
    publications = Object(
        properties={
            'level': Long(),
            'publicationCode': ESDefaultText()
        }
    )
    short_description = ESDefaultText()
    slug = ESDefaultText()
    stansberry_action = ESDefaultText()
    status = ESDefaultText()
    symbols = Nested(
        doc_class=Symbol,
        properties={
            'symbol': ESDefaultText(),
            'analysis': ESDefaultText(),
            'top_recommended': Boolean(),
            'best_buy': Boolean(),
            'initiated': Boolean(),
            'closed': Boolean()
        }
    )
    tickers = ESDefaultText()
    tickersText = ESDefaultText()
    title = ESDefaultText()
    type = ESDefaultText()
    wordpressId = Long()
    terminal_synopsis = ESDefaultText()
    terminal_action = ESDefaultText()
    terminal_author = ESDefaultText()
    terminal_image_url = ESDefaultText()
    terminal_title = ESDefaultText()
    terminal_top_article = Boolean()

    class Meta:
        index = 'articles'
        doc_type = 'articles'

    @staticmethod
    def valid_status(article):
        """
          Checks whether a 'status' key is present in an article and if it is,
          its value is not set to "trash" or "draft"
          :type article: JSON
          :param article: The article to check
          :rtype: bool
          :return: True if 'status' key is in not in the article.
          If it is, then its value is not set to 'trash'
          """
        invalid_statuses = ["trash"]
        if 'status' in article:
            return article['status'] not in invalid_statuses
        return True

    @staticmethod
    def is_newswire(article):
        publication = article.get('defaultPublication', {})

        if isinstance(publication, dict) \
                and publication.get('publicationCode', '') == 'new':
            return True
        else:
            return False

    @staticmethod
    def is_newsletter(article):
        category = article.get('defaultCategory', '')

        if category in ['newsletters_weekly', 'newsletters_monthly',
                        'newsletters_daily', 'updates']:
            return True
        else:
            return False

    @staticmethod
    def valid_article(article):
        """
        A helper function to determine whether an article should be indexed
        into Elasticsearch. This function follows on from the helper validity
        checking in the sbcontent_manager
        :type article: JSON
        :param article: The article that will be checked
        :rtype: bool
        :return: True if the 'status' field is not set to 'draft'.
        """
        logger.info("Checking whether the article is valid or invalid for "
                    "insertion into Elasticsearch")
        invalid_statues = ['draft', 'trash']
        if 'status' in article and article['status'] in invalid_statues:
            logger.info("The article is invalid for insertion into "
                        "Elasticsearch. Its status is"" {0}."
                        .format(article['status']))
            return False
        logger.info("The article is valid for insertion into Elasticsearch.")
        return True


    @staticmethod
    def get_standard_content(article, full_content=False):
        """
        Return the relevant fields that will be needed for the Front-end
        :param article: The article from which the field values will be taken
        :type article: Union[elasticsearch_dsl.response.hit.Hit, dict]
        :return: The dictionary of fields that will be needed for display on
        the Front-end
        :rtype: dict
        """
        item = {'analysts': list(article.analysts) if hasattr(article,
                                                              'analysts'
                                                              ) else [],
                'content': getattr(article, 'content', '') if full_content else '',
                'canonicalUrl': getattr(article, 'canonicalUrl', ''),
                'contentText': '',
                'excerpt': getattr(article, 'excerpt', ''),
                'createdAt': getattr(article, 'createdAt', ''),
                'modifiedAt': getattr(article, 'modifiedAt', ''),
                'title': getattr(article, 'title', ''),
                'slug': getattr(article, 'slug', ''),
                'wordpressId': getattr(article, 'wordpressId'),
                'category': getattr(article, 'defaultCategory', ''),
                'pdfOnly': getattr(article, 'pdfOnly', False),
                'pdfUrl': getattr(article, 'pdfUrl', ''),
                'publication': article.defaultPublication.to_dict() if
                hasattr(article, 'defaultPublication') else {},
                'symbols': [],
                'synopsis': getattr(article, 'terminal_synopsis', ''),
                'synopsis_action': getattr(article, 'terminal_action', ''),
                'synopsis_author': getattr(article, 'terminal_author', ''),
                'synopsis_title': getattr(article, 'terminal_title', ''),
                'imageUrl': getattr(article, 'terminal_image_url', ''),
                'tickers': list(article.tickers) if
                hasattr(article, 'tickers') else [],
                'teaser_content': []
                }
        epoch = datetime.utcfromtimestamp(0)
        item['modifiedAt'] = (item['modifiedAt']
                              - epoch).total_seconds() * 1000.0
        item['createdAt'] = (item['createdAt']
                             - epoch).total_seconds() * 1000.0

        # populate the symbols array
        if hasattr(article, 'symbols'):
            for symbol in article.symbols:
                sdict = symbol if isinstance(symbol,
                                             dict) else symbol.to_dict()
                item['symbols'].append(sdict)
        else:
            logger.debug('No symbols present on ES article')

        if hasattr(article, 'extracted_paragraphs'):
            ext_paras = getattr(article, 'extracted_paragraphs')
            for para in ext_paras[:2]:
                item['teaser_content'].append(para)

        return item

    @staticmethod
    def get_standard_content_from_dict(article):
        """
        Return the relevant fields that will be needed for the Front-end
        :param article: The article from which the field values will be taken
        :type article: Union[elasticsearch_dsl.response.hit.Hit, dict]
        :return: The dictionary of fields that will be needed for display on
        the Front-end
        :rtype: dict
        """
        item = {'analysts': article.get('analysts', []),
                'symbols': article.get('symbols', []),
                'content': article.get('content'),
                'canonicalUrl': getattr(article, 'canonicalUrl', ''),
                # 'contentText': article.get('contentText'),
                'contentText': '',
                'excerpt': article.get('excerpt'),
                'createdAt': article.get('createdAt'),
                'modifiedAt': article.get('modifiedAt'),
                'title': article.get('title'),
                'slug': article.get('slug', ''),
                'wordpressId': article.get('wordpressId'),
                'category': article.get('defaultCategory'),
                'pdfOnly': article.get('pdfOnly'),
                'pdfUrl': article.get('pdfUrl'),
                'publication': article.get('defaultPublication'),
                'synopsis': article.get('terminal_synopsis', ''),
                'synopsis_action': article.get('terminal_action', ''),
                'synopsis_author': article.get('terminal_author', ''),
                'synopsis_title': article.get('terminal_title', ''),
                'imageUrl': article.get('terminal_image_url', ''),
                'tickers': article.get('tickers')}
        return item

    @staticmethod
    def get_description(article):
        def _remove_description_text(text):
            rval = "\n".join(
                [x for x in text.split('\n')
                 if len(x.split(' ')) > 2
                 and x.lower() not in ['business description',
                                       'company profile',
                                       'company description']
                 ]
            )
            return rval

        temp_short_desc = getattr(article, 'excerpt', '')
        temp_long_desc = getattr(article, 'contentText', '')
        # remove first sentence that contains the title of the section
        # (e.g., "Business Description", "Company Description")
        short_desc = _remove_description_text(temp_short_desc)
        long_desc = _remove_description_text(temp_long_desc)

        return {'short_description': short_desc,
                'long_description': long_desc,
                'title': getattr(article, 'title', ''),
                'stansberry_action': getattr(article, 'stansberry_action', ''),
                'statistics': getattr(article, 'statistics', ''),
                'chart': getattr(article, 'chart', ''),
                'profile_type': getattr(article, 'profile_type', ''),
                'original_recommendation_url':
                    getattr(article, 'original_recommendation_url', ''),
                'snapshot': getattr(article, 'snapshot', '')}

    @staticmethod
    def get_bullets(article):
        bullets = getattr(article, 'contentText', '').splitlines()
        bullets = list(filter(None, bullets))

        return {'bullets_html': getattr(article, 'content', ''),
                'bullets_list': bullets}

    @staticmethod
    def response(articles, full_content=False):
        """
        Return a response dictionary to be used by CherryPy
        :param articles: The response from an Elasticsearch DSL search
        :param full_content: Boolean indication to add the complete content
        :return: A dictionary with articles
        :rtype: dict
        """
        return {"success": True,
                "articles": [Article.get_standard_content(article, full_content) for article in articles]}

    @staticmethod
    def response_from_dict(article):
        return {"success": True,
                "article": Article.get_standard_content_from_dict(article)}

    @staticmethod
    def process_description_articles(articles):
        return [Article.get_description(article) for article in articles]

    @staticmethod
    def process_bullet_articles(articles):
        res = []
        for article in articles:
            item = Article.get_bullets(article)
            res.append(item)
        return res

    @staticmethod
    def paragraphs_response(articles):
        res = []
        base_url = "https://members.stansberryresearch.com/post/"
        logger.info("Length of articles:" + str(len(articles)))

        for i in range(len(articles)):
            article = articles[i]
            try:
                article_id = str(article.wordpressId)
            except AttributeError:
                logger.warning(
                    "SBContentManager: Article is missing a wordpressId: " +
                    repr(article))
                continue
            logger.info("SBContentManager: Retrieving paragraphs for article "
                        "with ID {0}.".format(article_id))
            article_url = base_url + article_id
            item = {'title': getattr(article, 'title', ''), 'url': article_url,
                    'createdAt': getattr(article, 'createdAt', ''),
                    'modifiedAt': getattr(article, 'modifiedAt', ''),
                    'paragraphs': [], 'wordpressId': article_id,
                    'excerpt': getattr(article, 'excerpt', ''),
                    'category': getattr(article, 'defaultCategory', ''),
                    'pdfOnly': getattr(article, 'pdfOnly', False),
                    'pdfUrl': getattr(article, 'pdfUrl', ''),
                    'publication': article.defaultPublication.to_dict() if
                    hasattr(article, 'defaultPublication') else {},
                    'tickers': list(article.tickers) if
                    hasattr(article, 'tickers') else []}
            epoch = datetime.utcfromtimestamp(0)
            item['modifiedAt'] = (item['modifiedAt']
                                  - epoch).total_seconds() * 1000.0
            item['createdAt'] = (item['createdAt']
                                 - epoch).total_seconds() * 1000.0
            for paragraph in article.meta.inner_hits.paragraphs:
                item['paragraphs'].append(paragraph.to_dict())

            res.append(item)
        return {"success": True, "articles": res}

    @staticmethod
    def counts(filters):
      filter = Q('terms', **filters)
      query = Q('bool',
                filter=filter
                )

      count = Article.search().query(query)
      try:
          counts = count.count()
          return counts
      except ElasticsearchException as e:
          logger.exception("ElasticSearch exception: " + str(e))
          response.status = 400
          return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def find_with_keywords(symbols, types=['newswire', 'newsletter'], paging={'start': 0, 'count': 2, 'end': 2}):

        filter_queries = []
        symbols = [symbol.upper() for symbol in symbols]

        if len(types) > 0:
            filter_queries.append(Q('terms', base_type=types))

        # Add symbols filter
        if len(symbols) > 0:
            filter_queries.append(Q('terms', **{'tickers.keyword': symbols}))

        query = Q('bool',
                  filter=filter_queries
                  )

        search = Article.search().query(query)
        search = search.sort("-createdAt")
        search = search[paging['start']:paging['end']]

        try:
            items = search.execute()
            return Article.response(items)
        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    def find(user_entitlements=[], paging={}, analysts=[], publications=[],
             symbols=[], types=[], has_synopsis=False, start_date_epoch=0, collections=[], categories=[]):
        """
        Search for articles based on core parameters
        :param user_entitlements: array of level-pubcode slugs i.e. 100-dig
        :param paging: dict of paging data
        :param analysts: array of analyst slugs
        :param publications: array of publication codes
        :param symbols: array of ticker symbols
        :param types: array of article types
        :param has_synopsis: boolean only articles that have synopsis
        :param start_date_epoch: integer
        :rtype: list
        :return:
        """
        # TODO: Steve Finish method documentation
        filter_queries = []

        if start_date_epoch > 0:
            start_date_epoch_ms = start_date_epoch * 1000
            print(start_date_epoch_ms)
            filter_queries.append(Q("range",
                                    createdAt={"gte": start_date_epoch_ms,
                                               "format": "epoch_millis"}))

        if len(types) > 0:
            filter_queries.append(Q('terms', base_type=types))
        else:
            filter_queries.append(Q('terms', base_type=['newswire',
                                                        'newsletter']))

        # Add analysts filter
        if len(analysts) > 0:
            filter_queries.append(Q('terms', **{'analysts': analysts}))

        # Add collections filter
        if len(collections) > 0:
            # TOP_RECOMMENDATIONS
            if collections[0] == 'top_recommendations':
                must_list = [ Q("match", symbols__top_recommended=True) ]
                q = Q("bool", must=must_list)
                filter_queries.append(Q("nested", path="symbols", query=q))

        # Add symbols filter
        if len(symbols) > 0:
            filter_queries.append(Q('terms', **{'tickers': symbols}))

        # Add publications filter
        if len(publications) > 0:
            filter_queries.append(Q('terms', **{
                'defaultPublication.publicationCode.keyword': publications}))

        if has_synopsis is True:
            filter_queries.append(Q('exists', field='terminal_synopsis'))

        if len(categories) > 0:
            filter_queries.append( Q("terms", **{"categories.keyword": categories}))

        # Need to implement
        # if has_synopsis is False:
        #     filter_queries.append(Q('exists', field='terminal_synopsis'))

        query = Q('bool',
                  filter=filter_queries
                  )

        search = Article.search().query(query)
        search = search.sort("-createdAt")
        search = search[paging['start']:paging['end']]

        try:
            items = search.execute()
            return Article.response(items)
        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    def get_by_wordpress_id(wordpress_id):
        wordpress_id = str(wordpress_id)
        filter_query_list = [Q('term', **{'wordpressId': wordpress_id})]

        exclude_newswire = 'xxx'
        query = Q('bool',
                  must_not=[
                      Q('term',
                        **{'defaultPublication.publicationCode.keyword':
                            exclude_newswire}
                        )
                  ],
                  filter=filter_query_list
                  )
        search = Article.search().query(query)
        search = search[0:1]

        try:
            articles = search.execute()
            if len(articles) >= 1:
                return Article.get_standard_content(articles[0], True)
            else:
                return None

        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return None

    @staticmethod
    def get_newsletters(user_entitlements=[], symbol=None, count=None,
                        start_date=None):
        logger.info("get_newsletters called with symbol({0}), "
                    "count({1}) and start_date({2})".format(symbol,
                                                            count,
                                                            start_date)
                    )
        filter_query_list = []
        article_query_helper.add_symbol_filter(filter_query_list, symbol)
        article_query_helper.add_start_date_filter(filter_query_list,
                                                   start_date)
        article_query_helper.add_newsletter_filter(filter_query_list)
        # default
        # if symbol:
        # filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
        # if start_date:
        # filter_query_list.append(Q("range", createdAt={"gte": start_date,
        # "format": "epoch_millis"}))
        exclude_newswire = 'new'
        query = Q('bool',
                  must_not=[
                      Q('term',
                        **{'defaultPublication.publicationCode.keyword':
                            exclude_newswire}
                        )
                  ],
                  filter=filter_query_list)
        search = Article.search().query(query)
        search = search.sort("-createdAt")
        if count and isinstance(count, int):
            search = search[0:count]
        try:
            items = search.execute()
            return Article.response(items)
        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def get_articles(user_entitlements=[], symbol=None,
                     count=None, start_date=None, category=None):

        filter_query_list = []
        ArticleQueryHelper.add_article_categories_filter()

        if symbol:
            filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
        if category:
            filter_query_list.append(
                Q('term', **{'defaultCategory.keyword': category
                             }))
        if start_date:
            filter_query_list.append(Q("range",
                                       createdAt={
                                           "gte": start_date,
                                           "format": "epoch_millis"
                                       })
                                     )
        query = Q('bool', filter=filter_query_list)
        search = Article.search().query(query)
        search = search.sort("-createdAt")
        if count:
            search = search[0:count]
        try:
            items = search.execute()
            return Article.response(items)
        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}


    @staticmethod
    def get_top_articles():
        """
        """

        # TODO Move to dynamic articles
        top_filter_query_list = [Q('term',
                                   **{'terminal_top_article': True})]
        top_query = Q('bool', filter=top_filter_query_list)
        top_search = Article.search().query(top_query)
        top_search = top_search.sort("-createdAt")
        top_search = top_search[0:2]

        filter_query_list = [Q('terms',
                               **{'defaultPublication.publicationCode.keyword':
                                  ['sdw', 'empire-financial-daily', 'hwb', 'dig', 'tow', 'alt']})]
        query = Q('bool', filter=filter_query_list)
        search = Article.search().query(query)
        search = search.sort("-createdAt")
        search = search[0:2]

        sow_query = Q('bool', filter=[Q('terms',
                                        **{'defaultPublication.publicationCode.keyword':
                                           ['sow']})])
        sow_search = Article.search().query(sow_query)
        sow_search = sow_search.sort("-createdAt")
        sow_search = sow_search[0:1]

        try:
            top_items = top_search.execute()
            items = search.execute()
            sow_items = sow_search.execute()
            items = list(top_items) + list(sow_items) + list(items)
            items = items[:4]
            return Article.response(items)
        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}


    @staticmethod
    def get_analyzed_newsletters(user_entitlements=[], symbol=None,
                                 res_count=20):
        """
        Searches for articles containing the symbols analysis field and or
        symbols top_recommended field
        :param user_entitlements: array of level-pubcode slugs i.e. 100-dig
        :param symbol: ticker symbol (i.e AAPL)
        :param res_count: total articles to return to the client
        :rtype: dict
        :return: response dictionary to be used by CherryPy
        """
        filter_query_list = []
        ArticleQueryHelper.add_newsletter_filter(filter_query_list)

        # create clone of filters list for backup query
        backup_filter_list = filter_query_list.copy()
        backup_filter_list.append(Q('term', tickers__keyword=symbol))

        # ## Backup queries (in case there's no results from the main query)
        backup_queries = [
            Q('bool',
              must_not=[Q('match', defaultPublication__publicationCode='TTT')],
              filter=backup_filter_list)
        ]

        # ## Sorting order
        # (list of tuples => (symbols.analysis, symbols.top_recommended))
        sorting = [('recommended', True),
                   ('recommended', False),
                   ('analyzed', False),
                   ('mentioned', False)]

        # ## Main query
        # nested query for "symbols"
        q_list = [Q("match", symbols__symbol=symbol)]
        q = Q("bool", must=q_list)
        nested_query = Q("nested", path="symbols", query=q)
        # now filter results out by "categories"
        query = Q("bool", must=nested_query,
                  filter=filter_query_list)
        try:
            response.status = 200
            # create search instance
            search = Article.search().query(query)
            # sorting by time (the results will be sorted
            # by time within each sorting category listed
            # in the sorting list)
            search = search.sort("-createdAt")
            # return at most 1000 docs
            search = search[0:1000]
            # execute the search
            items = search.execute()

            # if the main query returns empty, run backup queries
            # as defined in the backup queries list
            counter = 0
            while len(items.hits.hits) < res_count and counter < len(
                    backup_queries):
                logger.info("Running backup queries...")
                bkp_response = [Article.search().query(q).execute()
                                for q in backup_queries][0]
                items.hits.hits.extend(bkp_response.hits.hits)
                counter += 1

            res = []
            sorted_res = []
            # create a custom object to extract
            # info that will be used in the sorting process
            [[res.append({y.symbol: y.analysis,
                          'top_rec': y.top_recommended,
                          'doc': x})
              for y in x.symbols if y.symbol == symbol] for x in items]
            # sorting by the order that is defined in the sorting list
            [[sorted_res.append(x['doc']) for x in res if
              x[symbol] == r[0] and x['top_rec'] is r[1]] for r in sorting]
            result = Article.response(sorted_res[0:res_count])

            return result

        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400

            return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def get_recommended_newsletters(user_entitlements=None, symbol=None):
        """
        Searches for articles containing the symbols analysis field and or
        symbols top_recommended field
        :param user_entitlements: array of level-pubcode slugs i.e. 100-dig
        :param symbol: ticker symbol (i.e AAPL)
        :rtype: dict
        :return: response dictionary to be used by CherryPy
        """
        filter_query_list = []
        ArticleQueryHelper.add_newsletter_filter(filter_query_list)

        # create clone of filters list for backup query
        backup_filter_list = filter_query_list.copy()
        backup_filter_list.append(Q('term', tickers__keyword=symbol))

        # ## Main query
        # nested query for "symbols" that are recommended and/or
        # top_recommended
        must_list = [
            Q("match", symbols__symbol=symbol),
            Q("match", symbols__analysis='recommended')
        ]
        should_list = [
            Q("match", symbols__top_recommended=True)
        ]
        q = Q("bool", must=must_list, should=should_list)
        nested_query = Q("nested", path="symbols", query=q)
        # now filter results out by "categories"
        query = Q("bool", must=nested_query,
                  filter=filter_query_list)
        try:
            response.status = 200
            # create search instance
            search = Article.search().query(query)
            # sorting by time (the results will be sorted
            # by time within each sorting category listed
            # in the sorting list)
            search = search.sort("-createdAt")
            # return at most 1000 docs
            search = search[0:1000]
            # execute the search
            items = search.execute()

            # return the standard response WITHOUT content
            rval = Article.response(items)
            return rval

        except ElasticsearchException as e:
            response.status = 400
            rval = {"success": False,
                    "error": "An error has occurred: {}".format(e)}

        return rval

    @staticmethod
    def get_paragraphs(symbol, start_date):
        query = Q('bool', filter=[Q("nested",
                                    path="paragraphs",
                                    query=Q("term",
                                            **{'paragraphs.tickers.keyword':
                                                symbol}
                                            ),
                                    inner_hits={}),
                                  Q("range",
                                    createdAt={"gte": start_date,
                                               "format": "epoch_millis"}
                                    )
                                  ]
                  )
        search = Article.search().query(query)
        search = search.sort("-createdAt")
        try:
            items = search.execute()
            return Article.paragraphs_response(items)

        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def get_by_publication(user_entitlements, publication, symbol=None,
                           count=None,
                           start_date=None):
        logger.info(
            "get_by_publication called with publication({0}), symbol({1}), "
            "count({2}) and start_date({3})".format(publication, symbol,
                                                    count, start_date))

        article_categories = ArticleHelper.article_categories()
        filter_query_list = [Q('terms',
                                   categories=list(article_categories))]
        filter_query_list.append(
            Q('term',
              **{'defaultPublication.publicationCode.keyword': publication}
              )
        )

        if symbol:
            filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
        if start_date:
            filter_query_list.append(Q("range",
                                       createdAt={"gte": start_date,
                                                  "format": "epoch_millis"}
                                       )
                                     )
        query = Q('bool', filter=filter_query_list)
        search = Article.search().query(query)
        search = search.sort("-createdAt")
        if count:
            search = search[0:count]
        logger.info(" FINAL QUERY: {}".format(search.to_dict()))
        try:
            items = search.execute()
            return Article.response(items)
        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def get_by_category(user_entitlements, symbol, category, start_date):
        article_categories = ArticleHelper.article_categories()

        # Return if not a valid article category
        if category not in article_categories:
            logger.info("SBContentManager: Invalid category '{0}' for article."
                        .format(category))
            return Article.response([])

        filter_query_list = []
        filter_query_list.append(Q('terms', categories=article_categories))
        filter_query_list.append(Q('term', **{'tickers.keyword': symbol}))
        filter_query_list.append(Q('range',
                                   createdAt={"gte": start_date,
                                              "format": "epoch_millis"}))

        query = Q('bool', filter=filter_query_list)
        search = Article.search().query(query)
        search = search.sort("-createdAt")
        try:
            items = search.execute()
            return Article.response(items)
        except ElasticsearchException as e:
            logger.exception("ElasticSearch exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}

    @staticmethod
    def get_relevant_results(req, user_entitlements, user_profile):
        if len(req['terms']) > 0:
            # fields to be used in the query
            fields_to_be_queried = ["title", "content", "contentText"]
            syn_list = ['recent', 'current', 'latest']
            terms = req['terms']
            terms_str = terms[0]
            # the page number the user's in
            page_number = req['pageNumber'] if 'pageNumber' in req else 1
            # number of results to display per page (default = 10)
            hits_per_page = req[
                'resultsPerPage'] if 'resultsPerPage' in req else 10
            # determine the first and last indices to be returned
            start = (page_number - 1) * hits_per_page
            end = page_number * hits_per_page
            # flag to sort by date or set sort_by_date = False
            sort_by_date = req['sortByDate'] if 'sortByDate' in req else False
            sorting_message = "SORT BY DATE: {}"
            if not sort_by_date:
                sort_by_date = True if sum(
                    [terms_str.lower().count(x.lower()) for x in syn_list]
                ) > 0 else False
                sorting_message = "SORT BY DATE (DETECTED KEYWORD IN SEARCH " \
                                  "TERM): {}" \
                    if sort_by_date else sorting_message
                # removing useless terms
                terms_str = " ".join([x for x in terms_str.lower().split()
                                      if x not in syn_list])
                terms = [terms_str]
            logger.info(sorting_message.format(sort_by_date))
            # filter by authors or set authors = None
            authors = req['filterByAuthors'] \
                if ('filterByAuthors' in req
                    and len(req['filterByAuthors']) > 0) else None
            # filter by publications or ser publications = None
            publications = req['filterByPubs'] \
                if ('filterByPubs' in req
                    and len(req['filterByPubs']) > 0) else None

            ###
            # BUILD ES QUERY
            ###
            must_list = []
            should_list = []
            filter_must_list = []
            filter_should_list = []

            # compound query components
            # MUST
            must_list.append(Q("multi_match",
                               query=terms[0],
                               fields=fields_to_be_queried))

            # SHOULD
            should_list.append(Q("multi_match",
                                 query=terms[0],
                                 fields=fields_to_be_queried,
                                 type="phrase", boost=10, slop=10))
            should_list.append(Q("multi_match",
                                 query=terms[0],
                                 fields=fields_to_be_queried,
                                 operator="and", boost=4))

            # FILTER
            if authors:
                # filter by authors
                filter_must_list.append(Q("terms", analysts=authors))

            # apply time restriction for free users
            user_profile_type = 'user_profile_type' \
                if 'user_profile_type' in user_profile \
                else 'user_profile_type_id'
            user_profile_paid_type = UserProfileType.STANSBERRY_USER.name \
                if 'user_profile_type' in user_profile \
                else UserProfileType.STANSBERRY_USER.value
            user_status = user_profile.get(user_profile_type)
            if user_status != user_profile_paid_type:
                ArticleQueryHelper.add_date_restriction_filter(
                    filter_must_list
                )

            if publications:
                # filter by publications
                # (using SHOULD because we have to search
                # multiple fields for this)
                filter_should_list.append(Q("terms", categories=publications))
                filter_should_list.append(
                    Q("terms",
                      publications__publicationCode__keyword=publications))

            filter_list = Q('bool', must=filter_must_list,
                            should=filter_should_list)

            ###
            # BUILD COMPOUND QUERY
            ###
            query = Q('bool', must=must_list, should=should_list,
                      filter=filter_list)

            # add pagination
            # give 'em only what's needed
            list_of_attributes = req['requiredFields'] \
                if 'requiredFields' in req and len(
                req['requiredFields']) > 0 else ['*']
            s = Article.search().source(fields=list_of_attributes)[start:end]
            # add query to search instance
            s = s.query(query)

            # SORT by date or relevance
            s = s.sort('-createdAt') if sort_by_date else s

            # HIGHLIGHT the occurrences of the terms in the query
            # rank the results by relevance and apply
            # custom tag for highlighting
            s = s.highlight_options(order='score')
            # fragment_size = 0 makes sure we are not spliting sentence
            # number_of_fragmanets = 5 gives us the
            # top 5 most relevant paragraphs
            s = s.highlight('content',
                            fragment_size=0,
                            number_of_fragments=5,
                            pre_tags=[""],
                            post_tags=[""])
            s = s.highlight('contentText',
                            fragment_size=0,
                            number_of_fragments=5,
                            pre_tags=["<div class=\"highlight_spl_style\""],
                            post_tags=["</div>"])

            logger.info("FINAL QUERY: {}".format(s.to_dict()))

            # execute the query
            items = s.execute()

            try:
                # serializing response object into dict
                hits = items.to_dict()['hits']
                # this fixes JSON serialization issues with
                # custom types created by the Articles class
                # (e.g. InnerObjectWrapper, Paragraphs)
                items_to_serialize = ['publications', 'paragraphs', 'symbols']
                for item in items_to_serialize:
                    for i, x in enumerate(hits['hits']):
                        if item in x['_source']:
                            for j, y in enumerate(x['_source'][item]):
                                hits['hits'][i]['_source'][item][j] = y
                # serialize dict into JSON object
                rval = json.loads(json.dumps(hits))
                logger.info('TOTAL HITS: {}'.format(rval['total']))
                # return JSON object to the caller
                return rval

            except ElasticsearchException as e:
                logger.exception("Search exception: " + str(e))
                response.status = 400
                return {"success": False, "error": "An error has occurred."}
        else:
            return {"success": False,
                    "error": "No search term has been provided."}

    @staticmethod
    def sort_paragraphs(req):
        pass

    @staticmethod
    def get_relevant_results_for_suggestions(req):
        terms = req['terms']
        # build ES query
        query_list = []
        [query_list.append(Q("match", contentText=term)) for term in terms]
        # excluding archived publications
        query_list.append(~Q("terms", **{"publications.publicationCode": ARCHIVED_PUBLICATIONS}))
        query = Q('bool', must=query_list)
        # execute ES query
        items = Article.search().query(query).execute()
        try:
            # serializing response object into dict
            hits = items.to_dict()['hits']
            # this fixes JSON serialization issues with
            # custom types created by the elasticsearch_dsl lib
            # (e.g. InnerObject, Paragraphs)
            items_to_serialize = ['publications', 'paragraphs']
            for item in items_to_serialize:
                for i, x in enumerate(hits['hits']):
                    if item in x['_source']:
                        for j, y in enumerate(x['_source'][item]):
                            hits['hits'][i]['_source'][item][j] = y
            # serialize dict into JSON object
            rval = json.loads(json.dumps(hits))
            logger.info(rval)
            # return JSON object to the caller
            return rval

        except ElasticsearchException as e:
            logger.exception("Search exception: " + str(e))
            response.status = 400
            return {"success": False, "error": "An error has occurred."}
