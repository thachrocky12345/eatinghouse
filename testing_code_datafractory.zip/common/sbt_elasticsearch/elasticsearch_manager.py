import certifi
from elasticsearch_dsl import Q, Search, Index, analyzer
from elasticsearch_dsl.document import DocTypeMeta, DocType
from elasticsearch import Elasticsearch, ElasticsearchException
import logging
import json
import traceback
import os
from bottle import response
from sbt_common import SbtCommon

logger = logging.getLogger(__name__)


class ElasticsearchManager:
  """
  An Elasticsearch Manager for managing everything related to Elasticsearch.
  Queries can be generated and indices can be deleted/created, which can
  include estypes.
  Query options supported: sorting, pagination, filtering
  """

  def __init__(self, config_path=os.path.join(
    os.path.dirname(os.path.abspath(__file__)), 'utils/es_config.json'), conf=None):
    """
    Initialize an `ElasticSearchManager` object with host and port of the ES
    instance that will be connected to.
    :param config_path: The hostname/IP of the ES instance
    :type config_path: str
    """
    self.conf = conf
    self.__es = None
    self.__load_config(config_path)

  def __load_config(self, config_path):
    """
    Load a config file to setup the connection to an Elasticsearch Cluster
    :param config_path: A path for a config file with options for the
    Elasticsearch constructor
    :type config_path: str
    """
    if not self.conf:
      with open(config_path) as config_file:
        config = json.load(config_file)
    else:
      config = self.conf

    # check if we're running this locally
    is_local = bool(sum([1 for x in config['hosts'] if 'hosts' in config and 'localhost' in x]))

    config["verify_certs"] = config.get("verify_certs", False if is_local else True)
    self._es = Elasticsearch(**config, use_ssl=True,
                             ca_certs=False if is_local else certifi.where())

    logger.info("Connected to the ES cluster: {0}".format(self._es.info()))

  def initial_search(self, query=None, sort_field=None, index="articles",
                     doc_type=None):
    """
    An initial search object with an optional query and sort field included.
    :param query: A query object built using elasticsearch_dsl
    :type query: elasticsearch_dsl.query.Query
    :param sort_field: The field used to sort the search
    :type sort_field: str
    :param index: The name of the index to use
    :type index: str
    :param doc_type: The Elasticsearch DSL Type Object to search on
    :type doc_type: DocType
    :return: An Elasticsearch DSL search object
    :rtype: Search
    """
    logger.debug(
      "Initial search object being created for index {0}".format(index))
    search = doc_type.search(using=self._es) if doc_type else Search(
      using=self._es, index=index)
    if query:
      logger.debug("Initial query being added to search")
      search = search.query(query)
    if sort_field:
      search = ElasticsearchManager.sort(search, sort_field)

    return search

  def index(self, index, doc_type, body, doc_id=None, params=None):
    """
    Index a document into Elasticsearch

    :param index: The index where the document will be stored
    :type index: str
    :param doc_type: The type the document will be stored as
    :type doc_type: str
    :param body: The contents of the document that will be stored
    :type body: dict
    :param doc_id: The optional id used to store the document under, in
    Elasticsearch
    :type doc_id: str
    :param params: Includes the rest of the arguments defined here:
    https://sbt_elasticsearch-py.readthedocs.io/en/master/api.html#sbt_elasticsearch.Elasticsearch.index
    :type params: dict
    :return: A status response from the insertion
    """
    return self._es.index(index=index, doc_type=doc_type, body=body, id=doc_id,
                          params=params)

  def create_index(self, name, settings=None, custom_analyzer=None,
                   doc_type=None):
    """
    Creates and returns an index in Elasticsearch
    :param name: The name of the index to create
    :type name: str
    :param settings: A dictionary of index settings used in the creation of the
    index
    :type settings: dict
    :param custom_analyzer: A custom analyzer to be used within the index
    :type custom_analyzer: elasticsearch_dsl.analysis.CustomAnalyzer
    :param doc_type: A type or list of Elasticsearch types to be used
    :type doc_type: Union[DocTypeMeta, list]
    :return: An Elasticsearch DSL Index object
    :rtype: Index
    """
    index = Index(name, using=self._es)
    if settings:
      index.settings(**settings)
    if custom_analyzer:
      index.analyzer(custom_analyzer)
    if doc_type:
      if isinstance(doc_type, DocTypeMeta):
        logger.info("Adding single type")
        index = ElasticsearchManager.add_type_to_index(index, doc_type)
      else:
        for doc in doc_type:
          ElasticsearchManager.add_type_to_index(index, doc)
    if not index.exists():
      index.create()

    return index

  def delete_index(self, name):
    """
    Deletes an index with a given name
    :param name: The name of the index to delete
    :type name: str
    :return: A dictionary indication whether the index was deleted or not
    :rtype: dict
    """
    index = Index(name, using=self._es)
    return index.delete(ignore=404)

  def index_exists(self, name):
    """
    Returns a bool indicating whether an index exists or not
    :param name: The name of the index to check
    :type name: str
    :return: True if an index exists, False otherwise
    :rtype: bool
    """
    index = Index(name, using=self._es)
    return index.exists()

  def get_status(self):
    """
    Returns True if the cluster is up, False otherwise
    :return: True if the cluster is up, False otherwise
    :rtype: bool
    """
    return {"success": True, "status": self._es.ping()}

  @staticmethod
  def add_filter(search, filter_name, filter_dict):
    """
    Returns a given search object with a filter attached
    :param search: The search object
    :type search: Search
    :param filter_name: The type of the filter
    :type filter_name: str
    :param filter_dict: A dictionary with the filter details
    :type filter_dict: dict
    :return: An Elasticsearch DSL object with a filter included
    :rtype: Search
    """
    search = search.filter(filter_name, **filter_dict)
    import json
    logger.warning(json.dumps(search.to_dict()))
    return search

  @staticmethod
  def sort(search, sort_field):
    """
    Returns a given search object with a sort included
    :param search: The search object
    :type search: Search
    :param sort_field: The field to sort on
    :type sort_field: str
    :return: An Elasticsearch DSL object with a sort included
    :rtype: Search
    """
    return search.sort(sort_field)

  @staticmethod
  def pagination(search, es_from=0, size=10):
    """
    Returns a given search object with pagination included
    :param search: The search object
    :type search: Search
    :param es_from: The initial document number to include in search results
    :type es_from: int
    :param size: The final document number to include in results
    :type size: int
    :return: An Elasticsearch DSL object with pagination included
    """
    return search[es_from:size]

  @staticmethod
  def add_query(search, query_type, query_dict):
    """
    Returns a given search object with a query included
    :param search: The search object
    :type search: Search
    :param query_type: The type of query being made
    :type query_type: str
    :param query_dict: The query details as a dictionary
    :type query_dict: dict
    :return: An Elasticsearch DSL object with a query included
    :rtype: Search
    """
    query = Q(query_type, **query_dict)
    return search.query(query)

  @staticmethod
  def add_type_to_index(index, doc_type):
    """
    Returns a given Index with a type included
    :param index: The index object
    :type index: Index
    :param doc_type: An Elasticsearch DSL Type
    :type doc_type: DocTypeMeta
    :return: An Elasticsearch DSL object with a Type included
    :rtype: Search
    """
    index.doc_type(doc_type)
    return index

  @staticmethod
  def create_analyzer(name, tokenizer, token_filters=None, char_filters=None):
    """
    Returns a Custom Analyzer to be used within an Index
    :param name: The name of the analzyer
    :type name: str
    :param tokenizer: An Elasticsearch DSL Tokenizer
    :type tokenizer: elasticsearch_dsl.analysis.CustomTokenizer
    :param token_filters: A list of token filters
    :type token_filters: list
    :param char_filters: A list of character filters
    :type char_filters:
    :return: An Elasticsearch DSL Custom Analyzer
    :rtype: elasticsearch_dsl.analysis.CustomAnalyzer
    """
    return analyzer(name, tokenizer=tokenizer, filter=token_filters,
                    char_filter=char_filters)

  @staticmethod
  def send_response(search, response_builder):
    """
    Returns a dictionary ready to be used as a response by CherryPy endpoints
    :param search: An Elasticsearch DSL Search object
    :type search: Search
    :param response_builder: A function that will take a list of hits from
    Elasticsearch and build a response
    :type response_builder: callable
    :return: A dictionary with a Success flag
    :rtype: dict
    """
    try:
      items = search.execute()
      return response_builder(items)
    except ElasticsearchException:
      response.status = 400
      return {"success": False, "error": traceback.format_exc()}
