import logging
import decimal
import json
import functools
import warnings
import inspect
import pytz

import certifi
import simplejson
import datetime
import base64
import os
import uuid
import socket
import requests
import collections
import time
import math

from pathlib import Path
from elasticsearch_dsl.connections import connections
from dateutil.relativedelta import relativedelta
from datetime import date
from time import sleep
from dateutil.rrule import rrule, MONTHLY
from enum import Enum

string_types = (type(b''), type(u''))

def deprecated(reason):
  """
  This is a decorator which can be used to mark functions
  as deprecated. It will result in a warning being emitted
  when the function is used.
  """

  if isinstance(reason, string_types):

      # The @deprecated is used with a 'reason'.
      #
      # .. code-block:: python
      #
      #    @deprecated("please, use another function")
      #    def old_function(x, y):
      #      pass

      def decorator(func1):

        if inspect.isclass(func1):
          fmt1 = "Call to deprecated class {name} ({reason})."
        else:
          fmt1 = "Call to deprecated function {name} ({reason})."

        @functools.wraps(func1)
        def new_func1(*args, **kwargs):
          warnings.simplefilter('always', DeprecationWarning)
          warnings.warn(
              fmt1.format(name=func1.__name__, reason=reason),
              category=DeprecationWarning,
              stacklevel=2
          )
          warnings.simplefilter('default', DeprecationWarning)
          return func1(*args, **kwargs)

        return new_func1

      return decorator

  elif inspect.isclass(reason) or inspect.isfunction(reason):
    # The @deprecated is used without any 'reason'.
    #
    # .. code-block:: python
    #
    #    @deprecated
    #    def old_function(x, y):
    #      pass

    func2 = reason

    if inspect.isclass(func2):
      fmt2 = "Call to deprecated class {name}."
    else:
      fmt2 = "Call to deprecated function {name}."

    @functools.wraps(func2)
    def new_func2(*args, **kwargs):
      warnings.simplefilter('always', DeprecationWarning)
      warnings.warn(
          fmt2.format(name=func2.__name__),
          category=DeprecationWarning,
          stacklevel=2
      )
      warnings.simplefilter('default', DeprecationWarning)
      return func2(*args, **kwargs)

    return new_func2
  else:
    raise TypeError(repr(type(reason)))

def singleton(cls):
  """
    Decorator for Singleton
  """
  instances = {}
  def getinstance():
    """
      Returns an instance of the specified class
    """
    if cls not in instances:
      instances[cls] = cls()
    return instances[cls]
  return getinstance

class Singleton(type):
  """
  Singleton class
  """
  _instances = {}

  def __call__(cls, *args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    """
    if cls not in cls._instances:
      cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
    return cls._instances[cls]

#TODO User Generic Singleton and then derrive

class SingletonCommonManager(type):
  _instances = {}

  def __call__(cls, *args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    """
    if cls not in cls._instances:
      cls._instances[cls] = super(SingletonCommonManager, cls).__call__(*args, **kwargs)
    return cls._instances[cls]

class SingletonServiceManager(type):
  _instances = {}

  def __call__(cls, *args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    """
    # TODO: Try configuring env here
    # self.env = dict(os.environ)
    if cls not in cls._instances:
      cls._instances[cls] = super(SingletonServiceManager, cls).__call__(*args, **kwargs)
    return cls._instances[cls]

class SingletonAccessorManager(type):
  _instances = {}

  def __call__(cls, *args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    """
    # TODO: Try configuring env here
    # self.env = dict(os.environ)
    if cls not in cls._instances:
      cls._instances[cls] = super(SingletonAccessorManager, cls).__call__(*args, **kwargs)
    return cls._instances[cls]

#@singleton
class SbtCommon (object, metaclass=SingletonCommonManager):
  """
    SbtCommon contains commonly used methods across the code base.
  """
  _available_env = ['qa', 'dev', 'prod']
  _api_routes    = {}
  _api_resources = []
  _config_file   = None

  def __init__ (self):
    """
      Constructor
    """
    self.logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    self.logger.info("Logging Configured...")
    self.last_request_time = 0

    p = Path(os.path.dirname(os.path.realpath(__file__)))
    p = p.parent

    self.config_dir = os.path.join(p.parent, 'config')

    self.logger.info("Configuration Directory set to: " + str(self.config_dir))

    self.dateutil        = self.DateUtil()
    self.stringutil      = self.StringUtil()
    self.collectionsutil = self.CollectionsUtil()
    self.securityutil    = self.SecurityUtil()
    self.numberutil      = self.NumberUtil()

    self._load_sbt_config()

    host = self.sbt_config['elasticsearch']['hosts']
    if 'verify_certs' in self.sbt_config['elasticsearch']:
      verify_certs = self.sbt_config['elasticsearch']['verify_certs']
    else:
      verify_certs = False if 'localhost' in host[0] else True

    connections.create_connection(
            hosts=host,
            use_ssl=True,
            ca_certs=certifi.where(),
            verify_certs=verify_certs,
    )

  @staticmethod
  def get_host_name ():
    """
      Returns current servers host name

      Returns:
        str : Host Name
    """
    return socket.gethostname()

  def supported_redis_host (self):
    """
      Returns true if the current host supports a
      connection to Redis host name.
    """
    conf = SbtGlobalCommon.get_sbt_config()
    if 'redis' in  conf:
      return SbtCommon.get_host_name() not in \
        conf['redis'].get('unsupported_host', [])
    else :
      return False
    
  def get_sbt_config_env (self):
    """
    Retrieves the env value in sbt_conf.json
    :return:
    """
    return self.get_sbt_config()['environment']

  def set_sbt_config_env (self, penv):
    """
    Sets the env variable in sbt_conf.json to the specified environment
    :param penv: Is the target environment
    :return:
    """
    self.get_sbt_config()['environment'] = penv
    self._config_api_routes()
    return self.get_sbt_config()['environment'] == penv

  @staticmethod
  def sleep (seconds):
    """
      Waits for specified period of time

      Args:
          seconds(int)  : Seconds
    """
    sleep(seconds)

  def get_sbt_config (self):
    """
      Returns the sbt configuration adjusted for environment

      Returns:
          dict: Sbt Configurations
    """
    return self.sbt_config

  @staticmethod
  def get_global_logger () :
    """
      Returns the global logger

      Returns:
          logger: Logger Object
    """
    return SbtGlobalCommon.logger

  @staticmethod
  def validate_uuid(strid, use_version=4):
    """
    Validates that the input stringid is a valid UUID as indicated by the use_version
    :param strid: The string id to be validated
    :user_version: UUID4 is used as the default version for validation unless
                   otherwise specified
    :return: True if the strid is a valid hex code, uuid
    """
    try:
      guid   = uuid.UUID(strid, version=use_version)
      rval = str(guid) == strid
    except Exception : # ValueException
      rval = False

    return rval

  @staticmethod
  def get_uuid ():
    """
      Creates a random UUID (RFC UUID v4)

      Returns:
          uuid: Unique UID
    """
    return uuid.uuid4()

  @staticmethod
  def get_logger (llevel=logging.INFO, lname='DefaultLogger', stream=None, *args) :
    """
      Instantiates and returns a logger.

      Args:
        llevel(int)  : Logging Level
        lname(str)   : Logger name
        args         : Additional arguments

      Returns:
        logger: Logger Object
    """
    #Setup logging service
    logger = logging.getLogger(lname)
    logger.setLevel(llevel)
    # create console handler with a higher log level
    ch = logging.StreamHandler() if not stream else logging.StreamHandler(stream)
    ch.setLevel(llevel)
    # create formatter and add it to the handlers

    fmt = ''

    if args:
      for i, arg in enumerate(args):
        fmt = fmt + '%(' + arg + ')s'
        if i + 1 < len(args):
          fmt = fmt + ' - '
    else:
      fmt = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

    formatter = logging.Formatter(fmt)
    ch.setFormatter(formatter)
    # add the handlers to logger
    logger.addHandler(ch)
    #TODO Fix this
    #if not logger.hasHandlers():
    #  logger.addHandler(ch)
    logger.propagate = False

    return logger

  def get_config(self, file_name):
    """
      Returns a configuration file as a dictionary

      Args:
          file_name(str): File contained in the project configuration directory.
                          File should be in JSON format.

      Returns:
          dict: Contents of file
    """
    self._config_file = os.path.join(self.config_dir, file_name)
    self.logger.info("loading config file: " + self._config_file)

    f = open(self._config_file, 'r')
    c = f.read()
    f.close()

    return json.loads(c, object_pairs_hook=collections.OrderedDict)

  def _load_sbt_config(self):
    """
      Loads the sbt_sonfig.json
    """
    self.raw_sbt_config = self.get_config('sbt_conf.json')
    config = self.raw_sbt_config.copy()
    self.environment = config['environment']
    self.sbt_config = config[self.environment]
    self._remove_available_env(config)
    self.sbt_config.update(config)
    self._config_api_routes()

  def _config_route(self, res, parent, pre):
    """
    Configure ApiGateway routes for specified resource
    :param res: resource to be configured
    :param parent: resource parent
    :param pre: route prefix
    :return:
    """
    if self.stringutil.is_empty(parent) :
      return

    parents = parent.split('/')
    resource_key = parents[0]
    for k in res.keys():
      if isinstance(res[k], str):
        parent_uri = ''
        for p in parents :
          parent_uri = parent_uri + '/' + p
        self._api_routes[resource_key].append((pre  + parent_uri + '/' + k, res[k]))
      else:
        self._api_routes[k] = []
        self._config_route(res[k], parent + '/' + k, pre)

    return self._api_routes[resource_key]

  def get_api_uri(self):
    """

    :return:
    """
    cfg = self.sbt_config
    env = cfg['environment']
    api = cfg['apigateway']

    return api['env'][env]

  def _config_api_routes(self):
    """
    Configure all api gateway routes for the current environment
    :return:
    """
    cfg = self.sbt_config
    env = cfg['environment']
    api = cfg['apigateway']
    uri = api['env'][env]
    res = api['resources']

    self._api_resources.extend(res.keys())

    for r in res.keys():
      if isinstance(res[r], str):
        # create and get
        self._api_routes[r] = (uri + '/' + r, res[r])
      else:
        self._api_routes[r] = []
        self._api_routes[r] = self._config_route(api['resources'][r], r, uri)

  def get_api_routes(self, res):
    """

    :param res:
    :return:
    """
    return self._api_routes[res]

  def get_api_resources(self):
    """

    :return:
    """
    return self._api_resources

  def get_api_token_key(self):
    """

    :return:
    """
    return self.sbt_config['apigateway']['auth-token-key']

  def get_api_token_value(self):
    """

    :return:
    """
    return self.sbt_config['apigateway']['auth-token-value']

  def _remove_available_env (self, selected_dict):
    """
      Removes environment data from a dictionary
    """
    for env in self._available_env :
      selected_dict.pop(env)

  def get_cfg_env(self):
    """
    :return: str
    """
    rval = self.environment
    return rval

  def get_cfg_env_var(self, var):
    """

    :param var:
    :return:
    """
    rval = None
    env  = self.sbt_config

    if self.CollectionsUtil.key_exists(var, env):
      rval = env[var]

    return rval

  def add_cfg_file_var(self, attroute, key, value):
    """

    :param attroute:
    :param key:
    :param value:
    :return:
    """
    attr    = None

    with open(self._config_file, "r") as config:
      cfgdata = json.load(config)

    for att in attroute:
      attr = cfgdata[att] if not attr else attr[att]

    cfgvar      = dict()
    cfgvar[key] = value
    attr.update(cfgvar)

    with open(self._config_file, "w") as config:
      json.dump(cfgdata, config, indent=2, separators=(',', ' : '))

  class NumberUtil :
    """
      The NumberUtil class contains commonly used numeric methods
    """
    @staticmethod
    def is_int (value):
      if value is None:
        return False
      
      if isinstance(value, int) :
        return True

      try :
        int(value) 
        return True
      except ValueError :
        return False  

  class SecurityUtil :
    """
      The SecurityUtil class contains commonly used security methods
    """

    @staticmethod
    def base64_to_string(b64):
      """
        Converts a base64 encoded value to a string.

        Args:
            b64(base64): The base64 value to be converted

        Returns:
            str: UTF-8 string representation of b64
      """
      if not isinstance(b64, bytes) :
        raise Exception('Invalid argument type provided for method.')

      return base64.b64decode(b64).decode('utf-8')

    @staticmethod
    def string_to_base64(s):
      """
        Converts a string encoded value to a base64.

         Args:
            s(str): The character string to be converted

        Returns:
            base64: The base64 representation of s
      """
      # if not isinstance(s, str) :
      #   raise Exception('Invalid argument type provided for method.')
      
      return base64.b64encode(s.encode('utf-8'))

    @staticmethod
    def is_base64(s):
      #TODO:
      '''
       rval = False
       s = ''.join([s.strip() for s in s.split("\n")])
       if len(s) % 4 == 0:
         rval = base64.b64encode(base64.b64decode(s)).strip()
       return rval
       ...or
       try:
         enc = base64.b64encode(base64.b64decode(s)).strip()
         return enc == s
       except TypeError:
         return False
      '''
      try:
        base64dec = base64.b64decode(s) 
        
        if base64.b64encode(base64dec) == s:
          # There are circumstances where an encoded UTF-8
          # string can be validated above.  This UTF-8
          # decode guards against that problem.  
          base64dec.decode('UTF-8')  
          return True
      except Exception:
        pass
      
      return False

  class CollectionsUtil :
    """
      The CollectionsUtil class contains commonly used collection methods
    """
  
    @staticmethod
    def set_in_dict(data_dict, map_list, value): 
      for k in map_list[:-1]: 
        if k not in data_dict : 
          data_dict[k] = {}
        data_dict = data_dict[k]
      data_dict[map_list[-1]] = value

    @staticmethod
    def is_empty (c):
      """
        Check whether a collection is none or contains zero elements.

        Args:
          c (collection): Collection

        Returns:
          bool: True is collection is empty. False otherwise.

        Exceptions :
          Raises an exception if the compare object is not a collection.
      """
      if c and not isinstance(c, collections.Sized):
        raise Exception('Not a collection.')

      return c is None or len(c) == 0

    @staticmethod
    def is_not_empty (c):
      """
        Check whether a collection is not none or contains at least one
        elements.

        Args:
          c (collection): Collection

        Returns:
          bool: True is collection is not empty. False otherwise.

        Exceptions :
          Raises an exception if the compare object is not a collection.
      """
      if c and not isinstance(c, collections.Sized):
        raise Exception('Not a collection.')

      return c and len(c) > 0

    @staticmethod
    def are_dictionaries_equal (dict1, dict2):
      """
        Check whether the keys and values in 2 dictionaries are equal.

        Args:
          dict1 (dict): Dictionary
          dict2 (dict): Dictionary

        Returns:
          bool: True dictionaries are equal. False otherwise.
      """
      equal_dict = True

      if (not dict1) or (not dict2):
        return False

      if type(dict1) is not dict or type(dict2) is not dict:
        return False

      if len(dict1) != len(dict2):
        return False

      for key, value in dict1.items() :
        equal_dict = SbtCommon.CollectionsUtil.contains_key_value(key,
                                                                  value,
                                                                  dict2)

        if not equal_dict :
          break

      return equal_dict

    @staticmethod
    def get_matching_dict_entries(src, tgt):
      """
      Retrieves key value pairs in src dict matching those in the target dict
      :param: d1 Is the source dict
      :param: d2 Is the targe dict
      :return: rval Dictionary containing key value pairs in source and target
      """
      rval = dict()

      d1 = src if len(src) > len(tgt) else tgt #d1 is the larger dict
      d2 = src if len(src) < len(tgt) else tgt #d2 is smaller if not same len

      for k, v in d1.items(): # iterate over the largest list only
        if k in d2 and d2[k] == v:
          rval[k] = v

      return rval

    @staticmethod
    def key_exists(key, dictionary):
      """
        Check whether a key is contained in a dictionary.

        Args:
          key (str): The key to check with.
          dictionary (dict): The dictionary to check the key against.

        Returns:
          bool: True if the key exists. False otherwise.
      """
      return key in dictionary.keys()

    @staticmethod
    def lists_intersect(list1, list2):
      """
        Check if two lists intersect.

        Args:
          list1: The first list to check the intersection with.
          list2: The second list to check the intersection with.

        Returns:
          bool: True if the lists intersect. False otherwise.
      """
      return not set(list1).isdisjoint(list2)

    @staticmethod
    def contains_key_value (key, value, compare_dict):
      equals_value = True

      if key not in compare_dict.keys() :
        return False

      value2 = compare_dict[key]

      value_type1 = type(value)
      value_type2 = type(value2)

      if value_type1 != value_type2 :
        equals_value = False
      else :
        if value_type1 == dict and \
        not SbtCommon.CollectionsUtil.are_dictionaries_equal (value,
                                                          compare_dict[key]) :
          equals_value = False

        if value_type1 == list and set(value) != set(value2):
          equals_value = False

        if equals_value and value != compare_dict[key] :
          equals_value = False

      return equals_value

  class DateUtil :
    """
      The DateUtil class contains commonly used date methods
    """

    @staticmethod
    def add_months (date, number_of_months):
      """
        Adds months to an existing date and returns the new date

        Args :
          date(date)             : Start Date
          number_of_months(int)  : Number of months to add to start date

        Returns :
          date : Date object
      """
      return date + relativedelta(months=+number_of_months)

    @staticmethod
    def add_days (date, number_of_days):
      """
        Adds days to an existing date and returns the new date

        Args :
          date(date)           : Start Date
          number_of_days(int)  : Number of days to add to start date

        Returns :
          date : Date object
      """
      return datetime.datetime(date.year, date.month, date.day) + \
              datetime.timedelta(days=number_of_days)

    @staticmethod
    def get_current_timestamp ():
      """
        Returns the current timestamp.

        Returns :
          datetime : current datetime
      """
      return datetime.datetime.now()

    @staticmethod
    def get_current_iso_timestamp ():
      """
        Returns the current timestamp in iso format to deal with deserialization.

        Returns :
          datetime : current datetime in iso format
      """
      return datetime.datetime.now().isoformat()

    @staticmethod
    def iso_timestamp_to_string (o):
      """
        Returns the current iso formatted datetime as a string.

        Args :
          0 (datetime) : Datatime type object.

        Returns :
          str : Current datetime represented as a formatted string
      """
      if isinstance(o, datetime.datetime):
        return o.__str__()

    @staticmethod
    def get_current_date_string (date_format="%Y-%m-%d"):
      """
        Returns the current date as a string.

        Args :
          date_format (str) : Format of the string. This parameter is
          optional but defaults to "%Y-%m-%d"

        Returns :
          str : Current date represented as a formatted string
      """
      return datetime.datetime.today().strftime(date_format)

    @staticmethod
    def get_date (string_date, date_format="%Y-%m-%d"):
      """
        Converts a formatted string to a date object

        Args :
          string_date (str) : String representation of date
          date_format (str) : Format of the string. This parameter is
          optional but defaults to "%Y-%m-%d"

        Returns :
          date : Date object
      """
      return datetime.datetime.strptime(string_date, date_format)

    @staticmethod
    def months_between (startdate, enddate) :
      """
        Returns number of months between 2 dates

        Args :
          startdate(date)  : Start Date
          enddate(date)    : End Date

        Returns :
          int : The number of months
      """
      return len([dt.strftime("%m") for dt in rrule(MONTHLY, dtstart=startdate,
                  until=enddate)])

    @staticmethod
    def get_relative_date(months=-6, date_format='%Y%m%d', **kwargs):
      return (date.today() + relativedelta(months=months, **kwargs)).strftime(
        date_format)
      
    @staticmethod
    def get_epoc_date (date_time_value):
      """
        Returns epoc value associated with datetime.
  
        Args :
          date_time_value(datetime)  : Datetime value
  
        Returns :
          int : EPOC value
      """
         
      epoc_value = 0
      
      try :
        epoc_value = int(time.mktime(date_time_value.timetuple()))
      except :
        ep = datetime.datetime(1970,1,1,0,0,0, tzinfo=datetime.timezone.utc)
        epoc_value = (date_time_value - ep).total_seconds()    
  
      return epoc_value

    @staticmethod
    def _is_dst ():
      """
        Determine whether or not Daylight Savings Time (DST)
        is currently in effect
      """
  
      x = datetime.datetime(datetime.datetime.now().year, 1, 1, 0, 0, 0, tzinfo=pytz.timezone('US/Eastern')) # Jan 1 of this year
      y = datetime.datetime.now(pytz.timezone('US/Eastern'))
  
      # if DST is in effect, their offsets will be different
      return not (y.utcoffset() == x.utcoffset())
    
  class StringUtil :
    """
      The StringUtil classes contains commonly used string methods
    """

    @staticmethod
    def is_not_empty (value) :
      """
        Returns True if the string contains a value.
        The method checks to make sure the value is
        not none, an instance of string and has a
        stripped length > 0

        Args :
          value(str)    : String

        Returns :
          boolean : True indicates the string contains
                    a value, otherwise False
      """
      return value is not None and isinstance(value, str) \
        and len(value.strip()) > 0

    @staticmethod
    def is_empty (value) :
      """
        Returns True if the string does not contain a value.
        The method checks to make sure the value is
        none or an instance of string and has a
        stripped length == 0

        Args :
          value(str)    : String

        Returns :
          boolean : True indicates the string contains
                    an empty value, otherwise False
      """
      return value is None or (isinstance(value, str) and
        len(value.strip()) == 0)

    @staticmethod
    def equal_ignore_case(lhs='', rhs=''):
      """
      Case insensitive string equality binary operation

      :param lhs: Left hand side of == operation
      :param rhs: Right hand side of == operation
      :return:    True if lhs == rhs where lhs and rhs are all lower case
                  False otherwise characters (utf-8)
      """
      return (lhs is None and rhs is None) or (lhs.lower() == rhs.lower())

  @staticmethod
  def makerequest(url, method, data=None, params=None, headers=None, *args):
    """

    :param url:
    :param method:
    :param data:
    :param params:
    :param headers:
    :param args:
    :return:
    """
    logger = SbtGlobalCommon.get_global_logger()
    rval    = None
    data    = {} if not data else data
    params  = {} if not params else params
    default = {
                'Content-type': 'application/json',
                'Accept': 'text/plain'
              }
    headers = default if not headers else headers
    try:
      req = SbtCommon._get_request (url, method, data, params, headers, *args)

      logger.debug('status_code:' + str(req.status_code))
      # Should return a dict on error
      try:
        rval = req.json()
      except Exception as e:
        logger.error('Function : makerequest Message : ' +
                     'Exception serializing response for (' + url +
                     ') System Exception : ' + str(e))        
        rval = {
                 'status' : req.status_code,
                 'reason': req.reason,
                 'exception' : str(e)
               }
    except Exception as e:
      logger.error('Encountered exception: ' + str(e))
      raise e

    return rval

  @staticmethod
  def _get_request (url, method, data, params, headers, *args):
    """

    :param url:
    :param method:
    :param data:
    :param params:
    :param headers:
    :param args:
    :return:
    """

    req = None

    logger = SbtGlobalCommon.get_global_logger()
    logger.debug('URL:\n' + url)

    if data:
      logger.debug('DATA:\n' + json.dumps(data))

    if params:
      logger.debug('PARAMS:\n' + str(params))

    if headers:
      logger.debug('HEADERS:\n' +str(headers))

    start = time.time()
    if method == 'POST':
      req = requests.post(url, params=params, data=json.dumps(data), headers=headers)
    elif method == 'DELETE':
      if data:
        req = requests.delete(url, params=params, data=json.dumps(data), headers=headers)
      else:
        if args:
          for i, arg in enumerate(args):
            logger.debug('Arg ' + str(i) + ' : ' + str(arg))
            url += '/' + arg
          logger.debug('URL:\n' + url)
        req = requests.delete(url, params=params, headers=headers)
    elif method == 'PUT':
      req = requests.put(url, params=params, data=json.dumps(data), headers=headers)
    elif method == 'GET':
      if args:
        for i, arg in enumerate(args):
          logger.debug('Arg ' + str(i) + ' : ' + str(arg))
          url += '/' + arg
        logger.debug('URL:\n' + url)
      req = requests.get(url, params=params, headers=headers)
    else:
      logger.error('Unsupported Method: ' + method)

    SbtGlobalCommon.last_request_time = time.time() - start

    return req

"""
Global instance of SbtCommon
"""
SbtGlobalCommon = SbtCommon()
_LOGGER = SbtGlobalCommon.get_global_logger().info

def timing(f):
  def timed(*args, **kw):
    tic = datetime.datetime.now()
    result = f(*args, **kw)
    tac = datetime.datetime.now()
    dt = tac - tic
    dt = "{} ms.".format(dt.microseconds/1000) if dt.seconds < 1 else dt
    _LOGGER(" {}: DONE IN {}".format(f.__name__, dt))
    return result
  return timed

# def timing(f):
#   def wrap(*args):
#     time1 = time.time()
#     ret = f(*args)
#     time2 = time.time()
#     SbtGlobalCommon.get_global_logger().info('%s function execution time %0.3f ms' % (f.__name__, (time2-time1)*1000.0))
#     return ret
#   return wrap

class ServiceStatus(Enum):
  """
  The Enumeration status of an sbt service is one of the following.
  """
  UNKNOWN = 0
  STOPPED = 1
  RUNNING = 2
  DEAD    = 3

  __namemap__ = dict()
  __namemap__[UNKNOWN] = 'unknown'
  __namemap__[STOPPED] = 'stopped'
  __namemap__[RUNNING] = 'running'
  __namemap__[DEAD]    = 'dead'

  def __str__(self):
    """
      Overload the string conversion operator using __namemap__ mangling
      note enums have _value_ and _name_ attributes
    """
    return '%s' % self.__namemap__[self._value_]

  def __str__(self):
    """
      Overload the string converstion operator with __namemap__
      :return: string representation of type for portfolio
    """
    return '%s' % self.__namemap__[self._value_]

  def __str__(self):
    """
      Overload the string converstion operator with __namemap__
      :return: string representation of trade type for position
    """
    return '%s' % self.__namemap__[self._value_]

class PositionStatusType(Enum):
  """
  The Enumeration type of a portfolio in Portfolio Manager
  """
  Open=0
  Closed=1

  __namemap__         = dict()
  __namemap__[Open]   = 'Open'
  __namemap__[Closed] = 'Closed'

  def __str__(self):
    """
      Overload the string converstion operator with __namemap__
      :return: string representation of trade type for position
    """
    return '%s' % self.__namemap__[self._value_]

class DecimalEncoder(json.JSONEncoder):
  """
    JsonEncoder for Decimal values
  """
  def default(self, o):
    """
    Encode numerical data estypes to decimal values for JSON
    """
    if isinstance(o, decimal.Decimal):
      if o % 1 > 0:
        return float(o)
      else:
        return int(o)
    return super(DecimalEncoder, self).default(o)

class SimpleJsonDateTimeEncoder(simplejson.JSONEncoder):
  """
  Encode DateTime data type to string for JSON serialization
  """
  def default(self, o):
    if isinstance(o, datetime.datetime):
      return o.isoformat()

    #TODO: FixMe not an instance or subclass of DateTimeEncoder
    return super(DateTimeEncoder, self).default(o)

class DateTimeEncoder(json.JSONEncoder):
  """
  Encode DateTime data type to string for JSON serialization
  """
  def default(self, o):
    if isinstance(o, datetime.datetime):
      return o.isoformat()

    return super(DateTimeEncoder, self).default(o)

class DecimalStringEncoder(json.JSONEncoder):
  """
    JsonEncoder that encodes a decimal data type to a string value.
  """
  def default(self, o):
    if isinstance(o, decimal.Decimal):
      return str(o)

    return super(DecimalStringEncoder, self).default(o)

class UUIDEncoder(json.JSONEncoder):
  """
  Encode UUID data type to string for JSON serialization
  """
  def default(self, o):
    if isinstance(o, uuid.UUID):
      return str(o)

    return super(UUIDEncoder, self).default(o)

def paginate_data (current_page, 
                  page_size, 
                  results,
                  sort=None,
                  filter_data=None):
  
  page = {"total_pages" : 0,
          "current_page" : 0,
          "total_records" : 0,
          "page_size" : 0,
          "page_data" : []}   

  if not current_page or current_page < 1 : 
    current_page = 1

  if results :
    results = filter_list (results, filter_data)
    results = sort_list(results, sort)
    
    total_records = len(results)
    if not page_size or page_size < 1 :
      page_size = total_records

    total_pages = math.ceil(total_records/page_size)

    if current_page > total_pages :
      current_page = total_pages
    page['current_page'] = current_page
    page['page_size'] = page_size
    page['total_records'] = total_records  
    
    page['total_pages'] = total_pages
    
    end_pos = current_page * page_size     
    start_pos = end_pos - page_size
    if start_pos < 0 :
      start_pos = 0  
    if end_pos > total_records :
      end_pos = total_records  
      
    if start_pos <= total_records :       
      page['page_data'] = results[start_pos:end_pos]  
    
  return page  

def filter_list (results, filter_data):
  f_results = []
  
  if not filter_data :
    return results
  
  filters = filter_data.split(',')
  
  for f_field in filters : 
    filter_field = f_field.split(':')
    
    if len(filter_field) == 2 :   
      f_results.extend(list(filter(lambda k: k[filter_field[0]] == filter_field[1],
                            results)))
  
  return f_results  

def sort_list (results, sort):
  if not sort :
    return results
  
  sort_fields = sort.split(':')
  reverse_value = False
  if len(sort_fields) == 2 and sort_fields[1][:1].lower() == 'd':
    reverse_value = True
    
  s_results = sorted(results, key=lambda k: k[sort_fields[0]], 
                   reverse=reverse_value)
  
  return s_results
