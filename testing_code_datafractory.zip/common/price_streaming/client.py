import json
import logging
import threading
import time
import urllib.parse
import websocket

from sbt_common import SbtGlobalCommon
from ecupmanager import ElasticCacheUPManager

class PriceStreamClient(object):
    def __init__(self, environment=None, api_key=None, create_session=True, sleep_time=30, read_timeout=10):
        self.symbols = set()
        self.prices = {}
        self.ws_thread = None
        self.is_finished = False
        self.api_key = api_key
        self.environment = environment
        self.create_session = create_session
        self.sleep_time = sleep_time
        self.read_timeout = read_timeout

        self.logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
        self.ecup = ElasticCacheUPManager()
        self.config = SbtGlobalCommon.get_sbt_config()

        if self.environment is None:
            self.environment = self.config["environment"]

    def __del__(self):
        self.stop()

    def start(self):
        self.is_finished = False
        self.ws_thread = threading.Thread(target=self.run_websocket, daemon=True)
        self.ws_thread.start()

    def stop(self):
        self.is_finished = True
        if self.ws_thread:
            self.ws_thread.join()

    def add_symbols(self, *symbols):
        self.symbols.update(symbols)

    def get_price(self, symbol, exchange):
        return self.prices.get((symbol, exchange))

    def get_ws_url(self):
        base_url = self.config["websocket_server"][self.environment]
        return urllib.parse.urljoin(base_url, "/socket.io/?apiKey={}&transport=websocket".format(self.api_key))

    def run_websocket(self):
        while not self.is_finished:
            if self.create_session:
                try:
                    user = self.ecup.get_public_session()
                    self.api_key = user["apikey"]
                except Exception as e:
                    self.logger.info("Could not create public session: {}".format(str(e)))
                    time.sleep(self.sleep_time)
                    continue

            try:
                ws = websocket.create_connection(self.get_ws_url(), timeout=self.read_timeout)
                ws.send('40/streaming?apiKey={}'.format(self.api_key))
            except Exception as e:
                self.logger.info("Could not connect to websocket: {}".format(str(e)))
                time.sleep(self.sleep_time)
                continue

            subscribed_symbols = set()

            while not self.is_finished:
                try:
                    if self.symbols != subscribed_symbols:
                        message = '42/streaming,["subscribe","{}"]'.format(",".join(self.symbols))
                        ws.send(message)
                        subscribed_symbols = set(self.symbols)

                    ws.ping()
                    ws.send("2")

                    while not self.is_finished:
                        full_message = ws.recv()
                        try:
                            channel, message_str = full_message.split(",", 1)
                        except ValueError:
                            continue

                        if channel != '42/streaming':
                            continue

                        message = json.loads(message_str)
                        if message[0] == "stock_price":
                            data = message[1].get("data")
                            if data:
                                symbol_exchange = (data["symbol"], data["exchange"])
                                self.prices[symbol_exchange] = data

                except websocket.WebSocketTimeoutException:
                    pass
                except Exception as e:
                    self.logger.info("Websocket disconnect: {}".format(str(e)))
                    break

            try:
                ws.close()
            except Exception as e:
                pass

            time.sleep(self.sleep_time)
