from . import cryptocompare

_coin_list = {}

def get_coin_list():
    if len(_coin_list) == 0:
        coin_descriptions = cryptocompare.get_coin_descriptions()
        for symbol, description in coin_descriptions.items():
            _coin_list[symbol] = {
                "symbol": symbol,
                "name": description["CoinName"],
                "algorithm": description["Algorithm"],
                "proof_type": description["ProofType"],
            }

    return _coin_list

def get_description(symbol):
    coin_list = get_coin_list()
    return coin_list.get(symbol)
