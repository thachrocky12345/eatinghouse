import logging
import psycopg2
from decimal import Decimal

from sbt_common import SbtGlobalCommon
from . import cryptocompare

config = SbtGlobalCommon.get_sbt_config()
logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
db_config = config["postgres"]["crypto_ts"]

def connect():
    return psycopg2.connect(
        dbname=db_config["database"],
        user=db_config["user"],
        password=db_config["credentials"],
        host=db_config["host"],
        port=db_config["port"],
    )

def update_timeseries_data():
    conn = connect()
    cursor = conn.cursor()

    try:
        top_ranked = cryptocompare.get_top_ranked(count=50)
        coin_list = [i["symbol"] for i in top_ranked]
        prices = cryptocompare.get_prices(*coin_list)
        rows = [(i, Decimal(prices[i])) for i in coin_list if i in prices]

        cursor.executemany("INSERT INTO pricedata(symbol, timestamp, price) VALUES(%s, NOW(), %s)", rows)
        conn.commit()

    except psycopg2.DatabaseError as error:
        logger.exception("Error updating timeseries data")
        try:
            conn.rollback()
        except:
            pass

    finally:
        if conn is not None:
            conn.close()

def get_top_movers(num_days):
    conn = connect()
    cursor = conn.cursor()

    current_prices = {}
    previous_prices = {}

    cursor.execute("""
        SELECT DISTINCT symbol, LAST_VALUE(price) OVER w
        FROM pricedata
        WINDOW w AS (PARTITION BY symbol
                     ORDER BY timestamp
                     RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
    """)

    for row in cursor:
        current_prices[row[0]] = row[1]

    cursor.execute("""
        SELECT DISTINCT symbol, LAST_VALUE(price) OVER w
        FROM pricedata
        WHERE timestamp < NOW() - %s * '1 day'::interval
        WINDOW w AS (PARTITION BY symbol
                     ORDER BY timestamp
                     RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
    """, (num_days, ))

    for row in cursor:
        previous_prices[row[0]] = row[1]

    symbol_list = set(current_prices.keys()) & set(previous_prices.keys())
    top_movers = [
        {"symbol": symbol, "increase": (current_prices[symbol] / previous_prices[symbol] - 1) * 100}
        for symbol in symbol_list
        if previous_prices[symbol] > 0
    ]

    top_movers.sort(key=lambda i: i["increase"], reverse=True)

    return top_movers[:10]

def get_price_change(symbols, num_days):
    conn = connect()
    cursor = conn.cursor()

    if not isinstance(symbols, list):
        symbols = [symbols]

    prices = {}

    placeholders = ",".join(["%s" for i in symbols])

    cursor.execute("""
        SELECT DISTINCT symbol, LAST_VALUE(price) OVER w
        FROM pricedata
        WHERE symbol IN ({})
        WINDOW w AS (PARTITION BY symbol
                     ORDER BY timestamp
                     RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
    """.format(placeholders), symbols)

    for row in cursor:
        prices[row[0]] = {"current_price": row[1]}

    cursor.execute("""
        SELECT DISTINCT symbol, LAST_VALUE(price) OVER w
        FROM pricedata
        WHERE timestamp < NOW() - %s * '1 day'::interval
          AND symbol IN ({})
        WINDOW w AS (PARTITION BY symbol
                     ORDER BY timestamp
                     RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
    """.format(placeholders), [num_days] + symbols)

    for row in cursor:
        if row[0] not in prices:
            continue

        price = prices[row[0]]
        price["previous_price"] = row[1]

        if price["current_price"] == 0 or price["previous_price"] == 0:
            price["change_amount"] = 0
            price["change_pct"] = 0
        else:
            price["change_amount"] = price["current_price"] - price["previous_price"]
            price["change_pct"] = 100 * price["change_amount"] / price["previous_price"]

    for symbol in symbols:
        if symbol in prices and "previous_price" not in prices[symbol]:
            del prices[symbol]

    return prices

