import requests
import urllib
from ratelimit import limits, sleep_and_retry
from sbt_common import SbtGlobalCommon

config = SbtGlobalCommon.get_sbt_config()
fs_config = config["api_feeds"]["flipside"]
base_url = fs_config["base_url"]
api_key = fs_config["api_key"]

symbol_to_id = {}
ONE_MINUTE = 60
CALLS = 10

@sleep_and_retry
@limits(calls=CALLS, period=ONE_MINUTE)
def do_request(urlpart, method="GET", data=None):
    url = urllib.parse.urljoin(base_url, urlpart)
    req = requests.request(method, url, json=data, params={"api_key": api_key})
    req.raise_for_status()

    return req.json()

def get_coin_list():
    coin_list = do_request("metrics/projects")
    for coin in coin_list['data']:
        symbol_to_id[coin["symbol"].upper()] = coin["id"]

    return symbol_to_id

def get_id_from_symbol(symbol):
    if not symbol_to_id:
        get_coin_list()

    return symbol_to_id.get(symbol.upper())

def get_metrics(symbol):
    coin_id = get_id_from_symbol(symbol)
    if coin_id is None:
        return None

    data = {}
    data["project_ids"] = [coin_id]
    data["metrics"] = ["fcas"]
    response = do_request("metrics/current/projects", "POST", data)
    return response['data'][0]['metrics']
