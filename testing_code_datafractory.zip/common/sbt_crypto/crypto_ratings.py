import logging
from decimal import Decimal

from sbt_common import SbtGlobalCommon
from crypto_currency_accessor import CryptoAccessor
from mongo_accessor import MongoAccessor

from . import coingecko
from . import cryptocompare
from . import flipside

config = SbtGlobalCommon.get_sbt_config()
logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)

cc_accessor = CryptoAccessor()
rating_table = MongoAccessor('sbt_crypto_scores')
excluded_table = MongoAccessor('sbt_crypto_excluded_symbols')
excluded_symbols = set()

def get_social_score(symbol):
    coin_data = coingecko.get_data(symbol)
    return coin_data["community_score"]

def get_developer_score(symbol):
    coin_data = coingecko.get_data(symbol)
    return coin_data["developer_score"]

def get_fcas_score(symbol):
    fs_metrics = flipside.get_metrics(symbol)
    for metric in fs_metrics:
        if metric["slug"] == "fcas" and metric.get("value") is not None:
            return float(metric["value"]) / 10

def get_30d_price_score(symbol):
    if symbol == "BTC":
        return 100

    gain = coingecko.get_pct_gain(symbol, 30)
    btc_gain = coingecko.get_pct_gain("BTC", 30)

    if gain is None:
        return 0

    if gain > btc_gain:
        return 100

    return 0

def get_30d_vol_growth(symbol):
    response = cc_accessor.generic_call(method="histoday", f=symbol.upper(), t="USD", limit=37)
    old_volume = sum([i["volumeto"] for i in response["Data"][:7]])
    new_volume = sum([i["volumeto"] for i in response["Data"][-7:]])

    if new_volume <= old_volume:
        return 0

    if new_volume <= old_volume * 1.1:
        return 50

    return 100

def get_rank_change(symbol):
    old_rank = cryptocompare.get_market_cap_rank(symbol, days_back=30)
    new_rank = cryptocompare.get_market_cap_rank(symbol)

    if old_rank is None or new_rank is None:
        return 50

    if old_rank < new_rank:
        return 0
    if old_rank == new_rank:
        return 50
    if old_rank - 5 <= new_rank:
        return 75

    return 100

def get_pageview_growth(symbol):
    social_stats = cryptocompare.get_social_stats(symbol, days_back=7)
    old_page_views = social_stats[0]["total_page_views"]
    new_page_views = social_stats[-1]["total_page_views"]

    growth_pct = (new_page_views - old_page_views) / old_page_views
    return min(100, max(0, growth_pct * 1000))

RATING_COMPONENTS = [
    {"weight": 0.20, "name": "social_score", "title": "Social Score", "function": get_social_score},
    {"weight": 0.20, "name": "developer_score", "title": "Developer Score", "function": get_developer_score},
    {"weight": 0.20, "name": "fcas_score", "title": "FCAS Score", "function": get_fcas_score},
    {"weight": 0.10, "name": "30d_price", "title": "30-Day Price vs. BTC", "function": get_30d_price_score},
    {"weight": 0.05, "name": "30d_vol_growth", "title": "30-Day Volume Growth", "function": get_30d_vol_growth},
    {"weight": 0.10, "name": "rank_change", "title": "Rank Change", "function": get_rank_change},
    {"weight": 0.15, "name": "pageview_growth", "title": "CryptoCompare Total Pageview Growth", "function": get_pageview_growth},
]

def get_stansberry_score(symbol):
    total_score = 0
    for component in RATING_COMPONENTS:
        component_score = component["function"](symbol)
        if component_score is not None:
            total_score += component_score * component["weight"]

    return total_score

def letter_grade(score):
    ratings = [
        (75, "A+"),
        (65, "A"),
        (60, "A-"),
        (55, "B+"),
        (50, "B"),
        (45, "B-"),
        (40, "C+"),
        (35, "C"),
        (30, "C-"),
        (25, "D+"),
        (20, "D"),
        (15, "D-"),
        ( 0, "F"),
    ]

    for min_score, letter in ratings:
        if score >= min_score:
            return letter

def get_coin_list():
    return set(coingecko.get_coin_list().keys()) & \
        set(cryptocompare.get_coin_list().keys()) & \
        set(flipside.get_coin_list().keys())

def update_rating(symbol):
    item = {"symbol": symbol, "score": Decimal(0), "score_components": []}
    for component in RATING_COMPONENTS:
        component_score = component["function"](symbol)
        if component_score is None:
            component_score = 0

        component_score = Decimal(component_score).quantize(Decimal("0.01"))
        item["score_components"].append({"name": component["name"], "score": float(component_score)})
        item["score"] += component_score * Decimal(component["weight"])

    item["score"] = float(item["score"].quantize(Decimal("0.01")))
    item["letter_grade"] = letter_grade(item["score"])

    upsert_mongo(item)

def update_all_ratings():
    coin_list = get_coin_list()
    logger.info("Found {} coins.".format(len(coin_list)))
    excluded = get_excluded_symbols()

    for symbol in coin_list:
        if symbol in excluded:
            continue

        try:
            logger.info("Updating rating for {}...".format(symbol))
            update_rating(symbol)
        except:
            logger.exception("Could not update rating for {}".format(symbol))

def get_rating(symbol):
    excluded = get_excluded_symbols()
    response = rating_table.find({'symbol': symbol})
    response = response[0]
    del response['_id']
    if response and response and symbol not in excluded:
        return response

def get_all_ratings():
    result = []
    excluded = get_excluded_symbols()
    response = rating_table.find({})
    for item in response:
      del item['_id']
      result.append(item)

    items = [i for i in result if i["symbol"] not in excluded]
    return items

def get_excluded_symbols():
    if len(excluded_symbols) == 0:
        response = excluded_table.find({})
        for item in response:
            excluded_symbols.add(item["symbol"])

    return excluded_symbols

def add_excluded_symbols(symbols):
    add_symbols = []
    for symbol in symbols:
      add_symbols.append({"symbol": symbol})

    excluded_table._insert_data(add_symbols, True)

def upsert_mongo(mongo_data):
    condition = {'symbol': mongo_data['symbol']}
    existing_data = rating_table.find(condition)

    if existing_data.count() > 0:
        rating_table._replace_data(condition, mongo_data)
    else:
        rating_table._insert_data(mongo_data)
