import requests
import urllib
from datetime import datetime, timedelta

from sbt_common import SbtGlobalCommon

config = SbtGlobalCommon.get_sbt_config()

BASE_URL = "https://api.coingecko.com/api/v3/"

symbol_to_id = {}

def do_request(urlpart, method="GET", data=None, params=None):
    url = urllib.parse.urljoin(BASE_URL, urlpart)
    req = requests.request(method, url, json=data, params=params)
    req.raise_for_status()

    return req.json()

def get_coin_list():
    coin_list = do_request("coins/list")
    for coin in coin_list:
        symbol_to_id[coin["symbol"].upper()] = coin["id"]

    return symbol_to_id

def get_id_from_symbol(symbol):
    if not symbol_to_id:
        get_coin_list()

    return symbol_to_id.get(symbol.upper())

def get_data(symbol):
    coin_id = get_id_from_symbol(symbol)
    if coin_id is None:
        return None

    return do_request("coins/" + coin_id)

def get_price(symbol, days_back=None):
    coin_id = get_id_from_symbol(symbol)
    if coin_id is None:
        return None

    if days_back is None:
        response = do_request("simple/price", params={"ids": coin_id, "vs_currencies": "USD"})
        return response[coin_id]["usd"]
    else:
        date = datetime.now() - timedelta(days=days_back)
        response = do_request("coins/{}/history".format(coin_id), params={"date": date.strftime("%d-%m-%Y")})
        if "market_data" in response:
            return response["market_data"]["current_price"]["usd"]

def get_pct_gain(symbol, days_back):
    price_current = get_price(symbol)
    price_past = get_price(symbol, days_back=days_back)
    if price_current is None or price_past is None:
        return None

    return (price_current - price_past) / price_past

def get_market_data(*symbols):
    ids = [get_id_from_symbol(i) for i in symbols]
    ids = filter(lambda i: i is not None, ids)

    params = {
        "vs_currency": "USD",
        "ids": ",".join(ids),
        "price_change_percentage": "24h",
        "order": "market_cap_desc",
    }

    return do_request("coins/markets", params=params)
