import logging

from . import articles
from . import crypto_ratings
from . import cryptocompare
from . import timeseries

from sbt_common import SbtGlobalCommon

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)

def run_updates():
    try:
        cryptocompare.update_coin_descriptions()
    except:
        logger.exception("Couldn't update coin descriptions")

    try:
        cryptocompare.update_market_cap_rankings()
    except:
        logger.exception("Couldn't update market cap rankings")

    try:
        timeseries.update_timeseries_data()
    except:
        logger.exception("Couldn't update timeseries data")

    try:
        crypto_ratings.update_all_ratings()
    except:
        logger.exception("Couldn't update crypto ratings")
