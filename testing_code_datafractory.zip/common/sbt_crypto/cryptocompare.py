import boto3
import pytz
import requests
import urllib
import uuid
from boto3.dynamodb.conditions import Key, Attr, And
from datetime import datetime, timedelta
from decimal import Decimal
from mongo_accessor import MongoAccessor
from sbt_common import SbtGlobalCommon
from mp_accessor import TableMappingGuid
from dd_accessor import DynamoAccessor

config = SbtGlobalCommon.get_sbt_config()
cc_config = config["api_feeds"]["cryptocompare"]
base_url = cc_config["base_url"]
api_key = cc_config["api_key"]

dynamo_accessor = DynamoAccessor()
session = boto3.session.Session(profile_name=config["aws"]["profile"])
dynamodb_client = session.client("dynamodb")
ranking_table = MongoAccessor('sbt_crypto_cap_rankings')
mapping_table = session.resource("dynamodb").Table(dynamo_accessor._get_environment_table_name("SBT_SYMBOL_EXCHANGE_MAPPING"))
symbol_to_id = {}

def do_request(urlpart, method="GET", data=None, params=None):
    url = urllib.parse.urljoin(base_url, urlpart)
    req = requests.request(method, url, json=data, params=params, headers={"Authorization": "Apikey " + api_key})
    req.raise_for_status()

    response = req.json()
    if "Data" in response:
        return response["Data"]

    return response

def get_coin_list():
    coin_list = do_request("all/coinlist")
    for coin in coin_list.values():
        symbol_to_id[coin["Symbol"].upper()] = coin["Id"]

    return symbol_to_id

def get_coin_descriptions():
    return do_request("all/coinlist")

def get_id_from_symbol(symbol):
    if not symbol_to_id:
        get_coin_list()

    return symbol_to_id.get(symbol.upper())

def get_prices(*symbols):
    symbol_list = ",".join(symbols)
    response = do_request("pricemulti", params={"fsyms": symbol_list, "tsyms": "USD"})

    return {k: v["USD"] for k, v in response.items()}

def get_social_stats(symbol, days_back=7):
    coin_id = get_id_from_symbol(symbol)
    if coin_id is None:
        return None

    return do_request("social/coin/histo/day", params={"coinId": coin_id, "aggregate": 1, "limit": days_back})

def get_market_cap_rank(symbol, days_back=0):
    timestamp = int((datetime.utcnow() - timedelta(days=days_back)).astimezone(pytz.utc).timestamp())
    condition = { 'symbol': symbol, 'date': { '$lt': timestamp } }
    
    response = ranking_table.find(condition)

    if response.count() > 0:
        return response[0]["ranking"]

def get_top_ranked(count=10):
    condition = { 'symbol': 'BTC' }
    response = ranking_table.find(condition)
    
    if response.count() > 0:
      timestamp = response[0]["date"]

    condition = { 'date': timestamp, 'ranking': { '$lte': count } }
    response = ranking_table.find(condition)
    top_ranked = []
    for item in response:
      del item['_id']
      top_ranked.append(item)
      
    return sorted(top_ranked, key=lambda x: x["ranking"])

def get_news():
    response = do_request("v2/news/")
    return response["Data"]

def update_market_cap_rankings():
    page = 0
    ranking = 1
    timestamp = int(datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0).astimezone(pytz.utc).timestamp())

    condition = { 'date': { '$lt': int((datetime.utcnow() - timedelta(days=60)).timestamp()) } }
    ranking_table.delete_many(condition)

    while True:
        current_rankings = do_request("top/mktcapfull", params={"limit": 10, "tsym": "USD", "page": page})
        if not current_rankings:
            return

        for coin in current_rankings:
            item = {
                "symbol": coin["CoinInfo"]["Name"],
                "date": timestamp,
                "ranking": ranking,
            }

            ranking_table._insert_data(item)
            ranking += 1

        page += 1
            
def update_coin_descriptions():
    coin_list = get_coin_descriptions()
    with mapping_table.batch_writer() as batch:
        for coin in coin_list.values():
            row = {
                "symbol": coin["Symbol"],
                "exchange": "CRYPTO",
                "composite_pk_id": "{}:CRYPTO".format(coin["Symbol"]),
                "entity_name": coin["CoinName"],
                "source": "CryptoCompare",
                "supports_streaming": False,
                "exchange_type": "CRYPTO",
                "exchange_name": "Cryptocurrency",
                "category": [TableMappingGuid.CRYPTOCURRENCY.value],
            }

            response = mapping_table.query(KeyConditionExpression=And(Key("symbol").eq(coin["Symbol"]), Key("exchange").eq("CRYPTO")))
            if response["Count"] > 0:
                row["guid"] = response["Items"][0]["guid"]
            else:
                row["guid"] = str(uuid.uuid4())

            batch.put_item(Item=row)
