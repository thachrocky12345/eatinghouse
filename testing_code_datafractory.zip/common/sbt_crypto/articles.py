import simplejson
import uuid
from datetime import datetime
from decimal import Decimal
from sbt_common import SbtGlobalCommon
from redis_manager import RedisManager
from process_external_articles import EsexternalArticles
from .cryptocompare import do_request
from mongo_accessor import MongoAccessor
from external_article import ExternalArticle

ARTICLE_SOURCE = "cryptocompare"

config = SbtGlobalCommon.get_sbt_config()
es = EsexternalArticles()
mongo_accessor = MongoAccessor('cryptocompare_articles')

redis_manager = RedisManager()
channel_name = "news"


def update_articles():
    articles = do_request("v2/news/")
    for article in articles:
        data = {
            "external_id": str(article["id"]),
            "source": ARTICLE_SOURCE,
            "external": True,
            "published_at": Decimal(article["published_on"]),
            "title": article["title"],
            "content": article["body"],
            "article_url": article["url"],
            "uuid": str(uuid.uuid4()),
            "created_at": str(Decimal(datetime.utcnow().timestamp())),
            "updated_at": str(Decimal(datetime.utcnow().timestamp())),
            'tickers': [ticker.lower() for ticker in article["categories"].split("|")],
            'channels': [channel.lower() for channel in article["tags"].split("|")],
            'authors': [article["source_info"]["name"]]
        }

        upsert_mongo_and_publish_to_channel(article, data)
        prepare_and_index_to_es(data)


def prepare_and_index_to_es(data):

    es_conditions = [
    {'external_id': data['external_id']},
    {'source': ARTICLE_SOURCE}]
    response = ExternalArticle.find_by(es_conditions)

    if len(response['articles']) > 0:
        if 'id' in response['articles'][0].keys():
            print('Updating' + response['articles'][0]['id'])
            data['uuid'] = response['articles'][0]['id']
            data['updated_at'] = response['articles'][0]['modifiedAt']
        else:
            data['uuid'] = str(uuid.uuid4())

    es.process(data)


def upsert_mongo_and_publish_to_channel(mongo_data, data):
    condition = {'id': mongo_data['id']}
    existing_data = mongo_accessor.find(condition)
    if existing_data.count() > 0:
        mongo_accessor._replace_data(condition, mongo_data)
    else:
        mongo_accessor._insert_data(mongo_data)
        redis_manager.publish(channel_name, simplejson.dumps(data))

def get_articles():
    articles = ExternalArticle.find([],{'start': 0, 'end': 10},[], [], ARTICLE_SOURCE)
    return articles
