import os
import sys
import logging
import cherrypy
import bottle
import requests
import random
import traceback
import service_utils
import simplejson as json
import pandas as pd
import numpy as np
from bottle import request
import datetime
import math

from api_service import app, start_app
from cache_utils import cached, get_cached_by_key, set_cached_by_key
from request_util import get_qs_str_param, get_qs_int_param, get_qs_ymd_date_param
from sbt_common import SbtGlobalCommon
from service_utils import ServiceUtilsGlobal
from sbt_common import SingletonServiceManager
from sbt_tradeit_accessor.tp_accessor import PortfolioList
from sbt_tradeit_accessor.tp_accessor import PortfolioAccessor
from mp_accessor import MappingAccessor
from mp_accessor import TableMappingGuid
from redis_manager import RedisManager
from services.util.auth_utils import authenticated, entitlements, authenticated_profile
from dateutil.relativedelta import relativedelta
from services.util.portfolio_formula import PortfolioFormula

from time import sleep

PORTERS_LIST = "PORTERS_LIST"
STOCK = "STOCK"
OPTION = "OPTION"
logger = SbtGlobalCommon.get_global_logger()
#TODO: Conditional if started by sbtdeployer use global otherwise...
upfm   = None
redis_manager = RedisManager()

MAX_TOKEN_VALIDITY = 60 * 60 * 2 # SSxMMxHH: seconds until expired

class UserPortfolioManager(object, metaclass=SingletonServiceManager):
  """
  UserPortfolioManager
  """
  _configured = False
  _COMBINED = 'combined'
  _PAIRED = 'paired'
  _CLOSE = 'close'

  def __init__(self, cfg):
    """
    :param cfg:
    """
    logger.info('UserPortfolioManager initializing...')
    self._logger  = SbtGlobalCommon.get_logger(logging.INFO, __name__)
    self.fin      = False
    self.env      = dict(os.environ)
    self.accessor = None
    self.cfg      = cfg
    self.tradeit_config = SbtGlobalCommon.get_sbt_config()['tradeit']

    self._logger.info('Environment:\n' + str(self.env))
    self._streaming_supported_exchanges_list = [
      'amex', 'bats', 'etf', 'nyse',
      'nsdq', 'nsdqcm', 'nysearca', 'otc', 'obb'
    ]

    self.portfolio_returns = {
      "daily_gain_value": 0,
      "daily_gain_percent": 0,
      "total_gain_value": 0,
      "total_gain_percent": 0,
      "invested_amount_all": 0,
      "invested_amount_open": 0
    }

    self._configure()

  def _configure(self):
    """
    Configure
    :return:
    """
    logger.info("UserPortfolioManager: configuring...")

    self.accessor = PortfolioAccessor(self.cfg)
    self._mapping_accessor = MappingAccessor()
    self._stock_table_mapping = \
      self._mapping_accessor.get_table_mapping(
        TableMappingGuid.US_COMPANY_STOCK_PRICE.value)

    UserPortfolioManager._configured = self.accessor.isconfigured()

    return UserPortfolioManager._configured

  @staticmethod
  def isconfigured():
    """
    :return:
    """
    return UserPortfolioManager._configured

  def __enter__(self):
    """
    Entry Point
    :return:
    """
    return self

  def __exit__(self, exception_type, exception_value, traceback):
    """
    Exit Point
    :return:
    """
    if not self.fin:
      self.fin = True
      self.clean()
      sleep(2)
    else:
      sleep(1)

    self._logger.info('INFO: System exiting now!')

    sys.exit(0)

  def clean(self):
    """
    Cleanup
    :return:
    """
    if self.fin:
      self._logger.info('INFO: cleaning up...')
      bottle.response.headers['Connection'] = 'close'
    else:
      self._logger.info('INFO: clean ignored')

  def get_pfs(self):
    """
    Retrieve the set of all portfolios
    :return:
    """
    pfs = self.accessor.get_pfs()

    return pfs

  def get_portfolio_list (self, list_name, limit=None):
    """
      Returns a specific portfolio list from the database.

      Args :
        list_name(str) : Portfolio List enum value
        limit(int) : Number of records to return.

      Returns :
        (dict) : The data associated with the list
    """
    ret_value = {}
    rec = self.accessor.get_portfolio_list(list_name)

    if SbtGlobalCommon.collectionsutil.is_not_empty(rec) and \
    'values' in rec:
      if list_name == PortfolioList.CONVICTION_BUYS.value or \
      list_name == PortfolioList.NEWEST_RECOMMENDATIONS.value :
        cur_list_date = self._populate_stock_price(rec['date'], rec['values'])
        if cur_list_date != rec['date'] :
          rec['date'] = cur_list_date

      ret_value = dict(rec)

      if limit and limit > 0 and len(rec['values']) > limit :
        ret_value['values'] = ret_value['values'][0:limit]

    return ret_value

  def get_conviction_buy_list(self, filter_type, page, page_size, from_dt, to_dt):
    return self.accessor.get_conviction_buy_list(filter_type, page, page_size, from_dt, to_dt)

  def get_portfolio_buy_sell_list(self, page, page_size, from_dt, to_dt, publication_codes):
    return self.accessor.get_portfolio_buy_sell_info(page, page_size, from_dt, to_dt, publication_codes)

  def get_pf_info(self, pfid):
    """
    Retrieve tab info for the specified portfolio
    :param pfid:
    :return:
    """
    return self.accessor.get_pf_info(pfid)

  def get_all_pf_info(self):
    """
    Retrieve all tab info for the specified portfolio
    :return:
    """
    return self.accessor.get_pf_all_info()

  def get_all_managed_pf_list(self,user=None):
    """
    Retrieve all tab info for the specified portfolio
    :return: portfolio manager list by user
    """
    return self.accessor.get_all_managed_pf_list(user)

  def get_all_managed_pf_list_by_broker(self,user=None,broker=None):
    """
    Retrieve all tab info for the specified portfolio
    :return: portfolio manager list by user
    """
    return self.accessor.get_all_managed_pf_list_by_broker(user,broker)

  def get_tradeit_api_key(self):
    return self.tradeit_config['apikey']

  def make_tradeit_call(self, url, payload):
    url = self.tradeit_config['baseurl'] + url
    data = requests.post(url, params=payload)
    return data.json()['status'] == 'SUCCESS', data.json()

  def get_tradeit_sessions(self, user_id):
    return self.accessor.get_tradeit_sessions(user_id)

  def store_tradeit_session(self, data=None):
    return self.accessor.store_tradeit_session(data)

  def create_managed_pf(self,data=None):
    """
    Add portfolio info for the specified portfolio to list
    :return:
    """
    return self.accessor.create_managed_pf(data)

  def delete_managed_pf(self,pfid=None):
    """
    Delete specified portfolio
    :return:
    """
    return self.accessor.delete_managed_pf(pfid)

  def update_pf_n_managed_pf(self,data=None):
    """
    Update specified portfolio
    :return:
    """
    return self.accessor.update_pf_n_managed_pf(data)

  def create_ps_n_managed_pf(self,data=None):
    """
    Update specified portfolio
    :return:
    """
    return self.accessor.create_ps_n_managed_pf(data)

  def get_all_positions_n_list(self,pdif=None):
    """
    Retrieve all tab info for the specified portfolio
    :return:
    """
    return self.accessor.get_all_positions_n_list(pdif)

  def get_symbol_details(self, symbols):
    return self.accessor.get_symbol_details(symbols)

  def get_company_description(self, valid_symbol):
    return self.accessor.get_company_description(valid_symbol)

  def is_barchart_stock(self, symbol):
    parts = None
    if '~' in symbol :
      parts = symbol.split('~')[-1]
    elif ':' in symbol :
      parts = symbol.split(':')[-1]

    if parts != None:
      return parts.lower() in self._streaming_supported_exchanges_list
    else:
      return False

  def filter_streaming_symbols(self, symbol_exchanges):
    streaming_symbols = []
    non_streaming_symbols = []
    if symbol_exchanges:
      for symbol_exchange in symbol_exchanges:
        if self.is_barchart_stock(symbol_exchange):
          streaming_symbols.append(symbol_exchange)
        else:
          non_streaming_symbols.append(symbol_exchange)

    return streaming_symbols, non_streaming_symbols

  def get_market_quote(self, symbol_exchanges):
    return self.accessor.get_market_quote(symbol_exchanges)

  def add_portfolio_value(self, total_portfolio, group_portfolio):
    total_portfolio["daily_gain_value"] += group_portfolio["daily_gain_value"]
    total_portfolio["total_gain_value"] += group_portfolio["total_gain_value"]
    total_portfolio["invested_amount_open"] += group_portfolio["invested_amount_open"]
    total_portfolio["invested_amount_all"] += group_portfolio["invested_amount_all"]

    return total_portfolio

  def calculate_returns_percentage(self, portfolio):
    if portfolio["invested_amount_open"] != 0:
      portfolio["daily_gain_percent"] = (portfolio["daily_gain_value"] / portfolio["invested_amount_open"]) * 100

    if portfolio["invested_amount_all"] != 0:
      portfolio["total_gain_percent"] = (portfolio["total_gain_value"] / portfolio["invested_amount_all"]) * 100

    return portfolio

  def get_pf_options_returns(self, positions):
    symbols = set()
    all_options_data = {}

    for position in positions:
      symbols.add(position['symbol'])

    for symbol in symbols:
      if symbol:
        symbol_data = self.accessor.get_option_data(symbol[0: -11])
        if symbol_data['success'] and len(symbol_data['result']) > 0:
          options = symbol_data['result'][0].get('data', None)
          if options and len(options) > 0:
            for option in options:
              if option['id'] == symbol:
                all_options_data[symbol] = option
                break

    for position in positions:
      # Load Default Values
      position['latest_close'] = 0
      position['dividend_total'] = 0
      position['dividend_yield'] = 0
      position['latest_dividend'] = 0
      position['volatility'] = 0
      position['current_price'] = 0
      position['daily_gain_value'] = 0
      position['daily_gain_percent'] = 0
      position['total_gain_value'] = 0
      position['total_gain_percent'] = 0
      position['one_year_high'] = 0
      position['one_year_low'] = 0
      position['support_streaming'] = False
      position['valid'] = False

      if all_options_data and all_options_data.get(position['symbol'], None):
        option_data = all_options_data[position['symbol']]
        position['valid'] = True
        position['latest_close'] = option_data['closingPrice']
        position['current_price'] = option_data['closingPrice']
        expiry_date = datetime.datetime.strptime(option_data['expirationDate'], '%Y%m%d')
        position['name'] = option_data['symbol'] + ' ' + expiry_date.strftime("%b %d") + ' $' + \
                           str(option_data['strikePrice']) + ' ' +option_data['side']

    return upfm.options_calculate_returns(positions)

  def get_group_returns(self, group):
    positions = group['positions']
    stock_portfolio = {}
    option_portfolio = {}
    total_portfolio = dict(self.portfolio_returns)

    if group["parent_position_guid"]:
      group["sum_entry_price"] = 0
      group["sum_recent_close_price"] = 0
      group["sum_dividend_total"] = 0
      group["sum_total_returns"] = 0

    if len(positions) > 0:
      for position in positions:
        # Replace with default values
        position['symbol'] = position.get('symbol', '')
        position['exchange'] = position.get('exchange', '')
        position['entry_date'] = position.get('entry_date', None)
        position['entry_price'] = position.get('entry_price', 0.0)
        position['num_shares'] = position.get('num_shares', 0)
        position['status_type'] = position.get('status_type', '')
        position['close_date'] = position.get('close_date', None)
        position['close_price'] = position.get('close_price', 0)
        position['trade_type'] = position.get('trade_type', 'Long')
        position['status'] = position.get('status', 'Buy')
        position["option_type"] = position.get("option_type", "put")
        position["instrument_type"] = position.get("instrument_type", STOCK)

      stock_positions = [position for position in positions if position["instrument_type"].upper() == STOCK]
      option_positions = [position for position in positions if position["instrument_type"].upper() == OPTION]

      positions = []

      if stock_positions:
        stock_positions, stock_portfolio = upfm.get_pf_returns(stock_positions)
        if stock_positions:
          total_portfolio = upfm.add_portfolio_value(total_portfolio, stock_portfolio)
          positions.extend(stock_positions)

      if option_positions:
        option_positions, option_portfolio = upfm.get_pf_options_returns(option_positions)
        if option_positions:
          total_portfolio = upfm.add_portfolio_value(total_portfolio, option_portfolio)
          positions.extend(option_positions)

      if total_portfolio:
        total_portfolio = upfm.calculate_returns_percentage(total_portfolio)

      if group['type'] == upfm._COMBINED:
        for pos in positions:
          if pos['valid']:
            current_or_close_price = pos['close_price'] if pos['status_type'].lower() == upfm._CLOSE else pos['current_price']
            current_or_close_price = current_or_close_price if current_or_close_price else 0

            group['sum_entry_price'] += pos['entry_price']
            group['sum_recent_close_price'] += current_or_close_price
            group['sum_dividend_total'] += pos['dividend_total']

        if group['sum_entry_price'] != 0:
          if group.get('default_pos_type', 'LONG').lower() == 'long':
            group['sum_total_returns'] = ((group['sum_recent_close_price'] + group['sum_dividend_total'] -
                                               group['sum_entry_price']) / group['sum_entry_price']) * 100
          else:
            group['sum_total_returns'] = ((group['sum_entry_price'] - group['sum_dividend_total'] -
                                               group['sum_recent_close_price']) / group['sum_entry_price']) * 100

      if group['type'] == upfm._PAIRED:
        total_return_percentage = [pos['total_gain_percent'] for pos in positions if pos['valid']]
        group['sum_total_returns'] = sum(total_return_percentage) / len(positions)

      group['positions'] = positions

    # Load the portfolio calculation in group
    group['portfolio'] = total_portfolio

    return group

  def get_pf_returns(self, positions):
    valid_symbols = set()
    trading_data = []

    for position in positions:
      position['trading_item_id'] = ''

      if position['symbol'] and position['exchange']:
        position['composite_pk_id'] = position['symbol'] + ':' + position['exchange']

        data = self.accessor.get_sbt_from_symbol_and_exchange(position['symbol'].upper(), position['exchange'].upper())
        if data:
          position['trading_item_id'] = str(data['snp_trading_item_id'])

    composite_pk_ids = [position['composite_pk_id'] for position in positions if position.get('composite_pk_id', 0) != 0]

    if composite_pk_ids:
      trading_data = self.accessor.get_trading_data(composite_pk_ids)

    for position in positions:
      # Load Default Values
      position['latest_close'] = 0
      position['dividend_total'] = 0
      position['dividend_yield'] = 0
      position['latest_dividend'] = 0
      position['volatility'] = 0
      position['current_price'] = 0
      position['daily_gain_value'] = 0
      position['daily_gain_percent'] = 0
      position['total_gain_value'] = 0
      position['total_gain_percent'] = 0
      position['one_year_high'] = 0
      position['one_year_low'] = 0
      position['support_streaming'] = False
      position['valid'] = False

      if position['num_shares'] > 0 and position['entry_price'] > 0 and \
          position['entry_date'] and trading_data and position.get('composite_pk_id', None):
        staging_data = None

        for each_trading_data in trading_data:
          if position['composite_pk_id'] == each_trading_data['composite_pk_id']:
            staging_data = each_trading_data
            break

        if staging_data:
          position['valid'] = True
          position['volatility'] = self.round(staging_data['volatility'])
          position['one_year_high'] = self.round(staging_data['price_highest'])
          position['one_year_low'] = self.round(staging_data['price_lowest'])
          position['latest_close'] = self.round(staging_data['last_close_price'])
          position['dividend_yield'] = self.round(staging_data['dividend_yield'])
          position['latest_dividend'] = self.round(staging_data['latest_dividend'])
          position['name'] = staging_data['name']

          for key in self.accessor._METRICS_METADATA:
            if key in staging_data:
              position[key] = staging_data[key]

          valid_symbols.add(position['symbol'] + '~' + position['exchange'])

          if position.get('trading_item_id', None):
            dividend_total = self.accessor.get_dividend_total(position['trading_item_id'], position['status_type'],
                                                              position['entry_date'], position['close_date'])
            if dividend_total:
              position['dividend_total'] = self.round(dividend_total[0]['dividend_total'])

    if valid_symbols:
      streaming_symbols, non_streaming_symbols = upfm.filter_streaming_symbols(valid_symbols)

      if streaming_symbols:
        current_price_data = upfm.get_market_quote(",".join(streaming_symbols))
        if current_price_data['success']:
          for position in positions:
            for each_position in current_price_data['results']:
              if position['symbol'] == each_position['symbol'] and (
                not position['exchange'] or position['exchange'] == each_position['exchange']):
                position['current_price'] = self.round(each_position['last_price'])
                position['support_streaming'] = True
                break

      if non_streaming_symbols:
        for non_streaming_symbol in non_streaming_symbols:
          for position in positions:
            if position['symbol'] + '~' + position['exchange'] == non_streaming_symbol:
              position['current_price'] = self.round(position['latest_close'])
              position['support_streaming'] = False
              break

    return upfm.calculate_returns(positions)

  def options_calculate_returns(self, positions):
    portfolio = dict(self.portfolio_returns)

    for pos in positions:
      if pos["current_price"] != 0 and pos["entry_price"] != 0:

        margin_percentage = 0
        if pos.get("margin", None):
          if pos["margin"]:
            capital_at_risk = pos["shares_purchased"] * pos["strick_price"]
            margin_percentage = pos["margin"] * capital_at_risk

        contract_type = pos["status"].lower() + "_" + pos["option_type"].lower()

        if contract_type == "buy_put" or contract_type == "sell_put":
          pos["total_gain_value"] = pos["current_price"] - pos["entry_price"]
          pos["total_gain_value_formula"] = "Current Price - Entry Price \n {current_price} - {entry_price}".format(
              current_price=pos["current_price"], entry_price=pos["entry_price"])

          if pos["entry_price"]:
            pos["total_gain_percent"] = self.round(((pos["current_price"] - pos["entry_price"]) / pos["entry_price"]) * 100)
            pos["total_gain_percentage_formula"] = "((Current Price - Entry Price) / Entry Price) * 100 \n ((" \
                                                   "{current_price} - {entry_price}) / {entry_price}) * 100".\
              format(current_price=pos["current_price"], entry_price=pos["entry_price"])

        else:
          if margin_percentage and margin_percentage > 0:
            pos["total_gain_value"] = 0
            pos["total_gain_percent"] = self.round(((pos["entry_price"] - pos["current_price"]) / margin_percentage) * 100)

            pos["total_gain_value_formula"] = ""
            pos["total_gain_percentage_formula"] = "((Entry Price - Current Price) / Margin Percentage) * 100 \n ((" \
                                                   "{entry_price} - {current_price}) / {margin_percentage}) * 100".\
              format(current_price=pos["current_price"], entry_price=pos["entry_price"], margin_percentage=margin_percentage)

          else:
            pos["total_gain_value"] = self.round(pos["entry_price"] - pos["current_price"])
            if pos["entry_price"]:
              pos["total_gain_percent"] = self.round(((pos["entry_price"] - pos["current_price"]) / pos["entry_price"]) * 100)

            pos["total_gain_value_formula"] = "Entry Price - Current Price \n {entry_price} - {current_price}".format(
                entry_price=pos["entry_price"], current_price=pos["current_price"])

            pos["total_gain_percentage_formula"] = "((Entry Price - Current Price) / Entry Price) * 100 \n ((" \
                                                   "{entry_price} - {current_price}) / {entry_price}) * 100".\
              format(current_price=pos["current_price"], entry_price=pos["entry_price"])

        portfolio["total_gain_value"] += pos["total_gain_value"]
        portfolio["invested_amount_open"] += (pos['entry_price'] * pos['num_shares'])
        portfolio["invested_amount_all"] += (pos['entry_price'] * pos['num_shares'])

        pos["daily_gain_value_formula"] = ""
        pos["daily_gain_percentage_formula"] = ""


      if portfolio["invested_amount_all"] != 0:
        portfolio["total_gain_percent"] = (portfolio['total_gain_value'] / portfolio["invested_amount_all"]) * 100

    return positions, portfolio

  def calculate_returns(self, positions):
    portfolio = {
      'daily_gain_value': 0,
      'daily_gain_value_formula': "Sum of Open Positions' Today's Return",
      'daily_gain_percent': 0,
      'daily_gain_percent_formula': "",
      'total_gain_value': 0,
      'total_gain_value_formula': "Sum of all Positions' Total Returns",
      'total_gain_percent': 0,
      'total_gain_percent_formula': "",
      'current_value': 0,
      'invested_amount_open': 0,
      'invested_amount_all': 0,
      'invested_amount_all_formula': "Sum of all Positions' Cost Basis Value"
    }

    for pos in positions:
      if pos['current_price'] != 0 and pos['latest_close'] != 0:
        pos['daily_gain_value'] = self.round((pos['current_price'] - pos['latest_close']) * pos['num_shares'])
        if pos['latest_close'] > 0:
          pos['daily_gain_percent'] = self.round(((pos['current_price'] - pos['latest_close']) / pos['latest_close']) * 100)

        current_or_close_price = pos['close_price'] if pos['status_type'].lower() == 'close' else pos['current_price']
        current_or_close_price = current_or_close_price if current_or_close_price else 0

        if pos['trade_type'].lower() == 'long':
          pos['total_gain_value'] = self.round((current_or_close_price - pos['entry_price'] + pos['dividend_total']) * pos['num_shares'])
        else:
          pos['total_gain_value'] = self.round((pos['entry_price'] - current_or_close_price - pos['dividend_total']) * pos['num_shares'])

        pos['total_gain_percent'] = self.round((pos['total_gain_value'] / (pos['entry_price'] * pos['num_shares'])) * 100)

        pf_formula = PortfolioFormula(pos)
        pos['daily_gain_value_formula'] = pf_formula.get_daily_gain_formula()
        pos['daily_gain_percentage_formula'] = pf_formula.get_daily_percentage_formula()
        pos['total_gain_value_formula'] = pf_formula.get_total_gain_formula()
        pos['total_gain_percentage_formula'] = pf_formula.get_total_percentage_formula()

        if pos['status_type'].lower() == 'open':
            portfolio['daily_gain_value'] += pos['daily_gain_value']
            portfolio['invested_amount_open'] += (pos['entry_price'] * pos['num_shares'])

        portfolio["total_gain_value"] += pos["total_gain_value"]
        portfolio["invested_amount_all"] += (pos['entry_price'] * pos['num_shares'])
        portfolio["current_value"] += (pos['current_price'] * pos['num_shares'])

    if portfolio['daily_gain_value'] != 0 and portfolio['invested_amount_open'] != 0:
      portfolio['daily_gain_percent'] = (portfolio['daily_gain_value'] / portfolio['invested_amount_open']) * 100
      portfolio['daily_gain_percent_formula'] = "(Sum of Open Positions' Today's Return / Sum of Open Positions' Cost Basis Value) * 100 \n" + \
                                                "({daily_gain_value} / {invested_amount_open}) * 100".format(
                                                    daily_gain_value = portfolio['daily_gain_value'],
                                                    invested_amount_open = portfolio['invested_amount_open']
                                                )
    if portfolio['total_gain_value'] != 0 and portfolio["invested_amount_all"] != 0:
      portfolio['total_gain_percent'] = (portfolio['total_gain_value'] / portfolio["invested_amount_all"]) * 100
      portfolio['total_gain_percent_formula'] = "(Sum of all Positions' Total Returns / Sum of all Positions' Cost Basis Value) * 100 \n" + \
                                                "({total_gain_value} / {invested_amount_all}) * 100".format(
                                                    total_gain_value = portfolio['total_gain_value'],
                                                    invested_amount_all = portfolio['invested_amount_all']
                                                )

    return positions, portfolio

  def round(self, num, default=0):
    if (isinstance(num, float) and not math.isnan(num)) or isinstance(num, int):
      # return round(num, 2)
      return num # UI will handle the rounding mechanism
    else:
      return default

  def get_all_position_company_snapshot(self,positions):
    """
    Retrieve all company snapshot data for each position
    :return:
    """
    symbol_exchange_mappings = {}

    for item in positions:

      mapping = self._mapping_accessor.unique_stock_symbol_exchange_mapping( \
          item.get('symbol'), \
          exchange=item.get('exchange')
        )

      # Look up last close price by using exchange
      # Function query_stock_price() in file snp_accessor.py is using attribute 'vendor_exchange_code' for exchange value
      # Load exchange value as 'vendor_exchange_code'
      if mapping and 'exchange' in mapping and mapping['exchange']:
        mapping['vendor_exchange_code'] = mapping['exchange']

      if 'guid' in mapping:
        symbol_exchange_mappings[item.get('symbol')] = mapping


    return self.accessor.get_company_list_data(symbol_exchange_mappings)


  def get_all_position_company_snapshot_tradeit(self,all_symbols):
    """
    Retrieve all company snapshot data for each position
    :return:
    """
    validate_symbols = upfm.get_symbol_details(','.join(all_symbols))

    all_positions = {}
    for validate_symbol in validate_symbols:
      position = {}
      if validate_symbol['valid']:
        guid = validate_symbol['guid']
        company_description = upfm.get_company_description(guid)
        if company_description:
          if company_description['dividendyield'] != 'N/A':
            if isinstance(company_description['dividendyield'], float):
              position['dividendyield'] = upfm.round(company_description['dividendyield'] * 100)
            elif isinstance(company_description['dividendyield'], dict) and 'value' in company_description['dividendyield']:
              position['dividendyield'] = upfm.round(company_description['dividendyield']['value'])

          position['volatility'] = upfm.round(company_description['volatility']) if company_description['volatility'] != 'N/A' else 0
          all_positions[validate_symbol['symbol']] = position

    return all_positions

  def adj_portfolio_rebal(self,pf_list=None):
    """
    Retrieve all tab info for the specified portfolio
    :return:
    """
    return self.accessor.adj_portfolio_rebal(pf_list)


  def import_portfolio(self, df, user):
    """
    Retrieve all tab info for the specified portfolio
    :return:
    """

    # extract the portfolio and position  details from input excel
    df_read = df

    snaid         =  user.get('snaid')
    user_id       =  user.get('guid')
    create_time   = datetime.datetime.now()
    commission    = df_read['Commission'].iloc[0]
    description   = df_read['Description'].iloc[0]
    name          = df_read['Portfolio Name'].iloc[0]
    cash          = df_read['Cash'].iloc[0]

    portofolio_list = {
                      "user_id"       : user_id,
                      "name"          : name,
                      "create_time"   : create_time,
                      "description"   : description,
                      "dividends"     : 0.00,
                      "value"         : 0.00,
                      "num_positions" : 0,
                      "day_gain"      : 0.00,
                      "cash"          : cash,
                      "commission"    : commission,
                      "notes"         : "",
                      "delisted"      : "false",
                      "currency_id"   : "USD",
                      "snaid"         : snaid,
                      "third_party"   : "",
                      "type"          : ""
                    }
    if upfm.create_managed_pf(portofolio_list):

       portfolio_guid = self.accessor.get_portfolio_guid(user_id, create_time, name)

       for index, row in df_read.iterrows():

           position_list = {
                    "symbol"             : row['Symbol'],
                    "name"               : name,
                    "num_shares"         : row['Shares'],
                    "value"              : row['Current Price'] * row['Shares'],
                    "entry_price"        : row['Entry Price'],
                    "trade_type"         : row['Trade Type'],
                   "status_type"         : "Open",
                    "portfolio_guid"     : portfolio_guid,
                    "entry_date"         : create_time,
                    "user_id"            : user_id,
                    "snaid"              : snaid,
                    "current_price"      : row['Current Price'],
                    "daily_gain_value"   : 0,
                    "daily_gain_percent" : 0,
                    "total_gain_value"   : 0,
                    "total_gain_percent" : 0,
                    "exchange"           : row['Exchange'],
                    "one_year_high"      : 0
                 }

           if upfm.create_ps_n_managed_pf(position_list):
              rval = {'success': True, 'user': user_id}
           else:
              rval = {'success': False, 'error': 'Could not add position'}

    else:
       rval = {'success': False, 'error': 'Could not add position'}

    return rval


  def vol_rebal(self,pf_list=None):
    """
    Retrieve all tab info for the specified portfolio
    :return:
    """
    return self.accessor.vol_rebal(pf_list)


  def update_ps_n_pf(self,data=None):
    """
    Update specified position in portfolio
    :return:
    """
    return self.accessor.update_ps_n_pf(data)

  def delete_ps_n_pf(self,guid=None):
    """
    Delete specified position
    :return:
    """
    return self.accessor.delete_ps_n_pf(guid)

  def get_first_pf(self):
    """

    :return:
    """
    return self.accessor.get_pf_first()

  def get_all_pf_pos_info(self, pfid):
    """

    :return:
    """
    return self.accessor.get_all_pf_pos_info(pfid)

  def get_pf_pos_info(self, id):
    """

    :return:
    """
    return self.accessor.get_pf_pos_info(id)

  def get_pf_pos_list(self, pfid):
    """

    :return:
    """
    return self.accessor.get_pf_pos_list(pfid)

  def get_pf_pos_status(self, pfid):
    """

    :return:
    """
    return self.accessor.get_pf_pos_status(pfid)

  def get_pf_pos_status_lam(self, pfid):
    """

    :return:
    """
    return self.accessor.get_stansberry_portfolio_positions(pfid)

  def get_pf_pos_status_static(self, pfid):
    """

    :return:
    """
    return self.accessor.get_static_pf(pfid)

  def _populate_stock_price (self, list_date, list_values):
    current_date = SbtGlobalCommon.dateutil.get_current_date_string()

    for r in list_values :
      if current_date != list_date or 'stock_price' not in r :
        logger.info('Pull stock prices for portfolio list.')
        sp = self._get_latest_stock_price(r['guid'])
        r['stock_price'] = sp

    return current_date

  def _get_latest_stock_price (self, guid):
    stock_price = 0.00

    results = self._mapping_accessor.query_table_by_mapping(
                self._stock_table_mapping, guid)

    if SbtGlobalCommon.collectionsutil.is_not_empty(results) :
      sorted_results = sorted(results, key=lambda k: k['timestamp'],
                              reverse=True)
      temp_stock = sorted_results[0]
      if 'values' in temp_stock and 'adj_close' in temp_stock['values'] :
        stock_price = temp_stock['values']['adj_close']

    return stock_price

  @staticmethod
  def _get_response(url, headers=None):
    """

    :param url:
    :param headers:
    :return:
    """
    if headers is None:
      headers = {}

    req = requests.get(url, headers=headers)

    return req.json()

@app.hook('before_request')
def strip_path():
  """
  IGNORE TRAILING SLASHES IN BOTTLE ROUTES
  :return:
  """
  service_utils.strip_path()



@app.route("/tp/portfolio/plaid", method="POST")
@app.route("/tp/portfolio/plaid", method="PUT")
@authenticated_profile
def update_and_insert_user_broker_portfolio(user):

  try:
    post_data = json.loads(json.dumps(bottle.request.json))
    post_data["user_id"] = user.get("guid")
    logger.info('loading portfolio for user {user_id}'.format(**post_data))

    rval = upfm.accessor.load_plaid_user_portfolio(post_data)
    if rval:
      rval = {'success': True, 'results': "portfolio loaded"}
    else:
      rval = {'success': False, 'error': 'Portfolio Could not load'}

  except Exception as e:
    rval = {'success': False, 'error': 'Portfolio Could not load from user: {}'.format(user.get("guid"))}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval



@app.route("/tp/portfolio/list", method="GET")
@app.route("/tp/portfolio/list/", method="GET")
@authenticated_profile
def get_managed_portfolio_list(user):
  """
  :return: Portfolio list
  """
  rval = {}
  broker = ''
  pf_list = []
  user_type = 'STANSBERRY_USER'
  user_obj = {}

  try:
    logger.info("Looking up portfolio manager list for user " + user.get('guid'))

    if bottle.request.query_string:
      broker = bottle.request.query_string.split('=')[1]
      logger.info("Sort by broker " + broker)
      pf_list = upfm.get_all_managed_pf_list_by_broker(user.get('guid'),broker)
    else:
      pf_list = upfm.get_all_managed_pf_list(user.get('guid'))


    if user:
      user_obj = user;
      if 'user_profile_type' in user:
        user_type = user['user_profile_type']

    rval = {'success' : True, 'user_obj': user_obj, 'user': user_type,
             'pf_list' : pf_list}
  except Exception as e:
    rval = {'success': False, 'error': 'Error trying to retrieve portfolios ' \
                                       + 'for user ' + user['guid']}
    bottle.abort(400,"encountered exception: " + str(e))

  return rval

@app.route("/tp/portfolio/create/", method="POST")
@app.route("/tp/portfolio/create", method="POST")
@authenticated_profile
def add_managed_portfolio(user):
  """
    :return: Success if able to add new entry in table
  """
  rval = {}
  user_type = 'FREE_USER'
  user_obj = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    data['user_id'] = user.get('guid')
    logger.info('Adding portfolio to portfolio manager list for user ' + \
                data.get('user_id') )
    if user:
      user_obj = user;
      if 'user_profile_type' in user:
        user_type = user['user_profile_type']

    if upfm.create_managed_pf(data):
      rval = { 'success' : True, 'user_obj': user_obj, 'user': user_type }

  except Exception as e:
    rval = {'success': False, 'error': 'Could not add portfolio'}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval

@app.route("/tp/portfolio/delete/<pfid>", method="DELETE")
@authenticated
def delete_managed_portfolio(pfid):
  """
    :return: Successfully deleted entry in table
  """
  rval = {}

  try:
    logger.info('Deleting portfolio ' + pfid + ' to portfolio manager list')
    if upfm.delete_managed_pf(pfid):
      rval = {'success': True, 'message': 'The Portfolio ' + str(pfid)
              + ' was successfully deleted'}
    else:
      rval = { 'success' : False, 'error' : 'Could not delete portfolio '
               + pfid}
  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))
  return rval

@app.route("/tp/portfolio/update/", method="PUT")
@app.route("/tp/portfolio/update", method="PUT")
@authenticated_profile
def update_pf_n_managed_portfolio(user):
  """
    :return: Update portfolio in table
  """
  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    data['user_id'] = user.get('guid')
    logger.info("Updating portfolio in portfolio manager list " + \
                "for user id " + data['user_id'])
    if upfm.update_pf_n_managed_pf(data):
      rval = {'success': True, 'message':'Updated portfolio ' + data.get('guid')}
    else:
      rval = { 'success' : False, 'error' : 'Could not update portfolio' }
  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/position/create/", method="POST")
@app.route("/tp/position/create", method="POST")
@authenticated_profile
def add_ps_to_managed_portfolio(user):
  """
    :return: Success if able to add new entry in table
  """
  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    data['user_id'] = user.get('guid')
    logger.info('Adding position to portfolio for user ' + data.get('user_id') )
    if upfm.create_ps_n_managed_pf(data):
      rval = { 'success' : True , 'user': data.get('user_id')}
    else:
      rval = { 'success' : False, 'error' : 'Could not add position' }
  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/position/metrics/metadata", method="GET")
@authenticated
@cached('METRICS_METADATA', '60min')
def get_metrics_metadata():
  try:
    rval = {}
    metrics_data = upfm.accessor.get_financial_meta_data()
    for fin in metrics_data:
      for key in upfm.accessor._METRICS_METADATA:
        if fin["data_item_id"] == int(upfm.accessor._METRICS_METADATA[key]):
          fin["key"] = key

    rval = {'success': True, 'metrics_data': metrics_data}
  except Exception as e:
    logger.exception("Exception in get_metrics_metadata")
    rval = {'success': False, 'error': 'Encountered exception ' + str(e)}

  return rval

@app.route("/tp/position/returns", method="POST")
@authenticated
def get_positions_returns():
  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    groups = data.get('groups')
    total_portfolio = dict(upfm.portfolio_returns)

    for each_group in groups:
      group_portfolio = dict(upfm.portfolio_returns)
      each_group = upfm.get_group_returns(each_group)
      if each_group.get("portfolio", {}):
        group_portfolio = upfm.add_portfolio_value(group_portfolio, each_group["portfolio"])

      for child_group in each_group["child_groups"]:
        child_group = upfm.get_group_returns(child_group)
        if child_group.get("portfolio", {}):
          group_portfolio = upfm.add_portfolio_value(group_portfolio, child_group["portfolio"])

      group_portfolio = upfm.calculate_returns_percentage(group_portfolio)
      each_group["portfolio"] = group_portfolio
      total_portfolio = upfm.add_portfolio_value(total_portfolio, group_portfolio)

    total_portfolio = upfm.calculate_returns_percentage(total_portfolio)

    rval = {'success': True, 'groups': groups, 'portfolio': total_portfolio}
  except Exception as e:
    logger.exception("Exception in get_positions_returns")
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/position/list/<pdif>", method="GET")
@authenticated
def get_positions_n_managed_portfolio(pdif):
  """
  :return: Positions in portfolio by pdif uuid
  """
  rval = {}

  try:
    logger.info("Looking up positions by portfolio id")
    pf_list = upfm.get_all_positions_n_list(pdif)
    if len(pf_list) > 0:
      positions, portfolio = upfm.get_pf_returns(pf_list)
      rval = { 'success' : True, 'ps_list' : positions, 'portfolio' : portfolio}
    else:
      rval = { 'success' : False, 'error' : 'No position list retrieved' }
  except Exception as e:
    logger.exception("Exception in get_positions_n_managed_portfolio")
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/position/update/", method="PUT")
@app.route("/tp/position/update", method="PUT")
@authenticated_profile
def update_ps_n_managed_portfolio(user):
  """
    :return: Update position in portfolio
  """
  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    data['user_id'] = user.get('guid')
    logger.info("Updating position in portfolio manager")
    if upfm.update_ps_n_pf(data):
      rval = {'success': True, 'message': 'Updated position'}
    else:
      rval = { 'success' : False, 'error' : 'Could not update position' }
  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/position/delete/<guid>", method="DELETE")
@authenticated
def delete_ps_n_managed_portfolio(guid):
  """
    :return: Successfully deleted entry in table
  """
  rval = {}

  try:
    logger.info("Deleting position in portfolio manager list")
    if upfm.delete_ps_n_pf(guid):
      rval = {'success': True, 'message': 'Deleted position'}
    else:
      rval = { 'success' : False, 'error' : 'Could not delete position' }
  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/portfolio/register", method="GET")
def register():
  try:
    code = json.loads(json.dumps(bottle.request.json))
    logger.info("Callback for Authentication for TD Ameritrade started with code "
                + code )
    return {'success': True, 'json': json}
  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

@app.route("/tp/portfolio/first/", method="GET")
@app.route("/tp/portfolio/first", method="GET")
def get_first_portfolio():
  """

  :return:
  """
  logger.info("Received first portfolio request")

  portfolio = upfm.get_first_pf()

  if portfolio is not None:
    rval = { 'success' : True, 'tabinfo' : portfolio }
  else:
    rval = { 'success' : False, 'error' : 'No portfolios retrieved' }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/position/list/<pfid>", method="GET")
def get_portfolio_position_list(pfid):
  logger.info("Received portfolio position list request for id: " + pfid)

  position = upfm.get_pf_pos_list(pfid)

  if position:
    rval = {'success': True, 'position': position}
  else:
    rval = {
      'success': False,
      'error':   'Unable to retrieve portfolio position list for ' + pfid
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval


@app.route("/tp/rebalance/list/<pdif>", method="GET")
@authenticated
def portfolio_rebalancer(pdif):
  """
  :return: Positions in portfolio by pdif uuid
  """

  logger.info("Looking up positions by portfolio id")
  pf_list = upfm.get_all_positions_n_list(pdif)

  if len(pf_list) <= 0:
     rval = { 'success' : False, 'error' : 'No position list retrieved' }
  else:
     logger.info("Rebalancer algorithm ")

     symbol_exchanges = [pos["symbol"] + "~" + pos["exchange"] for pos in pf_list if pos["symbol"] and pos["exchange"]]

     if symbol_exchanges:
       current_price_data = upfm.get_market_quote(",".join(symbol_exchanges))
       if current_price_data['success']:
         for position in pf_list:
           position["current_price"] = 0

           for each_position in current_price_data['results']:
             if position['symbol'] == each_position['symbol'] and (
                 not position['exchange'] or position['exchange'] == each_position['exchange']):
               position['current_price'] = each_position['last_price']
               break

     valid_positions = [pos for pos in pf_list if pos["current_price"] != 0]
     reballist = upfm.adj_portfolio_rebal(valid_positions)

     rval1 = {'success': True, 'ps_list': reballist}

     rval = json.dumps(rval1)

  return rval

@app.route("/tp/rebalance/vol/<pdif>", method="GET")
@authenticated
def rebalance_volatility(pdif):

  """
  :return: Positions in portfolio by pdif uuid
  """

  logger.info("Looking up positions by portfolio id")

  pf_list = upfm.get_all_positions_n_list(pdif)

  if len(pf_list) <= 0:
     rval = { 'success' : False, 'error' : 'No position list retrieved' }
  else:
     logger.info("Rebalancer algorithm ")
     positions, portfolio = upfm.get_pf_returns(pf_list)
     valid_positions = [pos for pos in positions if pos["current_price"] != 0]

     reballist = upfm.vol_rebal(valid_positions)

     rval1 = {'success': True, 'ps_list': reballist}

     rval = json.dumps(rval1)

  return rval

@app.route("/tp/rebalance/save/", method="POST")
@app.route("/tp/rebalance/save", method="POST")
@authenticated
def save_portfolio():
  """
    :return: Success if able to add new entry in table
  """

  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    data_portfolio = data.get('portfolio')
    data1_positions = data.get('rebalancer')

    logger.info('Adding portfolio to portfolio manager list for user ' + data.get('user_id'))

    if upfm.create_managed_pf(data_portfolio):
      for pos_list in data1_positions:
        if upfm.create_ps_n_managed_pf(pos_list):
          rval = {'success': True, 'user': data.get('user_id')}
        else:
          rval = {'success': False, 'error': 'Could not add position'}
    else:
      rval = {'success': False, 'error': 'Could not add portfolio'}

  except Exception as e:

    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/rebalance/import/", method="POST")
@app.route("/tp/rebalance/import", method="POST")
@authenticated_profile
def import_portfolio(user):
  """
    :return: Success if able to add new entry in table
  """

  rval = {}

  try:

    excel_file = request.files.get('file')
    data_df = pd.read_excel(excel_file.file)

    if upfm.import_portfolio(data_df,user):
       rval = {'success': True, 'user': user.get('guid')}
    else:
       rval = {'success': False, 'error': 'Could not add portfolio'}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval


@app.route("/tp/tradeit/getbroker/", method="GET")
@app.route("/tp/tradeit/getbroker", method="GET")
@authenticated
def get_broker():

  """
  :return: retreive the list of brokers
  """

  rval = {}

  try:
    #Request for OAuth pop-up page URL
    apikey = upfm.get_tradeit_api_key()
    success, data = upfm.make_tradeit_call('v2/preference/getBrokerList', { "apiKey": apikey })

    if success:
      rval = {'success': True, 'broker_list': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval


@app.route("/tp/tradeit/getbal/", method="GET")
@app.route("/tp/tradeit/getbal",  method="GET")
@authenticated
def get_balance():

  try:

    payload = {
                   'token': globalToken,
                   'accountNumber': globalAccountNumber
              }

    success, data = upfm.make_tradeit_call('v1/balance/getAccountOverview', payload)

    if success:
      rval = {'success': True, 'accountoverview': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval


@app.route("/tp/tradeit/getaccounts/", method="POST")
@app.route("/tp/tradeit/getaccounts",  method="POST")
@authenticated
def get_accounts():
  """
   Retrieve account overview and balances. Please note some brokerages have slight variations for these fields.
  """
  try:
    data = json.loads(json.dumps(bottle.request.json))
    token = data.get('token')
    success, data = upfm.make_tradeit_call('v2/user/getAccounts', {'token': token})

    if success:
      rval = {'success': True, 'accounts': data}
    else:
      rval = {'success': False, 'error': data}


  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/getaccountoverview/", method="POST")
@app.route("/tp/tradeit/getaccountoverview",  method="POST")
@authenticated
def get_account_overview():
  """
   Retrieve account overview and balances. Please note some brokerages have slight variations for these fields.
  """
  try:
    data = json.loads(json.dumps(bottle.request.json))

    token = data.get('token')
    AcctNumber = data.get('accountNumber')
    success, data = upfm.make_tradeit_call('v2/balance/getAccountOverview', {'token': token, 'accountNumber': AcctNumber})

    if success:
      rval = {'success': True, 'account_overview': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/getpositions/", method="POST")
@app.route("/tp/tradeit/getpositions",  method="POST")
@authenticated
def get_positions():
  """
    : Retrieve all positions for an account given its number. Please note some brokerages have slight variations for these fields
  """

  try:
    data = json.loads(json.dumps(bottle.request.json))

    token = data.get('token')
    AcctNumber = data.get('accountNumber')
    success, data = upfm.make_tradeit_call('v1/position/getPositions', {'token': token, 'accountNumber': AcctNumber})

    if success:
      rval = {'success': True, 'tradeitpositions': data['positions']}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/orderpreview/", method="POST")
@app.route("/tp/tradeit/orderpreview",  method="POST")
@authenticated
def orderpreview():

  """
  :Given parameters for an order, preview details and estimates of that order so that a user may review the order
  :before placing it. A successful result is required before being able to place the order.
  """
  try:

    data = json.loads(json.dumps(bottle.request.json))

    token = data.get('token')
    AcctNumber = data.get('accountNumber')
    orderAction = data.get('orderAction')
    orderQuantity = data.get('orderQuantity')
    orderSymbol = data.get('orderSymbol')
    orderPriceType = data.get('orderPriceType')
    orderExpiration = data.get('orderExpiration')
    orderLimitPrice = data.get('orderLimitPrice')
    orderStopPrice = data.get('orderStopPrice')
    userDisabledMargin = data.get('userDisabledMargin')
    orderQuantityType = data.get('orderQuantityType')

    payload = {
                "token": token,
                "accountNumber": AcctNumber,
                "orderAction": orderAction,
                "orderQuantity": orderQuantity,
                "orderSymbol": orderSymbol,
                "orderPriceType": orderPriceType,
                "orderExpiration": orderExpiration,
                "orderLimitPrice": orderLimitPrice,
                "orderStopPrice": orderStopPrice,
                "userDisabledMargin": userDisabledMargin,
                "orderQuantityType": orderQuantityType
            }

    success, data = upfm.make_tradeit_call('v2/order/previewStockOrEtfOrder', payload)

    if data:
      rval = {'success': True, 'orderpreview': data}
    else:
      rval = {'success': False, 'error': data }


  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/placeorder/", method="POST")
@app.route("/tp/tradeit/placeorder",  method="POST")
@authenticated
def place_order():

  """
     To place an order to trade equity, a request must first be made to preview the equity order.
     If successful, the response will contain a preview of the order to be placed and an orderId
     that is used to place the actual order when making the Place Equity Trade request.
  """

  try:

    data = json.loads(json.dumps(bottle.request.json))
    token = data.get('token')
    orderid = data.get('orderId')

    success, data = upfm.make_tradeit_call('v2/order/placeStockOrEtfOrder', { "token": token, "orderId": orderid })

    if success:
      rval = {'success': True, 'plcaeorder': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval


@app.route("/tp/tradeit/getallorders/", method="POST")
@app.route("/tp/tradeit/getallorders",  method="POST")
@authenticated
def get_all_order_status():

  """
  :Given an account number - canceled, completed, and rejected orders for the day, and all open orders are returned.
  """
  try:

    data = json.loads(json.dumps(bottle.request.json))

    token = data.get('token')
    AcctNumber = data.get('accountNumber')

    success, data = upfm.make_tradeit_call('v2/order/getAllOrderStatus', { "token": token, "accountNumber": AcctNumber })

    if success:
      rval = {'success': True, 'orders': data}
    else:
      rval = {'success': False, 'error': data }


  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval


@app.route("/tp/tradeit/singleorder/", method="POST")
@app.route("/tp/tradeit/singleorder",  method="POST")
@authenticated
def get_single_order_status():

  """
  :Given an account number and order number, return the order status.
  """
  try:

    data = json.loads(json.dumps(bottle.request.json))

    token = data.get('token')
    AcctNumber = data.get('accountNumber')
    orderid = data.get('orderId')

    payload = {
                  "token": token,
                  "accountNumber": AcctNumber,
                   "orderNumber": orderid
              }

    success, data = upfm.make_tradeit_call('v2/order/getSingleOrderStatus', payload)

    if success:
      rval = {'success': True, 'orders': data}
    else:
      rval = {'success': False, 'error': data }


  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/cancelorder/", method="POST")
@app.route("/tp/tradeit/cancelorder",  method="POST")
@authenticated
def cancel_order():

  """
  :Given parameters for an order, preview details and estimates of that order so that a user may review the order
  :before placing it. A successful result is required before being able to place the order.
  """
  try:

    data = json.loads(json.dumps(bottle.request.json))

    token = data.get('token')
    AcctNumber = data.get('accountNumber')
    orderid = data.get('orderId')

    payload = {
                  "token": token,
                  "accountNumber": AcctNumber,
                   "orderNumber": orderid
              }

    success, data = upfm.make_tradeit_call('v2/order/cancelOrder', payload)

    if success:
      rval = {'success': True, 'orders': data}
    else:
      rval = {'success': False, 'error': data }

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/getalltxns/", method="POST")
@app.route("/tp/tradeit/getalltxns",  method="POST")
@authenticated
def get_all_txn_history():

  """
    Given an account number all transactions, for the last 60 days are returned.
  """
  try:

    data = json.loads(json.dumps(bottle.request.json))

    token = data.get('token')
    AcctNumber = data.get('accountNumber')

    success, data = upfm.make_tradeit_call('v2/account/getAllTransactionsHistory', { "token": token, "accountNumber": AcctNumber })

    if success:
      rval = {'success': True, 'transactions': data}
    else:
      rval = {'success': False, 'error': data }

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval


@app.route("/tp/tradeit/auth/", method="GET")
@app.route("/tp/tradeit/auth", method="GET")
@authenticated
def authorize():
  # Payload for initial login pop-up

  rval = {}

  try:

    payload = {
      "apiKey": upfm.get_tradeit_api_key(),
      "broker": "Dummy"
    }

    # Request for OAuth pop-up page URL
    success, data = upfm.make_tradeit_call('v2/user/getOAuthLoginPopupUrlForWebApp', payload)

    if success:
      rval = {'success': True, 'popUpURLInfo': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/confirm", method="POST")
@app.route("/tp/tradeit/confirm/", method="POST")
@authenticated_profile
def confirm(user):

  try:

    data = json.loads(json.dumps(bottle.request.json))
    authData = data.get('oAuthVerifier')

    tradeit_data = {}
    tradeit_data['user_id'] = user.get('guid')
    tradeit_data['broker_name'] = data.get('broker', 'dummy')

    apikey = upfm.get_tradeit_api_key()

    # Uses oAuthVerifier to retrieve userToken and userId
    success, data = upfm.make_tradeit_call('v1/user/getOAuthAccessToken', { "apiKey": apikey, "oAuthVerifier": authData })

    if success:
      tradeit_data['tradeit_user_id'] = data['userId']

      payload2 = {
                  'userToken': data['userToken'],
                  'userId': data['userId'],
                  'apiKey': upfm.get_tradeit_api_key()
                  }
      # Uses userToken and userId to authenticate and retrieve account info
      success, data = upfm.make_tradeit_call('v1/user/authenticate', payload2)

      if success:
        globalToken = data['token']
        tradeit_data['token'] = data['token']

        # Upsert the session for user_id and broker
        upfm.store_tradeit_session(tradeit_data)

        globalAccountNumber = data['accounts'][0]['accountNumber']
        success, data = upfm.make_tradeit_call('v1/balance/getAccountOverview', { 'token': globalToken, 'accountNumber': globalAccountNumber })

        if success:
          return {'success': True, 'popUpURLInfo': data}

    # Return the error message
    return {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

@app.route("/tp/tradeit/keepsessionalive/", method="POST")
@app.route("/tp/tradeit/keepsessionalive", method="POST")
@authenticated
def keep_session_alive():
  """
  Used to keep a user's current session from expiring
  """

  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    token = data.get('token')

    success, data = upfm.make_tradeit_call('v2/user/keepSessionAlive', { "token": token })

    if success:
      rval = {'success': True, 'keep_session': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/closesession/", method="POST")
@app.route("/tp/tradeit/closesession", method="POST")
@authenticated
def close_session():
  """
    Used to close a user's current session
  """

  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    token = data.get('token')

    success, data = upfm.make_tradeit_call('v2/user/closeSession', { "token": token })

    if success:
      rval = {'success': True, 'closesession': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/getcryptoquote/", method="POST")
@app.route("/tp/tradeit/getcryptoquote", method="POST")
@authenticated
def get_crypto_quote():
  """
  Given a broker account that supports crypto instrument, return a quote of the crypto currency pair provided
  """

  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    token = data.get('token')
    accountNumber = data.get('accountNumber')

    payload = {
                "token": token,
                 "accountNumber": accountNumber,
                 "pair": "ETH/USD"
              }

    success, data = upfm.make_tradeit_call('v2/brokermarketdata/getCryptoQuote', payload)

    if success:
      rval = {'success': True, 'cryptoquote': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/sessions", method="GET")
@app.route("/tp/tradeit/sessions/", method="GET")
@authenticated_profile
def get_tradeit_sessions(user):
  try:
    user_id = user.get('guid')

    if user_id:
      sessions = upfm.get_tradeit_sessions(user_id)
      rval = {'success': True, 'sessions': sessions}
    else:
      rval = {'success': False, 'error': 'user_id is missing'}

  except Exception as e:
    rval = {'success': False, 'error': str(e)}

  return rval

@app.route("/tp/tradeit/mapping/<symbols>", method="GET")
@authenticated
def get_stansberry_tradeit_map_list(symbols):

  rval = {}
  ps_snapshots = {}
  sym_list = symbols.split(",")
  try:
      ps_snapshots = upfm.get_all_position_company_snapshot_tradeit(sym_list)
      if len(ps_snapshots) > 0:
        rval = { 'success' : True, 'ps_snapshots' : ps_snapshots}
      else:
        rval = { 'success' : False, 'error' : 'No position list retrieved' }
  except Exception as e:
    logger.exception("Exception in get_positions_list_for_tradeit")
    bottle.abort(400, "encountered exception: " + str(e))

  return rval

@app.route("/tp/tradeit/getcryptocurrencypairs/", method="POST")
@app.route("/tp/tradeit/getcryptocurrencypairs", method="POST")
@authenticated
def get_crypto_currency_pairs():
  """
  Given a broker account that supports crypto instrument, return a quote of the crypto currency pair provided
  """

  rval = {}

  try:
    data = json.loads(json.dumps(bottle.request.json))
    token = data.get('token')
    accountNumber = data.get('accountNumber')

    success, data = upfm.make_tradeit_call('v2/brokermarketdata/getCryptoCurrencyPairs', { "token": token, "accountNumber": accountNumber })

    if success:
      rval = {'success': True, 'crypto': data}
    else:
      rval = {'success': False, 'error': data}

  except Exception as e:
    bottle.abort(400, "encountered exception: " + str(e))

  return rval


# STANSBERRY RECOMMENDATIONS
@app.route("/tp/portfolio/idinfo/", method="GET")
@app.route("/tp/portfolio/idinfo", method="GET")
@cached('REC_ID_INFO', '10min')
def get_portfolio_idinfo():
  """
  """
  logger.info("Received get portfolio id info request")
  portfolios = upfm.get_pfs()

  if portfolios is not None:
    rval = { 'success' : True, 'portfolios' : portfolios }
  else:
    rval = { 'success' : False, 'error' : 'No portfolios retrieved' }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/tabinfo/<id>", method="GET")
@app.route("/tp/portfolio/tabinfo/", method="GET")
@app.route("/tp/portfolio/tabinfo", method="GET")
@authenticated
@entitlements
def get_portfolio_tabinfo(entitlements=[], id='all'):
  """
    Returns a portfolio or portfolio list from web teams shared api.

    Args :
      id(str) : Portfolio Id or 'all'

    Returns :
      portfolio(list) : The data associated with the list
  """
  logger.info("Received portfolio tab info request for id: " + id)

  # GET FROM CACHE
  cache_key = "REC_TABINFO_" + str(id)
  tabinfo = redis_manager.get(cache_key)

  # GET AND STORE TO CACHE
  if not tabinfo:
    if id == 'all':
      tabinfo = upfm.get_all_pf_info()
    else:
      tabinfo = upfm.get_pf_info(id)

    if tabinfo:
      redis_manager.set(cache_key, tabinfo)



  if tabinfo is not None:
    # Only replace static portfolios if returning all portfolios
    if id == 'all':
      try:
        new_tabinfo = tabinfo.copy()
        # Remove pubcodes that have static portfolios
        for index, portfolio in enumerate(new_tabinfo):
          # Remove static portfolios by pubcode
          if portfolio['PubCode']['PubCode'] in ['PSI', 'RTR']:
            del new_tabinfo[index]

          if portfolio['Name'] in ['Golden Triangle Portfolio']:
            del new_tabinfo[index]

        for index, portfolio in enumerate(new_tabinfo):
          try:
            # TODO: Steve. Temp fix since REL = RLE in portfolio tracker
            if portfolio['PubCode']['PubCode'].lower() is 'rle':
              publication_level_slug = '100-rel'
            else:
              publication_level_slug = '100-' + portfolio['PubCode']['PubCode'].lower()
          except:
            publication_level_slug = '100-NONE'

          # Remove non-entitled portfolios
          if publication_level_slug not in entitlements:
            del new_tabinfo[index]

        # Add in static portfolios with required info
        new_tabinfo.append({"$id": "5000",
                            "Name": "Retirement Trader",
                            "Id": 5000,
                            "PubCode":{"PubCode": "RTR",
                                       "$id": None,
                                       "PubTitle": "Retirement Trader",
                                       "PubCategory": None,
                                       "Id": None}})
        new_tabinfo.append({"$id": "5001",
                            "Name": "Stansberry's Investment Advisory",
                            "Id": 5001,
                            "PubCode": {
                              "PubCode": "PSI",
                              "$id": None,
                              "PubTitle": "Stansberry's Investment Advisory",
                              "PubCategory": None,
                              "Id": None}})
        new_tabinfo.append({"$id": "5003",
                            "Name": "Stansberry's Golden Triangle",
                            "Id": 5003,
                            "PubCode": {
                              "PubCode": "SCO",
                              "$id": None,
                              "PubTitle": "Stansberry's Golden Triangle",
                              "PubCategory": None,
                              "Id": None}})
        tabinfo = new_tabinfo
      except Exception as e:
        logger.error("Error injecting static portfolios into results" + e)

    rval = { 'success' : True, 'tabinfo' : tabinfo }
  else:
    rval = { 'success' : False, 'error' : 'No portfolios retrieved' }

  if not rval['success']:
    bottle.response.status = 400

  return rval


@app.route("/tp/portfolio/position/all/<pfid>", method="GET")
@cached('REC_POSITION_ALL', '10min', keys=["pfid"])
def get_all_portfolio_position(pfid):
  logger.info("Received all portfolio position request for id: " + pfid)

  position = upfm.get_all_pf_pos_info(pfid)
  if position:
    rval = {'success': True, 'position': position}
  else:
    rval = {
      'success': False,
      'error':   'Unable to retrieve all portfolio positions ' + pfid
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/position/info/<id>", method="GET")
@cached('REC_POSITION_INFO', '10min', keys=["id"])
def get_portfolio_position_info(id):
  logger.info("Received tab info portfolio position request for id: " + id)

  position = upfm.get_pf_pos_info(id)

  if position:
    rval = { 'success' : True, 'position' : position }
  else:
    rval = {
      'success' : False,
      'error' : 'Unable to retrieve portfolio tabinfo for ' + id
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/position/status/<pfid>", method="GET")
@cached('REC_POSITION_STATUS', '10min', keys=["pfid"])
def get_portfolio_position_status(pfid):
  logger.info("Received portfolio position status request for id: " + pfid)

  if pfid in ['5000', '5001', '5003']:
    position = upfm.get_pf_pos_status_static(pfid)
  else:
    position = upfm.get_pf_pos_status(pfid)

  if position:
    rval = {'success': True, 'position': position}
  else:
    rval = {
      'success': False,
      'error':   'Unable to retrieve all portfolio positions ' + pfid
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/stansberry-portfolios/<pfid>", method="GET")
# @app.route("/tp/lam/<pfid>", method="GET")
@authenticated
@entitlements
def get_portfolio_position(entitlements=[], pfid='0'):
  logger.info("Received portfolio position status request for id: " + pfid)

  # PULL FROM CACHE
  cache_key = "STANSBERRY_PORTFOLIO_" + str(pfid)
  position = redis_manager.get(cache_key)

  if not position:
    if pfid in ['5000', '5001', '5003']:
      position = upfm.get_pf_pos_status_static(pfid)
    else:
      position = upfm.get_pf_pos_status_lam(pfid)
    if position and 'error' in position:
      redis_manager.set(cache_key, position)

  if position and 'error' in position :
    rval = {
      'success': False,
      'error': 'ID :' + pfid + ', Retrieval Error : '  + position['error']
    }
  elif position:
    try:
      # TODO: Steve. Temp fix since REL = RLE in portfolio tracker
      if position['info']['PubCode']['PubCode'].lower() is 'rle':
        publication_level_slug = '100-rel'
      else:
        publication_level_slug = '100-' + position['info']['PubCode']['PubCode'].lower()
    except:
      publication_level_slug = '100-NONE'

    # Check for entitlement
    if publication_level_slug in entitlements:
      rval = {'success': True, 'position': position}
    else:
      rval = {
        'success': False,
        'error': 'User does not have access to portfolio'
      }
  else:
    rval = {
      'success': False,
      'error':   'Unable to retrieve all portfolio positions ' + pfid
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/buys/conviction", method="GET")
@authenticated
@cached('CONVICTION_BUYS', '10min', keys=['QS'])
def get_conviction_buys():
  """
    Returns the conviction buys.

    Returns :
      (dict) : The data associated with the conviction buys
  """
  logger.info("Retrieves conviction buys")

  rval = {}
  data = {}

  filter_type = get_qs_str_param(request, "filter_type", "latest")
  page = get_qs_int_param(request, "page", 1)
  page_size = get_qs_int_param(request, "page_size", 25, max_value=50)
  from_dt = get_qs_ymd_date_param(request, "from_dt")
  to_dt = get_qs_ymd_date_param(request, "to_dt")

  try:
      data = upfm.get_conviction_buy_list(filter_type, page, page_size, from_dt, to_dt)
  except:
    rval = {"success": False, "error": traceback.format_exc()}

  if data and not rval:
    rval = {'success': True, 'data': { "values": data } }
  else:
    rval = {
      'success': False,
      'error': 'No conviction buys available.'
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/recommendations/top", method="GET")
@authenticated
@cached('TOP_RECOMMENDATIONS', '10min')
def get_top_recommendations():
  """
    Returns the top recommended stocks.

    Returns :
      (dict) : The data associated with the top recommendations
  """
  logger.info("Retrieves top recommendations")

  rval = {}
  data = {}

  try:
      data = upfm.get_portfolio_list(
              PortfolioList.TOP_RECOMMENDATIONS.value)
  except:
    rval = {"success": False, "error": traceback.format_exc()}

  if data and not rval:
    rval = {'success': True, 'data': data}
  else:
    rval = {
      'success': False,
      'error': 'No recommendations available.'
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

def _match_pubcode(list1, list2):
  for x in list1:
    result = False
    for y in list2:
      if x == y:
        result = True
        return result
  return result


def filter_portfolio_position_based_on_entitlements(portfoliopositions, entitlements):
  logger.info("Filter the portfolio positions based on Entitlememts")

  allowedpositions = []

  for portfolioposition in portfoliopositions:
    publication_list_for_position = []
    for pub in portfolioposition.get('publications'):
      publication_level_pubcode = '100-' + pub['pub_code'].lower()
      publication_list_for_position.append(publication_level_pubcode)

    if _match_pubcode(publication_list_for_position, entitlements):
      allowedpositions.append(portfolioposition)

  logger.info("No. of positions user has entitlement for : " + str(len(allowedpositions)))
  return allowedpositions

@app.route("/tp/portfolio/marketwatch", method="GET")
@authenticated
@entitlements
def get_market_watch_symbols(user_entitlements):
  try:
    data = __get_user_portfolio_list(user_entitlements)
    return_dict = dict()
    if data:
      for item in data['values']:
        pf_symbol = item["symbol"]
        pf_sym_exch = item['exchange'] if 'exchange' in item else ''
        if pf_sym_exch == "":
          symbol = pf_symbol
        else:
          symbol = "{}~{}".format(pf_symbol, pf_sym_exch)
        for publication in item["publications"]:
          portfolio_id = publication['portfolio_id']
          if portfolio_id not in return_dict:
            portfolio_name = publication["portfolio_name"]
            pub_code = publication["pub_code"]
            return_dict[portfolio_id] = {
                                          "portfolio_id": portfolio_id,
                                          "portfolio_name": portfolio_name,
                                          "pub_code": pub_code,
                                          "symbol_exchanges": []
                                        }

          port_symbols = return_dict[portfolio_id]["symbol_exchanges"]
          if symbol not in port_symbols:
              port_symbols.append(symbol)

    return  {'success': True, 'data': list(return_dict.values()) }
  except:
    return {"success": False, "error": traceback.format_exc()}

@app.route("/tp/portfolio/porterslist", method="GET")
@authenticated
@entitlements
def get_porters_list(user_entitlements):
  """
    Returns porters list which contains all companies in all
    the portfolios.

    Returns :
      (dict) : All companies in all the portfolios
  """
  logger.info("Retrieve porters list ")

  rval = {}
  data = {}

  try:
      # PULL FROM CACHE
      data = __get_user_portfolio_list(user_entitlements)
  except:
    rval = {"success": False, "error": traceback.format_exc()}

  if data and not rval:
    rval = {'success': True, 'data': data}
  else:
    rval = {
      'success': False,
      'error': 'No data available.'
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/buysell", method="GET")
@authenticated
@entitlements
@cached('BUY_SELL_RECOMMENDATION', '10min', keys=['QS'])
def get_portfolio_buy_sell_status(user_entitlements):
  """
    Returns porters list which contains all companies in all
    the portfolios.

    Returns :
      (dict) : All companies in all the portfolios
  """
  logger.info("Retrieve porters list ")

  rval = {}

  page = get_qs_int_param(request, "page", 1)
  page_size = get_qs_int_param(request, "count", 25, max_value=5000)
  from_dt = get_qs_ymd_date_param(request, "date_from")
  to_dt = get_qs_ymd_date_param(request, "date_to")

  publication_codes = []
  publication_codes_str = get_qs_str_param(request, "publications")
  if publication_codes_str and publication_codes_str != "":
    publication_codes = publication_codes_str.split(",")

  try:
      # PULL FROM CACHE
      data = upfm.get_portfolio_buy_sell_list(page, page_size, from_dt, to_dt, publication_codes)
      # filter the positions that user is not entitled to based on publications
      data = filter_portfolio_position_based_on_entitlements(data, user_entitlements)
  except:
    rval = {"success": False, "error": traceback.format_exc()}

  if data and not rval:
    rval = {'success': True, 'data': data}
  else:
    rval = {
      'success': False,
      'error': 'No data available.'
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

def __get_user_portfolio_list(user_entitlements):
  cache_key = PORTERS_LIST
  data = get_cached_by_key(cache_key)
  if not data:
    data = upfm.get_portfolio_list(
      PortfolioList.PORTERS_LIST.value)
    set_cached_by_key(cache_key, data, "10min")
  # filter the positions that user is not entitled to based on publications
  data['values'] = filter_portfolio_position_based_on_entitlements(data.get('values'), user_entitlements)

  # Load financial metrics with porterlist
  if data['values']:
    composite_keys = [val["symbol"] + ":" + val["exchange"] for val in data["values"] if val.get("exchange", None)]
    financial_data = upfm.accessor.get_trading_data(composite_keys)

    for porter in data['values']:
      if porter["symbol"] and porter["exchange"]:
        for fin in financial_data:
          if fin["composite_pk_id"] == porter["symbol"] + ":" + porter["exchange"]:
            for key in upfm.accessor._METRICS_METADATA:
              if key in fin:
                porter[key] = fin[key]
            break

  return data


@app.route("/tp/portfolio/recommendations/newest/<limit>", method="GET")
@app.route("/tp/portfolio/recommendations/newest", method="GET")
@authenticated
@cached('NEWEST_RECOMMENDATIONS', '10min', keys=["PATH"])
def get_newest_recommendations(limit="5"):
  """
    Returns the latest recommended stocks.

    Returns :
      (dict) : The data associated with the latest recommendations
  """
  logger.info("Retrieves newest recommendations to limit of " + limit)

  rval = {}
  data = {}

  try:
      if request.query.get('type', '') == 'crypto':
        data = upfm.get_portfolio_list(
          PortfolioList.NEWEST_RECOMMENDATIONS_CRYPTO.value,
          int(limit))
      else:
        data = upfm.get_portfolio_list(
               PortfolioList.NEWEST_RECOMMENDATIONS.value,
               int(limit))
  except:
    rval = {"success": False, "error": traceback.format_exc()}

  if data and not rval:
    rval = {'success': True, 'data': data}
  else:
    rval = {
      'success': False,
      'error': 'No recommendations available.'
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval

@app.route("/tp/portfolio/movers/<days>", method="GET")
@authenticated
@cached('MOVERS', '10min', keys=['days'])
def get_movers(days):
  """
    Returns the latest movers from the database.

    Args :
      days(str) : Either 5 or 30

    Returns :
      (dict) : The data associated with the latest movers or an error
  """
  logger.info("Retrieves movers for days: " + days)

  rval = {}
  data = {}

  try:
    if days == '5' :
      data = upfm.get_portfolio_list(PortfolioList.FIVE_DAY.value)
    elif days == '30' :
      data = upfm.get_portfolio_list(PortfolioList.THIRTY_DAY.value)
  except:
    rval = {"success": False, "error": traceback.format_exc()}

  if data and not rval:
    rval = {'success': True, 'data': data}
  else:
    rval = {
      'success': False,
      'error':   days + ' day movers not available.'
    }

  if not rval['success']:
    bottle.response.status = 400

  return rval


def start():
  """
  Configure cherrypy and start service
  :param cfg:
  :return:
  """
  global upfm

  config = SbtGlobalCommon.get_sbt_config()['services']['portfolio']
  upfm = UserPortfolioManager(config)
  start_app(config)


if __name__ == "__main__":
  logger.info("starting")

  start()
  cherrypy.engine.block()
