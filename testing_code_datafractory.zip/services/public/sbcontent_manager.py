import calendar
import logging
import os
import os.path
import pymongo
import string
import time
import traceback
from datetime import date
import bottle
import cherrypy
from bottle import request
from dateutil.relativedelta import relativedelta
from api_service import app, start_app
from article_utils import ArticleHelper, ArticleExtractor, ArticleCleaner, \
    ArticleRequestHelper
from auth_utils import authenticated, entitlements, userprofile
from cftc_cot import CFTCCOT
from datafactory.vendor import sbt_iex
from dd_accessor import DynamoAccessor
from mn_accessor import MarketNotesAccessor
from sbt_common import SbtCommon, SbtGlobalCommon, SingletonServiceManager
from stansberry_article import Article
from external_article import ExternalArticle
from stansberry_educational import Educational
from benzinga_calendar import BenzingaApi
from redis_manager import RedisManager
from pg_accessor import PostgresAccessor
from cache_utils import cached, get_cached_by_key, set_cached_by_key
import edgar_accessor
from mongo_accessor import MongoAccessor
# from memory_profiler import profile
import gc

sbtcommon = SbtCommon()
dd = DynamoAccessor()
articles_mongo_accessor = MongoAccessor('articles')
benzinga_api = BenzingaApi()
logger = sbtcommon.get_logger(logging.DEBUG, 'sbcmanager')
# sbcm = None
redis_manager = RedisManager()
default_internal_limit = 2
default_external_limit = 3


###############################################################################
# SBContentManager:
###############################################################################
class SBContentManager(object, metaclass=SingletonServiceManager):
    # @profile
    def __init__(self, config):
        """
          Singleton class initializer
        """
        logger.info("SBContentManager: initializing")
        self.configured = False
        self.fin = False
        self.env = dict(os.environ)
        self.config = config
        self.deploy_env = sbtcommon.get_sbt_config_env()
        # esconf = sbtcommon.get_cfg_env_var("elasticsearch")
        # self.article_accessor = ArticleAccessor(esconf)
        # self.mapping_accessor = MappingAccessor()
        self.market_notes_accessor = MarketNotesAccessor()
        # self.cftc_accessor = CFTCAccessor()
        self._pgconfig = SbtGlobalCommon.get_sbt_config()['postgres']['datafactory']
        self._pg = PostgresAccessor(self._pgconfig)

        logger.info("config: " + str(self.config))
        for v in self.env:
            logger.info("env: " + v + " " + self.env[v])

    # @profile
    def get_symbol(self, identifier):

        if sbtcommon.validate_uuid(identifier.lower()):
            # it's a guid
            ret_value = dd._query_table(
                dd._get_environment_table_name('SBT_SYMBOL_EXCHANGE_MAPPING'),
                'guid',
                identifier.lower(),
                index_name='GUIDidx')
            # return symbol associated with GUID
            sym = ret_value[0].get('symbol')
        else:
            # it's a symbol
            if identifier.count("~"):
                # symbol + exchange were provided
                sym, exc = identifier.upper().split('~')
            else:
                # only symbol was provided
                sym = identifier.upper()

        gc.collect()
        return sym


    @staticmethod
    # @profile
    def get_authors():
        """
      Returns a list of all authors.

      Returns :
        (list) : List Authors (dict)
    """
        authors = dd._scan_table('authors', None)
        # remove wordpressId and _id
        [author.pop('wordpressId', None) for author in authors]
        [author.pop('_id', None) for author in authors]

        gc.collect()
        return authors


    # @profile
    def get_publication_codes(self):
        """
      Returns a single publication code.
      Args :
        code(str) : Publication Code
      Returns :
        (dict) : Publication Code
    """
        pub_codes = dd._scan_table('SBT_PUBLICATION_CODE', None)

        gc.collect()
        return pub_codes

    def get_benzinga_channels(self):
        query = 'SELECT * FROM benzinga_channel_tags ORDER BY order_no'
        return self._pg._execute_query(query, [])



    # @profile
    def update_market_notes(self, market_notes):
        """
      Update daily market notes
      Args :
        market_notes(dict): Market Notes Dictionary

      Returns:

    """
        logger.info("SBContentManager: update daily market notes")
        return self.market_notes_accessor.save_market_notes(market_notes)

    # @profile
    def get_market_notes(self):
        """
    Retrieve the latest market notes
    """
        logger.info("SBContentManager: getting market notes")
        return self.market_notes_accessor.get_market_notes()

    # @profile
    def update_articles_db(self, article):
        """
        Update MongoDB
        """
        logger.info("SBContentManager: update MongoDB Collection")
        item = {k: v for k, v in article.items() if v != ''}

        condition = {'wordpressId': article['wordpressId']}
        existing_data = articles_mongo_accessor.find(condition)
        if existing_data.count() > 0:
            articles_mongo_accessor._replace_data(condition, item)
        else:
            articles_mongo_accessor._insert_data(item)
        logger.info("saved article data to monogodb:", item)


    # # @profile
    # def delete_db(self, article):
    #     """
    #   Delete DynamoDB
    # """
    #     logger.info("SBContentManager: Deleting DynamoDB item")
    #     logger.info(
    #         "Deleting item with id {0} from dynamoDB".format(
    #             article['wordpressId']))
    #     return self.article_accessor.delete_article(article['wordpressId'])


###############################################################################
# Support CORS headers
# https://stackoverflow.com/
#       questions/17262170/bottle-py-enabling-cors-for-jquery-ajax-requests
# Answer by BrainCore
###############################################################################

@app.route('/<:re:.*>', method='OPTIONS')
def enable_cors_generic_route():
    """
    This route takes priority over all others. So any request with an OPTIONS
    method will be handled by this function.
    See: https://github.com/bottlepy/bottle/issues/402
    NOTE: This means we won't 404 any invalid path that is an OPTIONS request.
    """
    add_cors_headers()


@app.hook('after_request')
def enable_cors_after_request_hook():
    """
    This executes after every route. We use it to attach CORS headers when
    applicable.
    """
    add_cors_headers()


def add_cors_headers():
    bottle.response.headers['Access-Control-Allow-Origin'] = \
        '*'
    bottle.response.headers['Access-Control-Allow-Methods'] = \
        'GET, ' \
        'POST, ' \
        'PUT, ' \
        'OPTIONS'
    bottle.response.headers['Access-Control-Allow-Headers'] = \
        'Origin, ' \
        'Accept, ' \
        'Content-Type, ' \
        'X-Requested-With, ' \
        'X-CSRF-Token'


###############################################################################
#                             HELPER FUNCTIONS
###############################################################################
def get_default_date():
    """
        Retrieves the default date for endpoints with a start_date parameter
    :return: the date six months before the current date
    :rtype: string
    """
    return (date.today() + relativedelta(months=-6)).strftime('%Y%m%d')


def stream_article(validated_article):
    # Newswire channel
    if ArticleHelper.should_stream_by_channel(validated_article, 'newswire'):
        logger.info("SBContentManager: Sending article to newswire stream")
        redis_manager.stream_article(channel_prefix='newswire/',
                                     article=validated_article)

    # Newsletter channel
    if ArticleHelper.should_stream_by_channel(validated_article, 'newsletter'):
        logger.info("SBContentManager: Sending article to newsletter stream")
        redis_manager.stream_article(channel_prefix='newsletter/',
                                     article=validated_article)

    # All Content Channel
    # TODO: Steve: Verify that this is still in use
    if ArticleHelper.should_stream_by_channel(validated_article,
                                              'stansberry-content'):
        logger.info(
            "SBContentManager: Sending article to stansberry-content stream")
        redis_manager.stream_article(channel_prefix='stansberry-content/',
                                     article=validated_article)

    return


def stream_if_es_valid(article):
    """
    Broadcasts a message on the WebSocket Server to all connected clients
    if the article is valid for Elasticsearch
    :type article: JSON
    :param article: The article to check
    """
    logger.info("SBContentManager: Validating article for streaming")

    if article and Article.valid_article(article):
        # Newswire channel
        if ArticleHelper.is_newswire(article):
            logger.info("SBContentManager: Sending article to newswire stream")
            redis_manager.stream_article(channel_prefix='newswire/',
                                         article=article)

        # Newsletter channel
        if ArticleHelper.is_newsletter(article):
            logger.info(
                "SBContentManager: Sending article to newsletter stream")
            redis_manager.stream_article(channel_prefix='newsletter/',
                                         article=article)

        # All Content Channel
        logger.info(
            "SBContentManager: Sending article to stansberry-content stream")
        redis_manager.stream_article(channel_prefix='stansberry-content/',
                                     article=article)
        return

    logger.info("SBContentManager: The article is not valid for streaming")


###############################################################################
#                         IGNORE TRAILING SLASHES
###############################################################################
@app.hook('before_request')
def strip_path():
    bottle.request.environ['PATH_INFO'] = bottle.request.environ[
        'PATH_INFO'].rstrip('/')


###############################################################################
#                                REST API
###############################################################################
############################################
# NGINX LOCATION ~ ^/api/articles/ (START) #
############################################

# TODO: handle using jsend protocal
@app.route("/sbcmanager/articles/<wordpress_id>")
@authenticated
@entitlements
def get_by_wordpress_id(user_entitlements, wordpress_id=''):
    """
      get_by_wordpress_id
    """
    cache_key = "ARTICLE_SINGLE_" + str(wordpress_id);
    article = get_cached_by_key(cache_key)

    if not article:
        article = Article.get_by_wordpress_id(wordpress_id)
        if article:
            set_cached_by_key(cache_key, article, '1min')
        else:
            return {"success": False, "articles": []}

    if article['publication']['slug'] not in user_entitlements:
        article["content"] = ""

    return {"success": True, "articles": [article]}

# TODO Add Cache
@app.route("/sbcmanager/paragraphs/articles/<symbol>/<start_date>",
           method="GET")
@app.route("/sbcmanager/paragraphs/articles/<symbol>", method="GET")
@cached("ARTICLES_PARAGRAPHS", "10min", keys=["symbol","start_date"])
def get_articles_by_paragraphs_filtered_by_start_date(
        symbol,
        start_date=sbtcommon.dateutil.get_relative_date()
):
    """
  Get articles by paragraphs which contain the queried ticker symbol.
  Articles can be searched from a specified start date but an optional
  default start date can be used.
  :type symbol: str
  :param symbol: The ticker symbol to search articles for
  :type start_date: str
  :param start_date: The start date to start searching articles from
  :return: A response with success and articles keys, with an optional error
  key.
  :rtype: dict
  """
    logger.info(
        "SBContentManager: received get paragraphs request for: " + symbol +
        ", with start date: " + start_date)

    actual_symbol = sbcm.get_symbol(symbol)

    return Article.get_paragraphs(actual_symbol, start_date)


@app.route("/sbcmanager/articles/top", method="GET")
@authenticated
@cached("ARTICLES_TOP", "2min")
def get_top_articles():
    """
        get_top_articles
    """
    logger.info("SBContentManager: received a get_top_articles request")
    return Article.get_top_articles()

@app.route("/sbcmanager/articles/analyzed/<symbol>")
@authenticated
@entitlements
@cached("ARTICLES_ANALYZED", "20min", keys=['symbol'])
def get_analyzed_newsletters_by_symbol(user_entitlements, symbol, count=20):
    """
      get_analyzed_newsletters_by_symbol
    """

    if not type(count) == int or count > 20:
        count = 20

    logger.info(
        "SBContentManager: received get_analyzed_articles_by_symbol "
        "request for: " + symbol + " count: " + str(count))
    print('getting analyzed newsletters')

    actual_symbol = sbcm.get_symbol(symbol)

    return Article.get_analyzed_newsletters(
        user_entitlements=user_entitlements,
        symbol=actual_symbol, res_count=count)

@app.route("/sbcmanager/all/articles", method="GET")
@authenticated
def get_articles_by_symbol():
  helper = ArticleRequestHelper

  internal_limit = int(request.query.get('internal_limit', default_internal_limit))
  external_limit = int(request.query.get('external_limit', default_external_limit))
  symbols = helper.extract_param_list(request, 'symbols')

  stansberry_paging = { 'count': internal_limit, 'start': 0, 'end': internal_limit }
  external_paging = { 'count': external_limit, 'start': 0, 'end': external_limit }
  types = ['newswire']
  external_type = 'benzinga_news'

  actual_symbols = []
  if symbols:
    for sym in symbols:
      s = sbcm.get_symbol(sym)
      if s:
        actual_symbols.append(s.lower())

  try:
    data = []

    internal_count = Article.counts({"tickers.keyword": [symbol.upper() for symbol in actual_symbols]})
    external_count = ExternalArticle.counts({"tickers.keyword": actual_symbols})

    if internal_count < internal_limit:
      remaining_article = internal_limit - internal_count
      external_paging['count'] += remaining_article
      external_paging['end'] += remaining_article

    if external_count < external_limit:
      remaining_article = external_limit - external_count
      stansberry_paging['count'] += remaining_article
      stansberry_paging['end'] += remaining_article

    if internal_count > 0:
      internal = Article.find_with_keywords(actual_symbols, types, stansberry_paging)

      if 'articles' in internal:
        data.append(internal['articles'])

    if external_count > 0:
      external = ExternalArticle.find(actual_symbols, external_paging, [], [],external_type)

      if 'articles' in external:
        data.append(external['articles'])

    return {"success": True, "data": [item for sublist in data for item in sublist]}
  except:
      bottle.response.status = 400
      return {
          "success": False,
          "error": "An error occured processing your request for articles"
      }

@app.route("/sbcmanager/articles", method="GET")
# @authenticated
@cached("ARTICLES_MAIN", "2min", keys=['QS'] )
def get_articles_by_search():
    helper = ArticleRequestHelper

    start_date_epoch = 0
    paging = helper.extract_paging_params(request)
    types = helper.extract_param_list(request, 'types')
    analysts = helper.extract_param_list(request, 'analysts')
    publications = helper.extract_param_list(request, 'publications')
    symbols = helper.extract_param_list(request, 'symbols')
    days_back = helper.extract_days_params(request)
    has_synopsis = helper.extract_boolean_param(request, 'synopsis')
    collections = helper.extract_param_list(request, 'collections')
    category = helper.extract_param_list(request, 'category')

    actual_symbols = []
    if symbols:
        for sym in symbols:
            s = sbcm.get_symbol(sym)
            if s:
                actual_symbols.append(s.lower())

    if days_back > 0:
        # convert to est epoch
        start_date_epoch = calendar.timegm(time.gmtime())
        start_date_epoch = start_date_epoch - ((24 * days_back) * 3600)

    try:
        data = Article.find([], paging, analysts, publications,
                            actual_symbols, types, has_synopsis, start_date_epoch, collections, category)
        return {"success": True, "data": data}
    except Exception as exc:
        logging.error(str(exc)+ " Trace: "+ traceback.format_exc())
        bottle.response.status = 400
        return {
            "success": False,
            "error": "An error occured processing your request for articles"
        }


@app.route("/sbcmanager/authors", method="GET")
@cached("AUTHORS", "1hour")
def get_authors_info():
    """
    get_author_info
    """
    logger.info("ContentManager: Retrieve all author codes")

    try:
        data = sbcm.get_authors()
        rval = {"success": True, "data": data}
    except:
        rval = {"success": False, "error": traceback.format_exc()}

    return rval


@app.route("/sbcmanager/publications", method="GET")
@cached("PUBLICATIONS", "1hour")
def get_publication_codes():
    """
    get_publication_code_info
    """
    logger.info("ContentManager: Publication codes")
    try:
        codes = sbcm.get_publication_codes()
        rval = {"success": True,
                "data": codes}
    except:
        rval = {"success": False, "error": traceback.format_exc()}

    return rval


@app.route("/sbcmanager/news", method="GET")
# @authenticated
@cached("BENZINGA_NEWS", "1min", keys=['QS'])
def get_external_news():
    helper = ArticleRequestHelper

    paging = helper.extract_paging_params(request)
    symbols = helper.extract_param_list(request, 'symbols')
    channels = helper.extract_param_list(request, 'channels')
    authors = helper.extract_param_list(request, 'authors')
    type = request.query.get('type', None)
    text = request.query.get('q', None)

    actual_symbols = []
    if symbols:
        for sym in symbols:
            s = sbcm.get_symbol(sym)
            if s:
                actual_symbols.append(s.lower())

    try:
        data = ExternalArticle.find(actual_symbols, paging, channels, authors, type, text)
        return data
    except:
        bottle.response.status = 400
        return {
            "success": False,
            "error": "An error occured processing your request for articles"
        }


@app.route("/sbcmanager/benzinga/channels", method="GET")
@cached("BENZINGA_CHANNELS", "1hour", keys=['QS'] )
def return_benzinga_channels():
    channels = sbcm.get_benzinga_channels()

    if channels:
        return {"success": True, "categories": channels}
    else:
        return {"success": False, "error": "Error Retrieving Channels"}


@app.route("/sbcmanager/articles/external/calendar/<calendar_name>/<symbols>", method="GET")
@app.route("/sbcmanager/articles/external/calendar/<calendar_name>", method="GET")
# @authenticated
# @cached("BENZINGA_EVENTS", "10min", keys=['QS'] )
def external_calendar_events(calendar_name, symbols=None):
    date_from = request.query.get('date_from', None)
    date_to = request.query.get('date_to', None)
    eps = request.query.get('eps', None)
    revenue = request.query.get('revenue', None)
    importance = request.query.get('importance', None)

    query_params = {
        'date_from': date_from,
        'date_to': date_to,
        'eps': eps,
        'revenue': revenue,
        'importance': importance
    }

    if symbols and symbols is not None:
        events = benzinga_api.get_symbol_events(calendar_name, symbols, query_params)
    else:
        events = benzinga_api.get_calendar_events(calendar_name, query_params)

    return {"success": True, "events": events}


@app.route("/sbcmanager/articles/external/article/<uuid>", method="GET")
# @authenticated
@cached("ARTICLE_EXTERNAL","10min", keys=['uuid'])
def get_external_article(uuid):
    try:
        data = ExternalArticle.find_by_id(uuid)
        return data
    except:
        bottle.response.status = 400
        return {
            "success": False,
            "error": "An error occured processing your request for articles"
        }


@app.route("/sbcmanager/iex/news/<symbol>", method="GET")
@app.route("/sbcmanager/iex/news/<symbol>/page/<page:int>", method="GET")
@authenticated
def get_iex_articles(symbol, page=None):
    if page:
        start = 10 * (page - 1)
        count = 10
        articles = sbt_iex.news.get_news_by_symbol(symbol, start=start, count=count)
    else:
        articles = sbt_iex.news.get_news_by_symbol(symbol)

    return {"success": True, "articles": articles}


@app.route("/sbcmanager/articles/recommended/<symbol>")
@authenticated
@entitlements
@cached("ARTICLES_RECOMMENDED", "10min", keys=['symbol'])
def get_recommended_newsletters_by_symbol(user_entitlements, symbol):
    """
      get_recommended_newsletters_by_symbol
  """
    logger.info(
        "SBContentManager: received get_recommended_articles_by_symbol "
        "request for: " + symbol)
    print('getting recommended newsletters')

    actual_symbol = sbcm.get_symbol(symbol)

    return Article.get_recommended_newsletters(
        user_entitlements=user_entitlements, symbol=actual_symbol)


@app.route("/sbcmanager/updatedb/<table_name>", method="POST")
def update_db(table_name):
    """
      Update DynamoDB
    """
    table_name = 'articles'
    logger.info("SBContentManger: Received request to save article")
    request_json = bottle.request.json
    if request_json is not None:
        logger.info("SBContentManger: article content: {}".format(request_json))

    # Catch a major error in ArticleCleaner
    try:
        article_wrapper = ArticleCleaner(request_json)
        article_wrapper.clean()
        validated_article = article_wrapper.get_article()
    except Exception as e:
        bottle.response.status = 400
        logger.exception("SBContentManger: HARD_FAIL in ArticleCleaner: "
                         + str(e) + "\n request_json output: \n"
                         + str(request_json))
        # Fail and return error response
        return {"success": False,
                "error": "Failed to successfully clean article"}

    # TODO: Remove passing of company bullets and overview (see ST-2491)
    if validated_article['defaultCategory'] not in ['company-bullets',
                                                    'company-overview']:
        # Exit if article not Valid
        if not article_wrapper.valid:
            logger.error("SBContentManger: Article failed validation "
                         + article_wrapper.to_log_str())
            return {"success": True, "modified": True}
        else:
            logger.info("SBContentManger: Validation successful for article "
                        + str(validated_article['wordpressId']))

        if sbcm.deploy_env == 'staging' or sbcm.deploy_env == "prod":
            pass

    # Save article to DynamoDB & process it for indexing into ES.
    if ArticleHelper.should_save(validated_article):
        try:
            logger.info("SBContentManager: Updating DynamoDB item with ID: "
                        + str(validated_article['wordpressId']))
            sbcm.update_articles_db(validated_article)
            logger.info("SBContentManager: Processing item with ID: "
                        + str(validated_article['wordpressId']))
        except:
            bottle.response.status = 400
            logger.exception(
                "SBContentManger: Error saving article to DynamoDB.")

            # Bail on the rest of the processing because the main save failed.
            return {"success": False,
                    "error": "Failed to save article to DynamoDB."}

    # Stream Article to client
    if ArticleHelper.should_stream(validated_article):
        try:
            pass
            stream_article(validated_article)
        except:
            logger.error("SBContentManager: Error Streaming Article JSON"
                         + str(validated_article['wordpressId']))

    # Article Extraction
    # Process Market Notes / Chart of the day.
    try:
        if validated_article['defaultPublication'] \
                and validated_article['defaultPublication'] \
                .get("publicationCode", "") == 'sdw':
            chart_of_the_day = \
                ArticleExtractor.extract_daily_market_notes(
                    article_wrapper.raw)

            if chart_of_the_day:
                chart_of_the_day['wordpressId'] = request_json.get(
                    'wordpressId', '')
                sbcm.update_market_notes(chart_of_the_day)
                # sbcm.get_market_notes()
    except:
        logger.warning("SBContentManger: Error extracting Market Notes.")

    # Return res from DynamoDB Save.
    return {"success": True, "modified": True}  # was res


##########################################
# NGINX LOCATION ~ ^/api/articles/ (END) #
##########################################

@app.route("/sbcmanager/edgar/symbol/<symbol>", method="GET")
@app.route("/sbcmanager/edgar/symbol/<symbol>/<filing_type>", method="GET")
def get_edgar_doc_list(symbol, filing_type=None):
    symbol = sbcm.get_symbol(symbol)
    per_page = 30
    page = int(request.query.get("page", 1))
    sort_by = request.query.get("sort", "filing_date")
    sort_desc = pymongo.DESCENDING if request.query.get("desc") else pymongo.ASCENDING

    rval = {"success": True, "results": []}
    company = edgar_accessor.EdgarCompany.get(symbol)
    if company is None or company.last_loaded < time.time() - 86400:
        edgar_accessor.load_filings_by_ticker(symbol)

    query = {"ticker": symbol}
    if filing_type is not None:
        query["filing_type"] = filing_type

    rval["total_filings"] = edgar_accessor.EdgarFiling.accessor().find(query).count()

    query_args = {
        "limit": per_page,
        "skip": (page - 1) * per_page,
        "sort": [(sort_by, sort_desc)],
    }

    for filing in edgar_accessor.EdgarFiling.filter(query, **query_args):
        result = {
            "id": filing.id,
            "filing_type": filing.filing_type,
            "description": filing.description,
            "filing_date": filing.filing_date,
            "file_num": filing.file_num,
            "film_num": filing.film_num,
        }

        rval["results"].append(result)

    return rval


@app.route("/sbcmanager/edgar/filing/<filing_id>", method="GET")
@cached("EDGAR_FILING", "12hour", keys=['filing_id'])
def get_edgar_filing(filing_id):
    filing = edgar_accessor.EdgarFiling.get(filing_id)
    if filing_id is None:
        bottle.abort(404, "Document not found")

    result = {
        "id": filing.id,
        "filing_type": filing.filing_type,
        "description": filing.description,
        "filing_date": filing.filing_date,
        "file_num": filing.file_num,
        "film_num": filing.film_num,
        "documents": [],
    }

    for doc in filing.docs():
        result["documents"].append({
            "id": doc.id,
            "filename": doc.filename,
            "description": doc.description,
        })

    return {"success": True, "result": result}


@app.route("/sbcmanager/edgar/document/<document_id>", method="GET")
@cached("EDGAR_DOC", "12hour", keys=['document_id'])
def get_edgar_document(document_id):
    document = edgar_accessor.EdgarDocument.get(document_id)
    if document is None:
        bottle.abort(404, "Document not found")

    response = bottle.HTTPResponse(body=document.get_file())
    response.set_header("Content-Type", document.content_type)
    response.set_header("Content-Disposition", "attachment; filename={}".format(document.filename))
    response.set_header("Content-Length", len(document.content))

    return response

@app.route("/api/marketnotes/latest", method="GET")
@cached("MARKET_NOTES", "10min")
def get_market_notes_latest():
    try:
        return {"success": True, "results": sbcm.get_market_notes()}
    except:
        bottle.response.status = 400
        return {"success": False, "error": traceback.format_exc()}


@app.route("/sbcmanager/cftc/futures/<code>", method="GET")
@app.route("/sbcmanager/cftc/futures/<code>/<start_date>", method="GET")
# @authenticated
def get_ctfc_futures(code, start_date=None):
    try:
        return {"success": True, "results": sbcm.cftc_accessor.query_futures(
            code=code, date=start_date)}
    except:
        bottle.response.status = 400
        return {"success": False, "error": traceback.format_exc()}


@app.route("/sbcmanager/cftc/futures_suggest/<name>", method="GET")
# @authenticated
@cached("FUTURES_SUGGEST", "1min", keys=['name'])
def cftc_futures_suggest(name):
    return CFTCCOT.get_suggestions(name)


@app.route("/sbcmanager/search/search_engine", method="POST")
@userprofile
@entitlements
@cached("SEARCH_ENGINE", "10min", keys=['JSON'])
def search_engine(user_entitlements, user_profile):
    req = bottle.request.json
    logger.info("SBContentManager: Received search request: {}".format(req))
    try:
        results = Article.get_relevant_results(
            req=req,
            user_entitlements=user_entitlements,
            user_profile=user_profile
        )
        rval = {"success": True,
                "results": results}
        bottle.response.status = 200
    except Exception as err:
        bottle.response.status = 400
        rval = {"success": False,
                "error": "An error occurred ({}).".format(err)}
    return rval


@app.route("/sbcmanager/search/search_engine_for_suggestions", method="POST")
# @authenticated
@cached("SEARCH_SUGGESTIONS", "10min", keys=['JSON'])
def search_engine_for_suggestions():
    req = bottle.request.json
    logger.info("SBContentManager: Received search "
                "request for suggestions endpoint: {}".format(req))
    try:
        terms = req['terms']
        actual_terms = []
        for t in terms:
            s = sbcm.get_symbol(t)
            if s:
                actual_terms.append(s)

        req['terms'] = actual_terms

        results = Article.get_relevant_results_for_suggestions(req)
        rval = {"success": True,
                "results": results}
    except:
        bottle.response.status = 400
        rval = {"success": False,
                "error": "Sorry, search engine not implemented yet."}
    return rval


@app.route("/sbcmanager/search/educational/categories", method="GET")
@app.route("/sbcmanager/search/educational/categories/<category>",
           method="GET")
@app.route("/sbcmanager/search/educational/categories/<category>/<doc_id>",
           method="GET")
@authenticated
# @entitlements
# @authenticated_profile
def get_categories_for_educational(category=None, doc_id=None):
    logger.info("SBContentManager: Received search "
                "request for Educational categories.")
    punc = string.punctuation
    category = (" ".join(category.split('-'))).title() if category else None
    category_placeholder = category
    category = [word for word in category_placeholder.split() if
                word not in punc] if category else None

    try:
        if not category:
            res = Educational.get_categories_for_educational()
        elif not doc_id:
            res = Educational.get_docs_by_category(category)
        else:
            res = Educational.get_doc(doc_id=doc_id)
        rval = {"success": True,
                "results": res}
    except Exception as err:
        bottle.response.status = 400
        rval = {"success": False,
                "error": "An error occurred ({})".format(err)}
    return rval


@app.route("/sbcmanager/search/educational/category/<category>", method="GET")
@authenticated
@cached("EDUCATIONAL_CATEGORY", "10min", keys=['category'])
def get_educational_docs_by_category(category):
    logger.info("SBContentManager: Received search "
                "request for Educational categories.")
    try:
        res = Educational.get_docs_by_category(category)
        rval = {"success": True,
                "results": res}
    except Exception as err:
        bottle.response.status = 400
        rval = {"success": False,
                "error": "An error occurred ({})".format(err)}
    return rval


@app.route("/sbcmanager/search/educational", method="POST")
@authenticated
# @entitlements
# @authenticated_profile
def search_engine_for_educational():
    req = bottle.request.json
    logger.info("SBContentManager: Received search request: {}".format(req))
    try:
        terms = req['terms']
        actual_terms = []
        for t in terms:
            s = sbcm.get_symbol(t)
            if s:
                actual_terms.append(s)

        req['terms'] = actual_terms

        results = Educational.get_relevant_results(req=req)
        rval = {"success": True,
                "results": results}
        bottle.response.status = 200
    except Exception as err:
        bottle.response.status = 400
        rval = {"success": False,
                "error": "An error occurred ({}).".format(err)}
    return rval


###############################################################################
# start
###############################################################################
def start():
    global sbcm

    config = SbtGlobalCommon.get_sbt_config()['services']['content']
    sbcm = SBContentManager(config)
    start_app(config)


###############################################################################
# main
###############################################################################
if __name__ == '__main__':
    logger.info("starting")

    start()
    cherrypy.engine.block()
