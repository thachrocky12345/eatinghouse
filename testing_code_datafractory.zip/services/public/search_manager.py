import os
import sys
import logging
import cherrypy
import bottle
import traceback
from suggestion import Suggestion
from time import sleep
from api_service import app, start_app
from sbt_common import SbtGlobalCommon
from sbt_common import SingletonServiceManager
from cache_utils import cached

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)

search_manager = None


###############################################################################
# SearchManager:
###############################################################################
class SearchManager(object, metaclass=SingletonServiceManager):
    def __init__(self):
        """
          Constructor
        """
        logger.info("ScheduleManager: initializing")
        self.configured = False
        self.fin = False
        self.env = dict(os.environ)

        # self.data_admin_accessor = DataAdminAccessor()

        for v in self.env:
            logger.info("env: " + v + " " + self.env[v])

    """
    Entry Point
    """

    def __enter__(self):
        return self

    """
    Cleanup
    """

    def clean(self):
        """
        Cleanup
        """
        logger.info("INFO: cleaning up...")
        if self.fin:
            bottle.response.headers['Connection'] = 'close'
        else:
            logger.error("ERROR: Clean ignored fin flag set False")

    """
    Exit Point
    """

    def __exit__(self, exception_type, exception_value, trace_back):
        if not self.fin:
            self.fin = True
            self.clean()
            sleep(2)
        else:
            sleep(1)

        logger.info("INFO: System exiting now!")

        sys.exit(0)

    """
    """


###############################################################################
# REST API
###############################################################################
"""
  TBD
"""


@app.route("/search/search_suggestions", method="POST")
@cached('SEARCH_SUGGESTIONS', '10min', keys=['JSON'])
def search_suggestions():
    return Suggestion.get_suggestions(bottle.request.json)

@app.route("/search/new_search_suggestions", method="POST")
@cached('SEARCH_NEW_SUGGESTIONS', '10min', keys=['JSON'])
def new_search_suggestions():
    return Suggestion.get_new_suggestions(bottle.request.json)


###############################################################################
# start
###############################################################################
def start():
    global search_manager

    config = SbtGlobalCommon.get_sbt_config()['services']['search_manager']
    search_manager = SearchManager()
    app.search_manager = search_manager
    start_app(config)


###############################################################################
# main
###############################################################################
if __name__ == "__main__":
    logger.info("starting")

    start()
    cherrypy.engine.block()
