import cherrypy
import logging

import sbt_crypto.coinlist
import sbt_crypto.crypto_ratings
import sbt_crypto.cryptocompare
import sbt_crypto.timeseries
from api_service import app, start_app
from sbt_common import SbtGlobalCommon
from auth_utils import authenticated_profile
from crypto_currency_accessor import CryptoAccessor
from cache_utils import cached

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
config = SbtGlobalCommon.get_sbt_config()
crypto = CryptoAccessor()


def start():
    try:
        crypto_config = config["services"]["crypto_manager"]
    except KeyError:
        logger.error("no configuration found for crypto_manager")
        raise

    start_app(crypto_config)


@app.route("/crypto/news", method="GET")
@cached("CRYPTO_NEWS", "1min")
def get_crypto_news():
    return {"success": True, "articles": crypto.cryptocompare.get_news()}


@app.route("/crypto/ratings", method="GET")
@cached("CRYPTO_RATINGS", "10min")
def get_crypto_ratings():
    all_ratings = sbt_crypto.crypto_ratings.get_all_ratings()
    symbol_list = [i["symbol"] for i in all_ratings]
    market_data = sbt_crypto.coingecko.get_market_data(*symbol_list)

    price_changes_30d = sbt_crypto.timeseries.get_price_change(symbol_list, 30)
    for item in market_data:
        price_change = price_changes_30d.get(item["symbol"].upper(), {})
        item["price_change_30d"] = price_change.get("change_amount")
        item["price_change_percentage_30d"] = price_change.get("change_pct")

    market_data_by_symbol = {i["symbol"].upper(): i for i in market_data}

    for rating in all_ratings:
        description = sbt_crypto.coinlist.get_description(rating["symbol"])
        if description:
            rating.update(**description)

        if market_data_by_symbol.get(rating["symbol"]):
            market_data = market_data_by_symbol[rating["symbol"]]
            for k in ["current_price", "market_cap", "total_volume", "high_24h", "low_24h", "price_change_24h",
                      "price_change_percentage_24h", "market_cap_change_24h", "market_cap_change_percentage_24h",
                      "price_change_30d", "price_change_percentage_30d"]:
                if k in market_data:
                    rating[k] = market_data[k]

    return {"success": True, "ratings": all_ratings}


@app.route("/crypto/rating/<symbol>", method="GET")
@cached("CRYPTO_RATING", "10min", keys=["symbol"])
def get_crypto_rating(symbol):
    rating = sbt_crypto.crypto_ratings.get_rating(symbol)
    description = sbt_crypto.coinlist.get_description(symbol)
    if description:
        rating.update(**description)

    return {"success": True, "rating": rating}


@app.route("/crypto/prices/<symbols>", method="GET")
@cached("CRYPTO_PRICES", "1min", keys=["symbols"])
def get_crypto_price(symbols):
    symbols = symbols.split(",")
    return {"success": True, "prices": sbt_crypto.cryptocompare.get_prices(symbols)}


@app.route("/crypto/marketdata", method="GET")
@cached("CRYPTO_MARKET_DATA", "1min")
def get_crypto_market_data():
    coin_list = sbt_crypto.cryptocompare.get_top_ranked(count=25)
    symbol_list = [i["symbol"] for i in coin_list]

    market_data = sbt_crypto.coingecko.get_market_data(*symbol_list)
    price_changes_30d = sbt_crypto.timeseries.get_price_change(symbol_list, 30)

    for item in market_data:
        price_change = price_changes_30d.get(item["symbol"].upper(), {})
        item["price_change_30d"] = price_change.get("change_amount")
        item["price_change_percentage_30d"] = price_change.get("change_pct")

    return {"success": True, "marketdata": market_data}


@app.route("/crypto/news", method="GET")
@cached("CRYPTO_ARTICLES", "1min")
def get_crypto_news():
    articles = sbt_crypto.articles.get_articles()
    return articles


@app.route("/crypto/topmovers", method="GET")
@app.route("/crypto/topmovers/<num_days:int>", method="GET")
@cached("CRYPTO_MOVERS", "10min", keys=["num_days"])
def get_top_movers(num_days=7):
    top_movers = sbt_crypto.timeseries.get_top_movers(num_days)
    for coin in top_movers:
        description = sbt_crypto.coinlist.get_description(coin["symbol"])
        if description:
            coin.update(**description)

    return {"success": True, "top_movers": top_movers}


## Functions moved over from sbcontent_manager
# TODO Add Cache
@app.route("/crypto/<method>", method="GET")
@app.route("/crypto/data/<method>/<f>/<t>", method="GET")
@app.route("/crypto/data/<method>/<f>/<t>/<limit>", method="GET")
@app.route("/crypto/data/<method>/<f>/<t>/<limit>/<ts>", method="GET")
@cached("CRYPTO_GENERIC", "10min", keys=['method','f','t','limit','ts'])
def get_crypto_currencies(method="coinlist", f=None, t=None, limit=None, ts=None, id=None):
    try:
        data = crypto.generic_call(method=method, f=f, t=t, limit=limit, ts=ts, id=id)
        return {"success": True, "timestamp": ts, "data": data} if ts else \
            {"success": True, "data": data}
    except Exception:
        return {"success": False, "error": "Cannot retrieve data."}


@app.route("/crypto/social/<coin_symbol>", method="GET")
@cached("CRYPTO_SOCIAL", "2min", keys=["coin_symbol"])
def get_crypto_social_stats(coin_symbol=None):
    try:
        data = crypto.get_social_stats(coin_symbol)
        return {"success": True, "data": data}
    except Exception:
        return {"success": False, "error": "Cannot retrieve data."}


@app.route("/crypto/contracts", method="GET")
@cached("CRYPTO_CONTRACTS", "2min")
def get_mining_contracts():
    try:
        data = crypto.get_mining_contracts()
        return {"success": True, "data": data}
    except Exception:
        return {"success": False, "error": "Cannot retrieve data."}


if __name__ == "__main__":
    logger.info("starting")

    start()
    cherrypy.engine.block()
