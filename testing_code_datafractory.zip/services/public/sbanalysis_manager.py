import simplejson as json
from decimal import Decimal
import os
import numpy as np
import pandas as pd

import sys
import logging
import cherrypy
import bottle
import traceback
import datetime
import service_utils
from time import sleep
from datetime import datetime, timezone

from api_service import app, start_app
from sbt_model import Model
from sbt_model import ModelId
from dd_accessor import DynamoAccessor
from sbt_common import SbtCommon, SbtGlobalCommon
from sbt_common import SingletonServiceManager
from sc_accessor import ScreenerAccessor
from services.util.auth_utils import authenticated, entitlements
from pg_accessor import PostgresAccessor
from cache_utils import cached

# get the config
config = SbtGlobalCommon.get_sbt_config()['postgres']['datafactory']
# create an instance of the PG accessor
pg = PostgresAccessor(config)
# get the engine
engine = pg._engine

sbtcommon = SbtCommon()
logger = sbtcommon.get_logger(logging.INFO, __name__)

# sbanalysis = None


###############################################################################
# SBAnalysisManager:
###############################################################################
class SBAnalysisManager(object, metaclass=SingletonServiceManager):
    filesdir = '/opt/sbanalysis/res/'

    '''
    Singleton class initializer
    '''

    def __init__(self, cfg):
        logger.info("SBAnalysisManager: initializing")
        self.configured = False
        self.fin = False
        self.env = dict(os.environ)
        self.cfg = cfg
        self._password = 'datafactory'  # TODO: Fix me Read from config
        self.dbq = None
        self.screener = ScreenerAccessor()
        self.ce_model = Model(ModelId.CAPITAL_EFFICIENCY.value)
        self.md_model = Model(ModelId.MD_SCORE.value)
        self.md_model_fin = Model(ModelId.MD_SCORE_FIN.value)
        self.mom_model = Model(ModelId.MOMENTUM.value)
        self.mm_momentum = Model(ModelId.MM_MOMENTUM.value)
        self.dividend = Model(ModelId.DIVIDEND.value)
        self.composite = Model(ModelId.COMPOSITE.value)
        self.dd = DynamoAccessor()

        # list of monitors supported
        self.MONITORS_LIST = ['magic-stocks', 'trophy-assets', 'global-oil',
                              'global-elite', 'insurance']
        self.MONITORS_DESCRIPTION = {
            "magic-stocks": {
                "col_name": ['ticker', 'company', 'mcap', 'beta', 'opermargin',
                             'retcaprev', 'ev_ebitda'],
                "description": ['Ticker', 'Company', 'Market Cap', 'Beta',
                                'Oper. Margin (%)',
                                'Returned Capital (% of Revenue)',
                                'EV/EBITDA'],
                "dtype": ['text', 'text', 'number', 'number', 'number',
                          'number', 'number'],
            },
            "trophy-assets": {
                "col_name": ["rank", "company", "ticker", "trophy_asset",
                             "mcap", "total_assets",
                             "disc_prem_to_total_assets",
                             "value_above_low_valuation", 'updated_on'],
                "description": ['Rank', 'Company', 'Ticker', 'Trophy Asset',
                                'Market Cap', 'Total Assets',
                                'Discount/Premium to Total Assets',
                                'Percentage Above Low Valuation'],
                "dtype": ['number', 'text', 'text', 'text', 'number', 'number',
                          'number', 'number'],
            },
            "global-oil": {
                "col_name": ["rank", "company", "ticker", "oil_mix",
                             "debt_to_asset_ratio", "margin_per_boe", "equity",
                             "total_adj_debt", "adj_ev", "asset_value",
                             "disc_prem_to_asset_value", "is_debt_gt_equity"],
                "description": ["Rank", "Company", "Ticker", "Oil Mix",
                                "Debt-to-Asset Ratio", "Margin per BOE",
                                "Equity Value",
                                "Total Adjusted Debt", "Adjusted EV",
                                "Asset Value",
                                "Discount/Premium to Asset Value",
                                "Is Debt greater than Equity"],
                "dtype": ['number', 'text', 'text', 'number', 'number',
                          'number', 'number', 'number', 'number', 'number',
                          'number', 'number', 'text'],
            },
            "global-elite": {
                "col_name": ["company", "ticker", "industry", "mcap",
                             "ev_ebitda", "price_to_book", "price_to_sales",
                             "roe",
                             "roa", "dividend_yield", "sector", 'updated_on'],
                "description": ["Company", "Ticker", "Industry", "Market Cap",
                                "EV/EBITDA", "Price-to-Book Ratio",
                                "Price-to-Sale", "ROE (%)", "ROA (%)",
                                "12-mo Dividend Yield (%)", "Sector"],
                "dtype": ['text', 'text', 'text', 'number', 'number', 'number',
                          'number', 'number', 'number', 'number', 'text'],
            },
            "insurance": {
                "col_name": ["ticker", "name", "ranking", "avgcomb_ratio",
                             "sh_return", "float_growth", "growth_invest",
                             "bv_per_share_growth", "float_book",
                             "mcap", "disc_prem_to_float_bv", "in_portfolio"],
                "description": ["Ticker", "Company", "Rank",
                                "Avg. Combined Ratio",
                                "Shareholder (S/H Return)", "Float Growth",
                                "Growth in Investments",
                                "Growth in Book Value per Share",
                                "Float + Book", "Market Cap",
                                "Discount/Premium to Float + BV",
                                "Is it in Portfolio"],
                "dtype": ['text', 'text', 'number', 'number', 'number',
                          'number', 'number', 'number', 'number', 'number',
                          'number', 'text'],
            }
        }
        # create an object that can be easily handled by the UI (e.g. "magic-stocks": {"ticker": "Ticker"})
        self.MONITORS_DESCRIPTION = {x: [[k, v, dt]
                                         for k, v, dt in zip(
                self.MONITORS_DESCRIPTION[x]['col_name'],
                self.MONITORS_DESCRIPTION[x]['description'],
                self.MONITORS_DESCRIPTION[x]['dtype'])]
                                     for x in self.MONITORS_LIST}

        logger.info(str(self.env))

    def __enter__(self):
        """
         Entry Point
        """
        return self

    def clean(self):
        """
        Close connection
        :return:
        """
        if self.fin:
            logger.info('INFO: cleaning up...')
            bottle.response.headers['Connection'] = 'close'
        else:
            logger.info('INFO: clean ignored')

    def __exit__(self, exception_type, exception_value, traceback):
        """
        Exit Point
        """
        if not self.fin:
            self.fin = True
            self.clean()
            sleep(2)
        else:
            sleep(1)

        logger.info("INFO: System exiting now!")

        sys.exit(0)

    @staticmethod
    def datetime_handler(x):  # TODO: Use Common DateTimeEncoder
        """

        :param x:
        :return:
        """
        if isinstance(x, datetime.date):
            return x.isoformat()
        elif isinstance(x, Decimal):
            return str(x)

        raise TypeError("Unknown type")

    def screener_get_category_keys(self):
        return self.screener.populate()

    def screener_scan(self, jsn):
        return self.screener.new_screener(jsn)

    def screener_get_count(self, jsn):
        return self.screener.new_screener_count(jsn)

    def screener_get_top_companies(self, full_list=None):
        return self.screener.get_top_companies(full_list)

    # def screener_get_market_cap(self, capsize):
    #   return screener.screener_query_by_market_cap(capsize)
    #
    # def screener_get_market_cap_count(self):
    #   return screener.get_market_cap_count()
    #
    # def screener_get_sector(self, sector):
    #   return screener.screener_query_by_sector(sector)
    #
    # def screener_get_sector_count(self):
    #   return screener.get_sector_count()

    def get_model_rankings(self, modeltype):
        """
          Returns a listing of the model rankings.

          Args :
            modeltype (str) : Model Type

          Returns :
            list : List containing the model rankings

        """
        logger.info("get_model_rankings params: " + modeltype)

        if modeltype.upper() == 'CAPITALEFFICIENCY':
            return self.ce_model.get_rankings()
        elif modeltype.upper() == 'MDSCORE':
            return self.md_model.get_rankings()
        elif modeltype.upper() == 'MDSCOREFIN':
            return self.md_model_fin.get_rankings()
        elif modeltype.upper() == 'MOMENTUM':
            return self.mom_model.get_rankings()
        elif modeltype.upper() == 'MM_MOMENTUM':
            return self.mm_momentum.get_rankings()
        elif modeltype.upper() == 'DIVIDEND':
            return self.dividend.get_rankings()
        elif modeltype.upper() == 'COMPOSITE':
            return self.composite.get_rankings()
        else:
            raise Exception('Model type is not supported')

    def get_model(self, composite_pk_id, modeltype):
        """

        :param composite_pk_id:
        :param modeltype:
        :return:
        """
        composite_pk_id = composite_pk_id.replace('~', ':')
        logger.info(
            "get_model "" model type {} for composite_pk_id: {}".format(
                modeltype, composite_pk_id
            )
        )

        if modeltype.upper() == 'CAPITALEFFICIENCY':
            return self.ce_model.get_company_model(composite_pk_id)
        elif modeltype.upper() == 'MDSCORE':
            return self.md_model.get_company_model(composite_pk_id)
        elif modeltype.upper() == 'MDSCOREFIN':
            return self.md_model_fin.get_company_model(composite_pk_id)
        elif modeltype.upper() == 'MOMENTUM':
            # data = self.mom_model.get_company_model(ticker)
            # [data.pop(x) for x in ['display_value', 'units', 'rank_units']]
            return self.mom_model.get_company_model(composite_pk_id)
        elif modeltype.upper() == 'MM_MOMENTUM':
            # return self.dd._query_table(table_name='mm_model',
            #                             key_name='symbol',
            #                             key_value=ticker.upper())
            return self.mm_momentum.get_company_model(composite_pk_id)
        elif modeltype.upper() == 'O3_OSCILLATOR':
            to_ret = self.dd._query_table(table_name='o3_indicator',
                                          key_name='symbol',
                                          key_value=composite_pk_id.upper())
            to_ret[0]['value'] = to_ret[0]['value']*100
            to_ret[0]['units'] = 'percent'
            return to_ret
        elif modeltype.upper() == 'DIVIDEND':
            return self.dividend.get_company_model(composite_pk_id)
        elif modeltype.upper() == 'COMPOSITE':
            return self.composite.get_company_model(composite_pk_id)
        else:
            raise Exception('Model type is not supported')

    def get_monitor(self, monitor_name):
        sql_query = "SELECT * FROM {}".format(
            "monitors_{}".format(monitor_name.replace('-', '_')))
        df = pd.read_sql_query(sql_query, engine, coerce_float=True)
        # get column names
        col_names = [k for k, v in df.items()]
        res_json_str = df.to_json(orient="records")
        res = json.loads(res_json_str, use_decimal=True)
        # select a single date and transforming it to seconds
        # updated_on = res[0]['updated_on'] / 1000
        # date = datetime.fromtimestamp(updated_on).date().strftime('%Y-%m-%d')
        # remove updated_on column
        updated_on = [x for x in {x.pop('updated_on') for x in res}][0] / 1000
        date = datetime.fromtimestamp(updated_on, tz=timezone.utc).date().strftime('%Y-%m-%d')
        # get url & file_url data & remove url & file_url columns
        url = [y for y in {x.pop('url') for x in res}][0]
        file_url = [y for y in {x.pop('file_url') for x in res}][0]
        labels = [{"id": x[0], "label": x[1], "data-type": x[2]}
                  for x in self.MONITORS_DESCRIPTION[monitor_name]]
        return {"data": res,
                "labels": labels,
                "updated_on": date,
                "url": url,
                "file_url": file_url
                }

    def get_model_stats(self, model_id=None):
        # sql_query = "SELECT * FROM sbt_models_{}_rating_stats".format(model_id)
        # df = pd.read_sql_query(sql_query, engine, coerce_float=True)
        # res_json_str = df.to_json(orient="records")
        # res = json.loads(res_json_str, use_decimal=True)

        sql_query1 = "select * from " \
                    "development_sbt_models_capeff_score_stats"
        sql_query2 = "select * from " \
                    "development_sbt_models_mdscore_valuation_score_stats"
        sql_query3 = "select * from " \
                    "development_sbt_models_mdscore_financial_score_stats"
        sql_query4 = "select * from " \
                     "development_sbt_models_mmmomentum_score_stats"
        sql_query5 = "select * from " \
                     "development_sbt_models_dividend_score_stats"

        sql_query6 = "select * from " \
                     "development_sbt_models_composite_score_stats"

        if model_id == 'capitalefficiency':
            sql_query = sql_query1
        elif model_id == 'mdscore':
            sql_query = sql_query2
        elif model_id == 'mdscorefin':
            sql_query = sql_query3
        elif model_id == 'mm_momentum':
            sql_query = sql_query4
        elif model_id == 'dividend':
            sql_query = sql_query5
        elif model_id == 'composite':
            sql_query = sql_query6
        else:
            df1 = pd.read_sql_query(sql_query1, engine, coerce_float=True)
            df2 = pd.read_sql_query(sql_query2, engine, coerce_float=True)
            df3 = pd.read_sql_query(sql_query3, engine, coerce_float=True)
            df4 = pd.read_sql_query(sql_query4, engine, coerce_float=True)
            df5 = pd.read_sql_query(sql_query5, engine, coerce_float=True)
            df6 = pd.read_sql_query(sql_query6, engine, coerce_float=True)
            [x.pop('index') for x in [df1, df2, df3, df4, df5]]
            df1['model_id'] = 'CAPITAL_EFFICIENCY'
            df1.rename({'minRank': 'minscore', 'maxRank': 'maxscore'},
                       inplace=True, axis=1
                       )
            df2['model_id'] = 'MDSCORE_VALUATION'
            df3['model_id'] = 'MDSCORE_FINANCIAL'
            df4['model_id'] = 'MM_MOMENTUM'
            df5['model_id'] = 'DIVIDEND'
            df6['model_id'] = 'COMPOSITE'
            df = pd.concat([df1, df2, df3, df4, df5, df6])
            df.set_index('model_id')
            res_json_str = df.to_json(orient="records")
            res = json.loads(res_json_str, use_decimal=True)
            return {"results": res}

        df = pd.read_sql_query(sql_query, engine, coerce_float=True)
        res_json_str = df.to_json(orient="records")
        res = json.loads(res_json_str, use_decimal=True)
        return {"results": res}


###############################################################################
#                         IGNORE TRAILING SLASHES
###############################################################################
@app.hook('before_request')
def strip_path():
    bottle.request.environ['PATH_INFO'] = bottle.request.environ['PATH_INFO']. \
        rstrip('/')


###############################################################################
# REST API
###############################################################################
"""
  SBScreener
"""


@app.route("/analysis/screener/populate", method="GET")
# @cached("SCREENER_POPULATE", "1hour")
def sb_screener_populate():
    logger.info("Retrieve list of keys.")
    try:
        rval = {"success": True,
                "data": sbanalysis.screener_get_category_keys()}
    except Exception as e:
        bottle.response.status = 400
        rval = {"success": False, "error": "{}".format(e)}

    return rval


@app.route("/analysis/screener/get_top_companies/<full_list>", method="GET")
@app.route("/analysis/screener/get_top_companies", method="GET")
@cached("SCREENER_FULL", "1hour", keys=['full_list'])
def sb_screener_get_top_companies(full_list=None):
    logger.info("Get top companies.")
    try:
        if full_list is not None:
            if full_list == 'all':
                rval = {"success": True,
                        "data": sbanalysis.screener_get_top_companies(
                            full_list)}
            else:
                bottle.response.status = 400
                rval = {"success": False, "error": "Invalid parameters."}
        else:
            rval = {"success": True,
                    "data": sbanalysis.screener_get_top_companies()}
    except Exception as e:
        bottle.response.status = 400
        rval = {"success": False, "error": "{}".format(e)}

    return rval


@app.route("/analysis/screener", method="POST")
@cached('SCREENER', '10min', keys=['JSON'])
def sb_screener():
    jsn = bottle.request.json
    # logger.info(" Screening request using params: {}".format(jsn))

    try:
        result = sbanalysis.screener_scan(jsn)
        # not_empty = any(
        #         [[len(v) for v in item.values()][0] for item in result]
        # )
        # if not_empty:
        rval = {"success": True, "data": result}
        # else:
        #   return {"success": True,
        #           "warning": "Nothing matches the provided filter combination."
        #           }
    except:
        bottle.response.status = 400
        rval = {"success": False, "error": traceback.format_exc()}

    # logger.info(" Screener result: {}".format(rval))
    return rval


@app.route("/analysis/screener/get_count", method="POST")
@cached('SCREENER_COUNT', '10min', keys=['JSON'])
def sb_screener_get_count():
    jsn = bottle.request.json

    try:
        rval = {"success": True, "data": sbanalysis.screener_get_count(jsn)}
    except Exception as e:
        logger.debug(traceback.format_exc())
        bottle.response.status = 400
        rval = {"success": False, "error": str(e)}

    return rval


# @app.route("/analysis/screener/get_market_cap/<capsize>", method="GET")
# def sb_screener_get_market_cap(capsize):
#   logger.info(" Screening by market caps.")
#   result = app.sbanalysis.screener_get_market_cap_count() \
#     if capsize == "count" else app.sbanalysis.screener_get_market_cap(capsize)
#   try:
#     rval = {"success": True, "data": result}
#   except:
#     bottle.response.status = 400
#     rval = {"success": False, "error": traceback.format_exc()}
#
#   return rval
#
#
# @app.route("/analysis/screener/get_sector/<sector>", method="GET")
# def sb_screener_get_market_cap_by_sector(sector):
#   sector = sector.replace("-", " ").title()
#   logger.info(" Screening by sector: {}".format(sector))
#   result = app.sbanalysis.screener_get_sector_count() \
#     if sector.lower() == "count" else app.sbanalysis.screener_get_sector(sector)
#   try:
#     rval = {"success": True, "data": result}
#   except:
#     bottle.response.status = 400
#     rval = {"success": False, "error": traceback.format_exc()}
#
#   return rval
#
#
# @app.route("/analysis/screener/stats/<category>", method="GET")
# def sb_screener_get_market_cap_by_category(category):
#   logger.info(" Getting stats for {}".format(category))
#   result = app.sbanalysis.screener_get_sector_count() \
#     if category.lower() == "sector" else app.sbanalysis.screener_get_market_cap_count()
#   try:
#     rval = {"success": True, "data": result}
#   except:
#     bottle.response.status = 400
#     rval = {"success": False, "error": traceback.format_exc()}
#
#   return rval


# @app.route("/analysis/model/<modeltype>/<symbol>/<modelformat>", method="GET")
@app.route("/analysis/model/<modeltype>/<composite_pk_id>", method="GET")
@authenticated
@cached("SCREENER_MODELTYPE", "1hour", keys=["PATH"])
def sb_display_model_type(modeltype, composite_pk_id):
    """
    """
    try:
        m = sbanalysis.get_model(composite_pk_id, modeltype)
        return {"success": True if isinstance(m, dict) else False, "model": m}
    except:
        bottle.response.status = 400
        return {"success": False, "error": traceback.format_exc()}

@app.route("/analysis/modelstats/<modeltype>", method="GET")
@app.route("/analysis/modelstats/all", method="GET")
@authenticated
@cached("SCREENER_MODELTYPE", "1hour", keys=["PATH"])
def sb_display_model_stats(modeltype=None):
    """
    """
    try:
        m = sbanalysis.get_model_stats(modeltype)
        # m.update(model_id=modeltype)
        return {"success": True, "data": m}
    except:
        bottle.response.status = 400
        return {"success": False, "error": traceback.format_exc()}


@app.route("/analysis/modelrankings/<modeltype>", method="GET")
@authenticated
@cached("SCREENER_MODELRANKINGS", "1hour", keys=["PATH"])
def sb_model_rankings(modeltype):
    """
      Returns a JSON response containing the model rankings.

      Args :
        modeltype (str) : Model Type

      Returns :
        json : JSON containing the model rankings

    """
    logger.info("Model params - ModelType " + modeltype)

    try:
        m = sbanalysis.get_model_rankings(modeltype)
        return {"success": True, "model": {"type": modeltype, "rankings": m}}
    except:
        bottle.response.status = 400
        return {"success": False, "error": traceback.format_exc()}


"""
  SBDisplayModel
"""


@app.route("/analysis/display_model/<ticker>/<modeltype>", method="GET")
@authenticated
@cached("SCREENER_DISPLAY", "1hour", keys=["PATH"])
def sb_display_model(ticker, modeltype):
    logger.info(
        "Model params - Ticker : " + ticker + "  ModelType " + modeltype)

    try:
        m = sbanalysis.get_model(ticker, modeltype)
        return {"success": True, "model": m}
    except:
        bottle.response.status = 400
        return {"success": False, "error": traceback.format_exc()}


"""
  URLs to SEC Edgar documents
"""


@app.route("/analysis/secedgar/<symbol>/<prior_to>/<count>/<filing_type>",
           method="GET")
@authenticated
@cached("SCREENER_SECEDGAR", "1hour", keys=["symbol","prior_to","count","filing_type"])
def get_secedgar(symbol, prior_to, count, filing_type):
    """
    Get the URL for all the SEC Edgar filed forms
    :param symbol: a valid ticker symbol.
    :param prior_to: retrieve data up to this date (YYYYMMDD format).
    :param count: maximum number of items to retrieve
    :param filing_type: the type of filing to request (e.g.: 10-K, 10-Q, SD)
    :return: JSON file with a list of URL for all the docs that have been
    filed by the company.
    """
    data = sbanalysis.spider.get_url_list(symbol, prior_to, count, filing_type)
    if data is not None and len(data) > 0:
        return {"success": True, "url": data}
    else:
        bottle.response.status = 400
        return {"success": False, "error": 'Error: No results'}


@app.route("/analysis/monitors", method="GET")
@authenticated
@cached("SCREENER_MONITORS", "1hour")
def get_all_monitors_at_once():
    # returns all monitor's data at once
    all_monitors = []
    try:
        bottle.response.status = 200
        [all_monitors.append({
            "name": monitor,
            "data": sbanalysis.get_monitor(monitor).get("data", None),
            "labels": sbanalysis.get_monitor(monitor).get("labels", None),
            "updated_on": sbanalysis.get_monitor(monitor).get("updated_on", None),
            "url": sbanalysis.get_monitor(monitor).get("url", None),
            "file_url": sbanalysis.get_monitor(monitor).get("file_url", None)
        }) for monitor in sbanalysis.MONITORS_LIST]
        rval = {"success": True, "results": all_monitors}
    except Exception as e:
        bottle.response.status = 400
        rval = {"success": False, "error": "An error occurred: {}".format(e)}

    return rval


@app.route("/analysis/monitor/<monitor_name>", method="GET")
@authenticated
@cached("SCREENER_SECEDGAR", "1hour", keys=['monitor_name'])
def get_monitor(monitor_name=None):
    rval = {}
    try:
        if monitor_name:
            bottle.response.status = 200
            data = sbanalysis.get_monitor(monitor_name)
            if data:
                rval = {"success": True, "results": data}
            else:
                rval = {"success": False,
                        "error": "No data available for monitor {}".format(
                            monitor_name)}
    except Exception as e:
        bottle.response.status = 400
        rval = {"success": False, "error": "Error message: {}".format(e)}

    return rval


def error_401(error):
    """
    :param error:
    :return:
    """
    service_utils.add_cors_headers()
    return service_utils.json_error(error)

    ###############################################################################
    # error_500
    ###########################################################################
    return rval


@app.error(401)  ####
@bottle.error(500)
def error_500(error):
    """Standard dictionary returned on 500 error"""
    service_utils.add_cors_headers()
    return service_utils.json_error(error)


###############################################################################
# start
###############################################################################
def start():
    global sbanalysis

    config = SbtGlobalCommon.get_sbt_config()['services']['analysis']
    sbanalysis = SBAnalysisManager(config)
    app.sbanalysis = sbanalysis

    start_app(config)


###############################################################################
# main
###############################################################################
if __name__ == '__main__':
    logger.info("starting")

    start()
    cherrypy.engine.block()
