import logging
import json
from datetime import datetime
from redis_manager import RedisManager
from sbt_common import SbtGlobalCommon
logger = SbtGlobalCommon.get_logger(logging.INFO, 'PubSub')

def start():
  redis = RedisManager()
  pubsub = redis.pubsub()
  pubsub.psubscribe(['index', 'stocks'])
  logger.info("Listening to Stock Prices")

  stock_keys = [ 'symbol', 'name', 'day_code', 'server_timestamp', 'mode', 'last_price', 'trade_timestamp',
    'net_change', 'percent_change', 'tick', 'bid' , 'bid_size', 'ask', 'ask_size', 'unit_code','open',
     'high', 'low', 'close','num_trades', 'dollar_volume', 'flag', 'previous_close', 'volume',
     'previous_volume', 'fifty_two_week_high', 'fifty_two_week_low', 'exchange', 'price_change',
     'percentage_price_change', 'timestamp', 'trade_occurred']

  index_keys = ['symbol', 'day_code', 'value_change', 'percentage_value_change', 'value', 'previous_value']

  while True:
    for msg in pubsub.listen():
      try:
        if msg != None:
          data = json.loads(msg['data'].decode('utf-8'))

          if data:
            if 'exchange' in data:
              stock_key = data["symbol"] + '~' + data["exchange"]
            else:
              stock_key = data["symbol"]

            cache_data = {}

            if '~' in stock_key:
              if data['trade_occurred'] == 1:
                for key in stock_keys:
                  if key in data:
                    if key == 'price_change' :
                      cache_data['net_change'] = data[key]
                    elif key == 'percentage_price_change':
<<<<<<< HEAD
                      cache_data['percentage_change'] = data[key]
=======
                      cache_data['percent_change'] = data[key]
>>>>>>> origin
                    elif key == 'previous_trades':
                      cache_data['previous_trade_count'] = data[key]
                    elif key == 'period_trade_delta':
                      cache_data['trade_delta'] = data[key]
                    else:
                      cache_data[key] = data[key]

                cache_data["supports_streaming"] = True
            else:
              for key in index_keys:
                if key in data:
                  cache_data[key] = data[key]

            if cache_data:
              cache_data['created_at'] = int(datetime.utcnow().timestamp())
              redis.process_stock_cache(stock_key, cache_data)

      except Exception as exc:
        logger.error('Failed to process message Exception : ' + str(exc))
        logger.error(msg['data'])

if __name__ == "__main__":
  start()
