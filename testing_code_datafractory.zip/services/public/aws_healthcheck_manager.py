import bottle
import cherrypy
import logging
from api_service import app, start_app
from sbt_common import SbtGlobalCommon
from xmlrpc.client import ServerProxy

logger = SbtGlobalCommon.get_logger(logging.INFO, 'aws_healthcheck_manager')
config = SbtGlobalCommon.get_sbt_config()
server = ServerProxy('http://127.0.0.1:9001/RPC2')

def start():
    try:
        healthcheck_config = config["services"]["health_manager"]
    except KeyError:
        logger.error("no configuration found for health_manager")
        raise

    start_app(healthcheck_config)


def get_health_status():
    ## All Process Details
    process = server.supervisor.getAllProcessInfo()
    process_states = [program['state'] for program in process]
    logger.info(process_states)
    result = len(process_states) > 0 and all(elem == process_states[0] for elem in process_states)
    return result


# AWS HEALTH CHECK
@app.route("/aws/healthcheck")
def aws_healthcheck():
    services_response = {"success": get_health_status()}
    if not services_response["success"]:
        bottle.response.status = 500
    return services_response


if __name__ == "__main__":
    logger.info("starting")

    start()
    cherrypy.engine.block()
