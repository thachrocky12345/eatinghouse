import os
import uuid

import sys
import logging
import cherrypy
import bottle
import json
import traceback
import subprocess
import datetime
import collections
import pandas as pd
from urllib.parse import unquote
import service_utils
from functools import lru_cache

import intrinio_etf
from api_service import app, start_app
from barchart_accessor import BarchartAccessor
from fs_accessor import FinancialAccessor
from ar_accessor import ArticleAccessor
from pg_accessor import PostgresAccessor
from mongo_accessor import MongoAccessor
from time import sleep
from sbt_common import SbtCommon, SbtGlobalCommon
from sbt_common import SingletonServiceManager
from sbt_common import paginate_data
from sbt_common import timing
from services.util.auth_utils import authenticated, entitlements
from cbonds_accessor import CBondsAccessor
from mp_accessor import MappingAccessor
from cache_utils import cached

bottle.BaseRequest.MEMFILE_MAX = 2048 * 1024 * 512

sbtcommon = SbtCommon()
_symbol_expiration_details = MongoAccessor('symbol_expiration_details')
_symbol_options = MongoAccessor('symbol_options')
logger = sbtcommon.get_logger(logging.INFO, __name__)
# fum = None


###############################################################################
# SingletonFundamentalsManager:
###############################################################################
class FundamentalsManager(object, metaclass=SingletonServiceManager):
    filesdir = '/opt/sbt/fumanager/res/'

    def __init__(self, config):
        """
          Singleton class initializer
        """
        logger.info("FundamentalsManager: initializing")
        self.configured = False
        self.fin = False
        self.env = dict(os.environ)
        self.dbq = None
        esconf = sbtcommon.get_cfg_env_var("elasticsearch")
        self.article_accessor = ArticleAccessor(esconf)
        self._mp_accessor = MappingAccessor()
        # create instance of the porters_list_portfolio collection from mongoDB
        self._porters_list_portfolio = MongoAccessor("porters_list_portfolio")
        self._cache_refresh_date = None

        for v in self.env:
            logger.info("env: " + v + " " + self.env[v])

        self.configure(config)

    def __enter__(self):
        """
          Entry Point
        """
        return self

    def clean(self):
        """
          Entry Point
        """
        if self.fin:
            logger.info('INFO: cleaning up...')
            bottle.response.headers['Connection'] = 'close'
        else:
            logger.info('INFO: clean ignored')

    def __exit__(self, exception_type, exception_value, traceback):
        """
          Exit Point
        """
        if not self.fin:
            self.fin = True
            self.clean()
            sleep(2)
        else:
            sleep(1)

            logger.info("INFO: System exiting now!")

        sys.exit(0)

    def configure(self, config):
        """
          Configure
        """
        logger.info("FundamentalsManager: configuring")

        env_conf = sbtcommon.get_sbt_config()
        vendor = config['vendor']

        if 'financials' in env_conf and 'vendor' in env_conf['financials']:
            vendor = env_conf['financials']['vendor']

        logger.info('Financial Accessor setup with vendor : ' + vendor)
        self.dbq = FinancialAccessor(vendor)
        self._barchart_accessor = BarchartAccessor()
        self.category_groups = self.dbq.query_category_groups()
        pgconfig = SbtGlobalCommon.get_sbt_config()['postgres']['datafactory']
        self.pg_accessor = PostgresAccessor(pgconfig)
        self.description = pd.read_sql_table('screener_test_description',
                                             self.pg_accessor._engine,
                                             index_col=None)
        self.description_keys = self.description.column.tolist()
        self.configured = True

    def get_etf(self, symbol):
        return self.dbq.query_etf(symbol)

    def get_etf_holdings(self, symbol):
        return self.dbq.query_etf_holdings(symbol)

    def get_company_article_data(self, data):
        # articles = None
        # bullets = None
        # articles_length = None

        try:
            # Use this call to avoid issues with guids that are past in.
            # valid_data = self.is_valid_symbol(data, exchange=None)
            # if data.get('supports_sb_content'):
            bullets = self.article_accessor.query_articles_company_bullets(
                data.get('tickersymbol'))
            articles = self.article_accessor.query_articles_company_descriptions(
                data.get('tickersymbol'))
            articles_length = len(articles)
        except Exception as e:
            articles = None
            bullets = None
            articles_length = None
            logger.error(
                'Failed to retrieve article data for company description ' +
                'Exception: ' + str(e) + ' ' +
                'Traceback: ' + traceback.format_exc())

        # logger.error('S====TEST0')
        # logger.error(valid_data);
        # logger.error(articles);
        # logger.error(bullets);
        # logger.error('E====TEST0')

        # if not articles or bullets:
        #     return articles, bullets, articles_length

        # a_sym = None
        # check_symbol, check_exchange, check_country = \
        #     self._mp_accessor.parse_mapping_symbol(data)
        # if '.' in check_symbol and len(check_symbol) == 6 and \
        #         check_symbol.endswith('Y'):
        #     a_sym = check_symbol.replace('.', '')
        #
        # if not a_sym:
        #     return articles, bullets, articles_length
        #
        # try:
        #     # Use this call to avoid issues with guids that are past in.
        #     valid_data = self.is_valid_symbol(a_sym, exchange=check_exchange)
        #     if valid_data and valid_data['valid'] and \
        #             valid_data['supports_sb_content']:
        #         bullets = self.article_accessor.query_articles_company_bullets(
        #             a_sym)
        #         articles = self.article_accessor.query_articles_company_descriptions(
        #             a_sym)
        #         articles_length = len(articles)
        # except Exception as e:
        #     articles = None
        #     bullets = None
        #     articles_length = None
        #     logger.error(
        #         'Failed to retrieve article data for company description ' +
        #         'Exception: ' + str(e) + ' ' +
        #         'Traceback: ' + traceback.format_exc())
        #
        # # logger.error('S====TEST1')
        # # logger.error(valid_data);
        # # logger.error(articles);
        # # logger.error(bullets);
        # # logger.error('E====TEST1')
        #
        return articles, bullets, articles_length

    def get_capital_structure_debt_detail(self, symbol):
        return self.dbq.query_capital_structure_debt_detail(symbol)

    def query_capital_structure_debt_yearly_summary(self, symbol):
        return self.dbq.query_capital_structure_debt_yearly_summary(symbol)

    def get_debt_summary(self, symbol):
        return self.dbq.query_debt_summary(symbol)

    def lookup_symbol(self, limit, fields,
                      symbol, exchange=None):
        ret_value = {}

        data = self.dbq.lookup_symbol(symbol, exchange=exchange)

        if data:
            results = []
            for d in data:
                comp = {}
                comp['symbol'] = d['symbol']
                comp['name'] = d['entity_name']
                exchange_type = 'Stocks'
                if d.get('exchange_type', 'N/A') not in ['STOCK']:
                    exchange_type = d.get('exchange_type', 'N/A')
                comp['exchange'] = d['exchange']
                comp['type'] = exchange_type

                if exchange_type == 'Stocks' and \
                        d.get('exchange_country', 'N/A') == 'USA':
                    comp['supports_streaming'] = True
                else:
                    comp['supports_streaming'] = False

                results.append(comp)

            ret_value['status'] = {
                "code": 200,
                "message": "Success."
            }

            ret_value['results'] = results

        else:
            ret_value = self._lookup_barchart_symbol(limit, fields, symbol)

        return ret_value

    def is_valid_symbol(self, symbol, exchange=None, return_snapshot=False):
        """
          Returns a dictionary with metadata indicating whether a
          symbol is loaded in the database.

          Args :
            symbol(str)     : Stock ticker symbol
            exchange(str)   : Exchange
          Returns :
            dict : Validation response
            :param return_snapshot:

        """
        return self.dbq.is_valid_symbol(symbol, exchange, return_snapshot)

    def get_company_sec_filings(self, symbol):
        """
          Returns dictionary containing the SEC filings and related metadata
          for the specified company.

          Args :
            symbol(str)       : Stock ticker symbol

          Returns :
            dict : Sec filings and metadata

        """
        return self.dbq.query_company_sec_filings(symbol)

    def get_index(self, symbol):
        """
          Returns dictionary containing information related to the index.

          Args :
            symbol(str)     : index ticker symbol

          Returns :
            dict : index information

        """
        return self.dbq.query_index(symbol)

    def get_stock_price(self, symbol, timeframe, exchange=None):
        """
          Returns daily stock prices for a specific symbol.

          Args :
            symbol(str)     : Stock ticker symbol
            timeframe(str)  : Valid Values (1d,1m,1y,5y,10y,Max)
            enchange(str)   : Exchange code

          Returns :
            list : Stock Data by day

        """
        return self.dbq.query_stock_price(symbol, timeframe,
                                          exchange=exchange)

    def getfundamentals(self, symbol, year):
        """
          Get Fundamentals for the specified symbol
          TODO: testing here move to SBFundamentalsManager
        """
        logger.info(
            "FundamentalsManager: retrieve fundamentals for " + symbol + ' year ' + str(
                year))
        rval = {}
        try:
            rval = self.dbq.query_dynamodb(symbol, year)
        except subprocess.CalledProcessError as e:
            logger.info("Caught exception call subprocess: " + str(e))

        logger.info("query complete")
        logger.info(json.dumps(rval))

        return rval

    def get_history_data(self, symbol, column, typ=None):
        """
          Returns a list of financial data for the specified symbol
          and column and typ

          Args :
            symbol (str) : Ticker Symbol
            column (str) : Column data
            typ(str)     : Fiscal Period (a - annual, q - quarterly)

          Returns :
            list : Column values
        """
        typ = typ if typ is not None else 'a'
        logger.info("FundamentalsManager: retrieve column " + column +
                    " for " + symbol)
        return self.dbq.query_history_data(symbol, column, typ, 'asc')

    def getinsidermetric(self, symbol, metrictype):
        """
          Get a specific insider metrics type for the specified symbol
        """
        logger.info("FundamentalsManager: retrieve insider metric type " +
                    str(metrictype) + " for " + symbol)
        rval = {}
        try:
            if int(metrictype) < 1:
                rval = self._get_all_insider_metrics(symbol)
            else:
                temp = self.dbq.query_insider_metrics(symbol, metrictype)
                if temp and len(temp) > 0:
                    rval = temp[0]

            for k, v in rval.items():
                if v == "None":
                    rval[k] = None

        except subprocess.CalledProcessError as e:
            logger.info("Caught exception call subprocess: ") + str(e)
            logger.info("query complete")
            logger.info(json.dumps(rval))

            logger.info("query complete")
            logger.info(json.dumps(rval))

        return rval

    def get_insider_ownership(self, symbol):
        """
          Get insider ownership for the specified symbol

          Args :
            symbol (str) : Ticker Symbol

          Returns :
            dict : Insider ownership
        """
        logger.info("FundamentalsManager: retrieve insider ownership for " +
                    symbol)
        rval = {}
        try:
            temp = self.dbq.query_insider_ownership(symbol)
            if temp is not None:
                rval['ticker'] = symbol
                rval['count'] = len(temp)
                insiders = {}
                for item in temp:
                    owner_id = item['owner_cik']
                    item.pop('owner_cik')
                    item.pop('load_date')
                    insiders[owner_id] = item
                rval['owners'] = insiders

        except subprocess.CalledProcessError:
            logger.info("Caught exception call subprocess")
            logger.info("query complete")
            logger.info(json.dumps(rval))

            logger.info("query complete")
            logger.info(json.dumps(rval))

        return rval

    def getinsidertransactions(self, symbol):
        """
          Get insider transactions for the specified symbol
        """
        logger.info("FundamentalsManager: retrieve insider transactions for " +
                    symbol)
        rval = {}
        try:
            temp = self.dbq.query_insider_transactions(symbol)
            if temp is not None:
                rval['ticker'] = symbol
                rval['count'] = len(temp)
                insiders = {}
                for item in temp:
                    id = item['owner_id']
                    item.pop('owner_id')
                    insiders[id] = item
                rval['transactions'] = insiders

        except subprocess.CalledProcessError as e:
            logger.info("Caught exception call subprocess " + str(e))
            logger.info("query complete")
            logger.info(json.dumps(rval))

            logger.info("query complete")
            logger.info(json.dumps(rval))

        return rval

    def getinstitutionalholdings(self, symbol):
        """
          Get institutional holdings for the specified symbol
        """
        logger.info(
            "FundamentalsManager: retrieve institutional holdings for " +
            symbol)
        rval = {}
        try:
            temp = self.dbq.query_institutional_holdings(symbol)
            if temp is not None:
                rval['ticker'] = symbol
                rval['count'] = len(temp)
                inst = {}
                for item in temp:
                    if 'inst_nbr' in item.keys():
                        inst[item['inst_nbr']] = item
                    else:
                        inst[item['owner_cik']] = item
                rval['companies'] = inst

        except subprocess.CalledProcessError as e:
            logger.info("Caught exception call subprocess: " + str(e))
            logger.info("query complete")
            logger.info(json.dumps(rval))

            logger.info("query complete")
            logger.info(json.dumps(rval))

        return rval

    def getdescription(self, full, symbol):
        """
          Get company description for the specified symbol
        """
        logger.info("FundamentalsManager: retrieve description for " + symbol)
        rval = {}
        try:
            items = self.dbq.query_company(symbol.upper())
            if full == 'false':  # desc field only
                for i in items:
                    logger.info(str(i['comp_desc']))
                    rval = i['comp_desc']
                    break
            else:
                rval = items
        except subprocess.CalledProcessError as e:
            logger.info("Caught exception call subprocess: " + str(e))
            logger.info("query complete")
            logger.info(json.dumps(rval))

            logger.info("query complete")
            logger.info(json.dumps(rval))

        return rval

    def getcategoryfunds(self, category, symbol, year, typ):
        """
            getcategoryfunds
        """
        return self.dbq.query_financial_by_category(category, symbol, year,
                                                    typ)

    def getcategoryfundsrange(self, category, symbol, startyear, typ):
        """
            getcategoryfundsrange
        """
        return self.dbq.query_financial_by_category_from(category, symbol,
                                                         startyear, typ)

    @timing
    def getcategoryfundsfrmto(self, category, symbol, frm, to, typ):
        """
            getcategoryfundsrange
        """
        rval = self.dbq.query_financial_by_category_range(category, symbol,
                                                          frm, to, typ)
        if not rval:
            return {}

        params = []
        try:
            params = list(list(rval[list(rval.keys())[0]].values())[0].keys())
        except Exception as exc:
            logger.error(
                'Exception occurred retrieving descriptions : ' + str(exc))

        desc = []
        for param in params:
            entry = {}
            try:
                data = list(
                    self.description[self.description.column == param].values[
                        0])
                entry['column'] = data[0]
                entry['name'] = data[1]
                entry['unit'] = data[2]
                entry['description'] = data[3]
                entry['category'] = data[4]
            except Exception:
                entry['column'] = param
                entry['name'] = param
                entry['unit'] = 'N/A'
                entry['description'] = 'N/A'
                entry['category'] = category

            desc.append(entry)

        """
        This code causes an issue if a param is not present.
        It has been replaced by the above.

        desc = [{
          'column': list(
                  self.description[self.description.column == param].values[0])[0],
          'name': list(
                  self.description[self.description.column == param].values[0])[1],
          'unit': list(
                  self.description[self.description.column == param].values[0])[2],
          'description': list(
                  self.description[self.description.column == param].values[0])[3],
          'category': list(
                  self.description[self.description.column == param].values[0])[4]
        } for param in params]
        """
        # no_desc = [x['name'] for x in desc if x['description'] == '']
        # adding metadata
        rval.update(meta=desc)

        return rval

    def getcategorymetadata(self, category, symbol):
        """
          Returns metadata associated with a specific category and ticker
        """
        return self.dbq.query_metadata(category, symbol)

    @lru_cache(maxsize=2000, typed=False)
    def getcategorygroupings(self, category, symbol, frm, to, typ,
                             groupformat):
        logger.info("FundamentalsManager: retrieve category for " + symbol)

        if groupformat.lower() == 'snp' and \
                self.dbq.returns_formatted_grouping(category, symbol):
            return self.dbq.query_category_group_by_range_with_metadata(
                category, symbol,
                frm, to, typ)

        data = self.dbq.query_financial_by_category_range_with_metadata(
            category,
            symbol,
            frm, to, typ)
        cat_groups = self.dbq.query_category_group(category, symbol)

        if frm == "-1" and len(data['fundamentals']) > 0:
            frm = str(list(data['fundamentals'].keys())[0])

        if to == "-1":
            to = frm

        if typ.lower() == 'a':
            rval = self._convert_to_annual_groupings(data['fundamentals'],
                                                     cat_groups, frm, to)
        elif typ.lower() == 'q':
            rval = self._convert_to_quarterly_groupings(data['fundamentals'],
                                                        cat_groups, frm, to)
        else:
            raise Exception("Invalid type was provided.")

        if groupformat.lower() == 'snp':
            self.dbq.consolidate_and_check_groupings(category, rval)

        return {'metadata': data['metadata'], 'fundamentals': rval}

    def get_company_exchanges(self, company_id):
        return self.dbq.query_company_exchanges(company_id)

    def _convert_to_quarterly_groupings(self, data, cat_groups, frm, to):
        temp = collections.OrderedDict()

        for x in range(int(frm), int(to) + 1):
            if x in data.keys():
                temp[x] = {}
                for y in range(1, 5):
                    quarter_key = str(x) + '0' + str(y)
                    if quarter_key in data[x].keys():
                        data[x][quarter_key] = {k: v for k, v in \
                                                data[x][quarter_key].items() if
                                                v is not None}
                        temp[x][quarter_key] = collections.OrderedDict()
                        self._populate_quarterly_groupings(data, cat_groups,
                                                           temp,
                                                           x, quarter_key)

        return temp

    def _populate_quarterly_groupings(self, data, cat_groups,
                                      temp, x, quarter_key):
        field_descs = {}
        counter = 0

        for k, v in cat_groups.items():
            counter += 1
            label = k
            parent = None
            groupid = 'group_' + str(counter)
            parts = label.split(':')
            if len(parts) == 2:
                parent = parts[0]
                label = parts[1]
            temp[x][quarter_key][groupid] = {"group_label": label,
                                             "parent": parent,
                                             "order": counter,
                                             "fields": collections.OrderedDict()}
            sum = 0
            for group in v:
                value = "0"
                field = group.field
                if field.startswith('{sum}'):
                    value = str(sum)
                    field = field[5:]
                elif field in (data[x][quarter_key]).keys():
                    value = data[x][quarter_key][field]
                    sum += float(value)

                if field not in field_descs and \
                        field in self.description_keys:
                    field_descs[field] = \
                    self.description[self.description.column == field].values[
                        0][3]

                desc = 'Not Provided'
                if field in field_descs:
                    desc = field_descs[field]

                temp[x][quarter_key][groupid]["fields"][field] = {
                    "value": value,
                    "label": group.label,
                    "order": group.order,
                    "suffix": group.suffix,
                    "data_type_id": group.data_type_id,
                    "description": desc}

    def cache_clear(self):
        logger.info(self.getcategorygroupings.cache_info())
        if not self._cache_refresh_date:
            self._cache_refresh_date = datetime.datetime.now()
        else:
            current = datetime.datetime.now()

            if (current - self._cache_refresh_date).total_seconds() > 86400:
                logger.info('Clearing Fundamentals Cache')
                logger.info(self.getcategorygroupings.cache_info())
                self.getcategorygroupings.cache_clear()
                self.dbq.cache_clear()
                self._cache_refresh_date = current

    def _convert_to_annual_groupings(self, data, cat_groups, frm, to):
        temp = collections.OrderedDict()

        if data and frm and to:
            for x in range(int(frm), int(to) + 1):
                if x in data.keys() and str(x) in data[x].keys():
                    data[x][str(x)] = {k: v for k, v in data[x][str(x)].items() \
                                       if v is not None}
                    temp[x] = {str(x): collections.OrderedDict()}
                    self._populate_annual_groupings(data, cat_groups, temp, x)

        return temp

    def _populate_annual_groupings(self, data,
                                   cat_groups, temp, x):
        field_descs = {}

        counter = 0
        for k, v in cat_groups.items():
            counter += 1
            label = k
            parent = None
            groupid = 'group_' + str(counter)
            parts = label.split(':')
            if len(parts) == 2:
                parent = parts[0]
                label = parts[1]
            temp[x][str(x)][groupid] = {"group_label": label, "parent": parent,
                                        "order": counter,
                                        "fields": collections.OrderedDict()}
            sum = 0
            for group in v:
                value = "0"
                field = group.field
                if field.startswith('{sum}'):
                    value = str(sum)
                    field = field[5:]
                elif field in (data[x][str(x)]).keys():
                    value = data[x][str(x)][field]
                    sum += float(value)

                if field not in field_descs and \
                        field in self.description_keys:
                    field_descs[field] = \
                    self.description[self.description.column == field].values[
                        0][3]

                desc = 'Not Provided'
                if field in field_descs:
                    desc = field_descs[field]

                temp[x][str(x)][groupid]["fields"][field] = {
                    "value": value,
                    "label": group.label,
                    "order": group.order,
                    "suffix": group.suffix,
                    "data_type_id": group.data_type_id,
                    "description": desc}

    def _lookup_barchart_symbol(self, limit, fields, symbol):
        if '~' in symbol:
            parts = symbol.split('~')
            symbol = parts[0]
        elif ':' in symbol:
            parts = symbol.split(':')
            symbol = parts[0]

        barchart_data = self._barchart_accessor.get_symbol_lookup(limit,
                                                                  fields,
                                                                  symbol)

        results = []

        if barchart_data.get('status', {}).get('code', 400) == 200 and \
                barchart_data['results']:
            for b in barchart_data['results']:
                new = dict(b)
                b_type = new.get('type', 'N/A')
                if b_type in ['Stocks', 'ETF']:
                    new['supports_streaming'] = True

                if '-' in new.get('exchange', 'N/A'):
                    parts = new['exchange'].split('-')
                    b_exchange = parts[1].strip()
                    if b_exchange == 'NASDAQ':
                        b_exchange = 'NSDQ'
                    if b_exchange == 'OTHER OTC':
                        b_exchange = 'OTC'

                    new['exchange'] = b_exchange

                results.append(new)

            barchart_data['results'] = results

        return barchart_data

    def _get_all_insider_metrics(self, symbol):
        rval = {}

        temp = self.dbq.query_insider_metrics(symbol, 1)
        if temp and len(temp) > 0:
            rval = temp[0]
        temp = self.dbq.query_insider_metrics(symbol, 2)
        if temp and len(temp) > 0:
            rval.update(temp[0])
        temp = self.dbq.query_insider_metrics(symbol, 4)
        if temp and len(temp) > 0:
            rval.update(temp[0])

        return rval

    def get_snapshot(self, symbol):
        # calling is_valid_symbol from here requires the snapshot to be returned
        res = self.is_valid_symbol(symbol, return_snapshot=True)
        # res = self.dbq.get_snapshot(symbol_mapping.get('trading_item_id'))
        return res.get('snapshot')

    @staticmethod
    def is_valid_uuid(val):
        # returns True if val is formatted as a valid v4 UUID
        try:
            uuid.UUID(str(val))
            return True
        except ValueError:
            return False

    ###############################################################################


###############################################################################
#                         IGNORE TRAILING SLASHES
###############################################################################
@app.hook('before_request')
def strip_path():
    bottle.request.environ['PATH_INFO'] = bottle.request.environ['PATH_INFO']. \
        rstrip('/')


# Support CORS headers
# https://stackoverflow.com/questions/17262170/bottle-py-enabling-cors-for
# -jquery-ajax-requests
# Answer by ron.rothman
###############################################################################

@app.route('/<:re:.*>', method='OPTIONS')
def enable_cors_generic_route():
    """
    This route takes priority over all others. So any request with an OPTIONS
    method will be handled by this function.

    See: https://github.com/bottlepy/bottle/issues/402

    NOTE: This means we won't 404 any invalid path that is an OPTIONS request.
    """
    add_cors_headers()


@app.hook('after_request')
def enable_cors_after_request_hook():
    """
    This executes after every route. We use it to attach CORS headers when
    applicable.
    """
    add_cors_headers()


def add_cors_headers():
    bottle.response.headers['Access-Control-Allow-Origin'] = '*'
    bottle.response.headers['Access-Control-Allow-Methods'] = \
        'GET, POST, PUT, OPTIONS'
    bottle.response.headers['Access-Control-Allow-Headers'] = \
        'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token'


###############################################################################
#                                REST API
###############################################################################


@app.route("/zfmanager/history/<column>/<symbol>/<typ>", method="GET")
@app.route("/zfmanager/history/<column>/<symbol>", method="GET")
# @authenticated
@cached("FUN_HISTORY", "2min", keys=["column", "symbol", "typ"])
def get_historydata(column, symbol, typ=None):
    """
        Returns a dictional of financial data for the specified symbol
        and column and typ

        Args :
          symbol (str) : Ticker Symbol
          column (str) : Column data
          typ (str)    : Fiscal Period (a - annual, q - quarterly)

        Returns :
          dict : Column values
    """
    try:
        return {"success": True, 'fundamentals': fum.get_history_data(symbol,
                                                                      column,
                                                                      typ)}
    except:
        return {"success": False, "error": traceback.format_exc()}


@app.route("/zfmanager/categorymetadata/<category>/<symbol>", method="GET")
@authenticated
@cached("FUN_CATEGORYMETADATA", "2min", keys=["category", "symbol"])
def get_categorymetatdata(category, symbol):
    """
      Returns metadata associated with a specific category and ticker
    """
    try:
        return {"success": True,
                'metadata': {"ticker": symbol.upper(),
                             'category': category.upper(),
                             "fields": fum.getcategorymetadata(category,
                                                               symbol)}}
    except:
        return {"success": False, "error": traceback.format_exc()}


@app.route("/zfmanager/symbol/valid/<symbol>/<exchange>", method="GET")
@app.route("/zfmanager/symbol/valid/<symbol>", method="GET")
@cached("VALID", "10min", keys=["symbol", "exchange"])
def is_valid_symbol(symbol, exchange=None):
    fum.cache_clear()
    # create a list from the request
    symbol_list = symbol.split(',')
    # returned value list
    rval = []
    # set all UUID to valid = False
    [rval.append({'valid': False, 'symbol': x, 'exchange': None})
     for x in symbol_list if fum.is_valid_uuid(x)]

    # work on symbols that are not UUID
    [rval.append(fum.is_valid_symbol(symbol, exchange))
     for symbol in symbol_list if not fum.is_valid_uuid(symbol)]

    try:
        return {"success": True,
                "data": rval}
    except:
        return {"success": False, "error": traceback.format_exc()}


@app.route("/zfmanager/fundamentals/<symbol>/<year>", method="GET")
@app.route("/zfmanager/fundamentals/<symbol>", method="GET")
@cached("FUN_DETAILS", "10min", keys=["symbol", "year"])
@authenticated
def get_fundamentals(symbol, year=None):
    """
      get_fundamentals
    """
    logger.info(
        "FundamentalsManager: received fundamentals request for: " + symbol)

    if year is None:
        now = datetime.datetime.now()
        year = str(now.year - 1)

    try:
        return {"success": True,
                "fundamentals": fum.getfundamentals(symbol, year)}
    except:
        return {"success": False, "error": traceback.format_exc()}

# TODO Add cache
@app.route("/zfmanager/categoryfunds/<category>/<symbol>/<year>/<typ>",
           method="GET")
@app.route("/zfmanager/categoryfunds/<category>/<symbol>/<year>", method="GET")
@app.route("/zfmanager/categoryfunds/<category>/<symbol>", method="GET")
@authenticated
def get_categoryfunds(category, symbol, year=str(2018), typ="a"):
    """
      get_categoryfunds
    """
    logger.info(
        "FundamentalsManager: received category fundamentals request for: "
        + category + " " + symbol + " " +
        year + "-" + typ)

    try:
        return {"success": True,
                "fundamentals": fum.getcategoryfunds(category, symbol, year,
                                                     typ)}
    except:
        return {"success": False, "error": traceback.format_exc()}


@app.route(
    "/zfmanager/categoryfundsrange/<category>/<symbol>/<startyear>/<typ>",
    method="GET")
@app.route("/zfmanager/categoryfundsrange/<category>/<symbol>/<startyear>",
           method="GET")
@app.route("/zfmanager/categoryfundsrange/<category>/<symbol>", method="GET")
@authenticated
def get_categoryfundsrange(category, symbol, startyear=str(2012), typ="a"):
    logger.info(
        "FundamentalsManager: received category fundamentals request for: "
        + category + " " + symbol + " " +
        startyear + "-" + typ)
    """
    get_categoryfunds_range
    """
    try:
        return {"success": True,
                "fundamentals": fum.getcategoryfundsrange(category, symbol,
                                                          startyear, typ)}
    except:
        return {"success": False, "error": traceback.format_exc()}


@app.route(
    "/zfmanager/categorygrouping/<category>/<symbol>/<frm>/<to>/<typ>/<groupformat>",
    method="GET")
@app.route("/zfmanager/categorygrouping/<category>/<symbol>/<frm>/<to>/<typ>",
           method="GET")
@app.route("/zfmanager/categorygrouping/<category>/<symbol>", method="GET")
def getcategorygrouping(category, symbol, frm=str(2012),
                        to=str(2018), typ="a", groupformat='snp'):
    """
    get_categorygrouping
    """
    logger.info(
        "FundamentalsManager: received category grouping fundamentals "
        "request for: " + category + " " + symbol + " " +
        frm + "-" + to + " " + typ)

    try:
        fum.cache_clear()
        data = fum.getcategorygroupings(category, symbol, frm, to, typ,
                                        groupformat)

        data['success'] = True

        return data

    except Exception as e:
        logger.error('Method : getcategorygrouping Exception : ' +
                     str(e) + ' Stack Trace : ' + traceback.format_exc())
        return {"success": False,
                "error": "Unable to process request for for getcategorygrouping"}


@app.route(
    "/zfmanager/categoryfundsfromto/<category>/<symbol>/<frm>/<to>/<typ>",
    method="GET")
@authenticated
def get_categoryfundsfrmto(category, symbol, frm=str(2012), to=str(2018),
                           typ="a"):
    """
    get_categoryfunds_frm_to
    """
    logger.info(
        "FundamentalsManager: received category fundamentals request for: "
        + category + " " + symbol + " " +
        frm + "-" + to + " " + typ)

    try:
        return {"success": True,
                "fundamentals": fum.getcategoryfundsfrmto(category, symbol,
                                                          frm,
                                                          to, typ)}
    except:
        return {"success": False, "error": traceback.format_exc()}


@app.route("/zfmanager/insidermetrics/<symbol>", method="GET")
@app.route("/zfmanager/insidermetrics/<symbol>/<metrictype>", method="GET")
@authenticated
@cached("FUN_INSIDER", "10min", keys=["symbol", "metrictype"])
def get_insidermetrics(symbol, metrictype=-1):
    """
      get_institutionalholdings
    """
    logger.info("FundamentalsManager: received insider metrics type " + str(
        metrictype) + " request for: "
                + symbol)

    try:
        rval = {"success": True,
                "insider-metrics": fum.getinsidermetric(symbol.upper(),
                                                        metrictype)}
    except:
        rval = {"success": False, "error": traceback.format_exc()}

    return rval


@app.route("/zfmanager/insiderownership/<symbol>", method="GET")
@authenticated
@cached("FUN_OWNERSHIP", "10min", keys=['symbol'])
def get_insiderownership(symbol):
    """
      Get insider ownership for the specified symbol.

      Args :
        symbol (str) : Ticker Symbol

      Returns :
        dict : Insider ownership
    """
    logger.info("FundamentalsManager: received insider ownership request for: "
                + symbol)

    try:
        rval = {"success": True,
                "insider-ownership": fum.get_insider_ownership(
                    symbol.upper())}
    except:
        rval = {"success": False, "error": traceback.format_exc()}

    return rval


@app.route("/zfmanager/insidertransactions/<symbol>", method="GET")
@authenticated
@cached("FUN_TRANS", "10min", keys=['symbol'])
def get_insidertransactions(symbol):
    """
      get_insidertransactions
    """
    logger.info(
        "FundamentalsManager: received insider transactions request for: "
        + symbol)

    try:
        rval = {"success": True,
                "insider-transactions": fum.getinsidertransactions(
                    symbol.upper())}
    except:
        rval = {"success": False, "error": traceback.format_exc()}

    return rval


@app.route("/zfmanager/instholdings/<symbol>", method="GET")
@authenticated
@cached("FUN_HOLDINGS", "10min", keys=['symbol'])
def get_institutionalholdings(symbol):
    """
      get_institutionalholdings
    """
    logger.info(
        "FundamentalsManager: received institutional holdings request for: "
        + symbol)

    try:
        rval = {"success": True,
                "institutional-holdings": fum.getinstitutionalholdings(
                    symbol.upper())}
    except:
        rval = {"success": False, "error": traceback.format_exc()}

    return rval


@app.route("/zfmanager/etf/desc/<symbol>", method="GET")
@cached("FUN_ETF_DESC", "10min", keys=['symbol'])
def get_etf_description(symbol):
    logger.info("FundamentalsManager: received etf description request for: "
                + symbol)

    try:
        data = fum.get_etf(symbol)
        # create tickersymbol attribute (used in get_company_articles_data)
        data['tickersymbol'] = data.get('symbol')
        articles, bullets, articles_length = \
            fum.get_company_article_data(data)
        data['stansberry_bullets'] = {
                    "html": bullets[0]['bullets_html'],
                    "list": bullets[0]['bullets_list']
        } if bullets is not None and len(bullets) else {}
        rval = {"success": True, "description": data}
    except Exception as e:
        err = 'Encountered exception ' + str(e)
        rval = {'success': False, 'error': err}
        logger.error(err)
        logger.debug('Traceback: ' + traceback.format_exc())

    return rval


@app.route("/zfmanager/etf/holdings/<symbol>", method="GET")
@cached("FUN_ETF_HOLDINGS", "10min", keys=['symbol'])
def get_etf_holdings(symbol):
    logger.info("FundamentalsManager: received etf holdings request for: "
                + symbol)

    try:
        data = fum.get_etf_holdings(symbol)
        rval = {"success": True, "holdings": data}
    except Exception as e:
        err = 'Encountered exception ' + str(e)
        rval = {'success': False, 'error': err}
        logger.error(err)
        logger.debug('Traceback: ' + traceback.format_exc())

    return rval


@app.route("/zfmanager/desc/<symbol>/<full>", method="GET")
@app.route("/zfmanager/desc/<symbol>", method="GET")
@cached("FUN_DESC", "10min", keys=["symbol", "full"])
def get_description(symbol, full='true'):
    """
      get_description
    """
    logger.info(
        "FundamentalsManager: received company description request for: "
        + symbol)

    articles, bullets, articles_length = fum.get_company_article_data(symbol)

    """
    articles = None
    bullets = None
    articles_length = None

    try :
      #Use this call to avoid issues with guids that are past in.
      valid_data = fum.is_valid_symbol(symbol, exchange=None)
      if valid_data and valid_data['valid'] and \
      valid_data['supports_sb_content'] :
        bullets = fum.article_accessor.query_articles_company_bullets(
                    valid_data['symbol'])
        articles = fum.article_accessor.query_articles_company_descriptions(
                    valid_data['symbol'])
        articles_length = len(articles)
    except Exception as e :
      articles = None
      bullets = None
      articles_length = None
      logger.error('Failed to retrieve article data for company description ' +
        'Exception: ' + str(e) + ' ' +
        'Traceback: ' + traceback.format_exc())
    """

    zacs_description = fum.getdescription(full, symbol)

    if isinstance(articles, dict) and not articles.get('success', False):
        articles = None
        bullets = None
        articles_length = None
        logger.error('Failed to retrieve article data for company description')

    if articles_length:
        if zacs_description:
            zacs_description[0]['stansberry_short_description'] = \
                articles[0]['short_description']
            zacs_description[0]['stansberry_action'] = \
                articles[0]['stansberry_action']
            zacs_description[0]['stansberry_long_description'] = \
                articles[0]['long_description']
            zacs_description[0]['stansberry_company_name'] = articles[0][
                'title'] if \
                'title' in articles[0] else ""
            zacs_description[0]['stansberry_profile_type'] = articles[0][
                'profile_type'] if "profile_type" in articles[0] else ""
            zacs_description[0]['stansberry_recommendation_url'] = articles[0][
                'original_recommendation_url'] if 'original_recommendation_url' in \
                                                  articles[0] else ""
            zacs_description[0]['stansberry_snapshot'] = articles[0][
                'snapshot'] if \
                'snapshot' in articles[0] else ""
            zacs_description[0]['stansberry_statistics'] = articles[0][
                'statistics'] \
                if 'statistics' in articles[0] else ""
            zacs_description[0]['stansberry_chart'] = articles[0]['chart'] if \
                'chart' \
                in \
                articles[
                    0] \
                else ""
        else:
            zacs_description = list()
            item = {'stansberry_short_description': articles[0][
                'short_description'],
                    'stansberry_action': articles[0]['stansberry_action'],
                    'stansberry_long_description': articles[0][
                        'long_description'],
                    "stansberry_profile_type": articles[0]['profile_type'] if
                    "profile_type" in articles[0] else "",
                    "stansberry_recommendation_url": articles[0][
                        'original_recommendation_url'] if "original_recommendation_url"
                                                          in articles[
                                                              0] else "",
                    "stansberry_snapshot": articles[0][
                        'snapshot'] if "snapshot" in
                                       articles[
                                           0] else "",
                    "stansberry_statistics": articles[0]['statistics'] if
                    "statistics" in articles[0] else "",
                    "stansberry_chart": articles[0]['chart'] if "chart" in
                                                                articles[0]
                    else "",
                    'legal_name': articles[0]['title'] if 'title' in articles[
                        0] else
                    "",
                    'name': articles[0]['title'] if 'title' in articles[
                        0] else ""}
            zacs_description.append(item)

        if articles_length > 1:
            logger.warning(
                "More than one({0}) article appeared for get_description."
                .format(str(articles_length)))

    try:
        # attach company bullets FIXME
        if zacs_description:
            if bullets:
                zacs_description[0]['stansberry_bullets'] = {
                    "html": bullets[0]['bullets_html'],
                    "list": bullets[0]['bullets_list']}
            else:
                zacs_description[0]['stansberry_bullets'] = {}
                logger.info('No value for bullets')
        else:
            logger.info('No value for zacs_description')

    except Exception as e:
        logger.error('Encountered exception: ' + str(e))
        zacs_description = None

    if not zacs_description:
        zacs_description = list()
        zacs_description.append(dict())
        zacs_description[0]['stansberry_bullets'] = {}

    try:
        rval = {"success": True, "description": zacs_description}
    except Exception as e:
        err = 'Encountered exception ' + str(e)
        rval = {'success': False, 'error': err}
        logger.error(err)
        logger.debug('Traceback: ' + traceback.format_exc())

    return rval

# TODO Add Cache
@app.route("/zfmanager/secfilings/<symbol>/<page>/<size>/<sort>/<filter_data>",
           method="GET")
@app.route("/zfmanager/secfilings/<symbol>/<page>/<size>/<sort>", method="GET")
@app.route("/zfmanager/secfilings/<symbol>/<page>/<size>", method="GET")
@app.route("/zfmanager/secfilings/<symbol>", method="GET")
@authenticated
def get_company_sec_filings(symbol, page=1, size=0,
                            sort=None, filter_data=None):
    """
      Returns dictionary containing the SEC filings and related metadata
      for the specified company.

      Args :
        symbol(str)       : Stock ticker symbol

      Returns :
        dict : Sec filings and metadata

    """
    logger.info(
        "FundamentalsManager: received company sec filings request for: "
        + symbol)

    if sort:
        sort = unquote(sort)

    if filter_data:
        filter_data = unquote(filter_data)

    data = paginate_data(int(page), int(size),
                         fum.get_company_sec_filings(symbol),
                         sort=sort,
                         filter_data=filter_data)
    data["symbol"] = symbol.upper()

    try:
        rval = {"success": True,
                "data": data}
    except Exception as e:
        logger.error('Function : get_company_sec_filings, Exception : ' +
                     str(e) + ', Trace : ' + traceback.format_exc())
        rval = {"success": False, "error": "Failed to retrieve sec filings."}

    return rval


@app.route("/zfmanager/symbol/lookup/<symbol>/<exchange>", method="GET")
@app.route("/zfmanager/symbol/lookup/<symbol>", method="GET")
@cached("FUN_LOOKUP", "10min", keys=["symbol", "exchange"])
def get_symbol(symbol, exchange=None):
    """
    Returns symbol data.

    Args :
      symbol(str)     : Stock ticker symbol
      exchange(str)   : Exchange symbol

    Returns :
      list : Symbol Data

  """
    logger.info(
        "FundamentalsManager: received symbol data request for: "
        + symbol)

    try:
        rval = fum.lookup_symbol(10, 'type', symbol, exchange=exchange)
    except Exception as e:
        logger.error('Function : get_symbol, Exception : ' +
                     str(e) + ', Trace : ' + traceback.format_exc())
        rval = {
            "status":
                {
                    "code": 400,
                    "message": "Failure, " + str(e) + "."
                },
            "results": None
        }

    return rval


@app.route("/zfmanager/price/<symbol>/<timeframe>/<exchange>", method="GET")
@app.route("/zfmanager/price/<symbol>/<timeframe>", method="GET")
@app.route("/zfmanager/price/<symbol>", method="GET")
@authenticated
@cached("FUN_PRICE", "10min", keys=["symbol", "timeframe", "exchange"])
def get_stock_price(symbol, timeframe='1y', exchange=None):
    """
    Returns daily stock prices for a specific symbol.

    Args :
      symbol(str)     : Stock ticker symbol
      timeframe(str)  : Valid Values (1d,1m,1y,5y,10y,Max)

    Returns :
      list : Stock Data by day

  """
    logger.info(
        "FundamentalsManager: received stock price request for: "
        + symbol + ' for timeframe ' + timeframe)

    try:
        is_index = False
        index = fum.get_index(symbol)
        if index is not None and len(index) > 0:
            is_index = True

        rval = {"success": True,
                "data": {"symbol": symbol.upper(),
                         "index": is_index,
                         "prices": fum.get_stock_price(symbol, timeframe,
                                                       exchange=exchange)}}
    except:
        rval = {"success": False, "error": traceback.format_exc()}

    return rval


@app.route("/zfmanager/debt/structure/<symbol>/<page>/<size>", method="GET")
@app.route("/zfmanager/debt/structure/<symbol>", method="GET")
@authenticated
@cached("FUN_DEBT", "10min", keys=["symbol", "page", "size"])
def get_debt_capital_structure(symbol, page=1, size=0):
    logger.info(
        "FundamentalsManager: received capital structured debt request for: "
        + symbol)

    try:
        data = paginate_data(int(page), int(size),
                             fum.get_capital_structure_debt_detail(symbol))
        data["symbol"] = symbol.upper()

        rval = {"success": True,
                "data": data}

    except Exception as e:
        logger.error('Function : get_debt_capital_structure, Exception : ' +
                     str(e) + ', Trace : ' + traceback.format_exc())
        rval = {"success": False, "error":
            "Failed to retrieve capital structured debt."}

    return rval


@app.route("/zfmanager/debt/chart/yearly/<symbol>", method="GET")
@authenticated
@cached("FUN_DEBT_YEARLY", "10min", keys=['symbol'])
def get_debt_capital_structure_yearly_summary(symbol):
    logger.error(
        "FundamentalsManager: received capital structured debt summary " +
        "request for: " + symbol)

    try:
        rval = {"success": True,
                "data": fum.query_capital_structure_debt_yearly_summary(
                    symbol)}

    except Exception as e:
        logger.error('Function : get_debt_capital_structure_yearly_summary, ' +
                     'Exception : ' + str(e) + ', Trace : ' +
                     traceback.format_exc())
        rval = {"success": False, "error":
            "Failed to retrieve capital structured debt."}

    return rval


@app.route("/zfmanager/debt/summary/<symbol>/<page>/<size>", method="GET")
@app.route("/zfmanager/debt/summary/<symbol>", method="GET")
@authenticated
@cached("FUN_DEBT_SUMMARY", "10min", keys=["symbol", "page", "size"])
def get_debt_summary(symbol):
    logger.info(
        "FundamentalsManager: received debt summary request for: "
        + symbol)

    try:
        ret_data = {}

        data = fum.get_debt_summary(symbol)

        ret_data["symbol"] = symbol.upper()
        ret_data["debt_summary"] = data

        rval = {"success": True,
                "data": ret_data}

    except Exception as e:
        logger.error('Function : get_debt_summary, Exception : ' +
                     str(e) + ', Trace : ' + traceback.format_exc())
        rval = {"success": False, "error":
            "Failed to retrieve capital structured debt."}

    return rval


@app.route("/zfmanager/bonds/maturity/<date>", method="GET")
@cached("FUN_BONDS_MAT", "10min", keys=['date'])
def cbonds_by_m_date(date):
    cb_accessor = CBondsAccessor()
    data = cb_accessor.query_bond_by_maturity_date(date)

    rval = {"success": True,
            "data": data}

    return rval


@app.route("/zfmanager/bonds/isin/<isin_id>", method="GET")
@cached("FUN_BONDS_ISIN", "10min", keys=['isin_id'])
def cbonds_by_id(isin_id):
    cb_accessor = CBondsAccessor()
    data = cb_accessor.query_bond_by_isin(isin_id)

    rval = {"success": True,
            "data": data}

    return rval

@app.route("/zfmanager/bonds/trading/<issue_id>", method="GET")
@authenticated
@cached("FUN_BONDS_TRADING", "60min", keys=['issue_id'])
def cbonds_latest_price(issue_id):
    try:
        data = CBondsAccessor().get_trading(issue_id)
        trading_data = {}

        if data and data.get("Items", []):
            data["Items"].sort(key=lambda date: datetime.datetime.strptime(date["date"], "%Y-%m-%d"))
            trading_data = data["Items"][-1]

        rval = {
            "success": True,
            "data": trading_data
        }

    except Exception as e:
        logger.error('Failed to retrieve Trading data by Issue Id. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Trading data by Issue Id."
        }

    return rval

@app.route("/zfmanager/bonds/description/emitent/issuer/<issuer_id>", method="GET")
@authenticated
@cached("FUN_BONDS_ISSUER", "60min", keys=['issuer_id'])
def cbonds_emitent_by_issuerid(issuer_id):
    try:
        data = CBondsAccessor().get_emitent(issuer_id)

        if data and data.get("Items", []):
            branch_id = data["Items"][0]["branch_id"]
            branch_data = CBondsAccessor().get_branch(branch_id)

            if branch_data and branch_data.get("Items", []):
                data["Items"][0]["branch_name"] = branch_data["Items"][0]["name_eng"]

        rval = {
            "success": True,
            "data": data["Items"]
        }

    except Exception as e:
        logger.error('Failed to retrieve Emitent by Issuer ID. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emitent by Issuer ID."
        }

    return rval

@app.route("/zfmanager/bonds/description/emissions/issuerid/<issuer_id>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/emissions/issuerid/<issuer_id>", method="GET")
@authenticated
@cached("FUN_BONDS_ISSUERID", "60min", keys=["issuer_id", "page", "limit"])
def cbonds_emissions_by_issuerid(issuer_id, page=1, limit=25):
    try:
        data = CBondsAccessor().get_emissions_by_issuerid(issuer_id, page, limit)

        rval = {
            "success": True,
            "data": data["Items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Emissions by Issuer ID. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emissions by Issuer ID."
        }

    return rval

@app.route("/zfmanager/bonds/description/emissions/issuername/<issuer_name>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/emissions/issuername/<issuer_name>", method="GET")
@authenticated
@cached("FUN_BONDS_ISSUERNAME", "60min", keys=["issuer_name", "page", "limit"])
def cbonds_emissions_by_issuername(issuer_name, page=1, limit=25):
    try:
        data = CBondsAccessor().get_emissions_by_issuername(issuer_name, page, limit)

        rval = {
            "success": True,
            "data": data["items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Emissions by Issuer Name. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emissions by Issuer Name."
        }

    return rval

@app.route("/zfmanager/bonds/description/emissions/name/<name>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/emissions/name/<name>", method="GET")
@authenticated
@cached("FUN_BONDS_EMISSIONS_NAME", "60min", keys=["name", "page", "limit"])
def cbonds_emissions_by_name(name, page=1, limit=25):
    try:
        data = CBondsAccessor().get_emissions_by_name(name, page, limit)

        rval = {
            "success": True,
            "data": data["items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Emissions by Name. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emissions by Name."
        }

    return rval

@app.route("/zfmanager/bonds/description/emissions/isin/<isin_id>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/emissions/isin/<isin_id>", method="GET")
@authenticated
@cached("FUN_BONDS_EMISSIONS_ISIN", "60min", keys=["isin_id", "page", "limit"])
def cbonds_emissions_by_isin(isin_id, page=1, limit=25):
    try:
        data = CBondsAccessor().get_emissions_by_isin(isin_id, page, limit)

        if data and data.get("Items", []):
            country_id = data["Items"][0]["emitent_country"]
            country_data = CBondsAccessor().get_country(country_id)

            if country_data and country_data.get("Items", []):
                data["Items"][0]["country_name"] = country_data["Items"][0]["name_eng"]

            status_id = data["Items"][0]["status_id"]
            status_data = CBondsAccessor().get_emission_status(status_id)

            if status_data and status_data.get("Items", []):
                data["Items"][0]["status_name"] = status_data["Items"][0]["name_eng"]

            coupon_id = data["Items"][0]["coupon_type_id"]
            coupon_data = CBondsAccessor().get_coupon_type(coupon_id)

            if coupon_data and coupon_data.get("Items", []):
                data["Items"][0]["coupon_name"] = coupon_data["Items"][0]["name_eng"]

        rval = {
            "success": True,
            "data": data["Items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Emissions by ISIN Code. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emissions by ISIN Code."
        }

    return rval

@app.route("/zfmanager/bonds/description/emissions/figi/<figi_id>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/emissions/figi/<figi_id>", method="GET")
@authenticated
@cached("FUN_BONDS_EMISSIONS_FIGI", "60min", keys=["figi_id", "page", "limit"])
def cbonds_emissions_by_figi(figi_id, page=1, limit=25):
    try:
        data = CBondsAccessor().get_emissions_by_figi(figi_id, page, limit)

        if data and data.get("Items", []):
            country_id = data["Items"][0]["emitent_country"]
            country_data = CBondsAccessor().get_country(country_id)

            if country_data and country_data.get("Items", []):
                data["Items"][0]["country_name"] = country_data["Items"][0]["name_eng"]

            status_id = data["Items"][0]["status_id"]
            status_data = CBondsAccessor().get_emission_status(status_id)

            if status_data and status_data.get("Items", []):
                data["Items"][0]["status_name"] = status_data["Items"][0]["name_eng"]

            coupon_id = data["Items"][0]["coupon_type_id"]
            coupon_data = CBondsAccessor().get_coupon_type(coupon_id)

            if coupon_data and coupon_data.get("Items", []):
                data["Items"][0]["coupon_name"] = coupon_data["Items"][0]["name_eng"]

        rval = {
            "success": True,
            "data": data["Items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Emissions by ISIN Code. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emissions by ISIN Code."
        }

    return rval

@app.route("/zfmanager/bonds/description/flow/issue/<issue_id>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/flow/issue/<issue_id>", method="GET")
@authenticated
@cached("FUN_BONDS_FLOW", "60min", keys=["issue_id", "page", "limit"])
def cbonds_flow(issue_id, page=1, limit=25):
    try:
        data = CBondsAccessor().get_flow(issue_id, page, limit)

        rval = {
            "success": True,
            "data": data["Items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Flow by Emission ID. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Flow by Emission ID."
        }

    return rval

@app.route("/zfmanager/bonds/description/offert/issue/<issue_id>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/offert/issue/<issue_id>", method="GET")
@authenticated
@cached("FUN_BONDS_OVERT", "60min", keys=["issue_id", "page", "limit"])
def cbonds_offert(issue_id, page=1, limit=25):
    try:
        data = CBondsAccessor().get_offert(issue_id, page, limit)

        rval = {
            "success": True,
            "data": data["Items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Offert by Emission ID. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Offert by Emission ID."
        }

    return rval

@app.route("/zfmanager/bonds/description/emissiondefault/issue/<issue_id>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/emissiondefault/issue/<issue_id>", method="GET")
@authenticated
@cached("FUN_BONDS_EMDEFAULT", "60min", keys=["issue_id", "page", "limit"])
def cbonds_emission_default(issue_id, page=1, limit=25):
    try:
        data = CBondsAccessor().get_emission_default(issue_id, page, limit)

        rval = {
            "success": True,
            "data": data["Items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Emission Default by Emission ID. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emission Default by Emission ID."
        }

    return rval

@app.route("/zfmanager/bonds/description/emissiontapissues/issue/<issue_id>/<page>/<limit>", method="GET")
@app.route("/zfmanager/bonds/description/emissiontapissues/issue/<issue_id>", method="GET")
@authenticated
@cached("FUN_BONDS_EMAPI", "60min", keys=["issue_id", "page", "limit"])
def cbonds_emission_tab_issues(issue_id, page=1, limit=25):
    try:
        data = CBondsAccessor().get_emission_tap_issues(issue_id, page, limit)

        rval = {
            "success": True,
            "data": data["Items"]
        }
    except Exception as e:
        logger.error('Failed to retrieve Emission Tab Issues by Emission ID. ', str(e))
        rval = {
            "success": False,
            "error": "Failed to retrieve Emission Tab Issues by Emission ID."
        }

    return rval


@app.route("/zfmanager/company/exchanges/<company_id>", method="GET")
@cached("FUN_COMPANY_EXCHANGES", "10min", keys=['company_id'])
def get_company_exchanges(company_id):
    rval = {}

    try:
        data = fum.get_company_exchanges(company_id)

        rval = {"success": True,
                "data": data}

    except Exception as e:
        logger.error('Function : get_company_exchanges, Exception : ' +
                     str(e) + ', Trace : ' + traceback.format_exc())
        rval = {"success": False, "error":
            "Failed to retrieve company exchanges."}

    return rval



@app.route("/zfmanager/snapshot/<symbol>", method="GET")
@cached("FUN_SNAPSHOT", "10min", keys=['symbol'])
def get_snapshot(symbol):
    try:
        data = fum.get_snapshot(symbol)
        # add SB's bullets (returns empty dict if N/A)
        articles, bullets, articles_length = \
            fum.get_company_article_data(data)
        data['stansberry_bullets'] = {
                    "html": bullets[0]['bullets_html'],
                    "list": bullets[0]['bullets_list']
        } if bullets is not None and len(bullets) else {}

        # get portfolio list
        # use find({"symbol": symbol}) or find({"guid": symbol})
        k = "symbol" if symbol.count("~") else "guid"
        v = symbol.split("~")[0] if symbol.count("~") else symbol
        pf_list = [x for x in fum._porters_list_portfolio.find({k: v})]
        data['sb_portfolio_mapping'] = pf_list[0]['publications'] if len(pf_list) else []

        rval = {
            "success": True,
            "data": data
        }

    except Exception as e:
        logger.error('Function : get_snapshot, Exception : ' +
                     str(e) + ', Trace : ' + traceback.format_exc())
        rval = {
            "success": False,
            "error": "Failed to retrieve company's snapshot."
        }

    return rval

@app.route("/zfmanager/fundamentals/symbol/options/<expiration>", method="GET")
#@authenticated
@cached("FUN_OPTIONS", "10min", keys=['expiration'])
def symbol_option_expiration(expiration):
  try:
    condition = {}
    condition["id"] = expiration
    options = list(_symbol_expiration_details.find(condition))

    if len(options) > 0:
      for option in options:
        option.__delitem__('_id')

    rval = {
        "success": True,
        "result": options
    }

  except Exception as e:
    logger.error('Function : symbol_option_expiration, Exception : ' + ', Trace : ' + traceback.format_exc())
    rval = {
        "success": False,
        "error": "Failed to retrieve symbol option with expirations."
    }

  return rval


@app.route("/zfmanager/fundamentals/symbol/options", method="GET")
#@authenticated
def symbol_options():
  try:
    result = {}
    options = _symbol_options.find({})
    for option in options:
      result[option["id"]] = option["expirations"]

    rval = {
        "success": True,
        "result": result
    }

  except Exception as e:
    logger.error('Function : symbol_options, Exception : ' + ', Trace : ' + traceback.format_exc())
    rval = {
        "success": False,
        "error": "Failed to retrieve symbol options."
    }

  return rval

###############################################################################
# start
###############################################################################
def start():
    global fum
    config = SbtGlobalCommon.get_sbt_config()['services']['fundamentals']
    fum = FundamentalsManager(config)
    start_app(config)


###############################################################################
# main
###############################################################################
if __name__ == "__main__":
    logger.info("starting")

    start()
    cherrypy.engine.block()
