import os
import sys
import logging
import cherrypy
import bottle
import service_utils

from api_service import app, start_app
from sbt_common import SbtGlobalCommon
from sbt_common import SingletonServiceManager
from sbt_etrade_accessor.etrade_accessor import EtradeAccessor
from sbt_ibroker_accessor.ibrk_accessor import IBrokerAccessor

from mp_accessor import MappingAccessor
from mp_accessor import TableMappingGuid
from lib.json_convertor import json_format_result
from services.util.auth_utils import authenticated, entitlements, authenticated_profile
import simplejson

from time import sleep

PORTERS_LIST = "PORTERS_LIST"
STOCK = "STOCK"
OPTION = "OPTION"
logger = SbtGlobalCommon.get_global_logger()
#TODO: Conditional if started by sbtdeployer use global otherwise...
upfm   = None
# redis_manager = RedisManager()

MAX_TOKEN_VALIDITY = 60 * 60 * 2 # SSxMMxHH: seconds until expired

class Brokerage(object, metaclass=SingletonServiceManager):
  """
  UserPortfolioManager
  """
  _configured = False
  _COMBINED = 'combined'
  _PAIRED = 'paired'
  _CLOSE = 'close'

  def __init__(self, cfg):
    """
    :param cfg:
    """
    logger.info('UserPortfolioManager initializing...')
    self._logger  = SbtGlobalCommon.get_logger(logging.INFO, __name__)
    self.fin      = False
    self.env      = dict(os.environ)
    self.accessor = None
    self.cfg      = cfg
    self.tradeit_config = SbtGlobalCommon.get_sbt_config()['tradeit']

    self._logger.info('Environment:\n' + str(self.env))
    self._streaming_supported_exchanges_list = [
      'amex', 'bats', 'etf', 'nyse',
      'nsdq', 'nsdqcm', 'nysearca', 'otc', 'obb'
    ]

    self._configure()

  def _configure(self):
    """
    Configure
    :return:
    """
    logger.info("UserPortfolioManager: configuring...")

    self.etrade_accessor = EtradeAccessor(self.cfg)
    # self.ibroker_accessor = IBrokerAccessor(self.cfg)
    self._mapping_accessor = MappingAccessor()
    self._stock_table_mapping = \
      self._mapping_accessor.get_table_mapping(
        TableMappingGuid.US_COMPANY_STOCK_PRICE.value)

    Brokerage._configured = self.etrade_accessor.isconfigured()

    return Brokerage._configured

  def create_new_etrade_account_session(self, post_data):
    dto = self.etrade_accessor.create_new_etrade_account_session(post_data)
    return dto

  def authorize_etrade_by_user_id(self, user_id):
    url = self.etrade_accessor.authorize_user(user_id)
    return url

  def authorize_etrade_by_user_id_with_verifier(self, user_id, verifier):
    rval = self.etrade_accessor.verify_session(user_id, verifier)
    return rval

  @staticmethod
  def isconfigured():
    """
    :return:
    """
    return Brokerage._configured

  def __enter__(self):
    """
    Entry Point
    :return:
    """
    return self

  def __exit__(self, exception_type, exception_value, traceback):
    """
    Exit Point
    :return:
    """
    if not self.fin:
      self.fin = True
      self.clean()
      sleep(2)
    else:
      sleep(1)

    self._logger.info('INFO: System exiting now!')

    sys.exit(0)

  def clean(self):
    """
    Cleanup
    :return:
    """
    if self.fin:
      self._logger.info('INFO: cleaning up...')
      bottle.response.headers['Connection'] = 'close'
    else:
      self._logger.info('INFO: clean ignored')



@app.hook('before_request')
def strip_path():
  """
  IGNORE TRAILING SLASHES IN BOTTLE ROUTES
  :return:
  """
  service_utils.strip_path()


@app.route("/tradeit/etrade/confirm", method="POST")
@authenticated_profile
def authorize_etrade_user_with_verifier(user):
  """
  Authorize etrade user by client_key and secret_key
  :param user_id:
  """
  try:
    post_data = bottle.request.json
    user_id = user.get('guid')
    logger.info('verified etrade user_id: {} - {}'.format(user_id,
                                                          post_data["verifier"]))

    rval = upfm.authorize_etrade_by_user_id_with_verifier(user_id, post_data["verifier"])
    rval = {'success': True, 'results': rval}

  except Exception as e:
    rval = {'success': False, 'error': 'Could not authorize etrade account from user: {}'.format(user_id)}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval


@app.route("/tradeit/etrade/authorize", method="GET")
@authenticated_profile
def authorize_etrade_user(user):
  """
  Authorize etrade user by client_key and secret_key
  :param user_id:
  """
  try:
    user_id = user.get('guid')
    logger.info('authorize etrade user_id: {}'.format(user_id))

    url = upfm.authorize_etrade_by_user_id(user_id)
    rval = {'success': True, 'results': url}

  except Exception as e:
    rval = {'success': False, 'error': 'Could not authorize etrade account from user: {}'.format(user_id)}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval


@app.route("/tradeit/ibroker/authorize", method="GET")
@authenticated_profile
def authorize_ibroker_user(user):
  """
  Authorize ibroker user by client_key and secret_key
  :param user_id:
  """
  try:
    user_id = user.get('guid')
    logger.info('authorize ibroker user_id: {}'.format(user_id))

    rval = upfm.ibroker_accessor.authorize_broker_user(user_id)
    rval = {'success': True, 'results': rval}

  except Exception as e:
    rval = {'success': False, 'error': 'Could not authorize etrade account from user: {}'.format(user_id)}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval


@app.route("/tradeit/etrade/account", method="POST")
@app.route("/tradeit/etrade/account", method="PUT")
@authenticated_profile
def etrade_create_new_or_update_by_user_id(user):
  """
  :return: Etrade account session jsut created list
  """
  try:
    user_id = user.get('guid')

    post_data = bottle.request.json
    logger.info('Adding new etrade account to portfolio manager for user ')
    post_data["user_id"] = user_id

    dto = upfm.create_new_etrade_account_session(post_data)
    dto.session = "etrade session"
    rval = {'success': True, 'results': simplejson.loads(json_format_result(dto))}

  except Exception as e:
    rval = {'success': False, 'error': 'Could not add etrade account'}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval


@app.route("/tradeit/ibroker/account", method="POST")
@app.route("/tradeit/ibroker/account", method="PUT")
@authenticated_profile
def ibroker_create_new_or_update_by_user_id(user):
  """
  :return: Ibroker account session jsut created list
  """
  try:
    user_id = user.get('guid')

    post_data = bottle.request.json
    logger.info('Adding new Ibroker account to portfolio manager for user ')
    post_data["user_id"] = user_id

    dto = upfm.ibroker_accessor.create_new_ibroker_account(post_data)
    rval = {'success': True, 'results': simplejson.loads(json_format_result(dto))}

  except Exception as e:
    rval = {'success': False, 'error': 'Could not add ibroker account'}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval


@app.route("/tradeit/etrade/account", method="GET")
@authenticated_profile
def etrade_select_accout_session_by_user_id(user):
  """
  :return: Etrade account session jsut created list
  """
  try:
    user_id = user.get('guid')
    logger.info('Select account by user ')

    dto = upfm.etrade_accessor.select_account_session(user_id)
    rval = {'success': True, 'results': simplejson.loads(json_format_result(dto))}

  except Exception as e:
    rval = {'success': False, 'error': 'Could not add etrade account'}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval


@app.route("/tradeit/ibroker/account", method="GET")
@authenticated_profile
def ibroker_select_accout_session_by_user_id(user):
  """
  :return: broker account session jsut created list
  """
  try:
    user_id = user.get('guid')
    logger.info('Select account by user ')

    dto = upfm.ibroker_accessor.select_ibroker_account(user_id)
    rval = {'success': True, 'results': simplejson.loads(json_format_result(dto))}

  except Exception as e:
    rval = {'success': False, 'error': 'Could not add etrade account'}
    bottle.abort(400, "encountered exception: " + str(e))
  return rval


@app.route("/tradeit/etrade/is-active-session", method="GET")
@authenticated_profile
def etrade_validate_active_session(user):
  """
  :return: success: True and account values if session is active
  """
  try:
    user_id = user.get('guid')
    logger.info('validate active session by user:  {}'.format(user_id))
    accounts = upfm.etrade_accessor.validate_active_session(user_id)
    rval = {'success': True, 'results': accounts}

  except Exception as e:
    rval = {'success': False, 'error': 'Session is expired'}
    bottle.abort(400, "Session is expired")
  return rval


@app.route("/tradeit/ibroker/is-active-session", method="GET")
@authenticated_profile
def ibroker_validate_active_session(user):
  """
  :return: success: True and account values if session is active
  """
  try:
    user_id = user.get('guid')
    logger.info('validate active session by user:  {}'.format(user_id))
    accounts = upfm.ibroker_accessor.verify_session(user_id)
    rval = {'success': True, 'results': accounts}

  except Exception as e:
    rval = {'success': False, 'error': 'connection failed'}
    bottle.abort(400, "Session is expired")
  return rval



@app.route("/tradeit/etrade/account-overview", method="POST")
@authenticated_profile
def etrade_get_account_overview(user):
  """
  :return:
  """
  try:
    user_id = user.get('guid')
    post_data = bottle.request.json

    logger.info('get account overview user: {}:  {}'.format(user_id, post_data["accountNumber"]))
    accountOverview = upfm.etrade_accessor.get_account_overview(user_id, post_data["accountNumber"])
    rval = {'success': True, 'account_overview': accountOverview}

  except Exception as e:
    rval = {'success': False, 'error': 'Session is expired'}
    bottle.abort(400, "Session is expired {}".format(str(e)))
  return rval


@app.route("/tradeit/ibroker/account-overview", method="POST")
@authenticated_profile
def ibroker_get_account_overview(user):
  """
  :return:
  """
  try:
    user_id = user.get('guid')
    post_data = bottle.request.json
    logger.info('get account overview user: {}:  {}'.format(user_id, post_data["accountNumber"]))
    accountOverview = upfm.ibroker_accessor.get_ibroker_account_overview(user_id, post_data["accountNumber"])

    rval = {'success': True, 'account_overview': accountOverview}

  except Exception as e:
    rval = {'success': False, 'error': 'Session is expired'}
    bottle.abort(400, "Session is expired {}".format(str(e)))
  return rval


@app.route("/tradeit/etrade/positions", method="POST")
@authenticated_profile
def etrade_get_account_positions(user):
  """
  :return:
  """
  try:
    post_data = bottle.request.json
    user_id = user.get('guid')
    logger.info('get account overview user: {}:  {}'.format(user_id, post_data["accountNumber"]))
    account_positions = upfm.etrade_accessor.get_account_positions(user_id, post_data["accountNumber"])
    rval = {'success': True, 'tradeitpositions': account_positions}

  except Exception as e:
    rval = {'success': False, 'error': 'Session is expired'}
    bottle.abort(400, "Session is expired {}".format(str(e)))
  return rval


@app.route("/tradeit/ibroker/positions", method="POST")
@authenticated_profile
def etrade_get_account_positions(user):
  """
  :return:
  """
  try:
    post_data = bottle.request.json
    user_id = user.get('guid')
    logger.info('get account overview user: {}:  {}'.format(user_id, post_data["accountNumber"]))
    account_positions = upfm.ibroker_accessor.get_account_positions(user_id, post_data["accountNumber"])
    rval = {'success': True, 'tradeitpositions': account_positions}

  except Exception as e:
    rval = {'success': False, 'error': 'Failed to connected'}
    bottle.abort(400, "Failed to connected {}".format(str(e)))
  return rval

def start():
  """
  Configure cherrypy and start service
  :param cfg:
  :return:
  """
  global upfm

  config = SbtGlobalCommon.get_sbt_config()['services']['brokerage']
  upfm = Brokerage(config)
  start_app(config)


if __name__ == "__main__":
  logger.info("starting")
  start()
  cherrypy.engine.block()
