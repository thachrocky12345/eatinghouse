import boto3
import bottle
import cherrypy
import http
import logging
import os
import signal
import time
import uuid
from boto3.dynamodb.conditions import Attr, And, Key

from api_service import app, start_app
from sbt_common import SbtGlobalCommon
from dd_accessor import DynamoAccessor
from up_accessor import UserProfileAccessor
from service_utils import ServiceUtilsGlobal
from auth_utils import authenticated_profile
from services.sbt_email import send_email

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
config = SbtGlobalCommon.get_sbt_config()

TABLE_NAME = "SBT_NOTIFICATION"
SEND_TABLE_NAME = "SBT_NOTIFICATION_SEND"
USER_GUID_INDEX_NAME = "SBT_NOTIFICATION_USER_GUID"
PPT_GUID_INDEX_NAME = "SBT_NOTIFICATION_PPT_GUID"
env_filter = And(
    Attr("environment").eq(config["environment"]),
    Attr("type").ne("confirmation"),
)

dynamo_accessor = DynamoAccessor()
session = dynamo_accessor._session
dynamodb_client = session.client("dynamodb")

user_accessor = UserProfileAccessor(config["services"]["user"])

def start():
    try:
        notification_config = config["services"]["notifications_manager"]
    except KeyError:
        logger.error("no configuration found for notifications_manager")
        raise

    start_app(notification_config)

def send_confirmation(user, type, end_point, confirm_code):
    subject_line = "Your Stansberry Terminal confirmation code"
    message_text = "Stansberry Terminal confirmation: your confirmation code is {confirm_code}".format(confirm_code=confirm_code)

    if type == "sms":
        sms_session = boto3.session.Session(profile_name=config["aws"]["profile"])
        sns = sms_session.client("sns")
        sns.publish(PhoneNumber=end_point, Message=message_text)

    if type == "email":
        send_email("alert_email.html", end_point, subject_line, Name=user["name"], MessageText=message_text)

@app.route("/notifications/list", method="GET")
@authenticated_profile
def get_notifications_list(user):
    table = dynamo_accessor._dynamodb.Table(TABLE_NAME)
    result = table.query(
        IndexName=USER_GUID_INDEX_NAME,
        KeyConditionExpression=Key("user_guid").eq(user["guid"]),
        FilterExpression=env_filter,
    )

    return {"user_guid": user["guid"], "notifications": result["Items"]}

@app.route("/notifications/notification/<notification_id>", method="GET")
@authenticated_profile
def get_notification(user, notification_id):
    response = dynamo_accessor._query_table(TABLE_NAME, "guid", notification_id)
    if len(response) == 0:
        bottle.abort(http.HTTPStatus.NOT_FOUND)
    if response[0].get("environment") != config["environment"]:
        bottle.abort(http.HTTPStatus.NOT_FOUND)
    if response[0].get("user_guid") != user["guid"]:
        bottle.abort(http.HTTPStatus.UNAUTHORIZED, "user_guid does not match authenticated user")

    return response[0]

@app.route("/notifications/by-portfolio/<portfolio_id>", method="GET")
@authenticated_profile
def get_notifications_by_portfolio_id(user, portfolio_id):
    table = dynamo_accessor._dynamodb.Table(TABLE_NAME)
    result = table.query(
        IndexName=USER_GUID_INDEX_NAME,
        KeyConditionExpression=Key("user_guid").eq(user["guid"]),
        FilterExpression=And(Attr("portfolio_guid").eq(portfolio_id), env_filter),
    )

    return {"user_guid": user["guid"], "notifications": result["Items"]}

@app.route("/notifications/by-position/<position_id>", method="GET")
@authenticated_profile
def get_notifications_by_position_id(user, position_id):
    table = dynamo_accessor._dynamodb.Table(TABLE_NAME)
    result = table.query(
        IndexName=USER_GUID_INDEX_NAME,
        KeyConditionExpression=Key("user_guid").eq(user["guid"]),
        FilterExpression=And(Attr("position_guid").eq(position_id), env_filter),
    )

    return {"user_guid": user["guid"], "notifications": result["Items"]}

@app.route("/ppt/notifications/create", method="POST")
@app.route("/notifications/create", method="POST")
@authenticated_profile
def create_notification(user):
    data = bottle.request.json
    data["user_guid"] = user["guid"]
    data["created_at"] = time.time()
    data["guid"] = uuid.uuid4().hex
    data["environment"] = config["environment"]

    data = {k: v for k, v in data.items() if v != ""}

    response = dynamo_accessor._save(TABLE_NAME, data)
    return data

@app.route("/notifications/delete/<notification_id>", method="DELETE")
@authenticated_profile
def delete_notification(user, notification_id):
    condition = Attr("user_guid").eq(user["guid"])
    try:
        return dynamo_accessor._delete(TABLE_NAME, "guid", notification_id, ConditionExpression=condition)
    except dynamodb_client.exceptions.ConditionalCheckFailedException:
        return {"success": False, "error": "Could not update notification: notification does not exist or does not belong to the current user"}

@app.route("/notifications/update/<notification_id>", method="PUT")
@authenticated_profile
def update_notification(user, notification_id):
    table = dynamo_accessor._dynamodb.Table(TABLE_NAME)
    condition = Attr("user_guid").eq(user["guid"])
    data = bottle.request.json
    data["guid"] = notification_id
    data["user_guid"] = user["guid"]
    data["environment"] = config["environment"]

    data = {k: v for k, v in data.items() if v != ""}

    try:
        response = dynamo_accessor._save(TABLE_NAME, data, ConditionExpression=condition)
        return data
    except dynamodb_client.exceptions.ConditionalCheckFailedException:
        return {"success": False, "error": "Could not update notification: notification does not exist or does not belong to the current user"}

@app.route("/notifications/contact/set", method="POST")
@authenticated_profile
def set_contact_info(user):
    try:
        data = bottle.request.json
        if "contact_info" not in data:
            return {"success": False, "error": "missing contact_info"}

        existing_contact_info = user_accessor._execute_query("SELECT * FROM user_profile_contact_info WHERE user_id=%s", [user["guid"]])

        for row in data["contact_info"]:
            if row.get("type", "") not in ("sms", "email", "terminal"):
                bottle.abort(http.HTTPStatus.BAD_REQUEST, "invalid contact type")

            if row.get("endpoint"):
                row["endpoint"] = row["endpoint"].lower().strip()

            # If endpoint matches the existing row, and has already been confirmed, only update whether it's enabled or not
            exists = False
            if existing_contact_info:
                for existing_row in existing_contact_info:
                    if existing_row["confirmed"] and existing_row["ci_type"] == row["type"] and existing_row["ci_endpoint"] == row.get("endpoint", ""):
                        user_accessor.update_contact_info(user["guid"], row)
                        exists = True

            if exists:
                continue

            if row["type"] == "sms":
                if not row.get("endpoint"):
                    return {"success": False, "error": "phone number cannot be empty"}

                session = boto3.session.Session(profile_name=config["aws"]["profile"])
                pinpoint = session.client("pinpoint")

                try:
                    response = pinpoint.phone_number_validate(NumberValidateRequest={"PhoneNumber": row["endpoint"]})
                except pinpoint.exceptions.BadRequestException:
                    logger.exception("BadRequestException for phone number: '{}'".format(row["endpoint"]))
                    return {"success": False, "error": "phone number {} is not valid".format(row["endpoint"])}

                response = response["NumberValidateResponse"]

                if response["PhoneType"] == "INVALID":
                    # If it comes back invalid, put a 1 on the front and try again
                    # If it's still invalid then error out
                    response = pinpoint.phone_number_validate(NumberValidateRequest={"PhoneNumber": "1" + str(row["endpoint"])})
                    response = response["NumberValidateResponse"]

                    if ["PhoneType"] == "INVALID":
                        return {"success": False, "error": "phone number {} is not valid".format(row["endpoint"])}

                row["endpoint"] = response["CleansedPhoneNumberE164"]

            row_result = user_accessor.set_new_contact_info(user["guid"], row)
            if row.get("enabled") and row["type"] in ("sms", "email"):
                send_confirmation(user, row["type"], row["endpoint"], row_result["confirm_code"])

        if existing_contact_info:
            for row in existing_contact_info:
                if not [i for i in data["contact_info"] if i["type"] == row.get("ci_type", "")]:
                    user_accessor.delete_contact_info_row(row["guid"])

        response = user_accessor.get_contact_info(user["guid"])
        response["success"] = True
        return response
    except Exception as e:
        logger.exception("Failed to send SMS/Email notification for user: '{user_guid}'".format(user_guid=user["guid"]), e)
        return {"success": False, "error": "Failed to send SMS/Email notification"}

@app.route("/notifications/contact/get", method="GET")
@authenticated_profile
def get_contact_info(user):
    return user_accessor.get_contact_info(user["guid"])

@app.route("/notifications/contact/confirm", method="POST")
@authenticated_profile
def confirm_contact_info(user):
    data = bottle.request.json
    return user_accessor.confirm_contact_info(data["guid"], user["guid"], data["confirm_code"])

@app.route("/notifications/contact/confirm/resend", method="POST")
@authenticated_profile
def resend_confirmation(user):
    data = bottle.request.json
    contact_info = user_accessor.get_contact_info(user["guid"])

    for row in user_accessor._execute_query("SELECT * FROM user_profile_contact_info WHERE user_id=%s AND guid=%s AND confirmed is null",
                                            [user["guid"], data["guid"]]):
        send_confirmation(user, row["ci_type"], row["ci_endpoint"], row["confirm_code"])
        return {"success": True}

    bottle.abort(http.HTTPStatus.BAD_REQUEST, "no contact info found for user")

@app.route("/notifications/triggered", method="GET")
@authenticated_profile
def get_triggered_notifications(user):
    table = dynamo_accessor._dynamodb.Table(SEND_TABLE_NAME)
    result = table.query(
        IndexName=USER_GUID_INDEX_NAME,
        KeyConditionExpression=Key("user_guid").eq(user["guid"]),
        FilterExpression=env_filter,
    )

    items = [{
        "guid": i["guid"],
        "message_text": i["message_text"].get("terminal_long", i["message_text"]["terminal"]),
        "timestamp": i["timestamp"],
        "read": i.get("read"),
        "article_id": i.get("article_id"),
        "all_recommendations": i.get("all_recommendations"),
    } for i in result["Items"]]

    return {"user_guid": user["guid"], "notifications": items}

@app.route("/notifications/unread", method="GET")
@authenticated_profile
def get_unread_notifications(user):
    conditions = And(Attr("read").not_exists(), env_filter)
    table = dynamo_accessor._dynamodb.Table(SEND_TABLE_NAME)
    result = table.query(
        IndexName=USER_GUID_INDEX_NAME,
        KeyConditionExpression=Key("user_guid").eq(user["guid"]),
        FilterExpression=conditions,
    )

    items = [{
        "guid": i["guid"],
        "message_text": i["message_text"]["terminal"],
        "timestamp": i["timestamp"],
        "article_id": i.get("article_id"),
        "all_recommendations": i.get("all_recommendations"),
    } for i in result["Items"]]

    return {"user_guid": user["guid"], "notifications": items}

@app.route("/notifications/acknowledge", method="POST")
@authenticated_profile
def acknowledge_notification(user):
    data = bottle.request.json

    response = dynamo_accessor._query_table(SEND_TABLE_NAME, "guid", data["id"])
    if len(response) == 0:
        bottle.abort(http.HTTPStatus.NOT_FOUND)
    if response[0].get("user_guid") != user["guid"]:
        bottle.abort(http.HTTPStatus.UNAUTHORIZED, "user_guid does not match authenticated user")

    response[0]["read"] = time.time()
    dynamo_accessor._save(SEND_TABLE_NAME, response[0])
    return response[0]

@app.route("/notifications/acknowledge/all", method="POST")
@authenticated_profile
def acknowledge_all_notifications(user):
    table = dynamo_accessor._dynamodb.Table(SEND_TABLE_NAME)
    result = table.query(
        IndexName=USER_GUID_INDEX_NAME,
        KeyConditionExpression=Key("user_guid").eq(user["guid"]),
        FilterExpression=And(Attr("read").not_exists(), env_filter),
    )

    read_time = time.time()

    for send in result["Items"]:
        send["read"] = read_time
        dynamo_accessor._save(SEND_TABLE_NAME, send)

    return {"user_guid": user["guid"], "notifications_marked_read": result["Items"]}

@app.route("/notifications/clear", method="POST")
@authenticated_profile
def clear_notification(user):
    data = bottle.request.json

    response = dynamo_accessor._query_table(SEND_TABLE_NAME, "guid", data["id"])
    if len(response) == 0:
        bottle.abort(http.HTTPStatus.NOT_FOUND)
    if response[0].get("user_guid") != user["guid"]:
        bottle.abort(http.HTTPStatus.UNAUTHORIZED, "user_guid does not match authenticated user")

    dynamo_accessor._delete(SEND_TABLE_NAME, "guid", data["id"])
    return response[0]

@app.route("/notifications/clear/all", method="POST")
@authenticated_profile
def clear_all_notifications(user):
    table = dynamo_accessor._dynamodb.Table(SEND_TABLE_NAME)
    result = table.query(
        IndexName=USER_GUID_INDEX_NAME,
        KeyConditionExpression=Key("user_guid").eq(user["guid"]),
        FilterExpression=env_filter,
    )

    read_time = time.time()

    for send in result["Items"]:
        dynamo_accessor._delete(SEND_TABLE_NAME, "guid", send["guid"])

    return {"user_guid": user["guid"], "notifications_marked_read": result["Items"]}


@app.route("/ppt/notifications/by-portfolio/<ppt_portfolio_id>", method="GET")
@authenticated_profile
def get_ppt_notifications_by_portfolio_id(user, ppt_portfolio_id):
    notifications = []

    if ppt_portfolio_id:
        table = dynamo_accessor._dynamodb.Table(TABLE_NAME)
        result = table.query(
            IndexName=PPT_GUID_INDEX_NAME,
            KeyConditionExpression=Key("ppt_portfolio_guid").eq(ppt_portfolio_id)
        )
        notifications = result["Items"]

    return {"notifications": notifications}

@app.route("/ppt/notifications/notification/<ppt_notification_id>", method="GET")
@authenticated_profile
def get_ppt_notification(user, ppt_notification_id):
    response = dynamo_accessor._query_table(TABLE_NAME, "guid", ppt_notification_id)
    if len(response) == 0:
        bottle.abort(http.HTTPStatus.NOT_FOUND)

    return response[0]

@app.route("/ppt/notifications/update/<ppt_notification_id>", method="PUT")
@authenticated_profile
def update_ppt_notification(user, ppt_notification_id):
    condition = Attr("guid").eq(ppt_notification_id)
    data = bottle.request.json
    data["guid"] = ppt_notification_id
    data["user_guid"] = user["guid"]
    data["environment"] = config["environment"]

    data = {k: v for k, v in data.items() if v != ""}

    try:
        response = dynamo_accessor._save(TABLE_NAME, data, ConditionExpression=condition)
        return data
    except dynamodb_client.exceptions.ConditionalCheckFailedException:
        return {"success": False, "error": "Could not update notification: notification id does not exist"}

@app.route("/ppt/notifications/delete/<ppt_notification_id>", method="DELETE")
@authenticated_profile
def delete_ppt_notification(user, ppt_notification_id):
    try:
        if ppt_notification_id:
            return dynamo_accessor._delete(TABLE_NAME, "guid", ppt_notification_id)
    except Exception as e:
        return {"success": False, "error": "Could not delete notification: notification does not exist"}

@app.route("/ppt/notifications/triggered/<ppt_portfolio_guid>", method="GET")
@authenticated_profile
def get_ppt_triggered_notifications(user, ppt_portfolio_guid):
    table = dynamo_accessor._dynamodb.Table(SEND_TABLE_NAME)
    result = table.query(
        IndexName=PPT_GUID_INDEX_NAME,
        KeyConditionExpression=Key("ppt_portfolio_guid").eq(ppt_portfolio_guid),
        FilterExpression=env_filter,
    )

    items = [{
        "guid": i["guid"],
        "message_text": i["message_text"].get("terminal_long", i["message_text"]["terminal"]),
        "timestamp": i["timestamp"],
        "read": i.get("read"),
        "article_id": i.get("article_id"),
        "all_recommendations": i.get("all_recommendations"),
    } for i in result["Items"]]

    return {"ppt_portfolio_guid": ppt_portfolio_guid, "notifications": items}

@app.route("/ppt/notifications/unread/<ppt_portfolio_guid>", method="GET")
@authenticated_profile
def get_ppt_unread_notifications(user, ppt_portfolio_guid):
    conditions = And(Attr("read").not_exists(), env_filter)
    table = dynamo_accessor._dynamodb.Table(SEND_TABLE_NAME)
    result = table.query(
        IndexName=PPT_GUID_INDEX_NAME,
        KeyConditionExpression=Key("ppt_portfolio_guid").eq(ppt_portfolio_guid),
        FilterExpression=conditions,
    )

    items = [{
        "guid": i["guid"],
        "message_text": i["message_text"]["terminal"],
        "timestamp": i["timestamp"],
        "article_id": i.get("article_id"),
        "all_recommendations": i.get("all_recommendations"),
    } for i in result["Items"]]

    return {"ppt_portfolio_guid": ppt_portfolio_guid, "notifications": items}

@app.route("/ppt/notifications/acknowledge", method="POST")
@authenticated_profile
def acknowledge_notification(user):
    data = bottle.request.json

    response = dynamo_accessor._query_table(SEND_TABLE_NAME, "guid", data["id"])
    if len(response) == 0:
        bottle.abort(http.HTTPStatus.NOT_FOUND)
    if data["ppt_portfolio_guid"] != response[0]['ppt_portfolio_guid']:
        bottle.abort(http.HTTPStatus.NOT_FOUND)

    response[0]["read"] = time.time()
    dynamo_accessor._save(SEND_TABLE_NAME, response[0])
    return response[0]

if __name__ == "__main__":
    logger.info("starting")

    start()
    cherrypy.engine.block()

