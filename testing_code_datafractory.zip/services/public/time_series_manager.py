import os
import sys
import logging
import cherrypy
import bottle
import service_utils
import traceback
import json

from api_service import app, start_app
from mongo_accessor import MongoAccessor
from pg_accessor import PostgresAccessor
from suggestion import Suggestion
from mp_accessor import MappingAccessor, MPAccessor, TableMappingGuid
from intrinio_accessor import IntrinioAccessor
from barchart_accessor import BarchartAccessor
from fs_accessor import FinancialAccessor, FinancialVendors
from data_mapper import SbtDataMapper
from time import sleep
from time import time
from dateutil.relativedelta import relativedelta
from datetime import datetime
from dd_accessor import DynamoAccessor
from sbt_common import SbtGlobalCommon
from sbt_common import SingletonServiceManager
from crypto_currency_accessor import CryptoAccessor
from auth_utils import authenticated, entitlements, userprofile
from redis_manager import RedisManager
from cache_utils import cached

from snp_accessor import SNPAccessor

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
redis_manager = RedisManager()
BARCHART_STOCK_PRICE_TABLE_NAME = "BARCHART_STOCK_PRICE_FEED"
# time_series_manager = None


###############################################################################
# TimeSeriesManager:
###############################################################################





class TimeSeriesManager(object, metaclass=SingletonServiceManager):
    _trading_day_codes = {
        1: '1',
        2: '2',
        3: '3',
        4: '4',
        5: '5',
        6: '6',
        7: '7',
        8: '8',
        9: '9',
        10: '0',
        11: 'A',
        12: 'B',
        13: 'C',
        14: 'D',
        15: 'E',
        16: 'F',
        17: 'G',
        18: 'H',
        19: 'I',
        20: 'J',
        21: 'K',
        22: 'L',
        23: 'M',
        24: 'N',
        25: 'O',
        26: 'P',
        27: 'Q',
        28: 'R',
        29: 'S',
        30: 'T',
        31: 'U'
    }

    def __init__(self):
        """
          Constructor
        """
        logger.info("TimeSeriesManager: initializing")
        self.configured = False
        self.fin = False
        self.env = dict(os.environ)

        self.dynamo_accessor = DynamoAccessor()
        self.intrinio_accessor = IntrinioAccessor()
        env_conf = SbtGlobalCommon.get_sbt_config()
        self._vendor = SbtGlobalCommon.get_sbt_config()['services'][
            'time_series_manager']['vendor']

        if 'financials' in env_conf and 'vendor' in env_conf['financials']:
            self._vendor = env_conf['financials']['vendor']

        logger.info('Financial Accessor setup with vendor : ' + self._vendor)
        self._fs_accessor = FinancialAccessor(self._vendor)
        self._barchart_accessor = BarchartAccessor()
        self.data_mapper = SbtDataMapper()
        self._mapping_accessor = MappingAccessor()
        self._mpa_accessor = MPAccessor()
        self._crypto_accessor = CryptoAccessor()
        self._mapping_accessor.get_table_mappings()
        self._stock_exchange_tm_guid = '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
        self._pgconfig = SbtGlobalCommon.get_sbt_config()['postgres'][
            'datafactory']
        self._pg = PostgresAccessor(self._pgconfig)

        self._snp_accessor = SNPAccessor()

        for v in self.env:
            logger.info("env: " + v + " " + self.env[v])

    """
  Entry Point
  """

    def __enter__(self):
        return self

    """
  Cleanup
  """

    def clean(self):
        """
    Cleanup
    """
        logger.info("INFO: cleaning up...")
        if self.fin:
            bottle.response.headers['Connection'] = 'close'
        else:
            logger.error("ERROR: Clean ignored fin flag set False")

    """
  Exit Point
  """

    def __exit__(self, exception_type, exception_value, trace_back):
        if not self.fin:
            self.fin = True
            self.clean()
            sleep(2)
        else:
            sleep(1)

        logger.info("INFO: System exiting now!")

        sys.exit(0)

    def get_quote(self, symbols):
        indices = []
        commodities = []
        stocks = []
        crypto = []

        mappings = []
        mappings_not_valid = []

        for x in symbols:
            if not self._barchart_accessor.is_index(x) \
                    and not self._barchart_accessor.is_commodity(x):
                if x.count('~') == 0:
                    try:
                        # if x.isdigit():
                        # trading_item_id
                        mappings.append(
                            Suggestion.get_unique_item(trading_item_id=int(x))['result']
                        )
                        # else:
                        #     # SYM only
                        #     try:
                        #         mappings.append(
                        #             Suggestion.get_unique_item(symbol=x)[
                        #                 'result'][0]
                        #         )
                        #     except:
                        #         # x is not valid
                        #         mappings_not_valid.append(
                        #             {
                        #                 'symbol': x
                        #             }
                        #         )
                    except:
                        mappings_not_valid.append(
                            {
                                'symbol': x
                            }
                        )
                else:
                    # SYM~EXC
                    mappings.append(x)
            elif self._barchart_accessor.is_index(x):
                indices.append(x)
            elif self._barchart_accessor.is_commodity(x):
                commodities.append(x)
            elif x == '$BTCUSD':
                crypto.append('BTC:USD')
        #
        #
        # try:
        #     mappings = [
        #         x if x.count('~')
        #              and not self._barchart_accessor.is_index(x)
        #              and not self._barchart_accessor.is_commodity(x)
        #         else x
        #         for x in symbols
        #     ]
        # except:
        #     mappings = [
        #         [x for x in
        #          Suggestion.get_unique_item(trading_item_id=x).values()][1][0]
        #         if not self._barchart_accessor.is_index(x)
        #            and not self._barchart_accessor.is_commodity(x)
        #         else x
        #         for x in symbols
        #     ]
        # TODO: if only symbols or company_id are passed to this method, get their primary exchange
        symbols = [x.get('symbol') if isinstance(x, dict) else x for x in
                   mappings]

        # for symbol in symbols:
        #     if self._barchart_accessor.is_index(symbol):
        #         indices.append(symbol)
        #     elif self._barchart_accessor.is_commodity(symbol):
        #         commodities.append(symbol)
        #     elif symbol == '$BTCUSD':
        #         crypto.append('BTC:USD')
            # else:
            #     mapping = self.get_symbol_mapping(symbol)
            #
            #     if not mapping:
            #         symbol, exchange, exchange_country = \
            #             self._mapping_accessor.parse_mapping_symbol(symbol)
            #         mapping = {'symbol': symbol, 'exchange': exchange,
            #                    'exchange_country': exchange_country}
            #
            #     mappings.append(mapping)
            #
            #     if mapping.get('exchange_country', 'USA') in ['USA', 'CAN']:
            #         stocks.append(mapping.get('symbol', symbol) + '~' + \
            #                       mapping.get('exchange', 'N/A'))
        # [indices.append(x) for x in symbols
        #     if self._barchart_accessor.is_index(x)]
        #
        # [commodities.append(x) for x in symbols
        #     if self._barchart_accessor.is_commodity(x)]
        #
        # [crypto.append('BTC:USD') for x in symbols
        #     if x == '$BTCUSD']

        for x in mappings:
            if (x not in indices) and (x not in commodities) and (x not in crypto):
                if isinstance(x, dict):
                    stocks.append(x.get('composite_pk_id').replace(':', '~'))
                else:
                    stocks.append(x)

        # [stocks.append(x.get('composite_pk_id').replace(':', '~'))
        #  if isinstance(x, dict)
        #     and x not in indices
        #     and x not in commodities
        #     and x.get('exchange_country') in ['USA', 'CAN']
        #  else (stocks.append(x) if x not in indices
        #     and x not in commodities
        #     and x.get('exchange_country') in ['USA', 'CAN'] else None)
        #  for x in mappings
        #  ]

        results = []

        if indices:
            i_data = self._barchart_accessor.get_index_quote(indices)
            if i_data:
                results.extend(i_data)

        if commodities:
            c_data = self._barchart_accessor.get_commodity_quote(commodities)
            if c_data:
                results.extend(c_data)

        if crypto:
            c_list_data = []
            for c in crypto:
                crypto_parts = c.split(':')
                c_data = self._crypto_accessor.get_price(crypto_parts[0],
                                                         crypto_parts[1])
                fc_data = self._format_crypto_to_quote(crypto_parts[0],
                                                       crypto_parts[1],
                                                       c_data)
                if fc_data:
                    c_list_data.append(fc_data)

            if c_list_data:
                results.extend(c_list_data)

        if mappings:
            s_data = []
            if stocks:
                s_data = self._barchart_accessor.get_stock_quote(stocks)
            self._append_missing_quotes(
                [x for x in mappings if isinstance(x, dict)],
                s_data
            )

            if s_data:
                results.extend(s_data)

        # just in case we need to see what's invalid
        # if mappings_not_valid:
        #     results.extend(mappings_not_valid)

        return {'status': {'code': 200, 'message': 'Success.'},
                "results": results}

    def get_history(self, symbol, time_type, **kargs):
        results = None
        dividends = None
        interval = None
        start_date = None
        end_date = None
        exchange = None

        if kargs:
            dividends = kargs.get('dividends', None)
            interval = kargs.get('interval', None)
            start_date = kargs.get('start_date', None)
            end_date = kargs.get('end_date', None)
            exchange = kargs.get('exchange', None)

        if time_type.upper() == 'W':
            time_type = 'weekly'
        elif time_type.upper() == 'M':
            time_type = 'monthly'
        elif time_type.upper() == 'D':
            time_type = 'daily'

        if self._barchart_accessor.is_commodity(symbol) and time_type in ["daily", "weekly", "monthly", "quaterly", "yearly"]:
            time_type += "Nearest"

        mapping = self.get_symbol_mapping(symbol, exchange=exchange)

        ex_country = 'USA'
        if mapping:
            ex_country = mapping.get('exchange_country', 'USA')
            symbol = mapping['symbol']
            exchange = mapping['exchange']

        if exchange:
            e_symbol = symbol + '~' + exchange
        else:
            e_symbol = symbol

        if ex_country == 'USA':
            results = self._barchart_accessor.get_history(dividends,
                                                          time_type, interval,
                                                          start_date, end_date,
                                                          e_symbol)

        if not results and self._vendor == 'snp':
            results = self._get_history_from_snp(symbol, exchange,
                                                 ex_country, start_date,
                                                 end_date)

        return {'status': {'code': 200, 'message': 'Success.'},
                "results": results}

    def get_symbol_mapping(self, symbol, exchange=None):
        """
          Return symbol exchange mapping from the system.

          Args :
            symbol(str) : Symbol

          Returns :
            dict : Symbol Exchange Mapping
        """
        return self._mapping_accessor.unique_symbol_exchange_mapping(symbol,
                                                                     exchange=exchange)

    def create_stock_exchange_search_dict(self, symbol_exchange_mapping,
                                          interval,
                                          start_timestamp=None,
                                          end_timestamp=None):
        """
          Creates a JSON object that can be used to search stock exchange
          values for companies.

          Args :
            symbol_exchange_mapping(dict) : Symbol Exchange Mapping

          Returns :
            dict : Search Dictionary
        """

        ret_value = {}

        if SbtGlobalCommon.collectionsutil.is_empty(symbol_exchange_mapping):
            return ret_value

        category_guid = self._get_category_guid(symbol_exchange_mapping)

        if SbtGlobalCommon.stringutil.is_not_empty(category_guid):
            if "entity_description" in symbol_exchange_mapping:
                ret_value = {
                    "text": symbol_exchange_mapping['entity_name'],
                    "id": symbol_exchange_mapping['guid'],
                    "symbol": symbol_exchange_mapping['symbol'],
                    "category_guid": category_guid,
                    "exchange": symbol_exchange_mapping['exchange'],
                    "entity_description": symbol_exchange_mapping[
                        'entity_description'],
                    "exchange_currency":
                        symbol_exchange_mapping['exchange_currency']
                }
            else:
                ret_value = {
                    "text": symbol_exchange_mapping['entity_name'],
                    "id": symbol_exchange_mapping['guid'],
                    "symbol": symbol_exchange_mapping['symbol'],
                    "category_guid": category_guid,
                    "exchange": symbol_exchange_mapping['exchange'],
                    "entity_description": '',
                    "exchange_currency":
                        symbol_exchange_mapping['exchange_currency']
                }

            ret_value['interval'] = interval

            if start_timestamp is not None:
                ret_value['start_timestamp'] = start_timestamp

            if end_timestamp is not None:
                ret_value['end_timestamp'] = end_timestamp

        return ret_value

    def get_category(self, category_guid):
        return self.dynamo_accessor._query_table(
            table_name="SBT_METADATA_TABLE_MAPPING", key_name="guid",
            key_value=category_guid)

    def get_guid_from_symbol_and_exchange(self, symbol, exchange):
        query = self.dynamo_accessor._query_table(
            'SBT_SYMBOL_EXCHANGE_MAPPING', key_name="symbol", key_value=symbol,
            range_name="exchange", range_value=exchange)
        return query[0]['guid']

    def get_fred_data(self, symbol):
        guid = self.get_guid_from_symbol_and_exchange(symbol, "FRED")
        query = self.dynamo_accessor._query_table(
            self.dynamo_accessor._get_environment_table_name(
                'FRED_ECONOMIC_DATA'), key_name="guid", key_value=guid)
        return query

    def get_map_data(self, indicator, date):
        """
         Retrieve list of symbols (and supporting info like guid, exchange, etc) that contain the given tags.

         Args :
           tags(list) : tags to get symbols with

         Returns ;
           (list) : list of dictionaries containing a value and a code (country code)
         """
        query = "SELECT * from oecd_data_mapping where indicator = '{}'".format(
            indicator)
        data = self._pg._execute_query(query, [])
        if data:
            country_lst = []
            country_code_lst = []
            for x in range(len(data[0]['guids'])):
                country_lst.append(data[0]['guids'][x])
                country_code_lst.append(
                    data[0]['country_id'][x].split("_", -1)[-1])
            entity_name = data[0]['entity_name']
            entity_description = data[0]['entity_description']

            ret_lst = []
            count = 0
            for guid in country_lst:
                try:
                    ret_lst.append({'value': self.dynamo_accessor._query_table(
                        'FRED_ECONOMIC_DATA', 'guid', guid,
                        'date', date)[0]['values']['value'],
                                    'code': country_code_lst[count],
                                    'guid': guid, 'symbol': data[0]['symbol']
                                                            + "_" +
                                                            data[0][
                                                                'measure_code']
                                                            + "_" +
                                                            country_code_lst[
                                                                count]})
                except IndexError:
                    # logger.warning('No data for guid: ' + guid + " on given date")
                    pass
                count += 1

            return {"success": True, "data": ret_lst,
                    "metadata": {'entity_name': entity_name,
                                 'entity_description': entity_description,
                                 'start_date': data[0]['start_date'],
                                 'end_date': data[0]['end_date'],
                                 'unit': data[0]['unit']}}
        else:
            return {"success": False, "data": [],
                    "error": "Invalid indicator entered: " + indicator}

    def get_all_map_data(self, indicator):
        """
         Retrieve list of symbols (and supporting info like guid, exchange, etc) that contain the given tags.

         Args :
           tags(list) : tags to get symbols with

         Returns ;
           (list) : list of dictionaries containing a value and a code (country code)
         """
        query = "SELECT * from oecd_data_mapping where indicator = '{}'".format(
            indicator)
        data = self._pg._execute_query(query, [])
        if data:
            country_lst = []
            country_code_lst = []
            for x in range(len(data[0]['guids'])):
                country_lst.append(data[0]['guids'][x])
                country_code_lst.append(
                    data[0]['country_id'][x].split("_", -1)[-1])
            entity_name = data[0]['entity_name']
            entity_description = data[0]['entity_description']

            ret_dict = {}
            date = data[0]['start_date']
            while date <= data[0]['end_date']:
                ret_lst = []
                count = 0
                for guid in country_lst:
                    try:
                        ret_lst.append({'value':
                                            self.dynamo_accessor._query_table(
                                                'FRED_ECONOMIC_DATA', 'guid',
                                                guid,
                                                'date', date)[0]['values'][
                                                'value'],
                                        'code': country_code_lst[count]})
                    except IndexError:
                        pass
                        # logger.warning('No data for guid: ' + guid + " on given date")
                    count += 1
                ret_dict[date] = ret_lst
                d = datetime.strptime(date, '%Y-%m-%d')
                date = (d + relativedelta(months=+3)).strftime('%Y-%m-%d')

            return {"success": True, "data": ret_dict,
                    "metadata": {'entity_name': entity_name,
                                 'entity_description': entity_description,
                                 'start_date': data[0]['start_date'],
                                 'end_date': data[0]['end_date']}}
        else:
            return {"success": False, "data": [],
                    "error": "Invalid indicator entered: " + indicator}

    def get_map_indicators(self):
        query = "SELECT indicator, entity_name from oecd_data_mapping"
        data = self._pg._execute_query(query, [])
        ret_lst = []
        for indicators in data:
            ret_lst.append({'name': indicators['entity_name'],
                            'code': indicators['indicator']})
        return {"success": True, "data": ret_lst}

    def get_symbols_matching_tags(self, tags, text, size=None):
        """
         Retrieve data corresponding to the given economic indicator and date

         Args :
           indicator(string) : name of economic indicator (example gdp)
           date(YYYY-MM-DD)  : string representation of a date to get data for

         Returns ;
           (list) : list of dictionaries of symbols and supporting data
       """
        return Suggestion.get_suggestions_tags(tags, text, size)

    def get_symbols_exchange_prices(self, symbol_exchange_list, duration_days=5):
        """
         Retrieve pricing data for given symbol exchange combinations.
         Returns ;
           (list) : list of dictionaries of symbols and supporting data
       """
        symbol_exchange_trading_item_map = {}
        for symbol_exchange in symbol_exchange_list:
            symbol = symbol_exchange.get("symbol", "")
            exchange = symbol_exchange.get("exchange", "")
            unique_item = Suggestion.get_unique_item(symbol, exchange)
            if unique_item and len(unique_item['result']):
                trading_item_id = unique_item['result'].get("trading_item_id", 0)
                if trading_item_id > 0:
                    symbol_exchange_trading_item_map[trading_item_id] = symbol_exchange

        if len(symbol_exchange_trading_item_map) > 0:
            # get trading_item_id for valid symbols
            trading_item_id_list = list(symbol_exchange_trading_item_map.keys())

            # data in JSON format
            data_json = self._snp_accessor.get_prices_for_days(trading_item_id_list, duration_days)

            # update dict of valid trading item ids
            [symbol_exchange_trading_item_map.get(x.get('tradingitemid')).update(x)
             for x in data_json]

        return list(symbol_exchange_trading_item_map.values())

    def get_new_symbols_matching_tags(self, tags, text, size=None):
        """
         Retrieve data corresponding to the given economic indicator and date

         Args :
           indicator(string) : name of economic indicator (example gdp)
           date(YYYY-MM-DD)  : string representation of a date to get data for

         Returns ;
           (list) : list of dictionaries of symbols and supporting data
       """
        return Suggestion.get_new_suggestions_tags(tags, text, size)

    def get_all_tags(self):
        query = 'SELECT * from macro_chart_tags ORDER BY order_no'
        result = self._pg._execute_query(query, [])
        if result:
            return {"success": True, "categories": result}
        else:
            return {"success": False, "result": [],
                    "error": "Error Retrieving Tags From Database"}

    def get_data(self, company):
        """
          Retrieve data based on the search request.

          Args :
            company(dict) : Search Request Dictionary

          Returns ;
            (list) : Filtered results.
        """
        results = []
        a_metadata = None
        category_guid = company.get("category_guid",
                                    company.get("category", [""])[0])
        category_list = time_series_manager.get_category(category_guid)
        interval = company.get("interval", "D")
        start_timestamp = company.get("start_timestamp", -2208988800)
        end_timestamp = company.get("end_timestamp", int(time()))
        if end_timestamp < start_timestamp and end_timestamp > -2208988800:
            start_timestamp = -2208988800
        if category_list:
            table_mapping = self._mapping_accessor.get_table_mapping(
                category_guid)
            metadata = {'category_name': table_mapping.get_format_name(),
                        'mappings': table_mapping.get_value_attributes_metadata()}

            if category_guid == TableMappingGuid.US_COMPANY_STOCK_PRICE.value:
                results = self._fs_accessor.query_stock_price(
                    company['symbol'],
                    None,
                    standardized_format=True,
                    timestamp=start_timestamp,
                    exchange=company.get('exchange', None))
                a_table_mapping = self._mapping_accessor.get_table_mapping(
                    TableMappingGuid.US_FUNDAMENTALS_TIMESERIES_ANNUALLY.value)
                a_metadata = {
                    'category_name': a_table_mapping.get_format_name(),
                    'mappings':
                        a_table_mapping.get_value_attributes_metadata()}
            elif category_guid == \
                    TableMappingGuid.US_FUNDAMENTALS_TIMESERIES_ANNUALLY.value:
                results = self._fs_accessor.query_financial_timeseries(
                    company['symbol'], 'a',
                    exchange=company.get('exchange', None))
            elif category_guid == \
                    TableMappingGuid.US_FUNDAMENTALS_TIMESERIES_QUARTERLY.value:
                results = self._get_merged_quarterly_data(company)

            if not results:
                results = self._mapping_accessor.query_table_by_mapping(
                    table_mapping, company["guid"])

            # fix missing 'currency_code' attribute
            [x.update(currency_code=company.get('exchange_currency', None))
             for x in results if 'currency_code' not in x.keys()]

            results = self._get_filtered_data(results,
                                              category_guid,
                                              interval,
                                              start_timestamp,
                                              end_timestamp)

            self._adjust_metadata_for_sentiment(company,
                                                metadata)

            response = self.data_mapper.get_formatted_financial_data(
                company,
                metadata,
                results,
                associated_metadata=a_metadata)

            return {"success": True, "data": response}

        return {"success": False, "result": [], "error": "No Category found"}

    def sync_symbol_exchanges(self):
        dynamo_table = self.dynamo_accessor._get_table(BARCHART_STOCK_PRICE_TABLE_NAME)
        query = self.dynamo_accessor._scan_table(BARCHART_STOCK_PRICE_TABLE_NAME, None)
        data = []
        count = 0
        for item in query:
            symbol = item.get("symbol", None)
            comp_name = item.get("name", None)
            exchange = item.get("exchange", None)
            if symbol:
                suggestion_res = Suggestion.get_unique_item(symbol)
                if suggestion_res and suggestion_res["success"] and "result" in suggestion_res \
                        and "exchange" in suggestion_res["result"]:
                    suggestion_exchange = suggestion_res.get("result").get("exchange")
                    suggestion_comp_name = suggestion_res.get("result").get("entity_name")
                    figi_code = suggestion_res.get("result").get("global_id")
                    if suggestion_exchange == "N/A":
                        print("suggested exchange is N/A")

                    if (suggestion_exchange and suggestion_exchange != exchange and suggestion_exchange != ""
                        and suggestion_exchange != "N/A" )\
                         or (suggestion_comp_name != "" and comp_name != suggestion_comp_name ):
                        rec = {
                                "symbol": symbol,
                                "exchange": exchange,
                                "company_name": comp_name,
                                "suggested_exch": suggestion_exchange,
                                "suggested_name": suggestion_comp_name,
                                "figi_code": figi_code
                            }
                        update_resp = dynamo_table.update_item(
                                            Key={
                                                "symbol": symbol
                                            },
                                            UpdateExpression="set exchange=:e, #nm=:c",
                                            ExpressionAttributeNames={
                                              "#nm": "name"
                                            },
                                            ExpressionAttributeValues={
                                                ":e": suggestion_exchange,
                                                ":c": suggestion_comp_name
                                            }
                                        )
                        print(update_resp)
                        count = count + 1
                        data.append(rec)
                else:
                    rec = {
                        "symbol": symbol,
                        "exchange": exchange,
                        "name": item.get("name", None),
                        "suggested_exch": ""
                    }
                    data.append(rec)


        print("Non-matching count="+ str(count))
        return json.dumps(data)

    def sync_symbols_from_bats(self):
        bats_barchart_symbols = MongoAccessor('bats_exchange_symbols_process')
        barchart_symbols_data = bats_barchart_symbols.find({})
        query = self.dynamo_accessor._scan_table(BARCHART_STOCK_PRICE_TABLE_NAME, None)
        barchart_symbol_map = {}
        for item in query:
            barchart_symbol_map[item.get("symbol", "")] = item.get("exchange")

        found_count = 0
        missed_count = 0
        added_count = 0
        for rec in barchart_symbols_data:
            symbol = rec.get("symbol")
            if barchart_symbol_map.get(symbol):
                found_rec_in_barchart = True
                found_count = found_count + 1
            else:
                missed_count = missed_count + 1
                exchange = rec.get("exchange")
                company_name = rec.get("companyName")
                saved = self._save_new_symbol_to_dynamodb(symbol, exchange, company_name)
                if saved:
                    added_count = added_count + 1


            # if not found_rec_in_barchart:
            #     print(rec)
            # Check if the record is in barchart dynamodb table by symbol, if not add it, if already present,
            # make sure the exchange name is correct.
        print("Found count: {} missed count: {}. Newly Added: {}"
                .format(found_count, missed_count, added_count))

    def _save_new_symbol_to_dynamodb(self, symbol, exchange, comp_name):
        suggestion_res = Suggestion.get_unique_item(symbol)
        if suggestion_res and suggestion_res["success"] and "result" in suggestion_res \
                and "exchange" in suggestion_res["result"]:
            suggestion_exchange = suggestion_res.get("result").get("exchange")
            suggestion_comp_name = suggestion_res.get("result").get("entity_name")
            if suggestion_exchange:
                rec = {
                    "symbol": symbol,
                    "exchange": exchange,
                    "name": suggestion_comp_name,
                    "day_code": "R",
                    "message_count": 0,
                    "volume": 0,
                    "session_id": 0,
                    "ask_size": 0.0,
                    "ask_price": 0.0,
                    "bid_price": 0.0,
                    "bid_size": 0,
                    "close": 0,
                    "open": 0.0,
                    "high": 0.0,
                    "low": 0.0,
                    "last_price": 0.0,
                    "previous_close": 0.0,
                    "fifty_two_week_high": 0.0,
                    "fifty_two_week_low": 0.0,
                    "trades": 0,
                    "previous_trades": 0,
                    "previous_message_count": 0,
                    "percentage_price_change": 0.0,
                    "period_timeframe": 0,
                    "period_trade_delta": 0,
                    "period_trades_per_timeframe": 0.0,
                    "price_change": 0.0,
                    "timestamp": 0,
                    "trade_occurred": 0
                }
                self.dynamo_accessor._save(BARCHART_STOCK_PRICE_TABLE_NAME, rec)
                return True
            else:
                logger.info("Exchange mismatched. Input Exch: {} suggested: {}, symbol: {}"
                            .format(exchange, suggestion_exchange, symbol))
                return False
        else:
            logger.info("Missed get_unique_item for symbol {} exchange: {} symbol: {}"
                        .format(symbol, exchange, symbol))

    def _get_merged_quarterly_data(self, company):
        """
          This method adjusts the price to earnings to use the
          TTM value in lieu of the quarterly value.
        """
        results = self._fs_accessor.query_financial_timeseries(
            company['symbol'], 'q',
            exchange=company.get('exchange', None))

        results1 = self._fs_accessor.query_financial_timeseries(
            company['symbol'], 't',
            exchange=company.get('exchange', None))

        for d1 in results1:
            for d in results:
                if d['date'] == d1['date']:
                    d['values']['pricetoearnings'] = d1['values'][
                        'pricetoearnings']
                    break

        return results

    def _get_category_guid(self, symbol_exchange_mapping):
        table_mapping = symbol_exchange_mapping.get('table_mapping', [])

        ex_countries = []

        for ex in list(self._mapping_accessor.get_exchanges().values()):
            if ex['country_code'] not in ex_countries:
                ex_countries.append(ex['country_code'])

        category_guid = None

        if len(table_mapping) == 1:
            category_guid = table_mapping[0]
        elif len(table_mapping) > 1 and \
                self._stock_exchange_tm_guid in table_mapping:
            category_guid = self._stock_exchange_tm_guid
        elif symbol_exchange_mapping.get('exchange_type', 'NA') == 'STOCK' and \
                symbol_exchange_mapping.get('exchange_country',
                                            'NA') in ex_countries:
            category_guid = TableMappingGuid.US_COMPANY_STOCK_PRICE.value

        return category_guid

    def _adjust_metadata_for_sentiment(self,
                                       company,
                                       metadata):

        if '_SENTIMENT' in company.get('symbol'):
            for meta in metadata['mappings']:
                if meta['id'] == 'noncommerciallong':
                    meta['default'] = False
                if meta['id'] == 'sentiment':
                    meta['default'] = True

    def _append_missing_quotes(self, mappings, results):
        for s in mappings:
            f_data = list(filter(lambda x: s['symbol'] == x['symbol'] and \
                                           s['exchange'] == x['exchange'],
                                 results))
            if not f_data:
                data = self._get_quote_pricing(s)
                if data:
                    results.append(data)

    def _get_quote_pricing(self, s):
        if not s:
            return None

        default = \
            {
                "symbol": "",
                "name": "",
                "dayCode": "",
                "serverTimestamp": "",
                "mode": "d",
                "lastPrice": 0,
                "tradeTimestamp": "",
                "netChange": 0,
                "percentChange": 0,
                "tick": "-",
                "bid": 0,
                "bidSize": 0,
                "ask": 0,
                "askSize": 0,
                "unitCode": "2",
                "open": 0,
                "high": 0,
                "low": 0,
                "close": 0,
                "numTrades": 0,
                "dollarVolume": 0,
                "flag": "",
                "previousClose": 0,
                "volume": 0,
                "previousVolume": 0,
                "fiftyTwoWkHigh": 0,
                "fiftyTwoWkLow": 0,
                "exchange": None,
                "source": "S&P",
                "supports_streaming": False
            }

        new_entry = None

        prices = self._fs_accessor.query_stock_price(s['symbol'],
                                                     '1y',
                                                     standardized_format=False,
                                                     exchange=s['exchange'])

        high = 0
        low = 0
        for p in prices:
            price = p.get('priceclose', 0)
            if price > high:
                high = price
            if low == 0 or price < low:
                low = price

        if prices and len(prices) > 1:
            sort_prices = sorted(prices, key=lambda k: k['pricingdate'],
                                 reverse=True)
            date_string = sort_prices[0]['pricingdate'].strftime('%Y-%m-%d')
            current_close = sort_prices[0].get('priceclose', 0)
            previous_close = sort_prices[1].get('priceclose', 0)
            net_change = current_close - previous_close
            utc_offset = '04:00'
            if SbtGlobalCommon.dateutil._is_dst():
                utc_offset = '05:00'

            per_change = 0
            if previous_close != 0:
                per_change = (net_change / previous_close) * 100

            new_entry = dict(default)
            new_entry['symbol'] = s['symbol']
            new_entry['exchange'] = s['exchange']
            new_entry['name'] = s['entity_name']
            new_entry['open'] = sort_prices[0]['priceopen']
            new_entry['high'] = sort_prices[0]['pricehigh']
            new_entry['low'] = sort_prices[0]['pricelow']
            new_entry['close'] = current_close
            new_entry['previousClose'] = previous_close
            new_entry['lastPrice'] = sort_prices[0]['priceclose']
            new_entry['volume'] = sort_prices[0]['volume']
            new_entry['previousVolume'] = sort_prices[1]['volume']
            new_entry['netChange'] = net_change
            new_entry['percentChange'] = per_change
            new_entry['fiftyTwoWkHigh'] = high
            new_entry['fiftyTwoWkLow'] = low
            new_entry['tradeTimestamp'] = date_string + \
                                          'T00:00:00-' + utc_offset
            new_entry['serverTimestamp'] = \
                datetime.now().strftime('%Y-%m-%dT%H:%M:%S-') + utc_offset
            if len(date_string) > 9:
                new_entry['dayCode'] = \
                    self._trading_day_codes.get(
                        int(date_string[8:]), '-')

        return new_entry

    def _get_history_from_snp(self, symbol, exchange,
                              ex_country, start_date, end_date):
        results = []

        supports_streaming = False
        if ex_country == 'USA':
            supports_streaming = True

        compare_start_date = '19000101'
        compare_end_date = '99991231'
        prices = self._fs_accessor.query_stock_price(symbol,
                                                     'MAX',
                                                     standardized_format=False,
                                                     exchange=exchange)

        if start_date:
            compare_start_date = start_date

        if end_date:
            compare_end_date = end_date

        for p in prices:
            pd = p.get('pricingdate', None)
            compare_stock_date = '0000-00-00'
            pricing_date = '0000-00-00'
            stock_timestamp = "0000-00-00T00:00:00-00:00"
            if pd:
                compare_stock_date = pd.strftime('%Y%m%d')
                pricing_date = pd.strftime('%Y-%m-%d')
                stock_timestamp = pricing_date + "T00:00:00-00:00"

            if compare_stock_date >= compare_start_date and \
                    compare_stock_date <= compare_end_date:
                s_dict = {'symbol': symbol}
                s_dict['exchange'] = exchange
                s_dict['timestamp'] = stock_timestamp
                s_dict['tradingDay'] = pricing_date
                s_dict['open'] = p.get('priceopen', 0.0)
                s_dict['close'] = p.get('priceclose', 0.0)
                s_dict['high'] = p.get('pricehigh', 0.0)
                s_dict['low'] = p.get('pricelow', 0.0)
                s_dict['volume'] = p.get('volume', 0.0)
                s_dict['openInterest'] = None
                s_dict["source"] = "S&P"
                s_dict['supports_streaming'] = supports_streaming

                results.append(s_dict)

        return results

    @staticmethod
    def _get_filtered_data(results,
                           category_guid,
                           interval,
                           start_timestamp,
                           end_timestamp):
        """
          Filters time series response based on timestamp

          Args :
            results(list)        : Result list to be filtered
            start_timestamp(int) : Starting Timestamp
            end_timestamp(int)   : Ending Timestamp

          Returns :
            (list) : Filtered Results
        """
        if start_timestamp is None or end_timestamp is None:
            return results

        filter_timestamps = []
        previous_entry = None
        interval_values = {}
        interval = interval.upper()

        for r in results:
            if r['timestamp'] < start_timestamp:
                continue

            if r['timestamp'] > end_timestamp:
                if category_guid == TableMappingGuid.US_COMPANY_STOCK_PRICE.value and \
                        interval in ['M', 'W'] and interval_values.get(
                    'volume', 0) > 0:
                    TimeSeriesManager._append_interval_values(previous_entry,
                                                              interval_values,
                                                              filter_timestamps)
                break

            TimeSeriesManager._append_filter_timestamps(filter_timestamps,
                                                        category_guid,
                                                        interval_values,
                                                        previous_entry,
                                                        r,
                                                        interval)
            previous_entry = r

        return filter_timestamps

    @staticmethod
    def _append_filter_timestamps(filter_timestamps,
                                  category_guid,
                                  interval_values,
                                  previous_entry,
                                  r,
                                  interval):

        if category_guid == TableMappingGuid.US_COMPANY_STOCK_PRICE.value and \
                interval == 'W':
            TimeSeriesManager._adjust_interval_values(r, interval_values)

            dt = datetime.fromtimestamp(r['timestamp'])

            if dt.weekday() == 4:
                TimeSeriesManager._append_interval_values(r, interval_values,
                                                          filter_timestamps)

        elif category_guid == TableMappingGuid.US_COMPANY_STOCK_PRICE.value and \
                interval == 'M':
            dt = datetime.fromtimestamp(r['timestamp'])
            cur_month = dt.month
            prev_month = None
            if previous_entry:
                pdt = datetime.fromtimestamp(previous_entry['timestamp'])
                prev_month = pdt.month

            if prev_month and cur_month != prev_month:
                TimeSeriesManager._append_interval_values(previous_entry,
                                                          interval_values,
                                                          filter_timestamps)

            TimeSeriesManager._adjust_interval_values(r, interval_values)
        else:
            filter_timestamps.append(r)

    @staticmethod
    def _append_interval_values(r, interval_values,
                                filter_timestamps):
        interval_values['ex_dividend'] = r['values']['ex_dividend']
        interval_values['split_ratio'] = r['values']['split_ratio']
        interval_values['adj_close'] = r['values']['adj_close']
        interval_values['close'] = r['values']['close']
        ret = {}
        ret['guid'] = r['guid']
        if 'currency_code' in r:
            ret['currency_code'] = r['currency_code']
        ret['date'] = r['date']
        ret['timestamp'] = r['timestamp']
        ret['values'] = dict(interval_values)
        filter_timestamps.append(ret)
        for k in interval_values.keys():
            interval_values[k] = 0

    @staticmethod
    def _adjust_interval_values(r, interval_values):

        if interval_values.get('adj_open', 0) == 0:
            interval_values['adj_open'] = r['values']['adj_open']

        if interval_values.get('open', 0) == 0:
            interval_values['open'] = r['values']['open']

        if interval_values.get('adj_high', 0) < \
                r['values']['adj_high']:
            interval_values['adj_high'] = r['values']['adj_high']

        if interval_values.get('high', 0) < \
                r['values']['high']:
            interval_values['high'] = r['values']['high']

        if interval_values.get('adj_low', 0) == 0 or \
                interval_values.get('adj_low', 0) > \
                r['values']['adj_low']:
            interval_values['adj_low'] = r['values']['adj_low']

        if interval_values.get('low', 0) == 0 or \
                interval_values.get('low', 0) > \
                r['values']['low']:
            interval_values['low'] = r['values']['low']

        interval_values['adj_volume'] = interval_values.get('adj_volume', 0) + \
                                        r['values']['adj_volume']

        interval_values['volume'] = interval_values.get('volume', 0) + \
                                    r['values']['volume']

    def _format_crypto_to_quote(self, from_symbol, to_symbol,
                                data):
        ret_format = {}

        if not from_symbol or not to_symbol or not data:
            return ret_format

        utc_offset = '04:00'
        if SbtGlobalCommon.dateutil._is_dst():
            utc_offset = '05:00'

        ts = datetime.now().strftime('%Y-%m-%dT%H:%M:%S-') + utc_offset
        day_code = self._trading_day_codes.get(
            int(ts.split('T')[0][8:]), '-')

        c_info = data.get('RAW', {}).get(from_symbol, {}).get(to_symbol, {})

        if c_info:
            ret_format = {'symbol': '$' + from_symbol + to_symbol,
                          'name': 'Bit Coin',
                          'dayCode': day_code,
                          'serverTimestamp': ts,
                          'mode': 'i',
                          'lastPrice': c_info.get('PRICE', 0),
                          'tradeTimestamp': ts,
                          'netChange': c_info.get('CHANGE24HOUR', 0),
                          'percentChange': c_info.get('CHANGEPCT24HOUR', 0),
                          'tick': '.',
                          'bid': 0,
                          'bidSize': 0,
                          'ask': 0,
                          'askSize': 0,
                          'unitCode': '2',
                          'open': c_info.get('OPEN24HOUR', 0),
                          'high': c_info.get('HIGH24HOUR', 0),
                          'low': c_info.get('LOW24HOUR', 0),
                          'close': None,
                          'numTrades': 0,
                          'dollarVolume': 0,
                          'flag': '',
                          'previousClose': 0,
                          'volume': c_info.get('VOLUME24HOUR', 0),
                          'previousVolume': 0,
                          'fiftyTwoWkHigh': 0,
                          'fiftyTwoWkLow': 0,
                          'preMarketPrice': None,
                          'exchange': c_info.get('MARKET', ''),
                          'source': 'CrytoCompare',
                          'supports_streaming': False
                          }

        return ret_format

    def get_prices(self, symbols_list):
        # symbol validation
        valid = [self._fs_accessor.is_valid_symbol(x) for x in symbols_list]
        # only use valid symbols
        valid_symbols = [x for x in valid if x.get('valid')]

        valid_tradingitemids_dict = {
            x.get('trading_item_id'): {
                'symbol': x.get('symbol'),
                'exchange': x.get('exchange')[0]
            } for x in valid_symbols}

        # get trading_item_id for valid symbols
        trading_item_id_list = list(valid_tradingitemids_dict.keys())

        # data in JSON format
        data_json = self._snp_accessor.get_prices(trading_item_id_list)

        # update dict of valid trading item ids
        [valid_tradingitemids_dict.get(x.get('tradingitemid')).update(x)
            for x in data_json]

        values = [x for x in valid_tradingitemids_dict.values()]

        return values

    ###############################################################################


# Support CORS headers
# https://stackoverflow.com/questions/17262170/bottle-py-enabling-cors-for-jquery-ajax-requests
# Answer by ron.rothman
###############################################################################

@app.route('/<:re:.*>', method='OPTIONS')
def enable_cors_generic_route():
    """
  This route takes priority over all others. So any request with an OPTIONS
  method will be handled by this function.

  See: https://github.com/bottlepy/bottle/issues/402

  NOTE: This means we won't 404 any invalid path that is an OPTIONS request.
  """
    add_cors_headers()


@app.hook('after_request')
def enable_cors_after_request_hook():
    """
  This executes after every route. We use it to attach CORS headers when
  applicable.
  """
    add_cors_headers()


def add_cors_headers():
    bottle.response.headers['Access-Control-Allow-Origin'] = '*'
    bottle.response.headers['Access-Control-Allow-Methods'] = \
        'GET, POST, PUT, OPTIONS'
    bottle.response.headers['Access-Control-Allow-Headers'] = \
        'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token'


###############################################################################
#                         IGNORE TRAILING SLASHES
###############################################################################
@app.hook('before_request')
def strip_path():
    bottle.request.environ['PATH_INFO'] = bottle.request.environ['PATH_INFO']. \
        rstrip('/')


###############################################################################
# REST API
###############################################################################
"""
  TBD
"""


@app.route("/timeseries/data", method="POST")
@cached("TS_DATA", "4min", keys=['JSON'])
def time_series_data():
    request_json = bottle.request.json
    category_guid = request_json.get("category_guid", "").strip()

    symbol = ""
    exchange = ""
    if SbtGlobalCommon.stringutil.is_empty(category_guid):
        symbol = request_json.get("symbol", "").strip()
        symbol = symbol.upper()
        exchange = request_json.get("exchange", "").strip()
        exchange = exchange.upper()
        interval = request_json.get("interval", "D")

        start_timestamp = request_json.get('start_timestamp', 0)
        end_timestamp = request_json.get('end_timestamp', None)

        if time_series_manager._barchart_accessor.is_commodity(symbol) or \
                time_series_manager._barchart_accessor.is_index(symbol):
            # interval, start_date, end_date, dividends, exchnage

            selected_start_date = datetime.fromtimestamp(
                start_timestamp).strftime(
                '%Y-%m-%d') + '000000'

            selected_end_date = None
            if end_timestamp:
                selected_end_date = datetime.fromtimestamp(
                    end_timestamp).strftime(
                    '%Y-%m-%d') + '000000'

            data = time_series_manager.get_history(symbol, interval,
                               start_date=selected_start_date,
                               end_date=selected_end_date)
            table_mapping = \
                time_series_manager._mapping_accessor.get_table_mapping(
                    TableMappingGuid.US_INDEX_STOCK_PRICE.value)

            company = \
                time_series_manager._barchart_accessor.get_index_commodity_mapping(
                    symbol)

            response = \
                time_series_manager.data_mapper.get_converted_timeseries_data(
                    company,
                    table_mapping.get_format_name(),
                    data.get('results', []))

            return {"success": True, "data": response}
        else:
            request_json = time_series_manager.create_stock_exchange_search_dict(
                time_series_manager.get_symbol_mapping(symbol,
                                                       exchange=exchange),
                interval,
                start_timestamp=start_timestamp,
                end_timestamp=end_timestamp)
            category_guid = request_json.get("category_guid", "").strip()

    if SbtGlobalCommon.stringutil.is_not_empty(category_guid):
        clean_keys(request_json)
        return time_series_manager.get_data(request_json)
    else:
        message = "Invalid symbol entered: " + symbol
        if exchange:
            message = "Invalid symbol and exchange entered: " + symbol + \
                      " " + exchange

        return {"success": False, "result": [], "error":
            message}


@app.route("/timeseries/symbols_by_tag", method="POST")
@cached("TS_SYMBOLS_TAG", "10min", keys=['JSON'])
def symbols_by_tag():
    request_json = bottle.request.json
    tags = request_json.get("tags", "").strip()
    text = request_json.get("text", "").strip()
    # must be an integer
    size = request_json.get("size", None)
    tags_lst = tags.split(", ")
    try:
        return time_series_manager.get_symbols_matching_tags(tags_lst,
                                                             text,
                                                             size
                                                             )
    except Exception:
        return {"success": False, "result": [], "error":
            "An Error occurred while retrieving symbols"}

@app.route("/timeseries/pricechanges", method="POST")
def symbols_exchange_price_changes():
    request_json = bottle.request.json
    symbols_list = request_json.get("symbols", [])
    duration_days = request_json.get("days", 1)
    try:
        results = time_series_manager.get_symbols_exchange_prices(symbols_list, duration_days)
        return { "success": True, "result": results }
    except Exception as e:
        logger.error(e)
        return {"success": False, "result": [], "error":
            "An Error occurred while retrieving prices for symbol_exchange"}

@app.route("/timeseries/new_symbols_by_tag", method="POST")
@cached("TS_NEW_SYMBOLS_TAG", "10min", keys=['JSON'])
def new_symbols_by_tag():
    request_json = bottle.request.json
    tags = request_json.get("tags", "").strip()
    text = request_json.get("text", "").strip()
    # must be an integer
    size = request_json.get("size", None)
    tags_lst = tags.split(", ")
    try:
        return time_series_manager.get_new_symbols_matching_tags(tags_lst,
                                                                 text,
                                                                 size
                                                                 )
    except Exception:
        return {"success": False, "result": [], "error":
            "An Error occurred while retrieving symbols"}


@app.route("/timeseries/alltags", method="GET")
@cached('TS_ALL_TAGS', '10min')
def return_all_tags():
    return time_series_manager.get_all_tags()

@app.route("/timeseries/syncsymbols", method="GET")
# This route is only used for updating symboles to barchart_stock_price_feed.
def sync_symbol_exchanges():
    # return time_series_manager.sync_symbols_from_bats()
    # return time_series_manager.sync_symbol_exchanges()
    pass

@app.route(
    "/timeseries/market/history/<symbol>/<time_type>/<interval>/<start_date>/<end_date>/<dividends>/<exchange>",
    method="GET")
@app.route(
    "/timeseries/market/history/<symbol>/<time_type>/<interval>/<start_date>/<end_date>/<dividends>",
    method="GET")
@app.route(
    "/timeseries/market/history/<symbol>/<time_type>/<interval>/<start_date>/<end_date>",
    method="GET")
@app.route("/timeseries/market/history/<symbol>/<time_type>", method="GET")
@cached('TS_HISTORY', '1min', keys=["PATH"])
def get_history(symbol, time_type,
                interval=None, start_date=None,
                end_date=None, dividends=None,
                exchange=None):
    try:
        kargs = {}
        kargs['interval'] = interval
        kargs['start_date'] = start_date
        kargs['end_date'] = end_date
        kargs['dividends'] = dividends
        kargs['exchange'] = exchange

        if time_type.upper() == 'W':
            time_type = 'weekly'
        elif time_type.upper() == 'M':
            time_type = 'monthly'
        elif time_type.upper() == 'D':
            time_type = 'daily'

        ret_data = time_series_manager.get_history(symbol, time_type,
                                                   **kargs)
        ret_data['success'] = True
        return ret_data
    except Exception as exc:
        logger.error('Failed to process get_quote Exception : ' + str(exc) +
                     + ' Traceback : ' + traceback.format_exc())
        return {'success': False, 'status': {'code': 400, 'message':
            'Failed to process request'}, 'error': 'Failed to process request'}


@app.route("/timeseries/market/quote/<symbols>", method="GET")
@cached('TS_QUOTE_SYMBOLS', '1min', keys=['symbols'])
def get_quote(symbols):
    sym_list = symbols.split(",")
    try:
        ret_data = time_series_manager.get_quote(sym_list)
        ret_data['success'] = True
        return ret_data
    except Exception as exc:
        logger.error('Failed to process get_quote Exception : ' + str(exc) +
                     + ' Traceback : ' + traceback.format_exc())
        return {'success': False, 'status': {'code': 400, 'message':
            'Failed to process request'}, 'error': 'Failed to process request'}


@authenticated
@app.route("/timeseries/market/cached/quote/<symbols>", method="GET")
@cached('TS_QUOTE_CACHED_SYMBOLS', '1min', keys=["PATH"])
def get_cached_quote(symbols):
    try:
        ret_data = {}
        ret_data['success'] = True
        sym_list = symbols.split(",")
        sym_keys = []

        for sym in sym_list:
            mapping = time_series_manager.get_symbol_mapping(sym)
            if mapping:
                sym_keys.append(mapping['symbol'] + '~' + mapping['exchange'])
            else:
                sym_keys.append(sym)

        ret_data[
            "results"] = time_series_manager._barchart_accessor.get_cached_quotes(
            sym_keys)

        return ret_data
    except Exception as exc:
        logger.error('Failed to process get_cached_quotes Exception : ' + str(
            exc)) + ' Traceback : ' + traceback.format_exc()
        return {'success': False, 'status': {'code': 400, 'message':
            'Failed to process request'}}


@authenticated
@app.route("/timeseries/market/cached/history/<symbol>/<interval>",
           method="GET")
@cached('TS_HISTORY', '1min', keys=["PATH"])
def get_cached_history_quote(symbol, interval):
    try:
        mapping = time_series_manager.get_symbol_mapping(symbol)
        if mapping:
            sym = mapping["symbol"] + '~' + mapping["exchange"]
        else:
            sym = symbol

        ret_data = {}
        ret_data['success'] = True
        ret_data['results'] = json.loads(
            time_series_manager._barchart_accessor.get_cached_history(sym,
                                                                      interval))

        return ret_data
    except Exception as exc:
        logger.error('Failed to process get_cached_history Exception : ' + str(
            exc)) + ' Traceback : ' + traceback.format_exc()
        return {'success': False, 'status': {'code': 400, 'message':
            'Failed to process request'}, 'error': 'Failed to process request'}


@app.route("/timeseries/heatmap/<indicator>/<date>", method="GET")
@cached('HEATMAP_BY_INDICATOR', '10min', keys=['indicator', 'date'])
def get_map_data(indicator, date):
    return time_series_manager.get_map_data(indicator, date)


@app.route("/timeseries/mapdata/all/<indicator>", method="GET")
@cached('HEATMAP_ALL_INDICATOR', '10min', keys=['indicator'])
def get_map_data_all(indicator):
    return time_series_manager.get_all_map_data(indicator)


@app.route("/timeseries/heatmap/allindicators", method="GET")
@cached('HEATMAP_ALLINDICATORS', '10min')
def get_map_data_indicators():
    return time_series_manager.get_map_indicators()

@app.route("/timeseries/prices/<symbols_list>", method="GET")
def get_prices(symbols_list):
    # split list into symbols or composite_pk_id
    symbols_list = symbols_list.split(',')
    # get the data
    data = time_series_manager.get_prices(symbols_list)

    try:
        rval = {"success": True, "data": data}
    except Exception as e:
        rval = {"success": False, "error": e}

    return rval


def clean_keys(request_json):
    request_json["entity_name"] = request_json["text"]
    del request_json["text"]
    request_json["guid"] = request_json["id"]
    del request_json["id"]


###############################################################################
# error_500
###############################################################################
# Per Robert's request, we will now return json formatted errors

# @bottle.error(500)
# def error_500(error):
#   """Standard dictionary returned on 500 error"""
#   return {"success": False, "error": error}


@app.error(500)
def error_500(error):
    """
  :param error:
  :return:
  Standard dictionary returned on 500 error
  """
    return service_utils.json_error(error)


@app.error(409)
def error_409(error):
    """
  :param error:
  :return:
  """
    return service_utils.json_error(error)


@app.error(404)
def error_404(error):
    """
  :param error:
  :return:
  """
    return service_utils.json_error(error)


@app.error(401)
def error_401(error):
    """
  :param error:
  :return:
  """
    return service_utils.json_error(error)


@app.error(400)
def error_400(error):
    """
  :param error:
  :return:
  """
    return service_utils.json_error(error)


###############################################################################
# start
###############################################################################
def start():
    global time_series_manager

    config = SbtGlobalCommon.get_sbt_config()['services'][
        'time_series_manager']
    time_series_manager = TimeSeriesManager()
    app.time_series_manager = time_series_manager
    start_app(config)


###############################################################################
# main
###############################################################################
if __name__ == '__main__':
    logger.info("starting")

    start()
    cherrypy.engine.block()
