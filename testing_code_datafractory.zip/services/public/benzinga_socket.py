import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'common', 'sbt_websocket'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'common', 'sbt'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'common', 'sbt_redis'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'common', 'sbt_elasticsearch'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'common', 'sbt_elasticsearch', 'estypes'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'services', 'util'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'datafactory', 'common', 'ds'))

from benzinga_tcpsocket_handler import Client
from benzinga_news import BenzingaNews
from sbt_common import SbtGlobalCommon

#logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
config = SbtGlobalCommon.get_sbt_config()

def start():
    try:
        cc_config = config["api_feeds"]["benzingasocket"]
        user = cc_config["user"]
        key = cc_config["api_key"]
    except KeyError:
        #logger.error("no configuration found for crypto_manager")
        raise Exception ('Missing required user or key')

    print('Starting Benzinga TCP client.')
    client = Client(user, key)
    for content in client.content_items():
        bz_news = BenzingaNews(content)
        bz_news.process_message()

if __name__ == "__main__":
    start()
