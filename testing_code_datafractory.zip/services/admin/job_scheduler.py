#!/usr/local/bin/python3

import sys

sys.path.extend([
    '/opt/sbt/lib/python3.6/site-packages/common',
    '/opt/sbt/lib/python3.6/site-packages/config',
    '/opt/sbt/lib/python3.6/site-packages/datafactory',
    '/opt/sbt/lib/python3.6/site-packages/scripts',
    '/opt/sbt/lib/python3.6/site-packages/services',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/common',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/models',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/util',
    '/opt/sbt/lib/python3.6/site-packages/common/sbt',
    '/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch',
    '/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch/estypes',
    '/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch/utils',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/common/ds',
    '/opt/sbt/lib/python3.6/site-packages/common/sbt_redis',
    '/opt/sbt/lib/python3.6/site-packages/common/sbt_websocket',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/common/web',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_edgar',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_intrinio',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_quandl',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_sungard',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_snp',
    '/opt/sbt/lib/python3.6/site-packages/scripts/aws',
    '/opt/sbt/lib/python3.6/site-packages/scripts/datastore',
    '/opt/sbt/lib/python3.6/site-packages/scripts/datastore/dynamodb',
    '/opt/sbt/lib/python3.6/site-packages/scripts/datastore/elasticsearch_scripts',
    '/opt/sbt/lib/python3.6/site-packages/scripts/datastore/postgres',
    '/opt/sbt/lib/python3.6/site-packages/scripts/aws/kinesis',
    '/opt/sbt/lib/python3.6/site-packages/scripts/aws/kinesis/articles',
    '/opt/sbt/lib/python3.6/site-packages/scripts/aws/kinesis/articles/migration',
    '/opt/sbt/lib/python3.6/site-packages/scripts/aws/serverless/cftc_updater',
    '/opt/sbt/lib/python3.6/site-packages/scripts/aws/serverless/symbol_mapping',
    '/opt/sbt/lib/python3.6/site-packages/services/public',
    '/opt/sbt/lib/python3.6/site-packages/services/user',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_twitter',
    '/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch/esmappings',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_cryptocurrency',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_fred',
    '/opt/sbt/lib/python3.6/site-packages/services/util',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_portfolio',
    '/opt/sbt/lib/python3.6/site-packages/services/admin',
    '/opt/sbt/lib/python3.6/site-packages/scripts/aws/sbt_elasticsearch',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_barchart',
    '/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_cbonds',
    '/opt/sbt/lib/python3.6/site-packages/services/articles_processing',
    '/opt/sbt/lib/python3.6/site-packages/services/articles_processing/elasticsearch_ingestion',
    '/opt/sbt/lib/python3.6/site-packages/services/articles_processing/elasticsearch_ingestion/helper',
    '/opt/sbt/lib/python3.6/site-packages/services/articles_processing/tools',
    '/opt/sbt/lib/python3.6/site-packages/scripts/datastore/monitors',
    '/opt/sbt/lib/python3.6/site-packages'
])

from sbt_common import SbtCommon
from crontab import CronTab

sbtcommon = SbtCommon()

EXPORT_PATH = 'export PYTHONPATH=/opt/sbt/lib/python3.6/site-packages/common:/opt/sbt/lib/python3.6/site-packages/config:/opt/sbt/lib/python3.6/site-packages/datafactory:/opt/sbt/lib/python3.6/site-packages/scripts:/opt/sbt/lib/python3.6/site-packages/services:/opt/sbt/lib/python3.6/site-packages/datafactory/common:/opt/sbt/lib/python3.6/site-packages/datafactory/models:/opt/sbt/lib/python3.6/site-packages/datafactory/util:/opt/sbt/lib/python3.6/site-packages/common/sbt:/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch:/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch/estypes:/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch/utils:/opt/sbt/lib/python3.6/site-packages/datafactory/common/ds:/opt/sbt/lib/python3.6/site-packages/common/sbt_redis:/opt/sbt/lib/python3.6/site-packages/common/sbt_websocket:/opt/sbt/lib/python3.6/site-packages/datafactory/common/web:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_edgar:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_intrinio:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_quandl:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_sungard:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_snp:/opt/sbt/lib/python3.6/site-packages/scripts/aws:/opt/sbt/lib/python3.6/site-packages/scripts/datastore:/opt/sbt/lib/python3.6/site-packages/scripts/datastore/dynamodb:/opt/sbt/lib/python3.6/site-packages/scripts/datastore/elasticsearch_scripts:/opt/sbt/lib/python3.6/site-packages/scripts/datastore/postgres:/opt/sbt/lib/python3.6/site-packages/scripts/aws/kinesis:/opt/sbt/lib/python3.6/site-packages/scripts/aws/kinesis/articles:/opt/sbt/lib/python3.6/site-packages/scripts/aws/kinesis/articles/migration:/opt/sbt/lib/python3.6/site-packages/scripts/aws/serverless/cftc_updater:/opt/sbt/lib/python3.6/site-packages/scripts/aws/serverless/symbol_mapping:/opt/sbt/lib/python3.6/site-packages/services/public:/opt/sbt/lib/python3.6/site-packages/services/user:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_twitter:/opt/sbt/lib/python3.6/site-packages/common/sbt_elasticsearch/esmappings:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_cryptocurrency:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_fred:/opt/sbt/lib/python3.6/site-packages/services/util:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_portfolio:/opt/sbt/lib/python3.6/site-packages/services/admin:/opt/sbt/lib/python3.6/site-packages/scripts/aws/sbt_elasticsearch:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_barchart:/opt/sbt/lib/python3.6/site-packages/datafactory/vendor/sbt_cbonds:/opt/sbt/lib/python3.6/site-packages/services/articles_processing:/opt/sbt/lib/python3.6/site-packages/services/articles_processing/elasticsearch_ingestion:/opt/sbt/lib/python3.6/site-packages/services/articles_processing/elasticsearch_ingestion/helper:/opt/sbt/lib/python3.6/site-packages/services/articles_processing/tools:/opt/sbt/lib/python3.6/site-packages/scripts/datastore/monitors:/opt/sbt/lib/python3.6/site-packages'

# get scheduler for the current environment
config = sbtcommon.get_cfg_env_var('scheduler')
# get scheduler's options and jobs
job_options = config['options']
job_list = config['jobs']

jobs = [{"command": "from {} import {}; {}().{}()".format(v['module'],
                                                          v['class'],
                                                          v['class'],
                                                          v['method']
                                                          ),
         "name": k,
         "schedule": dict(v['schedule']['params']),
         } for k, v in job_list.items()]

# create a new CronTab instance
cron = CronTab(user="ec2-user")
# add jobs and set commands/comments
[cron.new(command='{} && $(which python3) -c "{}"'.format(EXPORT_PATH,
                                                          x['command']
                                                          ),
          comment=x['name']) for x in jobs]
# update job time
for i, j in enumerate(jobs):
    for k, v in j['schedule'].items():
        if k == 'minute':
            cron[i].minute.on(v)
        elif k == 'hour':
            cron[i].hour.on(v)
        elif k == 'dow':
            cron[i].dow.on(v)
        elif k == 'dom':
            cron[i].dom.on(v)

cron.write()

print("DONE.")
