import os
import sys
import logging
import logstash
import cherrypy
import bottle
import threading
import signal
import traceback
from time import sleep
from sbt_common import SbtGlobalCommon
from sbt_common import SingletonServiceManager
from da_accessor import DataAdminAccessor

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)

bottle.BaseRequest.MEMFILE_MAX = 2048 * 1024 * 512
app    = bottle.Bottle()
dataadminmanager   = None

###############################################################################
# sigterm handler
###############################################################################
def sigterm_handler(_signo, _stack_frame):

  logger.info("INFO:: received sigterm")
  cherrypy.engine.stop()
  cherrypy.engine.exit()
  global dataadminmanager
  if dataadminmanager is not None:
    dataadminmanager.fin = True
    dataadminmanager.clean()
  else:
    logger.info("INFO: no dataadminmanager")

  logger.info("INFO: system exiting now...")
  sys.exit(0)

###############################################################################
# get the ip addr string of host
###############################################################################
def hostip(request):
  """ Generate the host ID off of the provided PID and incoming IP"""
  ip_address = request.remote_addr
  host = "{0}".format(ip_address)

  return host

###############################################################################
# SBAnalysisManager:
###############################################################################
class DataAdminManager(object, metaclass=SingletonServiceManager):

  def __init__(self):
    """
      Constructor
    """
    logger.info("ScheduleManager: initializing")
    self.configured = False
    self.fin        = False
    self.env        = dict(os.environ)
    self.watcher     = threading.Thread(target = self.watch, args=(" "))

    self.data_admin_accessor = DataAdminAccessor()
    
    for v in self.env:
      logger.info("env: " + v + " " + self.env[v])
    self.watcher    = threading.Thread(target = self.watch, args=(" "))

  """
  Entry Point
  """
  def __enter__(self):
    return self

  """
  Cleanup
  """
  def clean(self):
    logger.info("INFO: cleaning up...")
    self.scheduler.stop()

  """
  Exit Point
  """
  def __exit__(self, exception_type, exception_value, traceback):
    logger.info("INFO: exiting...")
    self.watcher.join()

  """
  """
  def watch(self, r):
    logger.info("DataAdminManager: watcher activated")
    while self.fin == False:
        sleep(1)
    logger.info("DataAdminManager: deactivating watcher")

  """
  Start the DataAdminManager
  """
  def run(self):
    logger.info("INFO: running")
    self.watcher.start()

  def get_all_data_categories (self):
    return self.data_admin_accessor.query_data_categories()

###############################################################################
# Support CORS headers
# https://stackoverflow.com/questions/17262170/bottle-py-enabling-cors-for-jquery-ajax-requests
# Answer by ron.rothman
###############################################################################

@app.route('/<:re:.*>', method='OPTIONS')
def enable_cors_generic_route():
  """
  This route takes priority over all others. So any request with an OPTIONS
  method will be handled by this function.
  
  See: https://github.com/bottlepy/bottle/issues/402
  
  NOTE: This means we won't 404 any invalid path that is an OPTIONS request.
  """
  add_cors_headers()

@app.hook('after_request')
def enable_cors_after_request_hook():
  """
  This executes after every route. We use it to attach CORS headers when
  applicable.
  """
  add_cors_headers()

def add_cors_headers():
  bottle.response.headers['Access-Control-Allow-Origin'] = '*'
  bottle.response.headers['Access-Control-Allow-Methods'] = \
      'GET, POST, PUT, OPTIONS'
  bottle.response.headers['Access-Control-Allow-Headers'] = \
      'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token'



###############################################################################
# REST API
###############################################################################
"""
  TBD
"""

@app.route("/dataadmin/categories/all", method="GET")
def all_categories():
  try:
    return { "success": True, "data" : 
            app.dataadminmanager.get_all_data_categories()}
  except:
    return { "success": False, "error": traceback.format_exc()}


###############################################################################
# error_500
###############################################################################
@bottle.error(500)
def error_500(error):
  """Standard dictionary returned on 500 error"""
  return {"success":False, "error": error}

###############################################################################
# start
###############################################################################
def start(configuration):
  logger.setLevel(logging.INFO)
  ch = logging.StreamHandler(sys.stdout)
  ch.setLevel(logging.INFO)
  formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
  ch.setFormatter(formatter)
  logger.addHandler(ch)

  print(configuration['services'])
  config = configuration['services']['dataadminmanager']

  logger.addHandler(
      logstash.TCPLogstashHandler(
        config['logstash']['domain'], config['logstash']['port'], 
        version=config['logstash']['version']
        )
      )

  global dataadminmanager
  dataadminmanager     = DataAdminManager()
  app.dataadminmanager = dataadminmanager

  cherrypy.tree.graft(app, config['root_endpoint'])
  cherrypy.server.unsubscribe()
  cherrypy.config.update(config['server'])  
  cherrypy.server.subscribe()
  cherrypy.engine.start()

  logger.info("INFO: cherrypy configured")
  app.dataadminmanager.run()

  return dataadminmanager

###############################################################################
# main
###############################################################################
if __name__ == '__main__':
  signal.signal(signal.SIGTERM, sigterm_handler)

  dataadminmanager = start(SbtGlobalCommon.get_sbt_config())
  if dataadminmanager is not None:
    while not dataadminmanager.fin:
      sleep(1)

  logger.info("INFO: main exiting")
  sys.exit(0)
