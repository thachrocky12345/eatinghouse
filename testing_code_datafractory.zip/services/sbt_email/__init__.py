import boto3
import logging
import os
from jinja2 import Environment, FileSystemLoader, select_autoescape

from sbt_common import SbtGlobalCommon

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
config = SbtGlobalCommon.get_sbt_config()
session = boto3.session.Session(profile_name=config["aws"]["profile"])

dir_name = os.path.abspath(os.path.dirname(__file__))
jinja_env = Environment(
    loader=FileSystemLoader(dir_name),
    autoescape=select_autoescape(["html", "xml"]),
)

def get_email_text(template_name, **kwargs):
    template = jinja_env.get_template(template_name)
    return template.render(**kwargs)

def send_email(template_name, to_address, subject, **kwargs):
    email_text = get_email_text(template_name, **kwargs)

    ses = session.client("ses")
    ses.send_email(
        Destination={"ToAddresses": [to_address]},
        Message={
            "Body": {
                "Html": {
                    "Charset": "UTF-8",
                    "Data": email_text,
                },
            },
            "Subject": {
                "Charset": "UTF-8",
                "Data": subject,
            },
        },
        Source=config["services"]["email"]["from_address"],
    )
