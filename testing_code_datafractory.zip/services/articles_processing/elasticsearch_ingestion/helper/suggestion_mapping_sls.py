from elasticsearch_dsl import Mapping, Completion, Text, Keyword, \
  InnerObjectWrapper, Nested
from helper.es_default_text_sls import ESDefaultText
from helper.custom_analyzers_sls import autocomplete


class Category(InnerObjectWrapper):
  pass


class SuggestionMappingSLS(Mapping):
  def __init__(self, name):
    super().__init__(name)
    self.field('symbol', Text(
      fields={"keyword": Keyword(ignore_above=256),
              "autocomplete": Text(analyzer=autocomplete,
                                   search_analyzer="standard")}))
    self.field("symbol_suggest", Completion())
    self.field('exchange', ESDefaultText())
    self.field('entity_name', Text(
      fields={"keyword": Keyword(ignore_above=256),
              "autocomplete": Text(analyzer=autocomplete,
                                   search_analyzer="standard")}))
    self.field('category', Nested(
      doc_class=Category,
      properties={'category': ESDefaultText(), 'sub_category': ESDefaultText(),
                  'data_type': ESDefaultText()}
    ))

