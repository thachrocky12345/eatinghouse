from elasticsearch_dsl import DocType
from elasticsearch_dsl.document import META_FIELDS, DOC_META_FIELDS
from helper.suggestion_mapping_sls import SuggestionMappingSLS


class Suggestion(DocType):

  class Meta:
    doc_type = 'suggestions'
    mapping = SuggestionMappingSLS(doc_type)

  def save(self, using=None, index=None, validate=True, **kwargs):
    """
            Save the document into elasticsearch. If the document doesn't
            exist it
            is created, it is overwritten otherwise. Returns ``True`` if this
            operations resulted in new document being created.

            :arg index: elasticsearch index to use, if the ``DocType`` is
                associated with an index this can be omitted.
            :arg using: connection alias to use, defaults to ``'default'``
            :arg validate: set to ``False`` to skip validating the document

            Any additional keyword arguments will be passed to
            ``Elasticsearch.index`` unchanged.
            """
    if validate:
      self.full_clean()

    es = self._get_connection(using)
    # extract parent, routing etc from meta
    doc_meta = dict(
            (k, self.meta[k])
            for k in DOC_META_FIELDS
            if k in self.meta
    )
    doc_meta.update(kwargs)
    meta = es.index(
            index=self._get_index(index),
            doc_type=self._doc_type.name,
            body=self.to_dict(),
            **doc_meta
    )
    # update meta information from ES
    for k in META_FIELDS:
      if '_' + k in meta:
        setattr(self.meta, k, meta['_' + k])

    # return True/False if the document has been created/updated
    return meta.get('result', '') == 'created'