import json
import re
import inspect

from elasticsearch import Elasticsearch

# from sbt_common import SbtCommon
# from sbt_common import timing

from bs4 import BeautifulSoup

import ssl

# nlp = spacy.load('./models/en_core_web_sm-2.1.0/en_core_web_sm/en_core_web_sm-2.1.0')
import en_core_web_sm
nlp = en_core_web_sm.load()


class EsTools(object):

  def __init__(self):
    # who's calling this?
    # current_frame = inspect.currentframe()
    # caller_frame = inspect.getouterframes(current_frame, 2)
    # caller_name = caller_frame[1][3]
    # if caller_name != '_process_article_new_fields':
    #   self.sbt_config = SbtCommon().get_sbt_config()
    #   # self.es_client = Elasticsearch(
    #   #   hosts=self.sbt_config['elasticsearch']['hosts']
    #   # )
    self.index = None
    self.doc_type = None
    self.results = None

  def get_es_connection(self, host=None):
    '''
    :return: Instance of the Elasticsearch class. The host is determined by the
    'environment' attribute in the sbt_conf.json file.
    '''
    if host and 'localhost' in host:
      self.es_client = Elasticsearch(
        hosts=[host],
        ca_certs=False,
        verify_certs=False)
    else:
      self.es_client = Elasticsearch(hosts=[host])
    return self.es_client

  # @timing
  def create_index(self, index=None, doc_type=None, body=None):
    if not self.es_client.exists(index=index, doc_type=doc_type):
      self.es_client.create(index=index, doc_type=doc_type,
                            body=body if body else None)
      print("Index/type '{}/{}' created.".format(index, doc_type))
    else:
      print("WARNING: index already exists.")

  # @timing
  def delete_index(self, index=None, doc_type=None):
    if not self.es_client.exists(index=index, doc_type=doc_type):
      self.es_client.delete(index=index, doc_type=doc_type)
      print("Index '{}' deleted.".format(index))
    else:
      print("WARNING: index does not exist.")

  # @timing
  def get_all_docs(self, index=None, doc_type=None):
    '''
    Retrieve all documents from a given index and doc_type using scan/scroll.
    :param index: The index name.
    :param doc_type: The index type.
    :return: None; this method updates self.results.
    '''
    try:
      if index and doc_type:
        self.index = index
        self.doc_type = doc_type

        client = self.es_client
        search_obj = {'query': {'match_all': {}}}
        body = json.dumps(search_obj)

        final_res = []
        size = 5000
        # initial request
        res = client.search(index=self.index, doc_type=self.doc_type, body=body,
                            scroll='2m', size=size)
        final_res.extend(res['hits']['hits'])
        total_hits = res['hits']['total']
        sid = res['_scroll_id']
        scroll_size = res['hits']['total']
        print("Got the first {} out of {} docs".format(size, total_hits))
        n = 1
        while (scroll_size > 0):
          # scrolling
          docs_left = total_hits - size * n
          print("Scrolling... ({} docs left)".format(
            docs_left if docs_left > 0 else 0))
          res = client.scroll(scroll_id=sid, scroll='2m')
          final_res.extend(res['hits']['hits'])
          sid = res['_scroll_id']
          scroll_size = len(res['hits']['hits'])
          n+=1
        # updating results
        self.results = final_res
    except:
      print("No index/doc_type provided. Exiting.")

  # @timing
  def index_data(self, index=None, doc_type=None):
    ssl.match_hostname = lambda cert, hostname: True
    [self.es_client.index(
      index=index, doc_type=doc_type, id=x["_id"], body=x["_source"])
      for x in self.results]

  # @timing
  def _get_tags_list(self, text, tag):
    soup = BeautifulSoup(text, 'html')
    all_tags = soup.find_all(tag)
    tags_list = [x.get_text() for x in all_tags if len(x.get_text()) > 0]
    return tags_list

  # @timing
  def _get_symbols_list(self, text=None):
    # use the following regex: \(\b[A-Z]{1,5}\b\)
    pattern = re.compile(r'\(\b[A-Z]{1,5}\b\)')
    symbols_list = pattern.findall(text)
    symbols_list = [re.sub("\(|\)", "", x) for x in symbols_list]
    return symbols_list
  
  # @timing
  def _search_for_buy_and_sell_alerts(self, text=None):
    # create spaCy's Doc objects
    x = nlp(text)

    # applying selection rules
    alert_list = [{'alert': token.lemma_}
                  for token in x if (token.head.text == 'recommend' or
                                     token.head.text == 'suggest') and
                  (token.lemma_ == 'buy' or token.lemma_ == 'sell')
                  if ('to open' not in x.text) and
                  ('to close' not in x.text)]
#     if len(alert_list):
#       self._alert_count += 1
#       print("{} BUY AND SELL ALERT(S) FOUND".format(self._alert_count))
    return alert_list

  def add_new_fields(self, corpus=None):
    if corpus is None:
      corpus = self.results

    # is corpus an ES response?
    if isinstance(corpus, list):
      # list of ES responses (updating Dynamo)
      es_response = True
    else:
      es_response = True if '_source' in corpus else False

    # run corpus through the pipeline
    self.add_default_publication_slug(corpus, es_response)
    self.add_paragraph(corpus, es_response)
    self.add_htags(corpus, es_response)
    self.add_bold(corpus, es_response)
    self.add_symbols(corpus, es_response)
    self.add_buy_and_sell(corpus, es_response)

    # # updating results
    # self.results = corpus

    # index data before auto text summarization (takes longer to finish)
    # self.index_data(index='articles', doc_type='_doc')

    self.add_auto_excerpt(corpus, es_response)

    # updating results
    self.results = corpus
    print("Done.")

  # @timing
  def add_default_publication_slug(self, corpus, es_response=True):
    corpus = corpus if es_response else [{'_source': corpus}]
    # add _source.defaultPublicatio.slug
    [x['_source']['defaultPublication'].update(slug='-'.join([str(v)
                      for k, v in x['_source']['defaultPublication'].items()]))
                      for x in corpus if 'defaultPublication' in x['_source']]
    # updating results
    self.results = corpus if es_response else corpus[0]['_source']
    print("Done.")

  # @timing
  def add_paragraph(self, corpus, es_response=True):
    corpus = corpus if es_response else [{'_source': corpus}]
    [x['_source'].update(
      extracted_paragraphs=self._get_tags_list(x['_source']['content'], 'p'))
      for x in corpus if 'content' in x['_source']]
    # updating results
    self.results = corpus if es_response else corpus[0]['_source']
    print("Done.")

  # @timing
  def add_htags(self, corpus, es_response=True):
    corpus = corpus if es_response else [{'_source': corpus}]
    htags = ["h1", "h2", "h3", "h4", "h5", "h6"]
    [x['_source'].update(
      extracted_headerTags=self._get_tags_list(x['_source']['content'], htags))
      for x in corpus if 'content' in x['_source']]
    # updating results
    self.results = corpus if es_response else corpus[0]['_source']
    print("Done.")

  # @timing
  def add_bold(self, corpus, es_response=True):
    corpus = corpus if es_response else [{'_source': corpus}]
    [x['_source'].update(
      extracted_boldTags=self._get_tags_list(x['_source']['content'], 'b'))
      for x in corpus if 'content' in x['_source']]
    # updating results
    self.results = corpus if es_response else corpus[0]['_source']
    print("Done.")

  # @timing
  def add_symbols(self, corpus, es_response=True):
    corpus = corpus if es_response else [{'_source': corpus}]
    [x['_source'].update(
      extracted_symbols=self._get_symbols_list(x['_source']['content']))
      for x in corpus if 'content' in x['_source']]
    # updating results
    self.results = corpus if es_response else corpus[0]['_source']
    print("Done.")

  # @timing
  def add_auto_excerpt(self, corpus, es_response=True):
    # add _source.auto_excerpt
    corpus = corpus if es_response else [{'_source': corpus}]

    # only create auto excerpt if there's content
    [x['_source'].update(
      # auto_excerpt=create_auto_excerpt(x['_source']['contentText']))
      auto_excerpt='Not implemented yet')
      for x in corpus if 'content' in x['_source']]
    # updating results
    self.results = corpus if es_response else corpus[0]['_source']

  # @timing
  def add_buy_and_sell(self, corpus, es_response=True):
    corpus = corpus if es_response else [{'_source': corpus}]
    [x['_source'].update(
      buy_and_sell_alerts=self._search_for_buy_and_sell_alerts(
              x['_source']['contentText'])) for x in corpus
      if 'contentText' in x['_source']]
    # updating results
    self.results = corpus if es_response else corpus[0]['_source']
    print("Done.")


if __name__ == "__main__":

  estools = EsTools()

  estools.get_all_docs(index='articles', doc_type='articles')

  estools.add_new_fields()

  estools.index_data(index='articles', doc_type='articles')

  print("Done.")


