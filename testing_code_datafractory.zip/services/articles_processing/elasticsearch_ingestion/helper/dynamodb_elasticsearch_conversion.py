import re
import logging
import json
import bs4
import base64


# Return the dynamoDB table that received the event.
def get_table(record):
  p = re.compile(
    'arn:aws:(?:dynamodb|kinesis):.*?:(?:table|stream)/([\w-]+)(?:.)*')
  m = p.match(record['eventSourceARN'])
  if m is None:
    raise Exception("Table not found in SourceARN")
  logging.info("The table name extracted: " + m.group(1))
  return m.group(1)


# Generate the ID for ES. Used for deleting or updating item later
def generate_id(record):
  logging.info("Generating ID")
  if 'dynamodb' in record:
    keys = unmarshal_json(record['dynamodb']['Keys'])
  else:
    keys = unmarshal_json(record['Keys'])
  logging.info("Keys in record: " + json.dumps(keys))
  # Concat HASH and RANGE key with | in between
  new_id = ""
  i = 0
  for key, value in keys.items():
    if i > 0:
      new_id += "|"
    new_id += str(value)
    i += 1

  return new_id


# Unmarshal a JSON that is DynamoDB formatted
def unmarshal_json(node):
  logging.info("Unmarshalling record...")
  data = {"M": node}
  return unmarshal_value(data, True)


# ForceNum will force float or Integer to
def unmarshal_value(node, force_num=False):
  # Convert the record that is DynamoDB formatted into a plain JSON. e.g. Remove keys that indicate DynamoDB type
  for key, value in node.items():
    if key == "NULL":
      return None
    if key == "S" or key == "BOOL":
      return value
    if key == "N":
      if force_num:
        return int_or_float(value)
      return value
    if key == "M":
      data = {}
      for key1, value1 in value.items():
        data[key1] = unmarshal_value(value1, True)
      return data
    if key == "BS" or key == "L":
      data = []
      for item in value:
        data.append(unmarshal_value(item))
      return data
    if key == "SS":
      data = []
      for item in value:
        data.append(item)
      return data
    if key == "NS":
      data = []
      for item in value:
        if force_num:
          data.append(int_or_float(item))
        else:
          data.append(item)
      return data


# Detect number type and return the correct one
def int_or_float(s):
  try:
    return int(s)
  except ValueError:
    return float(s)


def get_paragraphs(article):
  # Check if content and tickers are fields in the article and tickers isn't empty. If not return the article as is.
  if {"content", "tickers"} <= set(article) and article['tickers']:
    return generate_paragraphs(article)
  else:
    logging.info("Generating paragraphs for special case")

  logging.info(
    "No paragraphs created for article with ID  " + str(article['wordpressId']))
  return json.dumps(article)


def check_paragraph_contains(ticker, paragraph):
  words = set(paragraph.get_text(strip=True).split())
  pattern = re.compile(r".*?"+ticker+r".*")
  for word in words:
    # Check's if the tag contains the ticker and it has no nested Tags. This
    # will prevent duplication.
    if re.search(pattern, word) and (len(paragraph.contents) == 1 and
       isinstance(paragraph.contents[0], bs4.element.NavigableString)):
      return True
  return False


def generate_paragraphs(article):
  logging.info("Generating paragraphs for article: " + json.dumps(article))
# Split 'content' field into paragraphs using the specified tags and Beautiful
# Soup library
  tags = ['p', 'div', 'table', 'a']
  separator = '<h4 style=\"text-align: center;\"><strong>Portfolio Update' \
              '</strong></h4>'
  content_no_portfolio_update = article['content'].split(separator, 1)[0]
# Separator for Trading notes
  separator = "\r\n<table class=\"dwt-head-table\""
  main_content = content_no_portfolio_update.split(
    separator, 1)[0]
  soup = bs4.BeautifulSoup(main_content, "html.parser")
  paragraphs = soup.find_all(tags)
  logging.info(
    "{0} preliminary paragraphs generated: {1}".format(str(len(paragraphs)),
                                                       str(paragraphs)))
  # Remove empty entries from the paragraphs
  logging.info("Removing empty entry from paragraphs")
  paragraphs = list(filter(None, paragraphs))
  # Remove invalid entries from the paragraphs e.g '\n'
  remove_invalid_entries(paragraphs)
  result = list()
  content_results_set = set()
  tickers = article['tickers']
  # Iterate through the paragraphs and determine which tickers appear in a paragraph. If none appear, discard the
  # paragraph.
  for p in paragraphs:
    # Convert Tag to str and split
    matches = [ticker for ticker in tickers if
               check_paragraph_contains(ticker, p)]
    if matches:
      logging.info("Matching tickers({0}) found in paragraph: {1}".format(
        ",".join(matches), p))
      # Strip the HTML tags from paragraph content
      content_text = p.get_text()
      paragraph = {'tickers': matches, 'content': str(p),
                   'contentText': content_text}
      logging.info("Appending paragraph " + json.dumps(paragraph))
      if content_text not in content_results_set:
        result.append(paragraph)
        content_results_set.add(content_text)

  if result:
    article['paragraphs'] = list(result)
  logging.info("{0} paragraphs created for article with ID {1}: {2}".format(
    str(len(result)),
    str(article['wordpressId']),
    " ".join(str(x) for x in result)))
  return json.dumps(article)


def remove_invalid_entries(items):
  logging.info("Removing invalid entries from paragraphs.")
  if '\n' in items:
    items.remove('\n')


def valid_article(article):
  """
  A helper function to determine whether an article should be indexed into
  Elasticsearch.
  This function follows on from the helper validity checking in the
  sbcontent_manager.
  :type article: JSON
  :param article: The article that will be checked
  :rtype: bool
  :return: True if the 'status' field is set to 'publish'.
  """
  logging.info("Checking whether the article is valid or invalid for insertion "
               "into Elasticsearch")
  valid_status = "publish"
  article_status = article.get('status', "")
  if article_status == valid_status:
    logging.info("The article with wordpressId {0} is valid for insertion into "
                 "Elasticsearch.".format(str(article.get('wordpressId', "-1"))))
    return True
  logging.info("The article is invalid for insertion into Elasticsearch. "
               "Its status is {0}.".format(article_status))
  return False


def generate_company_descriptions(article):
  """
  Generate the company descriptions for a company-overview article
  :param article: The input article.
  :return: The article with 'short_description' and 'long_description' added.
  """
  parse_content_text_for_descriptions(article)
  parse_content_for_financial_data(article)

  return article


def parse_content_for_financial_data(article):
  soup = bs4.BeautifulSoup(article['content'], "html.parser")
  tables = soup("table")
  if tables:
    article['snapshot'] = str(tables[0])
    article['statistics'] = str(tables[1:])
    links = soup("a")
    if links:
      for link in links:
        if link.img:
          article['chart'] = str(link)
          return


def parse_content_text_for_descriptions(article):
  # the pattern contains a lot of optional flags as the state of the content
  # is in flux
  key_strings = ["Statistics", "Original Recommendation"]
  if all(key_string in article['contentText'] for key_string in key_strings):
    pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)\W{0,2}Statistics(?:.*)\W{0,2}Original Recommendation\W{0,4}(?:\d+;){0,1}(?P<url>.*\d{1,6}(?:#\w+)?)"
  elif "Original Recommendation" in article['contentText']:
    pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)\W{0,2}Original Recommendation\W{0,4}(?:\d+;){0,1}(?P<url>.*\d{1,6}(?:#\w+)?)"
  elif "\r\nStatistics" in article['contentText']:
    pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)\W{0,}Statistics"
  else:
    pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)"

  compiled_pattern = re.compile(pattern)
  match = re.search(pattern, article['contentText'], re.DOTALL)
  logging.info('Generating company descriptions for article with wordpressId:' +
               str(article['wordpressId']))
  try:
    article['profile_type'] = match.group("profile_type")
    article['short_description'] = match.group("short_desc")
    article['stansberry_action'] = match.group("action")
    article['long_description'] = match.group("long_desc")
    if "url" in compiled_pattern.groupindex:
      article['original_recommendation_url'] = match.group("url") if \
        match.group("url") else ""
  except (IndexError, AttributeError):
    logging.exception("Unexpected contentText format for article with "
                      "wordpressID " + str(article['wordpressId']) +
                      " Pattern used: " + pattern)


def decode_kinesis_data(record):
  logging.info("Decoding Kinesis Record...")
  dec = base64.b64decode(record['kinesis']['data']).decode("utf-8")
  logging.info("Kinesis Record Data Decoded:")
  logging.info(dec)
  return dec


def unmarshal_record(record):
  if record['eventName'] == "aws:kinesis:record":
    record = json.loads(decode_kinesis_data(record))
    doc = json.dumps(unmarshal_json(record['NewImage']))
  else:
    doc = json.dumps(unmarshal_json(record['dynamodb']['NewImage']))
  return doc, record
