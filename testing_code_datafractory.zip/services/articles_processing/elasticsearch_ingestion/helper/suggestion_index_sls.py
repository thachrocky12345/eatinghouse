from elasticsearch_dsl import Index
from helper.suggestion_sls import Suggestion
from helper.custom_analyzers_sls import autocomplete


class SuggestionIndex(Index):

  def __init__(self, using='default'):
    super().__init__('suggestions', using)
    self.analyzer(autocomplete)
    self.doc_type(Suggestion)
