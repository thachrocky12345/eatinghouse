from abc import ABCMeta, abstractmethod
import logging
import many_stop_words
import re


class SuggestionGenerator(metaclass=ABCMeta):

  stop_words_list = list(many_stop_words.get_stop_words('en'))

  @staticmethod
  def factory(suggest_type):
    if suggest_type == "CFTC":
      return CFTCSuggestionGenerator()
    else:
      return StockSuggestionGenerator()

  @abstractmethod
  def generate_suggestions(self, entity_name):
    pass

  @staticmethod
  def add_item_to_list(item, suggest_list, weight=1):
    suggest_list.append({
      "input": item,
      "weight": weight,
    })

  @staticmethod
  def add_list_to_suggestions(word_list, suggest_list, weight=1):
    for word in word_list:
      SuggestionGenerator.add_item_to_list(word.strip(), suggest_list, weight)

  @staticmethod
  def replace_non_alphanumeric(name, pattern=r"[^\w\s]+"):
    non_alphanumeric_pattern = re.compile(pattern)
    new_name = non_alphanumeric_pattern.sub(' ', name)
    return new_name

  @staticmethod
  def remove_stop_words(name_list):
    return [word for word in name_list if word not in
            SuggestionGenerator.stop_words_list]

  @staticmethod
  def get_name_as_clean_list(entity_name, delimiter=None):
    return SuggestionGenerator.remove_stop_words(entity_name.split(
      delimiter))

  @staticmethod
  def remove_duplicate_dicts_from_list(suggest_list):
    result = [dict(tupleized) for tupleized in
              set(tuple(item.items()) for item in suggest_list)]
    return result


class CFTCSuggestionGenerator(SuggestionGenerator):

  def __init__(self, ):
    super().__init__()

  def generate_suggestions(self, entity_name):
    logging.info("Enriching the data, creating suggestions.")
    suggest_list = []
    self.add_item_to_list(entity_name, suggest_list)
    entity_name_list = entity_name.split(' - ')
    for count, item in enumerate(entity_name_list):
      if not count:
        CFTCSuggestionGenerator.part_one_suggestions(item, suggest_list)
      elif count == 1:
        CFTCSuggestionGenerator.part_two_suggestions(item, suggest_list)
      else:
        CFTCSuggestionGenerator.remaining_parts_suggestions(item, suggest_list)
    return CFTCSuggestionGenerator.remove_duplicate_dicts_from_list(
      suggest_list)

  @staticmethod
  def remaining_parts_suggestions(item, suggest_list):
    CFTCSuggestionGenerator.add_item_to_list(item, suggest_list)
    clean_word_list = CFTCSuggestionGenerator.get_name_as_clean_list(item)
    for word in clean_word_list:
      CFTCSuggestionGenerator.add_item_to_list(word, suggest_list)
    name = " ".join(clean_word_list)
    CFTCSuggestionGenerator.add_item_to_list(name, suggest_list)
    new_name = CFTCSuggestionGenerator.replace_non_alphanumeric(name)
    CFTCSuggestionGenerator.add_item_to_list(new_name, suggest_list)
    for word in new_name.split():
      CFTCSuggestionGenerator.add_item_to_list(word, suggest_list)

  @staticmethod
  def part_two_suggestions(item, suggest_list):
    weight = 10
    CFTCSuggestionGenerator.add_item_to_list(item, suggest_list, weight)
    word_list = item.split()
    if len(word_list) > 1:
      CFTCSuggestionGenerator.add_list_to_suggestions(word_list,
                                                      suggest_list, weight)

      clean_word_list = CFTCSuggestionGenerator.remove_stop_words(word_list)
      CFTCSuggestionGenerator.add_list_to_suggestions(clean_word_list,
                                                      suggest_list, weight)
      name = " ".join(clean_word_list)
      CFTCSuggestionGenerator.add_item_to_list(name, suggest_list, weight)
      new_name = CFTCSuggestionGenerator.replace_non_alphanumeric(name)
      CFTCSuggestionGenerator.add_item_to_list(new_name, suggest_list, weight)
      CFTCSuggestionGenerator.add_list_to_suggestions(new_name.split(),
                                                      suggest_list, weight)
    else:
      new_name = CFTCSuggestionGenerator.replace_non_alphanumeric(item)
      CFTCSuggestionGenerator.add_item_to_list(new_name, suggest_list, weight)
      CFTCSuggestionGenerator.add_list_to_suggestions(new_name.split(),
                                                      suggest_list, weight)

  @staticmethod
  def part_one_suggestions(item, suggest_list):
    CFTCSuggestionGenerator.add_item_to_list(item, suggest_list)
    word_list = CFTCSuggestionGenerator.get_name_as_clean_list(item)
    for word in word_list:
      CFTCSuggestionGenerator.add_item_to_list(word, suggest_list)
    name = " ".join(word_list)
    CFTCSuggestionGenerator.add_item_to_list(name, suggest_list)


class StockSuggestionGenerator(SuggestionGenerator):

  def __init__(self, ):
    super().__init__()

  def generate_suggestions(self, entity_name):
    suggest_list = []
    weight = 10
    StockSuggestionGenerator.add_item_to_list(entity_name, suggest_list, weight)
    entity_name_list = entity_name.split()
    StockSuggestionGenerator.add_list_to_suggestions(entity_name_list[:-1],
                                                     suggest_list, weight)
    StockSuggestionGenerator.add_item_to_list(entity_name_list[-1],
                                              suggest_list)
    return StockSuggestionGenerator.remove_duplicate_dicts_from_list(
      suggest_list)
