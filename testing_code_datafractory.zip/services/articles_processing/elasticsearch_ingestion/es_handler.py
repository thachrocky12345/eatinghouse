from __future__ import print_function

import base64
import json
import logging
import os

from elasticsearch import Elasticsearch, ElasticsearchException
from sbt_common import SbtCommon
from elasticsearch_manager import ElasticsearchManager

from helper.es_tools import EsTools
from helper.update_dynamodb import update_dynamodb
from helper.index import get_index_settings
from helper import dynamodb_elasticsearch_conversion as conversion_helper

FORMAT = '%(levelname)s - %(message)s'
logging.basicConfig(format=FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Tools to process and add new fields used in ES
es_tools = EsTools()

sbtcommon = SbtCommon()
logger = sbtcommon.get_logger(logging.DEBUG, 'articles_processing')
apm = None


class ArticlesProcessing(object):

  def __init__(self, config):
    """
      Singleton class initializer
    """
    logger.info("SBContentManager: initializing")
    self.configured = False
    self.fin = False
    self.env = dict(os.environ)
    self.config = config
    self.lastupdate = None
    self.deploy_env = sbtcommon.get_sbt_config_env()
    self.es_hosts = sbtcommon.get_cfg_env_var("elasticsearch")
    self._es = ElasticsearchManager(None, self.es_hosts)

    # index and doc type for testing process
    self._index = 'buy_and_sell'
    self._doc_type = 'articles'

    logger.info("config: " + str(self.config))
    for v in self.env:
      logger.info("env: " + v + " " + self.env[v])

  def process_stream(self, event=None, context=None):
    #  Connect to ES
    host = self.es_hosts["hosts"][0]

    if 'localhost' in host:
      es = es_tools.get_es_connection(host)
    else:
      es = Elasticsearch(hosts=[host])

    logging.info("Cluster info:")
    logging.info(es.info())

    record = event

    # if event:
    #   # Loop over the DynamoDB/Kinesis Stream records
    #   for record in event['Records']:
    #
    #     logging.info("New Record to process:")
    #     logging.info(json.dumps(record))
    #     try:
    #       # Determine the event type being processed
    #       if record['eventName'] == "INSERT" or record[
    #         'eventName'] == "aws:kinesis:record":
    #         self.insert_document(es, record)
    #       elif record['eventName'] == "REMOVE":
    #         self.remove_document(es, record)
    #       elif record['eventName'] == "MODIFY":
    #         self.modify_document(es, record)
    #     except Exception as e:
    #       logging.exception(e)
    #       continue
    # else:
    #   return self._test_call()

    self.insert_document(es, record)

    return

  def decode_kinesis_data(self, record):
    logging.info("Decoding Kinesis Record...")
    dec = base64.b64decode(record['kinesis']['data']).decode("utf-8")
    logging.info("Kinesis Record Data Decoded:")
    logging.info(dec)
    return dec

  def modify_document(self, es, record):
    # Process MODIFY events
    table = 'articles'
    logging.info("Dynamo Table: " + table)

    # doc_id = conversion_helper.generate_id(record)
    doc_id = record['wordpressId']
    logging.info("KEY")
    logging.info(doc_id)

    # Unmarshal the DynamoDB JSON to a normal JSON
    # doc = json.dumps(conversion_helper.unmarshal_json(record['dynamodb']['NewImage']))
    doc = record

    # add new fields
    doc = doc if table != 'articles' else \
      json.dumps(self.process_article_new_fields(json.loads(doc)))

    doc_json = json.loads(doc)
    if conversion_helper.valid_article(doc_json):
      doc = json.dumps(self.update_document(doc_json))
      logging.info("Updated document:")
      logging.info(doc)

      # We reindex the whole document as ES accepts partial docs
      es.index(index=self._index,
               body=json.loads(doc),
               id=doc_id,
               doc_type=self._doc_type,
               refresh=True)

      logging.info("Success - Updated index ID: " + doc_id)
      return
    es.delete(index=self._index,
              id=doc_id,
              doc_type=self._doc_type,
              refresh=True)

  def remove_document(self, es, record):
    # Process REMOVE events
    table = conversion_helper.get_table(record)
    logging.info("Dynamo Table: " + table)

    doc_id = conversion_helper.generate_id(record)
    logging.info("Deleting document ID: " + doc_id)

    es.delete(index=self._index,
              id=doc_id,
              doc_type=self._doc_type,
              refresh=True)

    logging.info("Successfully removed")

  def insert_document(self, es, record):
    # Process INSERT events
    table = 'articles'
    logging.info("Dynamo Table: " + table)

    # Create index if missing
    if not es.indices.exists(self._index):
      logging.info("Create missing index: " + self._index)
      es.indices.create(self._index, body=get_index_settings())
      logging.info("Index created: " + self._index)

    doc_json = record

    doc_id = str(record['wordpressId'])
    if not conversion_helper.valid_article(doc_json):
      try:
        es.delete(index=self._index,
                  id=doc_id,
                  doc_type=self._doc_type,
                  refresh=True)
      except ElasticsearchException:
        logger.exception("No item exists with the ID: " +
                         str(doc_json['wordpressId']))
      return
    doc = json.dumps(self.update_document(doc_json))

    logging.info("New document to Index:")
    logging.info(doc)

    # add new fields
    doc = doc if table != 'articles' else \
      json.dumps(self.process_article_new_fields(doc_json))

    logging.info("Final schema of document to be indexed:")
    logging.info(doc)

    #  Generate the id that will be used to stored in Elasticsearch
    logging.info("Indexing into Elasticsearch...")
    try:
      es.index(index=self._index,
               body=json.loads(doc),
               id=doc_id,
               doc_type=self._doc_type,
               refresh=True)
    except ElasticsearchException:
      logging.exception("Dynamo Record with id " + doc_id + " has an error")
      update_dynamodb({'doc': doc, 'id': int(doc_id), 'table': table})
      return

    logging.info("Success - New Index ID: " + doc_id)

  def update_document(self, doc_json):
    if doc_json['defaultCategory'] == 'company-overview':
      return conversion_helper.generate_company_descriptions(doc_json)

    # Add paragraphs attribute
    return conversion_helper.get_paragraphs(doc_json)

  def process_article_new_fields(self, doc):
    logging.info("Adding new fields to article...")
    es_tools.add_new_fields(doc)
    logging.info("-> New article schema: {}".format(es_tools.results))
    return es_tools.results
