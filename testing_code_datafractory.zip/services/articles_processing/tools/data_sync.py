import json
import logging
from boto3.dynamodb.conditions import Attr
from sbt_common import SbtCommon
import process_articles as pa


# list of the environments to run data sync on
RUN_DATA_SYNC_ON = ['dev']
# relative path to the file containing the settings and mappings for the index
ES_INDEX_CONFIG = '../es_settings_mappings/new_articles.json'


# TODO: create a log file for this
sbtcommon = SbtCommon()
logger = sbtcommon.get_logger(logging.DEBUG, 'datasync')


def _get_settings_mappings(filename):
    with open(filename, 'r') as f:
        mapping = json.load(f)
    print("Mapping and settings acquired.")
    return mapping


def data_sync():
    logger.info("STARTING DATA SYNC...")

    # get settings and mappings
    body = _get_settings_mappings(ES_INDEX_CONFIG)
    # get connections to ES
    pa.get_es_connection(RUN_DATA_SYNC_ON)
    # create index
    try:
        [pa.es_client[env].indices.create(index='new_articles', body=body)
         for env in RUN_DATA_SYNC_ON]
    except Exception as e:
        logger.info("An exception occurred: {}".format(e))

    # scan entire table and process/index data
    condition = Attr("wordpressId").gt(0)
    pa.scan_table(condition)
    logger.info("DATA SYNC FINISHED.")


if __name__ == "__main__":
    # run data sync
    data_sync()
