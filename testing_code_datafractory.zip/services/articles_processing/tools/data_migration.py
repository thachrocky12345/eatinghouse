from elasticsearch import Elasticsearch

########################################
# EDIT THE FOLLOWING LINES ACCORDINGLY #
########################################

# source of the data (copied from)
SOURCE = "dev"
# destination of the data (copied to)
DESTINATION = ["qa"]

# index that must be updated (include the alias too)
INDICES_TO_BE_UPDATED = [
    {"index": "new_articles", "alias": "articles"},
    {"index": "new_suggestions", "alias": "suggestions"},
    {"index": "educational", "alias": "educational"}
]

# name of the repo and ID of the snapshot to be restored
MANUAL_REPO_NAME = "data_migration_across_domains_repo"
MANUAL_SNAPSHOT_ID = "snap-2019-07-19"

#######################################
#     DO NOT EDIT PAST THIS LINE      #
# (UNLESS YOU KNOW WHAT YOU'RE DOING) #
#######################################

ES_HOSTS = {
    "dev": "https://localhost:9100",
    "qa": "https://localhost:9200",
    "prod": "https://localhost:9300"
}

MASTER_TIMEOUT = "30s"

ES_MANAGER = {env: Elasticsearch(
  hosts=[ES_HOSTS[env]],
  ca_certs=False,
  verify_certs=False,
  use_ssl=False,
  timeout=30
  )
  for env in ES_HOSTS.keys()}

ES_CLIENT = {k: v for k, v in ES_MANAGER.items()}


# REPOSITORY LEVEL
def create_manual_repository(source=SOURCE, repo_name=MANUAL_REPO_NAME):
    ES_CLIENT[source].snapshot.create_repository(
      repository=repo_name,
      verify=True
    )
    print("REPOSITORY {} CREATED".format(repo_name))


def delete_manual_repository(source=SOURCE, repo_name=MANUAL_REPO_NAME):
    ES_CLIENT[source].snapshot.delete_repository(
      repository=repo_name,
      master_timeout=MASTER_TIMEOUT,
      timeout=MASTER_TIMEOUT
    )
    print("REPOSITORY {} DELETED".format(repo_name))


# SNAPSHOT LEVEL
def create_manual_snapshot(source=SOURCE):
    ES_CLIENT[source].snapshot.create(
      repository=MANUAL_REPO_NAME,
      snapshot=MANUAL_SNAPSHOT_ID
    )
    print("MANUAL SNAPSHOT WITH ID {} CREATED.".format(MANUAL_SNAPSHOT_ID))


def delete_manual_snapshot(source=SOURCE):
    ES_CLIENT[source].snapshot.delete(
      repository=MANUAL_REPO_NAME,
      snapshot=MANUAL_SNAPSHOT_ID,
      master_timeout=MASTER_TIMEOUT
    )
    print("MANUAL SNAPSHOT WITH ID {} DELETED.".format(MANUAL_SNAPSHOT_ID))


def restore_manual_snapshot(source=SOURCE):
    ES_CLIENT[source].snapshot.restore(
      repository=MANUAL_REPO_NAME,
      snapshot=MANUAL_SNAPSHOT_ID
    )
    print("MANUAL SNAPSHOT WITH ID {} RESTORED.".format(MANUAL_SNAPSHOT_ID))


# INDEX LEVEL
def delete_index(source=SOURCE, index=None):
    ES_CLIENT[source].index.delete(
      index=index,
      ignore_unavailable=True,
      master_timeout=MASTER_TIMEOUT,
      timeout=MASTER_TIMEOUT
    )
    print("INDEX {} DELETED.".format(index))


def restore_alias(source=SOURCE, index=None, alias=None):
    ES_CLIENT[source].index.put_alias(
      index=index,
      name=alias
    )


# PIPELINE
def run_pipeline():
    # delete_manual_snapshot()

    # create_manual_snapshot()

    [[delete_index(source=source, index=index['index'])
      for index in INDICES_TO_BE_UPDATED] for source in DESTINATION]

    [restore_manual_snapshot(source=source) for source in DESTINATION]

    [[restore_alias(source=source, index=index['index'], alias=index['alias'])
      for index in INDICES_TO_BE_UPDATED] for source in DESTINATION]


if __name__ == "__main__":

    run_pipeline()

    print("DATA MIGRATION FINISHED.")
