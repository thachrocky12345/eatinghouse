import boto3
import requests
from requests_aws4auth import AWS4Auth

#
# Script for registering a snapshot repository for data migration accross ES domains.
# (NB: This is a ONE-STEP PROCESS.)
#
# REFERENCES:
# YouTube: https://www.youtube.com/watch?v=FmLmyvH83Ng
# GitHub: https://github.com/miztiik/AWS-Demos/tree/master/How-To/setup-manual-elasticsearch-snapshots
# AWS: https://aws.amazon.com/premiumsupport/knowledge-center/migrate-amazon-es-domain/

#
# dev: https://vpc-trm-elasticsearch-dev-i2h63z4szf2pdbt3if2sslirvu.us-east-1.es.amazonaws.com/
# QA: https://vpc-trm-elasticsearch-qa-wzu5ptwcmp56wa7z4z2u2taqfe.us-east-1.es.amazonaws.com/
# prod: https://vpc-trm-elasticsearch-prod-yhtk4fny5bpq3fwgbv2ows6zei.us-east-1.es.amazonaws.com
#

host = 'https://vpc-trm-elasticsearch-dev-i2h63z4szf2pdbt3if2sslirvu.us-east-1.es.amazonaws.com/'
region = 'us-east-1'
service = 'es'
credentials = boto3.Session().get_credentials()
aws_auth = AWS4Auth(credentials.access_key,
                    credentials.secret_key,
                    region, service,
                    session_token=credentials.token)

# Register repository
path = '_snapshot/data_migration_across_domains_repo'
url = host + path

payload = {
  "type": "s3",
  "settings": {
    "bucket": "sbt-es-manual-snapshots",
    "endpoint": "s3.amazonaws.com",
    "role_arn": "arn:aws:iam::063414442810:role/sbt-es-manual-snapshot-creator-role"
  }
}

headers = {"Content-Type": "application/json"}

r = requests.put(url, auth=aws_auth, json=payload, headers=headers)

print(r.status_code)
print(r.text)
