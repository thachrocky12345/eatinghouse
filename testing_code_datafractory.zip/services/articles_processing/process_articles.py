import html

import boto3
import decimal
import logging
import re

import bs4
import spacy
from elasticsearch import Elasticsearch
from spacy.pipeline import Sentencizer
import time
from boto3.dynamodb.conditions import Attr
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

from sbt_common import SbtCommon
from dd_accessor import DynamoAccessor
from elasticsearch_manager import ElasticsearchManager

###
# RUNTIME CONFIGURATIONS
#
# which domains to run this process on?
RUN_PROCESS_ON = {
    "dev": True,
    "qa": True,
    "prod": False
}
# set to True to run the service locally only (for testing purposes)
LOCAL_TEST = False
# which ES domain to use when running this locally?
LOCAL_ES_DOMAIN_TO_USE = ['dev', 'qa']
#
###


###
# MAIN
#
sbtcommon = SbtCommon()
config = sbtcommon.raw_sbt_config
config_env = config['environment']
# check if we're running this locally or on the server
# (please, change the 'environment' attribute in sbt_conf.json accordingly)
is_local_env = config_env == 'local'

logger = sbtcommon.get_logger(logging.DEBUG, 'apmanager')

### Elasticsearch configurations
# list of localhosts
LOCAL_HOSTS_LIST = {env: host for env, host in zip(['dev', 'qa', 'prod'],
                                                   config['local'][
                                                       'elasticsearch'][
                                                       'hosts'])}
# environments to run the article process on
ES_CLUSTER_ENVS = [k for k, v in RUN_PROCESS_ON.items() if v]
# get the host for the maching running this process
# (if we're running this locally then use the locahosts from the 'local' env)
ES_HOSTS = {env: LOCAL_HOSTS_LIST[env] for env in LOCAL_ES_DOMAIN_TO_USE} \
    if is_local_env else {env: config[env]['elasticsearch']['hosts'] for env in
                          RUN_PROCESS_ON}

### DynamoDB accessor & client & streams
dynamo_accessor = DynamoAccessor()
session = dynamo_accessor._session if not LOCAL_TEST else None
dynamodb_client = session.client("dynamodb",
                                 region_name=config[config_env]['aws'][
                                     'region']) if not LOCAL_TEST else None
streams_client = session.client("dynamodbstreams",
                                region_name=config[config_env]['aws'][
                                    'region']) if not LOCAL_TEST else None
streams = []
deserializer = boto3.dynamodb.types.TypeDeserializer()

# load spacy's English pre-compiled model
nlp = spacy.load("en_core_web_lg")
# add colon to the sentencizer
sentencizer = Sentencizer(punct_chars=[".", "?", "!", "\n"])
# apply new sentencizer to pipeline
nlp.add_pipe(sentencizer, before="parser")

# get the DynamoDB table name where the articles are
DYNAMO_TABLE_NAME = config['services']['process_articles']['dynamo_table_name']
# get the DynamoDB primary key's name
ES_DYNAMO_PK = config['services']['process_articles']['dynamo_pk']
# get the elasticsearch index and doc type to be used
ES_INDEX = config['services']['process_articles']['es_index_name']
ES_DOCTYPE = config['services']['process_articles']['es_doctype']
ES_INDEX_ALIAS = 'articles'

# used by the auto-tagger
TABLE_ARTICLES = 'articles'
TABLE_SYMBOL_EXCHANGE_MAP = 'SBT_SYMBOL_EXCHANGE_MAPPING'
ignore_list = [
    'Co',  # (except: PepsiCo)
    'Company',
    'Inc',
    'Incorporated',
    'PLC',
    'LLC',
    '.com',
    'ETF',
    'Limited',
    'Ltd',
    'Corp',
    'Corporation',
    'Group',
    'Gr',
    'ETN',
    'The'
]
#  prep_list is a newer list of stop words, started as just short prepositions, added more as needed.
prep_list = ['de', 'of', 'from', 'and', '&', '-', '.', 'com', '', 'Holdings',
             'the', '$']
# concatenated list of ignore and prep
extra_ignored = set(ignore_list + prep_list)
allowed_exchange_list = ["NYSE", "NYSEARCA", "NSDQ", "NSDQCM", "AMEX",
                         "BOX", "CBOE", "CBOT",
                         "CCX", "CME", "CHX",
                         "ICE", "MGEX", "NSX",
                         "NYMEX", "OCX", "PHLX",
                         "USFE", "OTC"
                         ]
# publication codes to be excluded form the auto-tagger
AUTO_TAGGER_PUBCODES_TO_SKIP = (
    'crux', 'dwt', 'dwp',
    'sdw', 'ipm', 'emp', 'trd'
)

# publication codes to be excluded form the buy/sell recommendation system
BUYSELL_PUBCODES_TO_SKIP = ('bmt', 'bsg', 'sdw', 'dwp', 'emp',
                            'hwb', 'ipm', 'pwa', 'pal', 'sal',
                            'cho', 'dig', 'sih', 'srp', 'crux',
                            'sug', 'trd', 'twa', 'new'
                            )


def get_es_connection(env_list=[]):
    global es_manager, es_client, run_datasync, datasync_env_list
    # are we running data sync?
    run_datasync = True if len(env_list) else False
    # if so, for which environment?
    datasync_env_list = env_list if run_datasync else None
    # get ES manager & client
    if is_local_env:
        # get connection for localhost
        es_manager = {env: Elasticsearch(
            hosts=[ES_HOSTS[env]],
            ca_certs=False,
            verify_certs=False,
            use_ssl=False)
            for env in (
                datasync_env_list if run_datasync else LOCAL_ES_DOMAIN_TO_USE)} if not LOCAL_TEST else None
        es_client = {k: v for k, v in
                     es_manager.items()} if not LOCAL_TEST else None
    else:
        # get connection to the corresponding AWS ES domain
        es_manager = {
            env: ElasticsearchManager(None, config[env]["elasticsearch"])
            for env in ES_CLUSTER_ENVS} if not LOCAL_TEST else None
        es_client = {k: v._es for k, v in
                     es_manager.items()} if not LOCAL_TEST else None

    print("Done.")


def is_doc_existent(id=None, env_list=None):
    # check if article exists
    if es_manager is None:
        get_es_connection()

    [es_manager[env].get() for env in env_list]


def get_tags_list(soup, tag):
    all_tags = soup.find_all(tag)
    tags_list = [x.get_text() for x in all_tags if len(x.get_text()) > 0]
    return tags_list


def get_symbols_list(text):
    # use the following regex: \(([A-Za-z]*\:\s*)?([A-Z]{1,6})\)+
    # to pick up on things like:
    # (AAPL), (NYSE: AAPL), (NYSE:AAPL), (Nasdaq: AAPL), (Nasdaq:AAPL)
    # the result is a tuple with the 2 groups:
    # (exchange, symbol) or ('', symbol) if exchange is not present
    # TODO: we also need to detect things like this: (NASDAQ:GOOG, NASDAQ:GOOGL)
    pattern = re.compile(r'\(([A-Za-z]*\:\s*)?([A-Z]{1,6})\)+')
    match_list = pattern.findall(text)
    # extract the symbol only
    symbols_list = [x[1].strip() for x in match_list]
    # extract the exchange only
    # exchange_list = [x[0].strip() for x in match_list]
    return symbols_list


def search_for_buy_and_sell_alerts(text):
    ###
    ### clean up & normalization
    ###
    # handle HTML entities
    text = html.unescape(text)
    # replace newline characters with spaces
    text = re.sub('[\n]{1,}', '\n', text)
    # remove "Trade Alert:" text from sentence and
    # also leading/trailing spaces
    if text.count('Trade Alert'):
        text = text.replace('Trade Alert:', '').strip()
        # capitalize the first word
        # (N.B: this step is not necessary when using the lg model)
        # text = text.replace('BUY', 'Buy').replace('SELL', 'Sell')

    # create spaCy's Doc object
    doc = nlp(text)
    # negation (we don't want negative recommendations)
    negation_list = ["not"]
    # tokens to be used as root
    trigger_lemmas = ["buy", "sell"]
    # tokens to be used as head
    trigger_tokens = ["recommend", "suggest"]
    # key tokens to be looking for in the sentence
    key_tokens = ["your shares", "put", "call", "position", "option"]
    alert_list = []

    # TODO: handle content within tables

    # direct syntactic connection between trigger_tokens and trigger_lemmas
    [[alert_list.append({"alert": token.lemma_, "text": sentence.text})
      for token in sentence
      if token.head.text in trigger_tokens and
      token.lemma_ in trigger_lemmas and
      token.head.lefts not in negation_list and
      # detect NER == MONEY (recommendations with a price in it)
      (sum([ent.label_.count('MONEY') for ent in sentence.ents]) or
       # detect NER == ORG OR POS == PROPN(recommendations with a company's name in it)
       (sum([ent.label_.count('ORG') for ent in sentence.ents]) or
        sum([token.pos_.count('PROPN') for token in sentence])) or
       # detect sentences containing 'your shares' (e.g. "do something with your shares")
       sum([sentence.text.count(kt) for kt in key_tokens]))]
     for sentence in doc.sents]

    detected_sentences = [x['text'] for x in alert_list]

    ###
    # detect imperative mood
    #
    imperative_mood_sentences = []
    # 1 - imperative mood only (DO SOMETHING)
    [[imperative_mood_sentences.append(
        {"alert": token.lemma_, "text": sentence.text})
      for token in sentence
      if sentence.text not in detected_sentences and
      token.is_sent_start and
      token.pos_ == 'VERB' and
      token.lemma_ in trigger_lemmas and
      # detect NER == ORG OR POS == PROPN (recommendations with a company's name in it)
      ((sum([ent.label_.count('ORG') for ent in sentence.ents]) or
        sum([token.pos_.count('PROPN') for token in sentence])) and
       sum([sentence.text.count(kt) for kt in key_tokens]))]
     for sentence in doc.sents]

    detected_sentences.extend([x['text'] for x in imperative_mood_sentences])

    # 2 - imperative mood with DOBJ syntactic relation between trigger_lemmas and the token 'shares' and an ORG
    # (BLAH BLAH BLAH, DO SOMETHING WITH YOUR SHARES/PUT/CALL/POSITION/OPTION OF COMPANY XYZ)
    [[imperative_mood_sentences.append(
        {"alert": token.head.lemma_, "text": sentence.text})
      for token in sentence
      if sentence.text not in detected_sentences and
      token.head.lemma_ in trigger_lemmas and
      token.dep_ == 'dobj' and
      sum([sentence.text.count(kt) for kt in key_tokens]) and
      # detect NER == ORG OR POS == PROPN(recommendations with a company's name in it)
      (sum([ent.label_.count('ORG') for ent in sentence.ents]) or
       sum([token.pos_.count('PROPN') for token in sentence])) and
      # detect NER == MONEY (has to have a price in it)
      sum([ent.label_.count('MONEY') for ent in sentence.ents])]
     for sentence in doc.sents]

    detected_sentences.extend([x['text'] for x in imperative_mood_sentences])

    # # 3 - imperative mood plus MONEY entity (DO SOMETHING FOR $)
    # [[imperative_mood_sentences.append({"alert": token.lemma_, "text": sentence.text})
    #   for token in sentence
    #   if sentence.text not in detected_sentences and
    #   (token.is_sent_start or token.dep_ == 'appos') and
    #   token.pos_ == 'VERB' and
    #   token.lemma_ in trigger_lemmas and
    #   # detect NER == MONEY (recommendations with a price in it)
    #   (sum([ent.label_.count('MONEY') for ent in sentence.ents]) or
    #    sum([sentence.text.count(kt) for kt in key_tokens]))]
    #  for sentence in doc.sents]

    # extend alert_list to include imperative mood sentences
    alert_list.extend(imperative_mood_sentences) if len(
        imperative_mood_sentences) else None

    return alert_list


def auto_tagger_get_company_name(symbol):
    """
    Given a symbol, from the extracted list, and the table (expected exchange mapping), return company names.
    :param symbol_name:
    :param table_name:
    :param allowed_exchange_list:
    :return:
    """
    exchange_query = dynamo_accessor._query_table(TABLE_SYMBOL_EXCHANGE_MAP,
                                                  'symbol', symbol)
    found_companies = None
    for x in exchange_query:
        if allowed_exchange_list:
            if x['exchange'] in allowed_exchange_list:
                found_companies = x['entity_name']
        else:
            found_companies = x['entity_name']

    return found_companies


def auto_tagger(article):
    try:
        final_res_list = []  # list to contain eventual processed results
        # sample list \/
        # self.my_list = ['a', 'b', 'aa', 'b', 'ca']

        my_list = article["extracted_symbols"]
        doc = article["contentText"]
        valid_flag = True

        # unique elements
        unique_list = set(my_list)
        # map of symbol frequency (symbol: N)
        res_list = [{x: my_list.count(x)} for x in my_list]
        # map of unique symbols frequency
        temp = [[{x: y.get(x)} for y in res_list if y.get(x) is not None][0]
                for x in unique_list]

        for d in temp:
            for key, value in d.items():
                if auto_tagger_get_company_name(symbol=key):
                    comp_name = auto_tagger_get_company_name(symbol=key)
                    logger.info("Valid Symbol: " + key)
                    final_res_list.append(
                        {"symbol": key, "entity_name": comp_name,
                         "count": value})
                else:
                    valid_flag = False
                    logger.info("Invalid Symbol Found: {}".format(key))

        # implement method to query DD for entity_name (SBT_SYMBOL_EXCHANGE_MAPPING table)
        # Template for the final result:
        # [{"symbol": "AAPL", "entity_name": "Apple Inc.", "count": 10}, ..., N]

        # call rules method
        # self._rules_set()

        # text output formatting

        # placeholder1 = [
        #   {'symbol': (y['symbol'], doc.count(y['symbol'])),
        #    'entity_name': (y['entity_name'], [doc.count(x) + doc.count(' ' + str(y['symbol']) + ' ') + doc.count(' ' + str(y['symbol']) + ')') for x in set(y['entity_name'].translate(y['entity_name'].maketrans("", "", string.punctuation.replace('&', '').replace('-', ''))).split()).difference(extra_ignored) if len(x) > 1 and x not in extra_ignored])}
        #  for y in final_res_list]

        placeholder1 = [{'symbol': (y['symbol'], doc.count(y['symbol'])),
                         'entity_name': (y['entity_name'], [
                             doc.count(x) + doc.count(
                                 ' ' + str(y['symbol']) + ' ') + doc.count(
                                 ' ' + str(y['symbol']) + ')') for x in
                             set(re.split("[.\\,\\ \\-]",
                                          y['entity_name'])).difference(
                                 extra_ignored) if
                             len(x) > 1 and x not in extra_ignored])}
                        for y in final_res_list]

        logger.info("Placeholder1: {}".format(placeholder1))

        tempoCheckList = []
        rankerList = []

        # # with deliverable:
        # print('\nTitle: \"', doc_type['title'], "\"     WordpressId(", doc_type['wordpressId'], ")", file=deliverable)
        # for dict in doc_type['symbols']:
        #     if dict["top_recommended"] == True:
        #         print("[", dict["symbol"], " is top recommended for this article]", file=deliverable)
        #         if not self._get_company_name(symbol_name=dict['symbol'], table_name=table, allowed_exchange_list=exchange):
        #             print("!!!!   The recommended symbol is not valid   !!!!! ", dict['symbol'], file=deliverable)

        for a in placeholder1:
            tempoCheck = (
            sum(a['entity_name'][1]), str(a['symbol'][0]), a['entity_name'][0])
            logger.info([str(sum(a['entity_name'][1])).ljust(5),
                         str(a['symbol'][0]).ljust(5), a['entity_name'][0]])
            tempoCheckList.append(tempoCheck)
            rankerList.append(tempoCheck)

        tempoCheckList.sort(
            reverse=True)  # THIS MESSES THE DELIVERABLE UP, use ranker
        rankerList.sort(reverse=False)

        # for item in tempoCheckList:
        #     print(str(item[0]).ljust(5), item[1].ljust(5), item[2], file=deliverable)
        #     # print(a['entity_name'])
        #     # print('\n')

        logger.info(auto_tagger_ranker(list_l=rankerList, dictionary_d={},
                                       count=len(final_res_list) - 1,
                                       tagged=0))
        new_field_dict_placeholder = auto_tagger_ranker(list_l=rankerList,
                                                        dictionary_d={},
                                                        count=len(
                                                            final_res_list) - 1,
                                                        tagged=0)
        # for dict in new_field_dict_placeholder:
        #     for symbol in dict:
        #         [{'symbol': (dict)[1]}]

        # doc_type.update(how_about_something_new=self.ranker(list_l=rankerList,dictionary_d={},count=len(final_res_list)-1, tagged=0))
        auto_tags = [
            {'symbol': x[1],
             'top_recommended': 'True' if new_field_dict_placeholder[
                                              x] == 'Recommended' else 'False',
             'analysis': 'analyzed' if new_field_dict_placeholder[
                                           x] == 'Analyzed' else 'unknown',
             'best_buy': False,
             'closed': False,
             'initiated': False
             } for x in new_field_dict_placeholder
        ]

        # return final_res_list
        # return temp
        # [{'symbol': (y['symbol'], doc.count(y['symbol'])), 'entity_name': (y['entity_name'], [doc.count(x) for x in y['entity_name'].split()])} for y in final_res_list]
    except Exception as e:
        logger.error("An error occurred: {}".format(e))
        auto_tags = []

    logger.info("auto-tags: {}".format(auto_tags))
    return auto_tags


def auto_tagger_ranker(list_l=None, dictionary_d=None, count=None, tagged=None,
                       analyzed=int()):
    if count == -1 or not len(list_l):
        return dictionary_d
    else:
        if list_l[count][0] >= .5 * list_l[-1][0] and list_l[count][0] > 10:
            dictionary_d[list_l[count]] = 'Recommended'
        elif list_l[count][0] != 0 and tagged < 4 and analyzed < 2 and \
                list_l[count][0] > 10:
            dictionary_d[list_l[count]] = 'Analyzed'
            analyzed += 1

    return auto_tagger_ranker(list_l, dictionary_d, count - 1, tagged + 1,
                              analyzed)


def add_default_publication_slug(article):
    article['defaultPublication'].update(slug='-'.join(
        [str(v) for k, v in article['defaultPublication'].items()])) \
        if 'defaultPublication' in article else None


def add_buy_and_sell(article, pubcode=None):
    # process it if publicationCode is not in the list of excluded publicationCode
    if pubcode is not None and pubcode not in BUYSELL_PUBCODES_TO_SKIP and "contentText" in article:
        article["buy_and_sell_alerts"] = search_for_buy_and_sell_alerts(
            article["contentText"])
    else:
        article["buy_and_sell_alerts"] = []


def add_tags(article, pubcode=None):
    # process it if publicationCode is not in the list of excluded publicationCode
    if pubcode is not None and pubcode not in AUTO_TAGGER_PUBCODES_TO_SKIP and "contentText" in article:
        article["auto_tags"] = auto_tagger(article)
    else:
        article["auto_tags"] = []
    logger.info("AUTO-TAGGING FINISHED.")


def check_attribute_types(article):
    # this part fixes the problem of booleans being assigned with 0 or 1
    article.update(extraFeature=False if article[
                                             'extraFeature'] == 0 else True) if 'extraFeature' in article else None

    article.update(pdfOnly=False if article[
                                        'pdfOnly'] == 0 else True) if 'pdfOnly' in article else None

    article.update(public=False if article[
                                       'public'] == 0 else True) if 'public' in article else None

    [y.update(best_buy=False if y['best_buy'] == 0 else True) for y in
     article['symbols'] if 'best_buy' in y] \
        if 'symbols' in article else None
    [y.update(top_recommended=False if y['top_recommended'] == 0 else True) for
     y in article['symbols'] \
     if 'top_recommended' in y] if 'symbols' in article else None

    article.update(defaultPublication={"level": -1, "publicationCode": ""}) \
        if 'defaultPublication' in article and isinstance(
        article['defaultPublication'], bool) else None

    article.update(tickers=[v for k, v in article['tickers'].items()]) \
        if 'tickers' in article and isinstance(article['tickers'],
                                               dict) else None

    (article.update(
        thumbnails=[{k: v} for k, v in article['thumbnails'].items()])
     if isinstance(article['thumbnails'], dict) else article.update(
        thumbnails={})) \
        if 'thumbnails' in article else None


def parse_content_text_for_descriptions(article):
    # the pattern contains a lot of optional flags as the state of the content
    # is in flux
    key_strings = ["Statistics", "Original Recommendation"]
    if all(key_string in article['contentText'] for key_string in key_strings):
        pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)\W{0,2}Statistics(?:.*)\W{0,2}Original Recommendation\W{0,4}(?:\d+;){0,1}(?P<url>.*\d{1,6}(?:#\w+)?)"
    elif "Original Recommendation" in article['contentText']:
        pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)\W{0,2}Original Recommendation\W{0,4}(?:\d+;){0,1}(?P<url>.*\d{1,6}(?:#\w+)?)"
    elif "\r\nStatistics" in article['contentText']:
        pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)\W{0,}Statistics"
    else:
        pattern = r"(?P<profile_type>(?:Company|Fund) (?:Profile|Description|Details))\W{0,2}(?P<short_desc>.*)\W{0,2}(?P<action>Why We're (?:Shorting|Buying))\W{0,2}(?P<long_desc>.*)"

    compiled_pattern = re.compile(pattern)
    match = re.search(pattern, article['contentText'], re.DOTALL)
    logging.info(
        'Generating company descriptions for article with wordpressId:' +
        str(article['wordpressId']))
    try:
        article['profile_type'] = match.group("profile_type")
        article['short_description'] = match.group("short_desc")
        article['stansberry_action'] = match.group("action")
        article['long_description'] = match.group("long_desc")
        if "url" in compiled_pattern.groupindex:
            article['original_recommendation_url'] = match.group("url") if \
                match.group("url") else ""
    except (IndexError, AttributeError):
        logging.exception(" NOTE: contentText format does not comply with Stansberry's company description"
                          "(wordpressID " + str(article['wordpressId']) + ").")


def parse_content_for_financial_data(article):
    soup = bs4.BeautifulSoup(article['content'], "html.parser")
    tables = soup("table")
    if tables:
        article['snapshot'] = str(tables[0])
        article['statistics'] = str(tables[1:])
        links = soup("a")
        if links:
            for link in links:
                if link.img:
                    article['chart'] = str(link)
                    return


def process_article(article):
    try:
        logger.info("Processing article {}".format(article[ES_DYNAMO_PK]))

        # check for any issues with data type of some attributes
        check_attribute_types(article)

        # get publication code
        pubcode = article['defaultPublication']['publicationCode'] \
            if ('defaultPublication' in article and 'publicationCode' in article[
            'defaultPublication']) else None

        # Do processing
        if 'content' in article:
            soup = BeautifulSoup(article["content"], "html")
            htags = ["h1", "h2", "h3", "h4", "h5", "h6"]
            article["extracted_paragraphs"] = get_tags_list(soup, "p")
            article["extracted_headerTags"] = get_tags_list(soup, htags)
            article["extracted_boldTags"] = get_tags_list(soup, "b")

        if 'contentText' in article:
            article["extracted_symbols"] = get_symbols_list(article["contentText"])
            add_default_publication_slug(article)
            # exclude selected publications from these processes
            add_buy_and_sell(article, pubcode=pubcode)
            add_tags(article, pubcode=pubcode)
            # create the description for the company-overview articles
            parse_content_text_for_descriptions(article)
            # create snapshot and statistics whenever available
            parse_content_for_financial_data(article)

        logger.info("Processing of article {} done.".format(article[ES_DYNAMO_PK]))

        # # Create index if missing
        # for env in ES_CLUSTER_ENVS:
        #     if not es_client[env].indices.exists(ES_INDEX):
        #         logging.info("Create missing index: " + ES_INDEX)
        #         es_client.indices.delete_alias(index=ES_INDEX, index_alias=ES_INDEX_ALIAS)
        #         es_client.indices.put_alias(index=ES_INDEX, name=ES_INDEX_ALIAS)
        #         # es.indices.create(table, body=get_index_settings())
        #         es_client[env].indices.create(ES_INDEX, body=MAPPING)
        #         logging.info("Index created: " + ES_INDEX)

        # indexing processed doc into Elasticsearch
        [es_client[env].index(
            index=ES_INDEX,
            doc_type=ES_DOCTYPE,
            body=article,
            id=article[ES_DYNAMO_PK],
            refresh=True
        ) for env in (datasync_env_list if run_datasync else ES_CLUSTER_ENVS)]
    except Exception as error_message:
        logger.error("""
        PROCESSING OF ARTICLE FAILED; wordpressID: {}, error message: {}
        """.format(article[ES_DYNAMO_PK], error_message))


def save_bare_article(article):
    logger.critical(" SAVE_BARE_ARTICLE: Saving article {}".format(
        article[ES_DYNAMO_PK])
    )

    [es_client[env].index(
        index=ES_INDEX,
        doc_type=ES_DOCTYPE,
        body=article,
        id=article[ES_DYNAMO_PK],
        refresh=True
    ) for env in (datasync_env_list if run_datasync else ES_CLUSTER_ENVS)]

    logger.critical(" SAVE_BARE_ARTICLE: Article {} saved".format(
        article[ES_DYNAMO_PK])
    )

def remove_document(doc_id):
    logger.info("REMOVING article ID={}.".format(doc_id))
    [es_client[env].delete(
        index=ES_INDEX,
        doc_type=ES_DOCTYPE,
        id=doc_id,
        refresh=True
    ) for env in ES_CLUSTER_ENVS]
    logger.info("doc_id={} DELETED.".format(doc_id))


def scan_table(condition=None):
    logger.info("In scan_table")
    min_time = datetime.timestamp(datetime.now() - timedelta(days=3))
    conditions = Attr("createdAt").gt(
        decimal.Decimal(min_time * 1000)) if not condition else condition
    results = dynamo_accessor._scan_table(DYNAMO_TABLE_NAME, conditions)
    for article in results:
        logger.info("Now processing {}...".format(article[ES_DYNAMO_PK]))
        process_article(article)
    logger.info("Table scanning done.")


def setup_streams():
    logger.info(" SETUP_STREAMS: Stream iterator expired, resetting streams...")
    response = streams_client.list_streams(TableName=DYNAMO_TABLE_NAME)

    streams.clear()
    for stream in response["Streams"]:
        stream_desc = streams_client.describe_stream(
            StreamArn=stream["StreamArn"])
        stream["iterators"] = []

        for shard in stream_desc["StreamDescription"]["Shards"]:
            shard_iterator = streams_client.get_shard_iterator(
                StreamArn=stream["StreamArn"],
                ShardId=shard["ShardId"],
                ShardIteratorType="LATEST",
            )

            stream["iterators"].append(shard_iterator["ShardIterator"])

        streams.append(stream)
    logger.info(" SETUP_STREAMS: Resetting streams done.")


def read_streams():
    # logger.info(" READ_STREAMS: Reading stream(s)...")
    records = []

    for stream in streams:
        new_iterators = []

        for iterator in stream["iterators"]:
            try:
                response = streams_client.get_records(ShardIterator=iterator)
                records.extend(response["Records"])

                new_iterators.append(
                    response.get("NextShardIterator", iterator))

            except streams_client.exceptions.ExpiredIteratorException as eie:
                logger.exception(" READ_STREAMS: ExpiredIteratorException occurred: {}".format(eie))
                setup_streams()
                return

            except streams_client.exceptions.TrimmedDataAccessException as tdae:
                logger.exception(" READ_STREAMS: TrimmedDataAccessException occurred: {}".format(tdae))

            except Exception as general_exception:
                logger.exception(" READ_STREAMS: Something happened with the streams: {}".format(general_exception))

        stream["iterators"] = new_iterators

    if len(records) > 0:
        logger.info(" READ_STREAMS: Processing {} new articles".format(len(records)))

    for record in records:
        logger.info(" READ_STREAMS: record object: {}".format(record))
        if record['eventName'] == "INSERT" or record['eventName'] == "MODIFY":
            # Convert AWS API data to a basic dict
            article = {k: deserializer.deserialize(v) for k, v in
                       record["dynamodb"]["NewImage"].items()}
            save_bare_article(article)
            process_article(article)
        elif record['eventName'] == "REMOVE":
            doc_id = deserializer.deserialize(
                record["dynamodb"]["Keys"][ES_DYNAMO_PK])
            remove_document(doc_id)

    # logger.info(" READ_STREAMS: Reading stream(s) done.")
    return records


if __name__ == "__main__":

    if not LOCAL_TEST:
        # fire up the service
        logger.info("Starting up.")

        # run article processing
        get_es_connection()
        scan_table()
        setup_streams()
        while True:
            try:
                read_streams()
            except Exception as e:
                logger.exception("Error reading stream(s).")

            time.sleep(1)

    else:
        # for local tests only
        import json

        # paste the article to be tested into the following file
        article = json.load(open("./article_template.json", "r"))
        print("Done reading the template.")

        process_article(article)
