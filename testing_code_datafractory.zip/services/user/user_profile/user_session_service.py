import sys
from sbt_common import SbtGlobalCommon, timing
import logging
from user_profile.constants import MAX_USER_SESSION_LIMIT

class UserSessionService:
    def __init__(self, session_key_helper, cache_util):
        self._session_key_helper = session_key_helper
        self._cache_util = cache_util
        self.logger = SbtGlobalCommon.get_logger(logging.DEBUG, type(self).__name__)

    def user_exceeded_active_sessions(self, snaid):
        matched_keys = self.__get_user_active_sessions__(snaid)
        matched_keys_count = len(matched_keys)

        self.logger.info("Session count for user snaid {} : {}".format(snaid, matched_keys_count))

        return matched_keys_count > MAX_USER_SESSION_LIMIT

    def __get_user_active_sessions__(self, snaid):
        key_pattern = self._session_key_helper.get_session_api_key(snaid) + "_*"
        self.logger.info("key pattern for user snaid count: {}".format(key_pattern))
        matched_keys = self._cache_util.get_cache_keys(key_pattern)
        return matched_keys

    def terminate_user_oldest_active_session(self, snaid):
        matched_keys = self.__get_user_active_sessions__(snaid)
        matched_keys_count = len(matched_keys)
        if matched_keys_count > MAX_USER_SESSION_LIMIT:
            oldest_key = None
            oldest_expiration = sys.maxsize
            for k in matched_keys:
                key_expiration = self._cache_util.get_cache_key_ttl(k)
                if key_expiration < oldest_expiration:
                    oldest_key = k
                    oldest_expiration = key_expiration

            self.logger.info("Terminating oldest session for user snaid:{}".format(snaid))
            self._cache_util.delete_cache_data_for_key(oldest_key)
            if matched_keys_count > MAX_USER_SESSION_LIMIT:
                self.terminate_user_oldest_active_session(snaid)

    def session_exists(self, cache_key):
        if cache_key is None:
            return False

        return self._cache_util.session_exists(cache_key)
