from sbt_common import SbtGlobalCommon, timing
import simplejson as json
import logging

CACHE_VALIDITY = 60 * 60 * 12  # SSxMMxHH: seconds until expired


# This class will be used to perform operations on elastic cache. Sole responsibility is to set/delete data from redis.
class UserSessionCacheUtil:
    def __init__(self, elastic_cache_mgr, session_key_helper):
        self._elastic_cache_manager = elastic_cache_mgr
        self._session_key_helper = session_key_helper
        self.logger = SbtGlobalCommon.get_logger(logging.DEBUG, type(self).__name__)

    @timing
    def clear_entitlements_and_profiles(self):
        self._delete_all_cached_entitlements()
        self._delete_all_cached_profiles()
        self.logger.info("Finished deleting old Entitlements and Profiles")

    @timing
    def get_cached_user(self, cache_key):
        user = None

        if not cache_key:
            return user

        user_session_key = self._session_key_helper.get_session_api_key(cache_key)

        self.logger.info('Get user "' + user_session_key + ' from elastic cache.')
        string_user = self._elastic_cache_manager.get_string_value(user_session_key)
        if string_user:
            self.logger.info('Convert cache value for user ' + user_session_key)
            try:
                user = json.loads(string_user)
            except Exception as e:
                self.logger.error('Encountered exception converting cached user ' +
                                  user_session_key + ' json : ' + str(e))

        return user

    @timing
    def delete_cached_user(self, cache_key):
        if not cache_key:
            return None

        user_session_key = self._session_key_helper.get_session_api_key(cache_key)
        self._elastic_cache_manager.delete_key(user_session_key)
        self.logger.info("User {} has been removed from elastic cache.".format(user_session_key))

    def _delete_all_cached_entitlements(self):
        for key in self._elastic_cache_manager.get_cache_keys(self._session_key_helper.get_base_entitlements_key('*')):
            if isinstance(key, bytes):
                str_key = key.decode('utf-8')
            else:
                str_key = key
            self.logger.info('Deleted Entitlements for ' + str_key)
            self.delete_cache_data_for_key(str_key)

    def _delete_all_cached_profiles(self):
        for key in self._elastic_cache_manager.get_cache_keys(
                self._session_key_helper.get_base_profile_key('*')):
            if isinstance(key, bytes):
                str_key = key.decode('utf-8')
            else:
                str_key = key
            self.logger.info('Deleted Profiles for ' + str_key)
            self.delete_cache_data_for_key(str_key)

    @timing
    def delete_cached_entitlements(self, user_name):
        if not user_name:
            self.logger.error('No user name provided for delete cached entitlements')
            return

        key = self._session_key_helper.get_base_entitlements_key(user_name)
        self.logger.info("Delete entitlements for user {} elastic cache.".format(key))
        self.delete_cache_data_for_key(key)

    @timing
    def session_exists(self, key):
        if key is None:
            return False

        user_session_key = self._session_key_helper.get_session_api_key(key)
        return self._elastic_cache_manager.cache_key_exists(user_session_key)

    @timing
    def delete_cache_data_for_key(self, key):
        if key:
            self._elastic_cache_manager.delete_key(key)
            self.logger.info("Deleted data for key {} from elastic cache".format(key))

    def get_cache_expiration_remaining_seconds(self, key):
        return self._elastic_cache_manager.remaining_seconds(key)

    def update_key_value_store(self, key, value, ex):
        return self._elastic_cache_manager.set_value(key, value, ex=ex)

    def get_cache_keys(self, pattern):
        return self._elastic_cache_manager.get_cache_keys(pattern)

    def get_formatted_cache_key(self, apikey, snaid):
        return "{}_{}".format(snaid, apikey)

    def get_all_cache_keys_for_user_session(self, key_prefix):
        pattern = key_prefix + "_:*"
        keys = self._elastic_cache_manager.get_cache_keys(pattern)
        if len(keys) >= 1:
            return keys[0]
        else:
            return None

    def get_cache_key_ttl(self, key):
        return self._elastic_cache_manager.remaining_seconds(key)
