import simplejson as json

class TemplateHelper:
    @staticmethod
    def read_json_template_file(file_content, file_name, logger):
        if not file_content is None:
            return file_content

        try:
            f = open(file_name, 'r')
            t = f.read()
            f.close()
            return json.loads(t)
        except Exception as e:
            logger.error('Encountered exception ' + str(e) + ' loading template')
