import secrets


class SessionKeyHelper:
    def __init__(self, env):
        self.env = env

    def get_snaid_key(self, snaid):
        return self.__get_key__('.security.session.snaid.', snaid)

    def get_session_api_key(self, session_api_key):
        return self.__get_key__('.security.session.apikey.', session_api_key)

    def get_base_session_key(self, session_key):
        return self.__get_key__('.security.session.', session_key)

    def get_base_entitlements_key(self, username):
        return self.__get_key__('.security.entitlements.', username)

    def get_base_profile_key(self, username):
        return self.__get_key__('.security.profile.', username)

    def __get_key__(self, prefix, key):
        if not key:
            return None

        return self.env + prefix + key

    def generate_session_key(self, snaid=None, api_key=None):
        if api_key is None:
            api_key = secrets.token_hex(16)
        if snaid is None:
            snaid = api_key

        return "{}_{}".format(snaid, api_key)  # python >= 3.6

    def get_unique_key(self):
        return secrets.token_hex(16)

    @staticmethod
    def get_snaid_from_session_key(session_key):
        if session_key is None:
            return

        return session_key.split("_", 2)[0]
