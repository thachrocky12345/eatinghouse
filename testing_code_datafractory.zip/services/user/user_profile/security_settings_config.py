class SecuritySettingsConfig:
    def __init__(self, security_config):
        self._static_entitlements = security_config.get('static_entitlements', {})
        self._use_static_entitlements = security_config.get('use_static_entitlements', False)
        self._use_static_login = security_config.get('use_static_login', False)
        self._test_auth_token_value = security_config.get('test_auth_token_value', None)
        self._free_publications = security_config.get('free_publications', {})
        self._admins = security_config.get('admins', [])
        self._is_iam_present = 'iam' in security_config;
        self._iam = security_config.get('iam')

    def get_use_static_entitlements(self):
        return self._use_static_entitlements

    def get_use_static_login(self):
        return self._use_static_login

    def get_static_entitlements(self):
        return self._static_entitlements

    def get_test_api_key(self):
        return self._test_auth_token_value

    def get_free_publications(self):
        return self._free_publications

    def get_admins(self):
        return self._admins

    def is_iam_present(self):
        return self._is_iam_present

    def get_iam(self):
        return self._iam