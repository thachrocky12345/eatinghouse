import sys
import logging
import logstash
import cherrypy
import bottle
import signal
import service_utils
import os
import traceback
import requests
import datetime
import simplejson as json
from services.util.auth_utils import authenticated, authenticated_profile

from sbt_common import SbtGlobalCommon
from time import sleep
from ecupmanager import ElasticCacheUPManager
from functools import partial
from service_utils import ServiceUtilsGlobal
from up_accessor import LoginException, RegistrationException

# Global Declarations
lname = os.path.splitext(os.path.basename(sys.argv[0]))[0]
logger = SbtGlobalCommon.get_logger(logging.INFO, lname)
app = bottle.Bottle()
usrpm = None
ec_usrpm = None
env = None
cfg = None
use_elastic_cache = True


def get_bottle_app_usrpm():
    return bottle.app.usrpm


def log_error(method, exc):
    if not method or not exc:
        return

    try:
        t = traceback.format_exc()
        s_exc = str(exc)

        if method.strip().lower() == 'authenticate' and \
                'not found' in s_exc.strip().lower():
            t = None

        if t:
            logger.error('Method : ' + method +
                         ' Exception : ' + s_exc + ' Traceback : ' +
                         t)
        else:
            logger.error('Method : ' + method +
                         ' Exception : ' + s_exc)
    except Exception:
        logger.error('Error generating log message')


def validate_ecapikey(req, email):
    """
    Validate the users api key (session)
    :param req: Request containing headers
    :param email: The user to be validated
    :return:
    """
    logger.info('Validating api key for ' + email + ' raddr:' +
                str(req.remote_addr) + ' rroute:' + str(req.remote_route))

    if 'ApiKey' in req.headers:
        reqkey = req.headers['ApiKey']
        um = ElasticCacheUPManager()
        authorized = um.api_key_valid(email, reqkey)
        if not authorized:
            logger.info('ApiKey: ' + reqkey + ' invalid for user ' + email)
    else:
        authorized = False
        logger.info('ApiKey not provided for user ' + email)

    return authorized


def validate_apikey(req, email):
    """
    Validate the users api key (session)
    :param req: Request containing headers
    :param email: The user to be validated
    :return:
    """
    logger.info('Validating api key for ' + email + ' raddr:' +
                str(req.remote_addr) + ' rroute:' + str(req.remote_route))

    if 'ApiKey' in req.headers:
        req_key = req.headers['ApiKey']
        authorized = usrpm.api_key_valid(email, req_key)
        if not authorized:
            logger.info('ApiKey: ' + req_key + ' invalid for user ' + email)
    else:
        authorized = False
        logger.info('ApiKey not provided for user ' + email)

    return authorized


def validate_xapikey(req):
    return ServiceUtilsGlobal.validate_xapikey(req)


###############################################################################
#                              REST API
###############################################################################
@app.hook('before_request')
def strip_path():
    """
    IGNORE TRAILING SLASHES IN BOTTLE ROUTES
    :return:
    """
    service_utils.strip_path()


@app.route("/<:re:.*>", method=['OPTIONS'])
def enable_cors_generic_route():
    """
    Enable Support for CORS headers
    This route takes priority over all others. So any request with an OPTIONS
    method will be handled by this function.

    See: https://github.com/bottlepy/bottle/issues/402

    NOTE: This means we won't 404 any invalid path that is an OPTIONS request.
    """
    service_utils.add_cors_headers()


@app.hook('after_request')
def enable_cors_after_request_hook():
    """
    This executes after every route. We use it to attach CORS headers when
    applicable.
    """
    service_utils.add_cors_headers()


@app.route("/upmanager/make", method="POST")
def make_user_profile():
    """
    Creates an account for the specified user
    :return:
    """
    logger.info('Received make user request')
    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = dict()
    msg = None

    try:
        ureq = bottle.request.json
        if ureq is None:
            logger.debug('JSON Request body not found')
            rval = {'success': False,
                    'error': 'JSON post request body not found'}
        else:
            rval['success'], msg = bottle.app.usrpm.make_user_profile(ureq)
            if rval['success']:
                rval['created'] = msg
    except Exception as e:
        log_error(make_user_profile.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not rval['success']:
        bottle.abort(409, msg)

    return rval


@app.route("/upmanager/create", method="POST")
def create_user_profile():
    """
    Creates an account for the specified user
    :return:
    """
    logger.info('Received create request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = dict()
    err = None

    try:
        ureq = bottle.request.json
        if ureq is None:
            logger.debug('JSON Request body not found')
            rval = {'success': False,
                    'error': 'JSON post request body not found'}
        else:
            api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
            rval['success'], err = bottle.app.usrpm.create_user_profile(ureq, api_key=api_key)

            if rval['success']:
                rval['created'] = ureq['email']
                rval['profile'] = bottle.app.usrpm.get_profile(ureq['email'], api_key=api_key)
    except Exception as e:
        log_error(create_user_profile.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if err:
        bottle.abort(409, err)

    return rval


@app.route("/upmanager/update", method="PUT")
def update_profile():
    """
    Post user profile to profile manager
    :return: success
    """
    logger.info('Received update request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}
    ureq = bottle.request.json
    email = None if ureq and 'email' not in ureq else ureq['email']

    if validate_apikey(bottle.request, email):
        try:
            if ureq is None:
                logger.debug('JSON Request body not found')
                rval = {'success': False,
                        'error': 'JSON post request body not found'}
            else:
                api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
                rval = {'success': bottle.app.usrpm.update_profile(ureq, api_key)}
        except Exception as e:
            log_error(update_profile.__name__, e)
            bottle.abort(400, "encountered exception: " + str(e))

        if not rval['success']:
            bottle.response.status = 400
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return rval


@app.route("/upmanager/pwd/update", method="PUT")
def update_user_pwd():
    """
    Update the specified users password
    :return:
    """
    logger.info('Received update pwd request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}
    ureq = bottle.request.json

    # if validate_apikey(bottle.request, email):
    try:
        if ureq is None:
            logger.debug('JSON Request body not found')
            rval = {'success': False,
                    'error': 'JSON post request body not found'}
        else:
            api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
            ok, msg = bottle.app.usrpm.update_pwd(ureq, api_key)
            rval = {'success': ok}
            if msg:
                rval['message'] = msg
    except Exception as e:
        log_error(update_user_pwd.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not rval['success']: bottle.response.status = 400

    return rval


@app.route("/upmanager/delete", method="DELETE")
def delete_user_profile():
    """
    Delete the specified users profile
    """
    logger.info('Received delete request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}
    ureq = bottle.request.json
    email = None if ureq and 'email' not in ureq else ureq['email']

    try:
        if not ureq or not email:
            raise Exception('Invalid parameters provided for delete profile.')
        elif bottle.app.usrpm.is_admin(None):
            email = ureq['email']
            rval['success'], msg = bottle.app.usrpm.delete_user(email)
            rval['user'] = email
            if not rval['success']:
                rval['error'] = msg
                bottle.response.status = 400
        else:
            bottle.abort(401, 'Unauthorized Access')

    except Exception as e:
        log_error(delete_user_profile.__name__, e)
        bottle.abort(400, "encountered exception: User delete failed.")

    if not rval['success']:
        bottle.response.status = 400

    return rval


@app.route("/upmanager/profile/<email>", method="GET")
@app.route("/upmanager/profile", method="GET")
def get_user_profile(email=None):
    """
    :param email:
    :return:
    """
    logger.info('Received get profile request')

    rval = {}

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    if email and not validate_apikey(bottle.request, email):
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    profile = None

    api_key = bottle.request.headers.get('ApiKey')

    if email:
        profile = bottle.app.usrpm.get_profile(email, api_key=api_key)
    else:
        profile = bottle.app.usrpm.get_profile_by_api_key(api_key, api_key=api_key)

    if profile is not None:
        publications = bottle.app.usrpm.get_entitlements(profile["email"], cache_key=api_key)
        rval = {
            'success': True,
            'profile': profile,
            'entitlements': { 'publication': publications }
        }
    else:
        rval = {'success': False, 'error': 'User profile not found'}

    if not rval['success']:
        bottle.response.status = 400

    return rval


@app.route("/upmanager/data/<email>", method="GET")
def get_user_data(email):
    """
    :param email:
    :return:
    """
    logger.info('Received get data request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
    data = bottle.app.usrpm.get_user_stat(api_key)
    rval = {
        'success': True,
        'data': data
    }
    logger.info('retrieved user data for ' + email)
    return rval


# @app.route("/upmanager/remote/login", method="POST")
# def login_remote():
#     """
#     Login the specified user by remote server request
#     :return:
#     """
#     logger.info('Received remote login request')
#
#     if not validate_xapikey(bottle.request):
#         bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')
#
#     ureq = bottle.request.json
#
#     if 'stats' in ureq and 'email' in ureq:
#         email = ureq['email']
#         stats = ureq['stats']
#         ok = bottle.app.usrpm.set_user_stat(email, stats)
#         msg = 'Remote login success!'
#     else:
#         ok = False
#         msg = 'Remote login failed!'
#
#     rval = {
#         'success': ok,
#         'msg': msg
#     }
#
#     return rval


@app.route("/upmanager/apikey/set", method="POST")
def update_apikey_remote():
    """
    Synch user API key with remote servers
    :return:
    """
    logger.info('Received remote apikey update request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    ureq = bottle.request.json

    if 'apikey' in ureq and 'email' in ureq:
        logger.debug(str(ureq))
        email = ureq['email']
        apikey = ureq['apikey']
        ukey, expires = bottle.app.usrpm.update_apikey(email, apikey,
                                                       True)  # update key
        ok = True if ukey else False
        msg = 'Remote key update success!' if ok else 'Remote key update failed!'
    else:
        ok = False
        msg = 'Remote key update failed!'

    rval = {
        'success': ok,
        'msg': msg
    }

    return rval


@app.route("/upmanager/dashboard/<email>", method="GET")
def get_user_dashboard(email):
    """
    :param email:
    :return:
    """
    logger.info('Received dashboard request')
    rval = {}

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')
    elif validate_apikey(bottle.request, email):
        api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
        profile = bottle.app.usrpm.get_profile(email, api_key=api_key)

        if profile is not None:
            dashboard = profile['dashboard']
            rval = {'success': True, 'dashboard': dashboard}
        else:
            rval = {
                'success': False,
                'error': 'Unable to retrieve profile for user ' + email
            }
            bottle.response.status = 400
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return rval

# Note: Commenting out this method since login_user method is not defined in ElasticCacheUPManager
# @app.route("/upmanager/loginbasic", method="Get")
# def user_profile_login_basic():
#     logger.info('Received user profile login request')
#
#     if not validate_xapikey(bottle.request):
#         bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')
#
#     rval = {}
#     err = None
#
#     try:
#         credentials = bottle.request.headers.get('Authorization')
#
#         if credentials:
#             credentials = credentials.split()[-1]
#             credentials = SbtGlobalCommon.securityutil.base64_to_string(
#                 credentials)
#             credentials = credentials.split(':')
#             email, passwd = SbtGlobalCommon.securityutil.string_to_base64(
#                 credentials[0]), \
#                             SbtGlobalCommon.securityutil.string_to_base64(
#                                 credentials[1])
#
#             if bottle.app.usrpm.login_user(email, passwd, True):
#                 apikey = bottle.app.usrpm.get_apikey(email)
#                 rval = {
#                     'success': True,
#                     'user': 'Authenticated user ' + email,
#                     'apikey': apikey
#                 }
#             else:
#                 err = 'Authentication failed'
#         else:
#             err = 'Authentication failed missing basic login credentials'
#     except Exception as e:
#         log_error(user_profile_login_basic.__name__, e)
#         bottle.abort(400, "encountered exception: " + str(e))
#
#     if err:
#         bottle.abort(404, err)
#
#     return rval


# Commenting this out since login_user method is not found in ElasticCacheUPManager
# def user_profile_login():
#     """
#     Login via pwd/email authentication (deprecated by iam_user_login)
#     :return:
#     """
#     logger.info('Received user profile login request')
#
#     if not validate_xapikey(bottle.request):
#         bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')
#
#     rval = {}
#     err = None
#
#     try:
#         ureq = bottle.request.json
#
#         if ureq is None:
#             logger.debug('JSON Request body not found')
#             rval = {'success': False,
#                     'error': 'JSON post request body not found'}
#         else:
#             email = ureq['email']
#             passwd = ureq['passwd']
#             ok, err = bottle.app.usrpm.login_user(email, passwd, True)
#
#             if ok:
#                 apikey = bottle.app.usrpm.get_apikey(email)
#                 rval = {
#                     'success': True,
#                     'user': 'Authenticated user ' + email,
#                     'apikey': apikey
#                 }
#     except Exception as e:
#         log_error(user_profile_login.__name__, e)
#         bottle.abort(400, "encountered exception: " + str(e))
#
#     if err:
#         bottle.abort(404, err)
#
#     return rval


@app.route("/upmanager/logout", method="POST")
def user_profile_logout():
    """
    :return:
    """
    logger.info('Received user profile logout request: raddr ' +
                str(bottle.request.remote_addr) + ' rroute:' +
                str(bottle.request.remote_route))

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    try:
        ureq = bottle.request.json
        email = None if ureq and 'email' not in ureq else ureq['email']
        if ureq is None:
            logger.warn('JSON Request body not found')
            rval = {'success': False,
                    'error': 'JSON post request body not found'}
        else:
            logger.info('Logging out user: ' + email)
            remote = True if 'remote' in ureq else False
            api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
            if bottle.app.usrpm.logout_user(api_key):
                rval = {'success': True, 'user': 'Logged out user ' + email}
            else:
                rval = {
                    'success': True,
                    'error': 'User ' + email + ' not logged in'
                }
    except Exception as e:
        log_error(user_profile_logout.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))
        if not rval['success']:
            bottle.response.status = 400

    return rval


@app.route("/upmanager/entitlements/<email>", method="GET")
def get_user_entitlements(email):
    """
    Retrieves a users entitlements (deprecated by get_user_iam_subscriptions)
    this method calls an undocumented api rather than iam
    :param email:
    :return:
    """
    logger.info('Received get entitlement request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    if validate_apikey(bottle.request, email):
        try:
            api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
            entitlements = bottle.app.usrpm.get_entitlements(email, cache_key=api_key)
            if entitlements:
                rval = {'success': True, 'entitlements': entitlements}
            else:
                rval = {
                    'success': True,
                    'error': 'User ' + email + ' has no valid subscriptions'
                }
        except Exception as e:
            log_error(get_user_entitlements.__name__, e)
            bottle.abort(400, "encountered exception: " + str(e))
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return rval


@app.route("/upmanager/users/loggedin", method="GET")
def get_loggedin_users():
    """
    :return:
    """
    logger.info('Received get logged in users request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    logger.info('Received get logged in users request')

    try:
        if bottle.app.usrpm.is_admin(None):
            return {"success": True, "users": bottle.app.usrpm.get_logged_in()}
        else:
            bottle.abort(401, 'Unauthorized Access')

    except Exception as e:
        log_error(get_user_activity.__name__, e)
        bottle.abort(400, "encountered exception: List logged in users failed")


@app.route("/upmanager/all", method="GET")
def get_all_users():
    """
    :return:
    """
    logger.info('Received get all users request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    logger.info('Received get all users request')

    try:
        if bottle.app.usrpm.is_admin(None):
            return {"success": True, "users": bottle.app.usrpm.get_all_users()}
        else:
            bottle.abort(401, 'Unauthorized Access')

    except Exception as e:
        log_error(get_user_activity.__name__, e)
        bottle.abort(400, "encountered exception: List all users failed")


@app.route("/upmanager/active/<email>", method="GET")
@app.route("/upmanager/active", method="GET")
def get_user_activity(email=None):
    """
    :return:
    """
    logger.info('Received get activity request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    if email and not validate_apikey(bottle.request, email):
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    rval = {}
    activity = None

    api_key = bottle.request.headers.get('ApiKey')
    activity = bottle.app.usrpm.get_activity_by_api_key(api_key)

    if activity:
        rval = {"success": True, "activity": activity}
    else:
        rval = {
            "success": True,
            "error": "Could not get activity for user " + email +
                     ", user is not logged in"
        }

    return rval


@app.route("/upmanager/stat", method="GET")
@authenticated_profile
def get_user_stat(user):
    """
    Retrieves the specified users status
    :return:
    """
    logger.info('Received stat user request ' + user["email"])

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}
    try:
        api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
        stats = bottle.app.usrpm.stat_user(user["email"], api_key)

        if stats:
            rval = {"success": True, "stats": stats}
        else:
            rval = {
                "success": True,
                "error": "Could not update status for user " + user["email"] +
                         ", user is not logged in"
            }
    except Exception as e:
        log_error(get_user_stat.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    return rval


@app.route("/upmanager/tscontext/<email>", method="GET")
def get_tscontext(email):
    """
    Retrieves a users tradestop context tscontext
    :param email: The specified user
    :return:
    """
    logger.info('Received create tscontext request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    if validate_apikey(bottle.request, email):
        try:
            api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
            tscontext = bottle.app.usrpm.get_tscontext(email, api_key)

            if tscontext:
                rval = {"success": True, "ContextKey": tscontext}
            else:
                rval = {
                    "success": True,
                    "error": "Unable to retrieve tscontext for user " + email +
                             ", is not logged in"
                }
        except Exception as e:
            log_error(get_tscontext.__name__, e)
            bottle.abort(400, "encountered exception: " + str(e))
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return rval


@app.route("/upmanager/screeners/get/<email>", method="GET")
@authenticated
def get_user_screeners(email):
    """
    Retrieves the specified users set of screeners
    :param email:
    :return:
    """
    logger.info('Received screener request for user ' + email)

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    if validate_apikey(bottle.request, email):
        api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
        screeners, err = bottle.app.usrpm.get_screeners(email, api_key)
        if not err:
            rval = {"success": True, "screeners": screeners}
        else:
            bottle.abort(400, err)
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return rval


@app.route("/upmanager/screeners/create", method="POST")
def save_user_screener_create():
    """
    Save the specified user screener
    :return:
    """
    logger.info('Received create screener request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    res = {}
    jsn = bottle.request.json

    if validate_apikey(bottle.request, jsn['email']):
        logger.info('Received screener request for CREATING.')
        api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
        res = bottle.app.usrpm.save_screeners(jsn, api_key)
        bottle.response.status = 200 if res["success"] else 400
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return res


@app.route("/upmanager/screeners/update", method="PUT")
def save_user_screener_update():
    """
    Update the specified user screener
    :return:
    """
    logger.info('Received update screener request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    res = {}
    jsn = bottle.request.json

    if validate_apikey(bottle.request, jsn['email']):
        logger.info('Received screener request for UPDATING.')
        api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
        res = bottle.app.usrpm.save_screeners(jsn, api_key)
        bottle.response.status = 200 if res["success"] else 400
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return res


@app.route("/upmanager/screeners/delete/<email>/<list_name>", method="DELETE")
def delete_user_screener(email, list_name):
    """
    Deletes the named screener for the specified user
    :param email:
    :param list_name:
    :return:
    """
    logger.info('Received delete screener request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    res = {}

    if validate_apikey(bottle.request, email):
        logger.info('Received screener request for deleting list {}.'.format(
            list_name))
        api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
        res = bottle.app.usrpm.delete_screener(email, list_name, api_key)
        bottle.response.status = 200 if res["success"] else 400
    else:
        bottle.abort(401, 'Unauthorized: ApiKey Invalid')

    return res


@app.route("/upmanager/rekey/<email>/<key>", method="GET")
@app.route("/upmanager/rekey/<email>", method="GET")
def update_user_apikey(email, key=None):
    """
    Update the specified user apikey
    :param email: Is the specified user
    :param key:
    :return:
    """
    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    res = {}
    api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
    if bottle.app.usrpm.is_logged_in(api_key):
        logger.info("Received rekey request for {} with apikey {}".format(email, api_key))
        key, expires = bottle.app.usrpm.update_apikey(email, api_key)
        res['success'] = True
        res['apikey'] = key
        if expires:
            res['expires'] = expires
        else:
            res['expires'] = get_bottle_app_usrpm().get_expiration(key)
    else:
        res['success'] = False
        res['error'] = 'Error: User ' + email + ' is not loggedin'
        bottle.response.status = 400

    return res


@app.route("/upmanager/log", method="POST")
def log_user_data():
    """
    Log user data to dynamodb
    :return:
    """
    logger.info('Received error logging request.')

    ureq = bottle.request.json
    rval = {}

    try:
        msgs = ureq['messages'] if 'messages' in ureq else None
        if msgs and len(msgs) > 0:
            for m in msgs:
                m['guid'] = str(SbtGlobalCommon.get_uuid())
                entry = {k: v for k, v in m.items() if v and str(v) != ''}
                if len(entry) > 0:
                    logger.debug('Entry: ' + str(entry))
                    bottle.app.usrpm.log_message(entry)
            rval = {'success': True}
    except Exception as e:
        log_error(log_user_data.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    return rval


@app.route("/upmanager/public/session", method="GET")
def public_session():
    """
    Login user via iam authentication
    :return:
    """
    logger.info('Received user profile login request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {"success": False}

    try:
        session = get_bottle_app_usrpm().get_public_session()

        if session:
            rval['success'] = True
            rval.update(session)
        else:
            rval['error'] = "Unable to create session"

    except Exception as e:
        log_error(iam_user_login.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not rval['success']:
        bottle.abort(401, rval['error'])

    return rval


@app.route("/upmanager/activate/<activation_id>", method="GET")
def activate(activation_id):
    """
    Register user
    :return:
    """
    logger.info('Received user activation request for : ' + activation_id)

    rval = {}

    try:
        ip = str(bottle.request.remote_addr)

        if activation_id:
            success = get_bottle_app_usrpm().activate(activation_id, ip)

            if success:
                rval = {'success': success,
                        'message': 'The account associated with ' +
                                   activation_id + ' has been activated'}

    except RegistrationException as re:
        log_error(activate.__name__, re)
        bottle.abort(400, "User activation error : " + str(re))
    except Exception as e:
        log_error(activate.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not rval:
        bottle.abort(400, 'Failed to activate user.')

    return rval


"""
This feature has been disabled per Michael.
The code is being left in place in case we
decide to turn the feature back on.
"""


@app.route("/upmanager/registration", method="POST")
def registration():
    """
    Register user
    :return:
    """
    logger.info('Received user registration request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    try:
        ureq = bottle.request.json
        ip = str(bottle.request.remote_addr)

        if ureq is None:
            logger.debug('JSON Request body not found')
            rval = {'success': False,
                    'error': 'JSON post request body not found'}
        else:
            user_name = ureq['user_name']
            email = ureq['email']
            first_name = ureq['first_name']
            last_name = ureq['last_name']
            passwd = ureq['passwd']
            success = get_bottle_app_usrpm().registration(user_name, email,
                                                          first_name,
                                                          last_name, passwd,
                                                          ip)

            if success:
                rval = {'success': success,
                        'user': 'Registered User ' + user_name}

    except RegistrationException as re:
        log_error(registration.__name__, re)
        bottle.abort(400, "User registration error : " + str(re))
    except Exception as e:
        log_error(registration.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not rval:
        bottle.abort(400, 'Failed to register user.')

    return rval


@app.route("/upmanager/authenticate", method="POST")
def authenticate():
    """
    Login user via iam authentication
    :return:
    """
    logger.info('Received user authentication request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    try:
        ureq = bottle.request.json
        ip = str(bottle.request.remote_addr)

        if ureq is None:
            logger.debug('JSON Request body not found')
            rval = {'success': False,
                    'error': 'JSON post request body not found'}
        else:
            email = ureq['email']
            passwd = ureq['passwd']
            api_key = get_api_key_from_request()
            session = get_bottle_app_usrpm().authenticate(email, passwd, ip, api_key)
            if session:
                rval = dict(session)
                rval['user'] = 'Authenticated user ' + email
                rval['stats'] = bottle.app.usrpm.stat_user(email, session['apikey'])
                rval['success'] = True
    except LoginException as le:
        log_error(authenticate.__name__, le)
    except Exception as e:
        log_error(authenticate.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not rval:
        rval = {'success': False,
                'error': 'Incorrect username or password. Please try again.'}

    return rval


def get_api_key_from_request():
    return bottle.request.headers['apikey'] if 'apikey' in bottle.request.headers else None


@app.route("/upmanager/login", method="POST")
def iam_user_login():
    """
    Login user via iam authentication
    :return:
    """
    logger.info("Received user profile login request")

    if not validate_xapikey(bottle.request):
        bottle.abort(401, "Unauthorized: X-Api-Key Invalid")

    rval = {}
    ok = False
    msg = None

    try:
        ureq = bottle.request.json

        if ureq is None:
            logger.debug('JSON Request body not found')
            rval = {"success": False,
                    "error": "JSON post request body not found"}
        else:
            email = ureq['email']
            passwd = ureq['passwd']
            ok, msg, api_key = get_bottle_app_usrpm().login_iam_user(email, passwd)

            if ok:
                expires = get_bottle_app_usrpm().get_expiration(api_key)
                rval = {
                    "success": True,
                    "user": "Authenticated user " + email,
                    "apikey": api_key,
                    "expires": expires,
                    "snaid": msg
                }
    except Exception as e:
        log_error(iam_user_login.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not ok and 'http' in msg:
        bottle.abort(307, msg)
    elif not ok:
        bottle.abort(401, msg)

    return rval

@app.route("/upmanager/session_status")
def get_session_status():
    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
    if api_key is None:
        bottle.abort(401, "Unauthorized: ApiKey is Invalid")

    expiration = bottle.app.usrpm.get_expiration(api_key)
    status = False
    if expiration is not None and expiration > 0:
        status = True

    return { "success": True, "active": status, "expires": expiration  }

@app.route("/upmanager/subscriptions/<email>", method="GET")
def get_user_iam_subscriptions(email):
    """
    :param email:
    :return:
    """
    logger.info('Received get subscription request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    if validate_apikey(bottle.request, email):
        try:
            api_key = ServiceUtilsGlobal.get_api_key(bottle.request)
            subs = bottle.app.usrpm.get_iam_subscriptions(email, api_key)
            if subs:
                rval = {"success": True, "subscriptions": subs}
            else:
                rval = {
                    "success": True,
                    "error": "User " + email + " has no valid subscriptions"
                }
        except Exception as e:
            log_error(get_user_iam_subscriptions.__name__, e)
            bottle.abort(400, "encountered exception: " + str(e))
    else:
        bottle.abort(401, "Unauthorized: ApiKey Invalid")

    return rval


@app.route("/upmanager/request/reset/<email>", method="GET")
def request_pwd_reset(email):
    """
    Update the specified users password
    :return:
    """
    logger.info("Received password reset request")

    rval = {}

    try:
        ok, msg = bottle.app.usrpm.request_iam_reset(email)
        if ok:
            rval = {"success": True, "message": msg}
        else:
            rval = {
                "success": True,
                "error": msg
            }
    except Exception as e:
        log_error(request_pwd_reset.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    return rval


@app.route("/upmanager/validate/reset", method="POST")
def validate_pwd_reset():
    """
    Validate the users password reset token
    :return:
    """
    logger.info("Received update pwd request")

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}
    ureq = bottle.request.json

    try:
        if ureq is None:
            logger.debug("JSON Request body not found")
            rval = {"success": False,
                    "error": "JSON post request body not found"}
        else:
            ok, msg = bottle.app.usrpm.validate_iam_reset(ureq)
            rval = {"success": ok}
            if msg:
                rval['message'] = msg
    except Exception as e:
        log_error(validate_pwd_reset.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))

    if not rval["success"]:
        bottle.response.status = 400

    return rval


@app.route("/upmanager/portfolio/deposit/", method="POST")
@app.route("/upmanager/portfolio/deposit", method="POST")
@authenticated_profile
def deposit_token(user):
    logger.info("Starting token deposit process")

    try:

        json_obj = json.loads(json.dumps(bottle.request.json))

        if json_obj["code"]:
            api_url = "https://api.tdameritrade.com/v1/oauth2/token"
            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            data = bottle.urlencode({
                "grant_type": "authorization_code",
                "access_type": "offline",
                "code": json_obj["code"],
                "client_id": "PORTFOLIOMGN2@AMER.OAUTHAP",
                "redirect_uri": "https://" + json_obj[
                    "env"] + '/portfoliomanager'
            })

            logger.info("The data obj for request " + data)

            auth_reply = requests.post(api_url, headers=headers, data=data)
            logger.info("Response from TD Ameritrade: " + auth_reply.text)

            if auth_reply.status_code == 200:
                if bottle.app.usrpm.td_create_access_token_entry(
                        json.loads(json.dumps(auth_reply.text)),
                        user.get("guid")):
                    return {"success": True}
                else:
                    raise Exception(
                        "was not able to retrieve access token from TD Ameritrade")
            else:
                raise Exception("Td Ameritrade response -- code : " + str(
                    auth_reply.status_code)
                                + ", text: " + auth_reply.text.replace('\n',
                                                                       ''))
    except Exception as e:
        log_error(deposit_token.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))
    return {'success': False}


@app.route("/upmanager/portfolio/reset/", method="POST")
@app.route("/upmanager/portfolio/reset", method="POST")
@authenticated_profile
def reset_token(user):
    logger.info("Starting token reset process for " + user.get('guid'))

    try:
        res = bottle.app.usrpm.check_for_token(user.get('guid'))[0]

        if res['reset_token'] and user.get('guid'):
            api_url = 'https://api.tdameritrade.com/v1/' + 'oauth2/token'
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            data = bottle.urlencode({
                'grant_type': 'refresh_token',
                'refresh_token': res['reset_token'],
                'client_id': 'PORTFOLIOMGN2@AMER.OAUTHAP'
            })

            logger.info("The data obj for request " + data)

            auth_reply = requests.post(api_url, headers=headers, data=data)
            logger.info("Response from TD Ameritrade: " + auth_reply.text)

            if auth_reply.status_code == 200:
                if bottle.app.usrpm.td_update_access_token_entry(
                        json.loads(json.dumps(auth_reply.text)),
                        user.get('guid'), res['reset_token']):
                    return {'success': True}
                else:
                    raise Exception(
                        "was not able to retrieve access token from TD Ameritrade")
            else:
                raise Exception("Td Ameritrade response -- code : " + str(
                    auth_reply.status_code)
                                + ", text: " + auth_reply.text.replace('\n',
                                                                       ''))
    except Exception as e:
        log_error(reset_token.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))
    return {'success': False}


@app.route("/upmanager/portfolio/check/", method="GET")
@app.route("/upmanager/portfolio/check", method="GET")
@authenticated_profile
def check_for_token_by_id(user):
    logger.info("Checking that token exists for " + user.get('guid'))

    rslt = ''

    try:
        rslt = bottle.app.usrpm.check_for_token(user.get('guid'))
        logger.info("Checking that token exists return {}".format(rslt))
        if rslt:
            return {'success': True, 'result': rslt}
        else:
            return {'success': False}
    except Exception as e:
        log_error(check_for_token_by_id.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))
    return {'success': False, 'error': 'Bad request for TD token'}


@app.route("/upmanager/portfolio/accounts/", method="GET")
@app.route("/upmanager/portfolio/accounts", method="GET")
@authenticated_profile
def retrieve_accounts_from_td(user):
    logger.info(
        "Retrieve accounts for user from TD API for " + user.get('guid'))

    try:
        res = bottle.app.usrpm.check_for_token(user.get('guid'))[0]

        if res["token"]:
            api_url = 'https://api.tdameritrade.com/v1/'
            path_positions = 'accounts?fields=positions%2Corders'
            headers = {'Content-Type': 'application/x-www-form-urlencoded',
                       'Accept': 'application/json',
                       'Authorization': 'Bearer ' + res["token"]}

            reply = requests.get(api_url + path_positions, headers=headers)

            if reply.status_code == 200:

                accounts = json.loads(reply.text)

                account_details = {
                    'id': accounts[0]['securitiesAccount']['accountId'],
                    'totalCash':
                        accounts[0]['securitiesAccount']['initialBalances'][
                            'totalCash']
                }

                positions = []

                for x in accounts[0]['securitiesAccount']['positions']:
                    pos = {}
                    pos['symbol'] = x['instrument']['symbol']
                    pos['num_shares'] = x['longQuantity']
                    pos['entry_price'] = x['averagePrice']
                    pos['current_price'] = x['marketValue']
                    pos['type'] = x['instrument']['assetType']
                    pos['value'] = pos['current_price'] * pos['num_shares']

                    path_transactions = 'accounts/' + \
                                        accounts[0]['securitiesAccount'][
                                            'accountId'] \
                                        + '/transactions?' + 'type=TRADE&symbol=' + \
                                        pos['symbol']

                    reply = requests.get(api_url + path_transactions,
                                         headers=headers)
                    transactions = json.loads(reply.text)

                    if reply.status_code == 200 and len(transactions) > 0:
                        pos['entry_date'] = \
                            str(transactions[0]['orderDate']).split('T')[0]
                        pos['commission'] = transactions[0]['fees'][
                            'commission']
                    else:
                        log_error(retrieve_accounts_from_td.__name__,
                                  'TD returned not 200 status for transaction history.')
                        now = datetime.datetime.now()
                        pos['entry_date'] = now.strftime("%Y-%m-%d")
                        pos['commission'] = 0.00

                    positions.append(pos)

                return {'success': True, 'accountDetails': account_details,
                        'positions': positions}

            else:
                log_error(retrieve_accounts_from_td.__name__,
                          'TD returned not 200 status, so cannot retrieve TD accounts.')
                raise Exception(
                    'Received non 200 status code from TD Amer API')
        else:
            log_error(retrieve_accounts_from_td.__name__,
                      'TD token missing in database, so cannot retrieve TD accounts.')
            raise Exception('Missing TD token')
    except Exception as e:
        log_error(retrieve_accounts_from_td.__name__, e)
        bottle.abort(400, "encountered exception: " + str(e))
    return {'success': False, 'error': 'Bad request for TD token'}


@app.route("/upmanager/listbrandids/<email>", method="GET")
def user_exists_in_brands(email):
    logger.debug('Received user List BrandIDs request')

    if not validate_xapikey(bottle.request):
        bottle.abort(401, 'Unauthorized: X-Api-Key Invalid')

    rval = {}

    try:
        if not email:
            bottle.abort(401, 'Unauthorized: Invalid Request')
        else:
            data, exists = bottle.app.usrpm.request_iam_list_brandids(email)
            rval = {'success': True, 'data': data}
    except Exception as e:
        log_error(user_exists_in_brands.__name__, e)

    return rval


@app.error(500)
def error_500(error):
    """
    :param error:
    :return:
    Standard dictionary returned on 500 error
    """
    service_utils.add_cors_headers()
    return service_utils.json_error(error)


@app.error(409)
def error_409(error):
    """
    :param error:
    :return:
    """
    service_utils.add_cors_headers()
    return service_utils.json_error(error)


@app.error(405)
def error_405(error='Method Not Allowed'):
    """
    :param error:
    :return:
    """
    service_utils.add_cors_headers()
    return service_utils.json_error(error)


@app.error(404)
def error_404(error):
    """
    :param error:
    :return:
    """
    service_utils.add_cors_headers()
    return service_utils.json_error(error)


@app.error(401)
def error_401(error):
    """
    :param error:
    :return:
    """
    service_utils.add_cors_headers()
    return service_utils.json_error(error)


@app.error(400)
def error_400(error):
    """
    :param error:
    :return:
    """
    service_utils.add_cors_headers()
    if error.args[1].startswith('User registration error : '):
        additional_params = {'user_correctable_error': True}
        return service_utils.json_error(error,
                                        additional_params=additional_params)
    else:
        return service_utils.json_error(error)


@app.error(307)
def error_307(error):
    """
    :param error:
    :return:
    """
    service_utils.add_cors_headers()
    return service_utils.json_error(error)


def start(config):
    """
    Configure cherrypy and start service
    :param config: Is the user service configuration
    :return: Configured usrpm instance
    """
    global cfg
    global usrpm
    global use_elastic_cache

    logger.addHandler(
        logstash.TCPLogstashHandler(
            config['logstash']['domain'], config['logstash']['port'],
            version=config['logstash']['version']
        )
    )

    logger.info("log configured\nconfiguring cherrypy...")

    usrpm = ElasticCacheUPManager()
    bottle.app.usrpm = usrpm

    cherrypy.tree.graft(app, config['root_endpoint'])
    cherrypy.server.unsubscribe()
    cherrypy.config.update(config['server'])
    cherrypy.server.subscribe()
    cherrypy.engine.start()

    logger.info("cherrypy configured")

    return usrpm


def main(config):
    """
    Main configures the user profile manager and starts running a server
    :param config: Is the user service configuration for the deployment env
    :return:
    """
    logger.info("main starting up...")
    upm = start(config)

    logger.info("main exit code 0")
    sys.exit(0)


if __name__ == '__main__':
    """
    Configure signal handlers before starting service
    """
    cfg = SbtGlobalCommon.get_sbt_config()
    config = cfg['services']['user']
    if 'security' in cfg:
        config['security'] = {}

        config['security']['test_auth_token_value'] = \
            cfg['security'].get('test_auth_token_value', None)

        config['security']['free_publications'] = \
            cfg['security'].get('free_publications', {})

        config['security']['use_static_entitlements'] = \
            cfg['security'].get('use_static_entitlements', False)

        config['security']['use_static_login'] = \
            cfg['security'].get('use_static_login', False)

        config['security']['static_entitlements'] = \
            cfg['security'].get('static_entitlements', {})

        # Allow for whitelisting of accounts in an environment
        if 'white_list' in cfg['security'] and \
                cfg['security']['white_list']:
            config['white_list'] = cfg['security']['white_list']

        # Allow for admin accounts in an environment
        if 'admins' in cfg['security'] and \
                cfg['security']['admins']:
            config['admins'] = cfg['security']['admins']

        config['security']['use_elastic_cache'] = True
        if 'iam' in cfg['security']:
            config.pop('iam')
            config['iam'] = cfg['security']['iam']

    service = ElasticCacheUPManager.__name__

    signal.signal(signal.SIGTERM,
                  partial(ServiceUtilsGlobal.sig_handler, service))
    signal.signal(signal.SIGHUP,
                  partial(ServiceUtilsGlobal.sig_handler, service))
    signal.signal(signal.SIGINT,
                  partial(ServiceUtilsGlobal.sig_handler, service))

    main(config)
