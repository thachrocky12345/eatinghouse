from sbt_common import SbtGlobalCommon
from ecupmanager import ElasticCacheUPManager
from threading import Lock

class SecurityUtil :
  _up_mananger = None

  @staticmethod
  def get_up_manager ():
    if SecurityUtil._up_mananger :
      return SecurityUtil._up_mananger

    with Lock() :
      SecurityUtil._set_up_manager()

    return SecurityUtil._up_mananger

  @staticmethod
  def _set_up_manager ():
    use_elastic_cache = True

    cfg                = SbtGlobalCommon.get_sbt_config()
    config             = cfg['services']['user']

    if 'security' in cfg:
      config['security'] = {}

      # Allow for whitelisting of accounts in an environment
      if 'white_list' in cfg['security'] and \
      cfg['security']['white_list'] :
        config['white_list'] = cfg['security']['white_list']

      # Allow for admin accounts in an environment
      if 'admins' in cfg['security'] and \
      cfg['security']['admins'] :
        config['admins'] = cfg['security']['admins']

      config['security']['test_auth_token_value'] = \
        cfg['security'].get('test_auth_token_value', None)

      config['security']['free_publications'] = \
        cfg['security'].get('free_publications', {})

      config['security']['use_static_entitlements'] = \
        cfg['security'].get('use_static_entitlements', False)

      config['security']['use_static_login'] = \
        cfg['security'].get('use_static_login', False)

      config['security']['static_entitlements'] = \
        cfg['security'].get('static_entitlements', {})

      if 'iam' in cfg['security']:
        config.pop('iam')
        config['iam'] = cfg['security']['iam']
      else:
        SbtGlobalCommon.logger.error('Elastic Cache Configuration does not contain ' +
                                     'iam configuration, defaulting to UPManager')

    SbtGlobalCommon.logger.info('Set ElasticCacheUPManager')
    SecurityUtil._up_mananger = ElasticCacheUPManager()
