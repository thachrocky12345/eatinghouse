import base64
import os
import logging
import datetime
import dateutil.parser
import secrets
import simplejson as json

from date_util import get_current_timestamp_iso
from sbt_common import SbtGlobalCommon, SingletonServiceManager, timing
from dd_accessor import DynamoAccessor
from up_accessor import UserProfileAccessor
from redis_manager import RedisManager
from up_accessor import LoginException
from user_profile.user_session_cache_util import UserSessionCacheUtil
from user_profile.security_settings_config import SecuritySettingsConfig
from user_profile.session_key_helper import SessionKeyHelper
from user_profile.template_helper import TemplateHelper
from user_profile.user_session_service import UserSessionService

UNREGISTERD_MAX_TOKEN_VALIDITY = 60 * 15 * 1  # SSxMMxHH: seconds until expired
MAX_TOKEN_VALIDITY = 60 * 60 * 8  # SSxMMxHH: seconds until expired
CACHE_VALIDITY = 60 * 60 * 12  # SSxMMxHH: seconds until expired


class ElasticCacheUPManager(object, metaclass=SingletonServiceManager):
    """
    ElasticCacheUPManager
  """
    _configured = False
    _user_profile_service = None

    def __init__(self):
        self.logger = SbtGlobalCommon.get_logger(logging.DEBUG, type(self).__name__)
        self.logger.info("Initializing")
        self.env = dict(os.environ)
        self.xapikey = SbtGlobalCommon.get_api_token_value()
        self.upaccessor = None
        self.dblogger = self.DBLogger()
        self.logtable = ""
        self.dep_env = SbtGlobalCommon.environment
        self._template = None
        self._tempfile = ""
        self._user_session_svc = None

        self.logger.info("Environment:\n" + str(self.env))

        self._configure()
        self.logger.info("Initialized!")

    def _configure(self):
        """
    Configure
    :return:
    """
        self.logger.info("Configuring...")

        config = SbtGlobalCommon.get_sbt_config()

        cfg = config["services"]["user"]
        # use_elastic_cache is environment specific and I need to add it
        # manually to the config.
        cfg["security"] = {}
        cfg["security"]["use_elastic_cache"] = True

        self._security_settings_config = SecuritySettingsConfig(config["security"])

        if self._security_settings_config.is_iam_present():
            self.logger.warn("Replacing IAM configuration")
            cfg.pop("iam")
            cfg["iam"] = self._security_settings_config.get_iam()

        self.upaccessor = UserProfileAccessor(cfg)

        self._elastic_cache_manager = RedisManager()
        if self._elastic_cache_manager:
            self.logger.info("Elastic Manager Initialized")
        env = SbtGlobalCommon.get_sbt_config_env()
        self.logger.info("Environment " + env)

        self._session_key_helper = SessionKeyHelper(env)

        # clear old keys from cache for profiles and entitlements
        self._cache_util = UserSessionCacheUtil(self._elastic_cache_manager, self._session_key_helper)
        self._cache_util.clear_entitlements_and_profiles()

        self._user_session_svc = UserSessionService(self._session_key_helper, self._cache_util)

        self._configured = True
        self.logtable = cfg["logging"]["table"]
        self.port = cfg["server"]["server.socket_port"]

        err = False

        self.logger.info("Host " + str(SbtGlobalCommon.get_host_name()))
        self.logger.info("Logging table " + self.logtable)

        if not self.dblogger.have_table(self.logtable):
            self.logger.info("Creating log table " + self.logtable)
            self.dblogger.create_table(self.logtable, rkey="date", hkey="guid")

        if "template" in cfg:
            self._tempfile = cfg["template"]
        else:
            self._tempfile = "./template.json"

        self._template = TemplateHelper.read_json_template_file(self._template, self._tempfile, self.logger)

        if self._template:
            self.logger.debug("Template: " + json.dumps(self._template))
        else:
            self.logger.error("Failed to retrieve template profile from: " + str(self._tempfile))
            err = True

        self._unregistered_template = None

        if "unregistered_template" in cfg:
            self._unregistered_template_file = cfg["unregistered_template"]
        else:
            self._unregistered_template_file = os.path.join(os.path.dirname(__file__),
                                                            "..",
                                                            "..",
                                                            "config",
                                                            "unregistered_user_template.json")

        self._unregistered_template = TemplateHelper.read_json_template_file(self._unregistered_template,
                                                                             self._unregistered_template_file,
                                                                             self.logger)
        # self._get_unregistered_template(self._unregistered_template_file)

        if self._unregistered_template:
            self.logger.debug("Template: " + json.dumps(self._unregistered_template))
        else:
            self.logger.error("Retrieving template profile from: " +
                              str(self._unregistered_template_file))
            err = True

        if not err:
            self.logger.info("Configured!")

    def get_public_session(self):
        api_key = self._session_key_helper.generate_session_key()

        user, cache_key = self._create_public_session(api_key)

        if "entitlements" in user:
            ents = user["entitlements"]
            ents["ui"] = {}

            user.pop("entitlements", None)

            user["entitlements"] = ents

        self._set_cached_user(cache_key, user, True)

        return user

    def activate(self, activation_id, ip):
        return self.upaccessor.activate(activation_id, ip)

    def registration(self, user_name, email,
                     first_name, last_name, passwd,
                     ip):

        user = {"user_name": user_name,
                "email": email,
                "first_name": first_name,
                "last_name": last_name,
                "passwd": passwd}

        if ip:
            user["ip_address"] = ip

        ret_val = self.upaccessor.free_user_registration(**user)

        return ret_val

    def authenticate(self, user_name, passwd, ip_address, api_key):
        if not user_name or not passwd:
            raise LoginException("User data not provided.")

        user = None
        profile = self.upaccessor.authenticate(user_name, passwd, ip_address, api_key)
        if profile:
            user_snaid = profile["snaid"] if "snaid" in profile else api_key
            cache_key = self._session_key_helper.generate_session_key(user_snaid)
            if not self._user_session_svc.session_exists(cache_key):
                user = dict()
                user["timestamp"] = get_current_timestamp_iso()
                user["snaid"] = profile["snaid"]
                user["profile"] = profile

            actual_user_name = profile.get("user_name",
                                           profile.get("email", None))
            user = self.refresh_user_data(actual_user_name, user, cache_key)

            if self._user_session_svc.user_exceeded_active_sessions(user_snaid):
                self.logger.info("User ( {} ) with cache_key {} is already logged into the system, they are being "
                                 "logged out.".format(user_name, cache_key))
                # Terminate the oldest session
                self._user_session_svc.terminate_user_oldest_active_session(user_snaid)
        else:
            raise LoginException("User (" + user_name + ") not found.")

        return user

    def user_exists(self, email, cache_key):
        """
    Determins whether or not the specified user exists
    :param email:
    :param cache_key:
    :return:
    """
        rval = False

        if email:
            self.logger.info("Check to see if user " + email +
                             " exists")
            rval = self._user_session_svc.session_exists(cache_key) or self.upaccessor.profile_exists(email)

        return rval

    def create_user_profile(self, profile, api_key=None):
        """
    Adds the specified profile to the user profile data store if it does not exists
    :param profile:
    :param api_key:
    :return:
    """
        self.logger.info("Create user profile.")

        created = False
        msg = ""
        snaid = profile["snaid"] if profile is not None and "snaid" in profile else None
        cache_key = self._cache_util.get_formatted_cache_key(api_key, snaid)
        if not profile:
            msg = "Unable to construct empty profile"
        elif "email" not in profile:
            msg = "Field \"email\" required for user creation"
        elif "passwd" not in profile:
            msg = "Field \"passwd\" required for user creation"
        elif self.user_exists(profile["email"], cache_key=cache_key):
            msg = "User " + profile["email"] + " already exists..."
        else:

            created = self.upaccessor.add_profile(profile)

            if not created and self.user_exists(profile["email"], cache_key):
                msg = "Rolling back user " + profile["email"] + " creation..."
                self.delete_user(profile["email"], cache_key)
            elif not created:
                msg = "Failed to create user account for " + profile["email"]

        return created, msg

    def get_profile_by_user_name(self, user_name, user=None, cache_key=None):
        """
    Retrieves a profile for the specified user if it exists
    :param user_name:
    :param user:
    :param cache_key: key  used to store info in the key value store
    :return:
    """
        profile_info = {}

        if not user_name:
            self.logger.error("No user_name provided for get_profile_by_user_name")
            return profile_info

        self.logger.info("Get profile for user " + cache_key)

        if not user:
            user = self._cache_util.get_cached_user(cache_key)

        if user and "profile" in user:
            profile_info = user["profile"]
        elif user_name and user_name != "":
            profile_info = self.upaccessor.get_profile_by_user_name(user_name)

        return profile_info

    def get_profile(self, email, user=None, api_key=None):
        """
    Retrieves a profile for the specified user if it exists
    :param email:
    :param user:
    :param api_key:
    :return:
    """
        rval = None

        if not email:
            self.logger.error("No email provided for get_profile")
            return rval

        self.logger.info("Get profile for user " + email)

        if not user:
            user = self._cache_util.get_cached_user(api_key)

        if user and "profile" in user:
            rval = user["profile"]
        elif email and email != "":
            rval = self.upaccessor.getprofile(email)

        return rval

    # def get_session_profile_by_id(self, uid):
    #     rval = None
    #
    #     if not uid:
    #         self.logger.error("No id provided for get_session_profile_by_id")
    #         return rval
    #
    #     if uid.upper().startswith("SAC"):
    #         rval = self.get_session_profile_by_snaid(id)
    #     else:
    #         rval = self.get_profile_by_api_key(id)
    #         if not rval:
    #             rval = self.get_session_profile_by_email(id)
    #
    #     return rval

    # def get_session_profile_by_email(self, email):
    #     """
    # Retrieves a profile for the specified user if it exists
    # :param email:
    # :return:
    # """
    #     rval = None
    #
    #     if not email:
    #         self.logger.error("No email provided for get_session_profile_by_email")
    #         return rval
    #
    #     user = self._cache_util.get_cached_user(email)
    #
    #     if user:
    #         rval = user.get("profile", {})
    #     else:
    #         self.logger.error("Requested user profile for email " + email +
    #                           " was not found")
    #
    #     return rval

    # def get_session_profile_by_snaid(self, snaid):
    #     """
    # Retrieves a profile for the specified user if it exists
    # :param snaid:
    # :return:
    # """
    #     rval = None
    #
    #     if not snaid:
    #         self.logger.error("No snaid provided for get_session_profile_by_snaid")
    #         return rval
    #
    #     email = self.upaccessor.get_email_by_snaid(snaid)
    #     if email:
    #         rval = self.get_session_profile_by_email(email)
    #     else:
    #         self.logger.error("No email provided for get_session_profile_by_snaid")
    #
    #     return rval

    def get_profile_by_api_key(self, cache_key, user=None):
        """
    Retrieves a profile for the specified user if it exists
    :param cache_key:
    :param user:
    :return:
    """
        rval = None

        if not cache_key:
            self.logger.error("No api key provided for get_profile_by_api_key")
            return rval

        if not user:
            user = self._cache_util.get_cached_user(cache_key)

        if user:
            rval = user.get("profile", {})
        else:
            self.logger.error("Requested user profile for cache key " + cache_key +
                              " was not found")

        return rval

    def get_user_stat(self, api_key):
        """

    :param email:
    :return:
    """
        rval = {}

        if not api_key:
            self.logger.error("No api_key provided for get_user_stat")
            return rval

        self.logger.info("Copy stats for user " + api_key)

        user = self._cache_util.get_cached_user(api_key)

        if user:
            rval = user.copy()
        else:
            self.logger.error("Requested user stats update for user " + api_key +
                              " not logged in")

        return rval

    def set_user_stat(self, email, stats):
        """

    :param email:
    :param stats:
    :return:
    """
        rval = True

        if email and stats:
            self.logger.info("Set stats for user " + email)

            self._set_cached_user(email, stats)
            self.logger.info("Set User stats updated " + " for user " + email + ": " +
                             stats["apikey"])
        else:
            rval = False

        return rval

    def is_logged_in(self, cache_key):
        """
    :param cache_key: The target user
    :return:
    """
        if not cache_key:
            self.logger.error("No email provided for is_logged_in")
            return False

        self.logger.info("Check to see if user " + cache_key + "is logged in.")

        return self._user_session_svc.session_exists(cache_key)

    @timing
    def refreshuserdata(self, email, user=None, api_key=None, refresh_entitlements=False):
        """
        Refresh the local user data with new data
        :param email: The user to update
        :param user: The users profile if provided
        :param api_key: api_key for the session
        :return:
        """
        if not email:
            self.logger.error("No email provided for refreshuserdata")
            return None

        self.logger.info("Refresh data for user " + api_key)

        if not user:
            user = self._cache_util.get_cached_user(api_key)

        if not user:
            self.logger.warn("Refresh user data for " + api_key + " not logged in")
            return user

        update_cache = False

        if "entitlements" not in user or refresh_entitlements:
            update_cache = True
            if refresh_entitlements:
                user.pop("entitlements")
            self._insert_missing_publication_entitlements(user)
            # append the user entitlements
            ents = self.get_entitlements(email, user, api_key)
            if ents:
                user["entitlements"]["publication"].extend(ents)

        if "profile" not in user:
            update_cache = True
            profile = self.get_profile(email, user, api_key)
            if profile:
                if "snaid" not in profile or not profile["snaid"]:
                    profile["snaid"] = user["snaid"]
                user["profile"] = profile
            else:
                user["profile"] = {}
                self.logger.error("Could not find profile for : " + email)

        if "apikey" not in user:
            update_cache = True
            if api_key is None:
                key = self._session_key_helper.generate_session_key(snaid=user["snaid"])
            else:
                key = api_key

            user["apikey"] = key

        if "screeners" not in user:
            update_cache = True
            screeners = self.upaccessor.get_screeners(email)
            user["screeners"] = screeners

        if update_cache:
            self._set_cached_user(api_key, user)

        return user

    @timing
    def refresh_user_data(self, user_name, user=None, cache_key=None):
        """
    Refresh the local user data with new data
    :param user_name: The user to update
    :param user: The users profile if provided
    :param cache_key: key used for retrieving data from key/value store
    :return:
    """
        if not user_name:
            self.logger.error("No user_name provided for refresh_user_data")
            return None

        self.logger.info("Refresh data for user " + user_name)

        if not user:
            user = self._cache_util.get_cached_user(cache_key)

        if not user:
            self.logger.warn("Refresh user data for " + user_name + " not logged in")
            return user

        update_cache = False

        profile = user.get("profile", None)

        if not profile:
            profile = self.get_profile_by_user_name(user_name, user, cache_key)
            if profile:
                update_cache = True
                user["profile"] = profile

        if not profile:
            self.logger.error("Could not find profile for : " + user_name)
        else:
            if not profile.get("snaid", None):
                update_cache = True
                profile["snaid"] = user.get("snaid", "")

        if "entitlements" not in user and profile:
            update_cache = True

            user["entitlements"] = dict(profile.get("entitlements", {}))
            profile.pop("entitlements", None)

            self._insert_missing_publication_entitlements(user)

        if "apikey" not in user:
            update_cache = True
            if cache_key is None:
                cache_key = self._session_key_helper.generate_session_key(snaid=user["snaid"])

            user["apikey"] = cache_key

        if "screeners" not in user:
            update_cache = True
            screeners = self.upaccessor.get_screeners(user_name)
            user["screeners"] = screeners

        if update_cache:
            self._set_cached_user(cache_key, user)

        return user

    def stat_user(self, email, api_key):
        """
    Returns the specified users entry with modified timestamp
    :param email:
    :param api_key:
    :return:
    """
        rval = None

        if not email:
            self.logger.error("No email provided for stat_user")
            return rval

        self.logger.info("Get stats for user " + email)

        user = self._cache_util.get_cached_user(api_key)

        if user:
            self.refreshuserdata(email, user, api_key)

            if user:
                rval = user.copy()
            else:
                self.logger.error("Requested user stats for user " + email + " not logged in")
        else:
            self.logger.warn("Requested user stats for user " + email + " not logged in")

        return rval

    def get_expiration(self, cache_key):
        """
    Retrieves the apikey expiration time
    :param cache_key:
    :return:
    """
        rval = None

        if not cache_key:
            self.logger.error("No email provided for get_expiration")
            return rval

        self.logger.info("Get expiration for user " + cache_key)

        user = self._cache_util.get_cached_user(cache_key)

        if user and "expires" in user:
            rval = user["expires"]
        else:
            self.logger.error("Unable to find user for expiration.")

        return rval

    def auth_iam_user(self, email, passwd, create=True, api_key=None):
        """

    :param email: b64 enc
    :param passwd:  b64 enc
    :param create:  b64 enc
    :param api_key:  b64 enc
    :return:
    """
        self.logger.info("Method : auth_iam_user Message : " +
                         "Authenticating iam user: " + email)

        rval = False
        msg = ""
        snaid_val = ""
        uiam = True  # use iam default
        guid = self.upaccessor.get_user_id(email)  # indicates profile exists
        cache_key = None
        if self._security_settings_config.get_use_static_login() and guid:  # TODO: Polling update required
            self.logger.info("Use SBT Login for " + email)
            creds = self.upaccessor.get_user_creds(guid)
            if creds and creds[0] != "" and creds[1] != "":  # have valid credentials
                rval, msg, snaid = self.upaccessor.authpasswd(email, passwd)
                if rval:
                    uiam = False
                    snaid_val = snaid
                    self.logger.debug("Logged in with local credentials")

        if uiam:
            self.logger.info("Use IAM Login for " + email)
            # self.cache_util.delete_cached_entitlements(email)
            rval, snaid = self.upaccessor.iam_auth(email, passwd)
            if rval and guid and self.upaccessor.update_credentials(guid, passwd):
                self.logger.debug("Local credentials updated")
                snaid_val = snaid

        if not rval:
            msg = "Authentication failed for user: " + email
        else:
            self.logger.info("Login Response " + str(rval) + " " + str(snaid_val))
            cache_key = self._process_login_response(email, snaid_val, passwd, guid, create, api_key)
            msg += " success!"

        self.logger.info("Authentication for user SNAID: " + msg)

        return rval, msg, cache_key

    def get_iam_subscriptions(self, email, api_key):
        """

    :param email:
    :param api_key:
    :return:
    """
        if not email:
            self.logger.error("No email provided for get_iamsubscription")
            return None

        self.logger.info("Retrieving subscriptions for user: " + email)
        user = self._cache_util.get_cached_user(api_key)
        if user and "snaid" in user:
            snaid = user["snaid"]
            return self.upaccessor.get_subscriptions(snaid)
        else:
            self.logger.error("Failed to find subscriptions for user: " + email)
            return None

    def request_iam_reset(self, email):
        """

    :param email:
    :return:
    """
        self.logger.info("Requesting iam reset")

        rval, msg = self.upaccessor.request_reset(email)

        return rval, msg

    def request_iam_list_brandids(self, email):
        self.logger.debug("Requesting iam list brandids")

        rval, exists = self.upaccessor.iam_list_brandIDs(email)

        return rval, exists

    def validate_iam_reset(self, credentials):
        """
    Update user password (deprecated -> IAM)
    :param credentials:
    :return:
    """
        email = None if "email" not in credentials else credentials["email"]
        npwd = None if "npwd" not in credentials else credentials["npwd"]
        tokn = None if "token" not in credentials else credentials["token"]

        if email:
            self.logger.info("Validate IAM reset for user " + email)

        return self.upaccessor.validate_reset(tokn, email, npwd)

    def login_iam_user(self, email, passwd):
        """
    Authenticate user with the specified credentials against data store
    :param email:
    :param passwd:
    :return:
    """
        if not email:
            self.logger.error("No email provided for login_iam_oser")
            return False, "Missing email"

        self.logger.info("Login user " + email)

        # if self.is_logged_in(email):
        #     self.logger.info("User " + email + "already logged in log them out.")
        #     self.logout_user(email)

        api_key = self._session_key_helper.get_unique_key()
        rval, snaid_val, cache_key = self.auth_iam_user(email, passwd, api_key=api_key)
        if rval:
            user = self.refreshuserdata(email, api_key=cache_key)
            if user and "snaid" in user:
                msg = user["snaid"]
            else:
                rval = False
                msg = "Authentication failed for " + email + " unable to pull cached value."
                self.logger.error(msg)
        else:
            msg = "Authentication failed for " + email
            self.logger.error(msg)

        return rval, msg, cache_key

    def get_all_users(self):
        """
    Retrieve the list of all users
    :return:
    """
        self.logger.info("Get all users")

        return self.upaccessor.getusers()

    def update_profile(self, profile, api_key):
        """
    Update a user profile with specified values if user exists
    :param profile:
    :param api_key:
    :return:
    """

        rval = False
        if not profile or "email" not in profile:
            self.logger.error("No valid profile provided for update_profile")
            return rval

        email = profile["email"]

        self.logger.info("Update profile for user " + email)

        user = self._cache_util.get_cached_user(api_key)

        if user and "profile" in user:
            rval = self.upaccessor.update_profile(profile)
            if rval:
                user.pop("profile")
                self.refreshuserdata(email, user, api_key=api_key, refresh_entitlements=True)
            else:
                self.logger.error("Update user profile " + email + " failed ")
        else:
            self.logger.warn("User " + email + " is not logged in")

        return rval

    def delete_user(self, email, cache_key):
        """
    Delete the specified user if it exists
    :param email:
    :param cache_key:
    :return:
    """
        rval = False
        msg = ""

        if not email:
            self.logger.error("No email provided for delete_user")
            return rval, "Missing email"

        self.logger.info("Delete user " + email)

        if self.user_exists(email, cache_key):
            self.logout_user(cache_key)
            rval = self.upaccessor.deleteprofile(email)
        else:
            msg = "User does not exists"

        return rval, msg

    def logout_user(self, cache_key):
        """
    :param cache_key:
    :return:
    """

        if not cache_key:
            self.logger.error("No email provided for logout_user")
            return False

        self._cache_util.delete_cached_user(cache_key)
        self.logger.info("User " + cache_key + " has been logged out")

        return True

    def get_logged_in(self):
        """
    Retrieves the list of logged in users
    :return:
    """
        self.logger.info("Get logged in users.")

        pattern = self._session_key_helper.get_base_session_key("*")

        keys = self._cache_util.get_cache_keys(pattern)

        ret_list = []

        for key in keys:
            ret_list.append(key[len(self._session_key_helper.get_base_session_key("")):])

        return ret_list

    def get_entitlements(self, email, user=None, cache_key=None):
        """
    Retrieves the list of entitlements for the specified user.
    We need to fetch data from cache using api_key and use email to fetch data from the database for the user
    :param email: Is the targe user
    :param user: user info
    :param cache_key: key used to pull data from the key/value store for the current session
    :return: list of dict entitlement attributes
    """
        rval = {}

        if not email:
            self.logger.error("No email provided for get_entitlements")
            return rval

        self.logger.info("Get entitlements for user " + email)

        if not user:
            user = self._cache_util.get_cached_user(cache_key)

        if user:
            rval = self._get_accessor_entitlements(user)
        else:
            self.logger.error("Unable to pull cached entitlements for user " + email)

        return rval

    def get_entitlements_by_api_key(self, api_key, user=None):
        """
    Retrieves the list of entitlements for the specified user
    :param api_key: Is the target api key
    :param user: user info
    :return: list of dict entitlement attributes
    """
        rval = []

        if not api_key:
            self.logger.error("No email provided for get_entitlements")
            return rval

        self.logger.info("Get entitlements for api_key " + api_key)

        cache_key = None
        if self._security_settings_config.get_test_api_key() \
                and api_key == self._security_settings_config.get_test_api_key():
            user, cache_key = self._create_public_session(api_key)
            return user.get("entitlements", [])

        if cache_key is None:
            cache_key = api_key
        email = ""
        if not user:
            user = self._cache_util.get_cached_user(cache_key)

        if user:
            if "profile" in user and "email" in user["profile"]:
                email = user["profile"]["email"]
            rval = user.get("entitlements", [])
            if email and not rval:
                rval = self._get_accessor_entitlements(user)
                if rval:
                    user["entitlements"] = rval
                    self._set_cached_user(cache_key, user)
                    # self.cache_util.set_cached_entitlements(api_key, rval)
        else:
            self.logger.error("Unable to pull cached entitlements for user " + email)

        return rval

    def get_tscontext(self, email, api_key):
        """
    Retrieve the specified users tradestops user context key
    :param email:
    :param api_key:
    :return:
    """
        if not email:
            self.logger.error("No email provided for get_tscontent")
            return None

        self.logger.info("Retrieving tscontext for user " + email)

        user = self._cache_util.get_cached_user(api_key)
        if user:
            if "tscontext" in user:
                rval = user["tscontext"]
            else:
                rval = self.upaccessor.get_tscontext(api_key)
                user["tscontext"] = rval
                self._set_cached_user(api_key, user)
        else:
            rval = None
            self.logger.error("TS Context not retrieved, " + email + " is not logged in")

        return rval

    def get_activity_by_api_key(self, api_key):
        """
    Retrieves the specified users most recent activity time
    :param api_key:
    :return:
    """
        rval = None

        if not api_key:
            self.logger.error("No email provided for get_activity")
            return rval

        self.logger.info("Get activity for user " + api_key)

        user = self._cache_util.get_cached_user(api_key)

        if user:
            rval = user["timestamp"]
        else:
            self.logger.error("Activity time not retrieved, " + api_key +
                              " is not logged in")

        return rval

    def update_apikey(self, email, api_key=None):
        """
    :param email:
    :param api_key:
    :return:
    """
        session_key = None
        expires = None

        if not email:
            self.logger.error("No email provided for update_apikey")
            return session_key

        self.logger.info("Update API key for user " + email)

        user = self._cache_util.get_cached_user(api_key)

        if user:
            snaid = user["snaid"]
            session_key = api_key if api_key else self._session_key_helper.generate_session_key(snaid)
            user["apikey"] = session_key
            user["timestamp"] = get_current_timestamp_iso()
            # below statement deletes old cache key
            self._cache_util.delete_cached_user(api_key)
            if self._is_unregistered_user(user):
                self._cache_util.delete_cached_user(api_key)
                self._cache_util.delete_cached_user(session_key)
                user["snaid"] = session_key
                if "profile" in user:
                    user["profile"]["email"] = session_key
                    user["profile"]["snaid"] = self._session_key_helper.get_snaid_from_session_key(session_key)
                    user["profile"]["user_name"] = session_key
                self._set_cached_user(session_key, user, True)
            else:
                self._set_cached_user(session_key, user, True)
            expires = user.get("expires", None)
            self.logger.info("ApiKey Update: " + str(session_key))
        else:
            self.logger.error("Unable to update api key for : " + email)

        return session_key, expires

    def update_pwd(self, credentials, api_key):
        """
    Update user password (deprecated -> IAM)
    :param credentials:
    :param api_key:
    :return:
    """
        email = None if "email" not in credentials else credentials["email"]
        cpwd = None if "cpwd" not in credentials else base64.b64decode(credentials["cpwd"]).decode("utf-8")
        npwd = None if "npwd" not in credentials else base64.b64decode(credentials["npwd"]).decode("utf-8")

        if not email:
            self.logger.error("No email provided for update_pwd")
            return False, "Missing email"

        self.logger.info("Update password for user " + email)

        if self._user_session_svc.session_exists(api_key):
            if email and cpwd and npwd:
                if cpwd == npwd:
                    rval = False
                    msg = "New password must not be the same as current password"
                    self.logger.info(msg)
                elif len(npwd) < 8:
                    rval = False
                    msg = "Password must contain at least 8 characters"
                    self.logger.info(msg)
                else:
                    rval, msg = self.upaccessor.updatepasswd(email, cpwd, npwd)
            else:
                rval = False
                msg = "Missing one of required values email, cpwd, or npwd"
                self.logger.info(msg)
        else:
            rval = False
            msg = "User " + email + " is not logged in"
            self.logger.info(msg)

        return rval, msg

    def log_message(self, msg):
        """
    :param msg:
    :return:
    """

        if msg:
            self.dblogger.insert_into_table(self.logtable, msg)

    def get_screeners(self, email, api_key):
        """
    Retrieves the set of screeners for the specified user
    :param email:
    :param api_key:
    :return:
    """
        rval = None
        err = None

        if not email:
            self.logger.error("No email provided for get_screeners")
            return None, "Missing email"

        self.logger.info("Retrieving screeners for user " + email)

        user = self._cache_util.get_cached_user(api_key)

        if user:
            if "screeners" in user:
                rval = user["screeners"]
            else:
                rval = self.upaccessor.get_screeners(email)
                user["screeners"] = rval
                self._set_cached_user(api_key, user)
        else:
            err = "Screeners not retrieved " + email + " is not logged in"
            self.logger.error(err)

        return rval, err

    def save_screeners(self, jsn, api_key):
        """
    Save or update a screener for the specified user
    :param jsn:
    :param api_key:
    :return:
    """
        if not json or "email" not in jsn:
            self.logger.error("No email provided for save_screeners")
            return {"success": False, "error": "Missing email"}

        email = jsn["email"]

        self.logger.info("Saving screeners to the database...")

        user = self._cache_util.get_cached_user(api_key)

        if user:
            res = self.upaccessor.save_screener(jsn)
            user.pop("screeners")
            self.refreshuserdata(email, user, api_key)
        else:
            self.logger.error("Failed to save screeners to the database for " + email)
            res = {"success": False, "error": "User " + email + " is not logged in "}

        return res

    def delete_screener(self, email, list_name, api_key):
        """
    Delete a screener for the specified user
    :param email: user"s email
    :param list_name: list name
    :param api_key: apikey of the user
    :return:
    """
        if not email:
            self.logger.error("No email provided for delete_screener")
            return {"success": False, "error": "Missing email"}

        self.logger.info("Deleting list name {} for user {}".format(list_name, email))

        user = self._cache_util.get_cached_user(api_key)

        if user:
            res = self.upaccessor.delete_screener(email, list_name)
            user.pop("screeners", None)
            self.refreshuserdata(email, user, api_key)
        else:
            self.logger.error("Failed to delete screeners to the database for " + email)
            res = {"success": False, "error": "User " + email + " is not logged in "}
        return res

    def td_create_access_token_entry(self, token, email):
        return self.upaccessor.td_create_access_token_entry(token, email)

    def td_update_access_token_entry(self, token, ident, reset_token):
        return self.upaccessor.td_update_access_token_entry(token, ident, reset_token)

    def check_for_token(self, ident):
        return self.upaccessor.check_for_token(ident)

    def api_key_valid(self, email, cache_key):
        """
    Validates the specified API key
    :param email:
    :param cache_key: input key
    :return:
    """
        rval = False

        if not email:
            self.logger.error("No email provided for api_key_valid")
            return rval

        if not cache_key:
            return rval

        if self.is_logged_in(cache_key):
            user = self._cache_util.get_cached_user(cache_key)
            if user and "profile" in user and "email" in user.get("profile"):
                if user["profile"]["email"] != email:
                    self.logger.info("ApiKey for user: " + email + " invalid")
                else:
                    rval = True
                    self.logger.info("ApiKey " + cache_key + " valid for user: " + email)
            else:
                self.logger.error("ApiKey for user: " + email + " not found")
        else:
            self.logger.info("ApiKey for user: " + email + " not logged in, invalid")

        return rval

    def is_admin(self, api_key):
        is_admin = False

        if not api_key:
            return is_admin

        user = self._cache_util.get_cached_user(api_key)

        if user and "profile" in user and "email" in user["profile"] and \
                user["profile"]["email"] in self._security_settings_config.get_admins():
            is_admin = True

        return is_admin

    def _create_public_session(self, api_key):
        session_data = {"name": api_key, "snaid": api_key,
                        "email": api_key}

        profile = self.make_unregistered_profile(session_data)

        user = dict()
        user["timestamp"] = get_current_timestamp_iso()
        user["snaid"] = api_key
        user["apikey"] = api_key
        user["profile"] = profile
        user["screeners"] = []
        user["public_session"] = True

        expire_ts = self._get_calculated_expiration(user)
        user["expires"] = expire_ts

        user = self.refreshuserdata(api_key, user, api_key, refresh_entitlements=False)

        # Clean up some of the default keys
        user["profile"].pop("passwd", "N/A")
        user["profile"]["sungard_pwd"] = ""
        user["profile"]["sungard_group"] = ""

        return user, api_key

    @staticmethod
    def _gen_apikey():
        """
    Generates a user api key (session)
    """
        return secrets.token_hex(16)  # python >= 3.6

    @staticmethod
    def _is_unregistered_user(user):
        return user.get("snaid", "snaid") == \
               user.get("apikey", "apikey")

    @timing
    def _set_cached_user(self, cache_key, user, reset_time=False):
        """
            this method fetches the data from the key/value store using the cache_key.
            cache_key is prefixed with the environment and session info.
            for ex. if cache_key = 90a2b285dd131ba35de5ac5d15484093_90a2b285dd131ba35de5ac5d15484093
            then the key used to store in keyvalue store for local environment
            will be local.security.session.id.90a2b285dd131ba35de5ac5d15484093_90a2b285dd131ba35de5ac5d15484093
            Input cache_key is always just a combination of snaid_16bithex key
        """
        if not cache_key or not user:
            self.logger.error("No user name or user provided for set cached user")
            return

        if "timestamp" not in user:
            user["timestamp"] = get_current_timestamp_iso()
            reset_time = True

        session_cache_key = self._session_key_helper.get_session_api_key(cache_key)

        seconds = self._cache_util.get_cache_expiration_remaining_seconds(session_cache_key)

        if reset_time or seconds < 1:
            expiration_ts = self._get_calculated_expiration(user)
            user["expires"] = expiration_ts
            seconds = round(expiration_ts - datetime.datetime.now().timestamp()) + 1

        self.logger.info("User {} elastic cache (expires in {} seconds)".format(session_cache_key, str(seconds)))

        try:
            user_string = json.dumps(user)

            if cache_key:
                self._cache_util.update_key_value_store(session_cache_key, user_string, ex=seconds)
                self.logger.info("_set_cached_user - storing data for {}".format(cache_key))

        except Exception as e:
            self.logger.error("Unable to set cached value for " + cache_key + " : " +
                              str(e))
            raise

    def _process_login_response(self, email, snaid, passwd, guid, create, api_key):
        cache_key = self._cache_util.get_formatted_cache_key(api_key, snaid)
        if not guid and create:
            # if not self.accessor.profile_exists(email) and create:
            name = self.upaccessor.get_iam_name(snaid)
            self.logger.info("Creating profile for: " + name + ":" + email +
                             ":" + snaid)
            if name and name != "":
                users = [{"name": name, "snaid": snaid,
                          "email": email, "passwd": passwd}]

                self.make_user_profile(users, cache_key)

        if not self._user_session_svc.session_exists(cache_key):
            user = dict()
            user["timestamp"] = get_current_timestamp_iso()
            user["snaid"] = snaid

            self._set_cached_user(cache_key, user, True)

        return cache_key

    def _get_calculated_expiration(self, user):
        rval = None

        try:
            session_ts = user["timestamp"]

            validity = MAX_TOKEN_VALIDITY

            if self._is_unregistered_user(user):
                validity = UNREGISTERD_MAX_TOKEN_VALIDITY

            ts = dateutil.parser.parse(session_ts) + datetime.timedelta(
                seconds=validity)
            rval = round(ts.timestamp())
        except Exception as e:
            self.logger.error("Encountered exception calculating expiration: " +
                              str(e))

        return rval

    def _get_accessor_entitlements(self, user):
        snaid = user.get("snaid", None)

        if not snaid:
            self.logger.error("No SNAID provided for _get_accessor_entitlements")
            return None

        static_ent = None
        if self._is_unregistered_user(user):
            static_ent = self._security_settings_config.get_free_publications()
        elif self._security_settings_config.get_use_static_entitlements():
            static_ent = self._security_settings_config.get_static_entitlements()

        if static_ent:
            self.logger.info("Use static entitlements to avoid hitting " +
                             "entitlements endpoint.")

            rval = self.get_static_entitlements(snaid, static_ent)
        else:
            rval = self.upaccessor.get_subscriptions(snaid)

        return rval

    @staticmethod
    def get_static_entitlements(snaid, static_ent):
        rval = []
        for k, v in static_ent.items():
            ent = {
                "memberOrg": None,
                "memberCat": None,
                "expirationDate": "0000-00-00",
                "levelWeight": 600,
                "startDate": "2018-08-16",
                "circStatus": "R",
                "deliveryCode": None,
                "issuesRemaining": 0,
                "finalExpirationDate": "0000-00-00",
                "renewMethod": "A",
                "subType": None,
                "termNumber": 0,
                "temp": False,
                "term": 0,
                "level": "LIFETIME",
                "status": "ACTIVE",
                "id": {
                    "customerNumber": snaid,
                    "subRef": "",
                    "item": {
                        "itemNumber": k,
                        "itemDescription": v,
                        "itemType": ""
                    }
                }
            }

            rval.append(ent)
        return rval

    def _insert_missing_publication_entitlements(self, user):
        if not user:
            return

        try:
            snaid = user.get("snaid", "N/A")

            static_ent = None
            if not user.get('entitlements', {}).get('publication', {}):
                static_ent = self._security_settings_config.get_free_publications()

            if static_ent:
                rval = []
                self.logger.info("Use free static entitlements.")
                static_entitlements = self.get_static_entitlements(snaid, static_ent)
                rval.extend(static_entitlements)

                if "entitlements" not in user:
                    user["entitlements"] = { "publication": [] }

                user["entitlements"]["publication"].extend(rval)
        except Exception as e:
            self.logger.error("insert missing entitlements error. {}".format(str(e)))
            return

    @timing
    def make_unregistered_profile(self, session):
        """
    Creates a default profile for the specified session
    from configuration template
    :param session: session information of the suer
    :return: True if all user profiles create false otherwise
    """
        profile = None

        if not session:
            self.logger.info("Received empty make session request")
            return profile

        template = TemplateHelper.read_json_template_file(self._unregistered_template, self._unregistered_template_file,
                                                          self.logger)

        profile = None

        if template and "name" in session and \
                "snaid" in session and \
                "email" in session:
            profile = dict(template)
            profile["name"] = session["name"]
            profile["snaid"] = session["snaid"]
            profile["email"] = session["email"]
            profile["user_profile_type"] = "PUBLIC_USER"
            profile["created"] = get_current_timestamp_iso()

        return profile

    @timing
    def make_user_profile(self, users=None, cache_key=None):
        """
    Creates a default profile for the specified users from configuration template
    :param users: List of users and attributes to be constructed
    :param cache_key: cache key for the current user session
    :return: True if all user profiles create false otherwise
    """
        rval = True
        msg = ""

        if not users:
            rval = False
            msg = "Received empty make user request"
            self.logger.info(msg)
            return rval, msg

        for atts in users:
            template = TemplateHelper.read_json_template_file(self._template, self._tempfile, self.logger)

            if atts and "name" in atts and "snaid" in atts and "email" in atts:
                msg += atts["email"] + " "

                template["name"] = atts["name"]
                template["snaid"] = atts["snaid"]
                template["email"] = atts["email"]
                template["chat_id"] = atts["email"]
                template["created"] = get_current_timestamp_iso()

                if "passwd" in atts: template["passwd"] = atts["passwd"]

                sl = atts["email"] if "@" not in atts["email"] else (atts["email"].split("@"))[0]

                template["sungard_login"] = sl
                template["tradestop_user"] = ""
                template["tradestop_pwd"] = ""

                ok, err = self.create_user_profile(template, cache_key)

                if not ok:
                    rval = False
                    err = "Make user " + atts["email"] + " failed. " + err
                    msg = msg + "\n" + err
                    self.logger.info(err)

            template.clear()

        return rval, msg

    class DBLogger(DynamoAccessor):
        """
    Adds public methods to avoid private member access warnings
    """

        def have_table(self, table):
            return self._table_exists(table)

        def create_table(self, name, hkey, rkey=None, **kwargs):
            return self._make_table(name, hkey, rkey, **kwargs)

        def insert_into_table(self, tname, data):
            return self._save(tname, data)
