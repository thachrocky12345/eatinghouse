import boto3
import dateutil.parser
import decimal
import logging
import os
import pytz
import requests
import simplejson
import time
import uuid
from boto3.dynamodb.conditions import Attr, And, Or
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from ppt_accessor import PPTAccessor

import price_streaming
import sbt_crypto.cryptocompare
from vendor.sbt_barchart.barchart_accessor import BarchartAccessor
from dd_accessor import DynamoAccessor
from up_accessor import UserProfileAccessor
from sbt_common import SbtGlobalCommon
from redis_manager import RedisManager
from services.sbt_email import send_email
from stansberry_article import Article
from ar_accessor import ArticleAccessor
from elasticsearch_manager import ElasticsearchManager
from suggestion import Suggestion

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
config = SbtGlobalCommon.get_sbt_config()
notification_config = config["services"]["notification_rules"]

barchart_accessor = BarchartAccessor()
dynamo_accessor = DynamoAccessor()
user_accessor = UserProfileAccessor(config["services"]["user"])
article_accessor = ArticleAccessor(SbtGlobalCommon.get_cfg_env_var("elasticsearch"))
es_manager = ElasticsearchManager(None, SbtGlobalCommon.get_cfg_env_var("elasticsearch"))
redis_manager = RedisManager()
price_stream = price_streaming.PriceStreamClient()
ppt_accessor = PPTAccessor()

TABLE_NAME = "SBT_NOTIFICATION"
SEND_TABLE_NAME = "SBT_NOTIFICATION_SEND"
REDIS_CHANNEL = "notifications"
MOVING_AVG_UNITS = {
    "day": { "time_type": "daily", "time_unit": timedelta(days=1) },
    "week": { "time_type": "weekly", "time_unit": timedelta(weeks=1) },
    "month": { "time_type": "monthly", "time_unit": timedelta(days=31) },
}

session = dynamo_accessor._session
dynamodb_client = session.client("dynamodb")
streams_client = session.client("dynamodbstreams")
cw_client = session.client("cloudwatch")

notifications = {}
pubcodes = {}
symbol_exchanges = {}
streams = []
metrics = {
    "checked": 0,
    "triggered": 0,
    "sent_sms": 0,
    "sent_email": 0,
}


def get_api_url(path, *args, **kwargs):
    environment = config["environment"]
    api_url = config["apigateway"]["env"][environment]

    url_fmt = api_url + "/" + path
    return url_fmt.format(*args, **kwargs)

def get_volatility(symbol):
    unique_item = {}
    if "~" in symbol:
        symbol_exchange = symbol.split("~")
        if len(symbol_exchange) == 2:
            unique_item = Suggestion.get_unique_item(symbol_exchange[0], symbol_exchange[1])
        else:
            unique_item = Suggestion.get_unique_item(symbol)
    else:
        unique_item = Suggestion.get_unique_item(symbol)

    if unique_item and len(unique_item['result']) > 0:
        is_etf = unique_item['result'].get("is_etf", False)
        volatility = 0
        if is_etf:
            url = get_api_url("fundamentals/etf/description/{symbol}", symbol=symbol)
            req = requests.get(url)
            data = req.json()
            if data["success"] and "snapshot" in data["description"]:
                volatility = data["description"]["snapshot"]["volatility"]
        else:
            url = get_api_url("fundamentals/snapshot/{symbol}", symbol=symbol)
            req = requests.get(url)
            data = req.json()
            if data["success"]:
                volatility = data["data"]["volatility"]

    return volatility if volatility else 0

def get_symbol_exchange(symbol):
    if symbol not in symbol_exchanges:
        try:
            url = get_api_url("fundamentals/symbol/valid/{symbol}", symbol=symbol)
            req = requests.get(url)
            symbol_exchanges[symbol] = req.json()["data"][0]
        except Exception as e:
            logger.warning("Could not get symbol for {}: {}".format(symbol, str(e)))

    return symbol_exchanges.get(symbol)

def get_symbol(notification):
    if "symbol" in notification:
        return notification["symbol"].upper().strip()
    else:
        return None

def get_publication_info(pubcode):
    if pubcode not in pubcodes:
        pubcodes[pubcode] = article_accessor.query_publication_code(pubcode)

    return pubcodes[pubcode]

def get_message_text(notification, user, **kwargs):
    notification_type = notification.get("type", "confirmation")
    message_fmt = notification_config["templates"][notification_type]
    if isinstance(message_fmt, dict):
        return {k: v.format(notification=notification, user=user, **kwargs) for k, v in message_fmt.items()}
    else:
        message_text = message_fmt.format(notification=notification, user=user, **kwargs)
        return {
            "terminal": message_text,
            "sms": message_text,
            "email": message_text,
        }

def is_repeatable(notification):
    return notification.get("type") in ["publication", "recommend"]

# Send notification to redis, which will pass it to the terminal
def send_notification_redis(notification, send, user):
    try:
        channel_name = REDIS_CHANNEL
        redis_message = {
            "guid": send["guid"],
            "notification_guid": notification["guid"],
            "user_guid": user["guid"],
            "user_snaid": user["snaid"],
            "message_text": send["message_text"]["terminal"],
            "article_id": send.get("article_id"),
            "notification": notification,
        }

        redis_manager.publish(channel_name, simplejson.dumps(redis_message))

    except Exception as e:
        logger.exception("Could not send notification to redis: {}".format(str(e)))

# Send notification to a contact endpoint using AWS
def send_notification_aws(contact_info, user, message_text, subject_line):
    session = boto3.session.Session(profile_name=config["aws"]["profile"])
    logger.info("Sending notification via {} to endpoint {}".format(contact_info["ci_type"], contact_info["ci_endpoint"]))

    if contact_info["ci_type"] == "sms":
        sns = session.client("sns")
        sns.publish(PhoneNumber=contact_info["ci_endpoint"], Message=message_text["sms"])
        metrics["sent_sms"] += 1

    if contact_info["ci_type"] == "email":
        send_email("alert_email.html", contact_info["ci_endpoint"], subject_line, Name=user["name"], MessageText=message_text["email"])
        metrics["sent_email"] += 1

def mark_error_notification(notification, error_message=""):
    try:
        if notification:
            if "error_count" in notification:
                notification["error_count"] += 1
            else:
                notification["error_count"] = 1

            notification["error_message"] = error_message

        logger.debug(error_message)
        dynamo_accessor._save(TABLE_NAME, notification)
    except Exception as e:
        logger.exception("Exception occur while marking error notification", e)

# Called when a notification is triggered. Sets triggered time and creates an entry in the send table.
def trigger_notification(notification, **kwargs):
    # Avoid trying to send from more than one instance of this script at the same time
    condition = And(
        Or(
            Attr("triggered").not_exists(),
            Attr("triggered").lt(decimal.Decimal(time.time() - notification_config["retry_after"])),
        ),
        Attr("completed").not_exists(),
    )

    notification["triggered"] = time.time()
    try:
        result = dynamo_accessor._save(TABLE_NAME, notification, ConditionExpression=condition)
    except dynamodb_client.exceptions.ConditionalCheckFailedException:
        logger.debug("Failed condition for notification {}; skipping".format(notification["guid"]))
        return

    notification_type = notification.get("type", "confirmation")
    subject_fmt = notification_config["subject_lines"].get(notification_type, notification_config["subject_lines"]["default"])

    if not is_repeatable(notification):
        notification["completed"] = time.time()

    dynamo_accessor._save(TABLE_NAME, notification)

    users = user_accessor._execute_query("SELECT * FROM user_profile WHERE guid=%s", [notification["user_guid"]])
    if not users:
        logger.error("Could not find user with GUID {}. Cannot send notification {}.".format(notification["user_guid"], notification["guid"]))
        return

    user = users[0]
    message_text = get_message_text(notification=notification, user=user, **kwargs)
    subject_line = subject_fmt.format(notification=notification, user=user, **kwargs)

    send = {
        "guid": str(uuid.uuid4()),
        "notification_guid": notification["guid"],
        "type": notification["type"],
        "environment": config["environment"],
        "user_guid": notification["user_guid"],
        "timestamp": time.time(),
        "message_text": message_text,
        "subject_line": subject_line,
        "article_id": kwargs.get("article_id"),
        "sent_ci_endpoints": [],
        "sent_redis": False,
    }

    if 'ppt_portfolio_guid' in notification:
        send['ppt_portfolio_guid'] = notification['ppt_portfolio_guid']

    dynamo_accessor._save(SEND_TABLE_NAME, send)

    logger.info("Triggered notification {} ({})".format(notification["guid"], notification.get("type")))
    metrics["triggered"] += 1

# Called for entries in the send table. Attempts to actually send the alert.
def send_notification(send):
    # Avoid trying to send from more than one instance of this script at the same time
    condition = And(
        Or(
            Attr("last_send_attempt").not_exists(),
            Attr("last_send_attempt").lt(decimal.Decimal(time.time() - notification_config["retry_after"])),
        ),
        Attr("completed").not_exists(),
    )

    send["last_send_attempt"] = time.time()
    try:
        result = dynamo_accessor._save(SEND_TABLE_NAME, send, ConditionExpression=condition)
    except dynamodb_client.exceptions.ConditionalCheckFailedException:
        logger.debug("Failed condition for send {}; skipping".format(send["guid"]))
        return

    logger.info("Sending notification {} (send ID {})".format(send["notification_guid"], send["guid"]))

    # Get user and notification info
    response = dynamo_accessor._query_table(TABLE_NAME, "guid", send["notification_guid"])
    if len(response) == 0 or response[0].get("environment") != config["environment"]:
        logger.warning("Cannot find notification {} for send {}, skipping".format(send["notification_guid"], send["guid"]))
        return

    notification = response[0]
    notification_type = notification.get("type", "confirmation")

    if notification.get("ppt_portfolio_guid", None):
        ppt_portfolio_email = ppt_accessor.get_ppt_portfolio_email(notification['ppt_portfolio_guid'])

        if ppt_portfolio_email:
            for email in ppt_portfolio_email.split(","):
                if email:
                    ppt_contact_info = {
                        'ci_type': 'email',
                        'ci_endpoint': email.strip()
                    }

                    user = {
                        'name': 'User'
                    }

                    send_notification_aws(ppt_contact_info, user, send["message_text"], send["subject_line"])
    else:
        users = user_accessor._execute_query("SELECT * FROM user_profile WHERE guid=%s", [notification["user_guid"]])
        if not users:
            logger.error("Could not find user with GUID {}. Cannot send notification {}.".format(notification["user_guid"], notification["guid"]))
            return

        user = users[0]

        # Create entry in redis, will be sent to terminal
        if not send["sent_redis"] and notification_type != "confirmation":
            send_notification_redis(notification, send, user)
            send["sent_redis"] = time.time()
            dynamo_accessor._save(SEND_TABLE_NAME, send)

        # Get user's contact info, and attempt to send to each endpoint
        query_results = user_accessor._execute_query("SELECT * FROM user_profile_contact_info WHERE user_id=%s AND enabled", [send["user_guid"]])
        if query_results is not None:
            for contact_info in query_results:
                if contact_info["guid"] in notification.get("sent_ci_endpoints", []):
                    continue

                # If this is a confirmation message, only send it to the specified endpoint
                if notification_type == "confirmation" and contact_info["guid"] != notification.get("row_id", ""):
                    continue

                # If this is not a confirmation message, don't send it to unconfirmed endpoints
                if notification_type != "confirmation" and not contact_info["confirmed"]:
                    continue

                send_notification_aws(contact_info, user, send["message_text"], send["subject_line"])
                send["sent_ci_endpoints"] = send.get("sent_ci_endpoints", []) + [contact_info["guid"]]
                dynamo_accessor._save(SEND_TABLE_NAME, send)


    # Set as completed
    send["completed"] = time.time()
    dynamo_accessor._save(SEND_TABLE_NAME, send)

# Checks for notifications that should be triggered
def check_notifications():
    quotes = {}
    crypto_quotes = {}
    volatility = {}

    sent_notifications = set()
    for guid, notification in notifications.items():
        if "completed" in notification or "expired" in notification:
            sent_notifications.add(guid)

        # When the error count is three or more, we have to remove that notification from processing
        if "error_count" in notification and notification["error_count"] >= 3:
            sent_notifications.add(guid)

    for guid in sent_notifications:
        del notifications[guid]

    # Get quotes for notifications by symbol (no symbol_guid)
    symbols = list(set([i["symbol"].upper().strip() for i in notifications.values() if "symbol" in i and not i.get("crypto")]))
    for symbol in symbols:
        symbol_exchange = get_symbol_exchange(symbol)

        if symbol_exchange and symbol_exchange.get('valid', False) and len(symbol_exchange.get('exchange', [])) > 0:
            price_stream.add_symbols("{}~{}".format(symbol_exchange["symbol"], symbol_exchange["exchange"][0]))
            quote = price_stream.get_price(symbol_exchange["symbol"], symbol_exchange["exchange"][0])
            if quote:
                quotes[symbol] = quote

    # Get volatility for any notifications that require it
    volatility_symbols = set([i["symbol"] for i in notifications.values() if "symbol" in i and i.get("trailing_type") == "Volatility"])
    for symbol in volatility_symbols:
        try:
            volatility[symbol] = get_volatility(symbol)
        except Exception as e:
            volatility_notification = [i for i in notifications.values() if "symbol" in i and i.get("trailing_type") == "Volatility" and i.get("symbol") == symbol]
            if len(volatility_notification) > 0:
                mark_error_notification(volatility_notification[0], "Could not process volatility for symbol: {}".format(symbol))
            logger.error("Could not get volatility for symbol {}: {}".format(symbol, str(e)))

    # Crypto symbols handled by cryptocompare
    crypto_symbols = list(set([i["symbol"].upper().strip() for i in notifications.values() if "symbol" in i and i.get("crypto")]))
    for crypto_symbol in crypto_symbols:
        try:
            quote = sbt_crypto.cryptocompare.get_prices(crypto_symbol)
            for symbol, price in quote.items():
                crypto_quotes[symbol] = price
        except Exception as e:
            logger.exception("Could not update crypto prices: {}".format(str(e)))
            crypto_notification = [i for i in notifications.values() if "symbol" in i and i.get("crypto") and crypto_symbol == i["symbol"].upper().strip()]
            if len(crypto_notification) > 0:
                mark_error_notification(crypto_notification[0], "Crypto price is missing for symbol: {}".format(crypto_symbol))
            return

    for notification in notifications.values():
        try:
            # Check if notification has expired
            if "time_type" in notification and "created_at" in notification:
                expire_time = None
                created_at = datetime.fromtimestamp(notification["created_at"]).astimezone(pytz.timezone("US/Eastern"))

                if notification["time_type"] == "Day":
                    # One day after creating
                    expire_time = created_at + timedelta(days=1)

                if notification["time_type"] == "Till Close":
                    # The next 4pm Eastern
                    expire_time = created_at.replace(hour=16, minute=0, second=0)
                    if expire_time <= created_at:
                        expire_time += timedelta(days=1)

                if notification["time_type"] == "Good till Canceled" and "time_range" in notification:
                    expire_time = dateutil.parser.parse(notification["time_range"]).astimezone(pytz.UTC)

                if expire_time and expire_time < datetime.utcnow().astimezone(pytz.UTC):
                    notification["expired"] = expire_time.timestamp()
                    dynamo_accessor._save(TABLE_NAME, notification)
                    continue

            metrics["checked"] += 1
            notification_type = notification.get("type", "confirmation")

            # If this is a confirmation message, send it immediately
            if notification_type == "confirmation":
                trigger_notification(notification)
                continue

            # Publication alerts
            if notification_type == "publication":
                since_time = max(notification.get("created_at", 0), notification.get("triggered", 0))
                for pub_code in notification["publications"]:
                    publication = get_publication_info(pub_code)
                    response = Article.get_by_publication([], pub_code.lower(), start_date=since_time*1000)
                    for article in response["articles"]:
                        symbol = get_symbol(notification)
                        if symbol:
                            if "~" in symbol:
                                symbol = symbol.split("~")[0]

                            if symbol not in [i.upper() for i in article["tickers"]]:
                                continue

                        article_title = BeautifulSoup(article["title"]).get_text()
                        article_id = str(article["wordpressId"])
                        trigger_notification(notification, article_id=article_id, pub_title=publication["title"], article_title=article_title)

                continue

            # Buy/Sell Recommendation alerts
            if notification_type == "recommend":
                since_time = max(notification.get("created_at", 0), notification.get("triggered", 0))
                query_terms = [
                    {"range": {"createdAt": {"gt": since_time * 1000}}},
                    {"exists": {"field": "buy_and_sell_alerts.alert"}},
                ]

                query_body = {"query": {"bool": {"must": query_terms}}}
                es_result = es_manager._es.search(index="articles", body=query_body)
                for article in es_result["hits"]["hits"]:
                    if notification.get("publications"):
                        if article["_source"]["defaultPublication"]["publicationCode"].lower() not in [i.lower() for i in notification["publications"]]:
                            continue

                    symbol = get_symbol(notification)
                    if symbol:
                        if "~" in symbol:
                            symbol = symbol.split("~")[0]

                        if symbol not in [i.upper() for i in article["_source"].get("tickers", [])]:
                            continue

                    publication = get_publication_info(article["_source"]["defaultPublication"]["publicationCode"])
                    article_title = BeautifulSoup(article["_source"]["title"]).get_text()

                    recommendation_short_text = article["_source"]["buy_and_sell_alerts"][0]["text"]
                    if len(article["_source"]["buy_and_sell_alerts"]) > 1:
                        recommendation_short_text = "{} recommendations, including: {}".format(len(article["_source"]["buy_and_sell_alerts"]), recommendation_short_text)

                    recommendation_html = "".join(["<li>{}</li>".format(i["text"]) for i in article["_source"]["buy_and_sell_alerts"]])

                    trigger_notification(
                        notification,
                        pub_title=publication["title"],
                        article_title=article_title,
                        article_id=article["_source"]["wordpressId"],
                        all_recommendations=[i["text"] for i in article["_source"]["buy_and_sell_alerts"]],
                        recommendation_short_text=recommendation_short_text,
                        recommendation_html=recommendation_html,
                    )

                continue

            if "symbol" not in notification:
                logger.error("symbol not found for notification {} - deleting".format(notification["guid"]))
                dynamo_accessor._delete(TABLE_NAME, "guid", notification["guid"])
                continue

            if "symbol" in notification:
                notification["symbol"] = notification["symbol"].upper().strip()

            if notification.get("crypto"):
                if notification["symbol"] not in crypto_quotes:
                    mark_error_notification(notification, "Crypto symbol {} is missing price data".format(notification["symbol"]))
                    continue

                last_price = round(decimal.Decimal(crypto_quotes[notification["symbol"]]))

            else:
                if notification["symbol"] not in quotes:
                    mark_error_notification(notification, "Stock symbol {} is missing price data".format(notification["symbol"]))
                    continue

                quote = quotes[notification["symbol"]]

                # Use bid, ask, or last depending on value of trailing_based_on (default to last)
                price_based_on = notification.get("trailing_based_on", "Last")
                quote_key = {
                    "Bid": "bid_price",
                    "Ask": "ask_price",
                    "Last": "last_price",
                }

                last_price = round(decimal.Decimal(quote[quote_key[price_based_on]]), 2)

            if notification_type == "price":
                price_type = notification.get("price_type", "above")
                if price_type == "above" and last_price >= notification["alert_price"]:
                    trigger_notification(notification, price=last_price)
                if price_type == "below" and last_price <= notification["alert_price"]:
                    trigger_notification(notification, price=last_price)

            if notification_type == "stoploss":
                if notification.get("max_price") is None or last_price > notification.get("max_price", 0):
                    notification["max_price"] = last_price
                    dynamo_accessor._save(TABLE_NAME, notification)

                trailing_type = notification.get("trailing_type")
                alert_price = notification.get("alert_price")

                if trailing_type == "Dollar":
                    alert_price = notification["max_price"] - notification["trailing_value"]
                if trailing_type == "Percent":
                    alert_price = notification["max_price"] * (1 - notification["trailing_value"] / 100)
                if trailing_type == "Volatility":
                    alert_price = notification["max_price"] * (1 - volatility[notification["symbol"]])

                if alert_price is None:
                    mark_error_notification(notification, "Alert price is missing for notification {}".format(str(notification["guid"])))
                    logger.warning("Could not find alert price for notification {}. Skipping.".format(notification["guid"]))
                    continue

                if last_price < alert_price:
                    trigger_notification(notification, price=last_price)

            if notification_type == "salelimit":
                if notification.get("min_price") is None or last_price < notification.get("min_price", 0):
                    notification["min_price"] = last_price
                    dynamo_accessor._save(TABLE_NAME, notification)

                trailing_type = notification.get("trailing_type")
                alert_price = notification.get("alert_price")

                if trailing_type == "Dollar":
                    alert_price = notification["min_price"] + notification["trailing_value"]
                if trailing_type == "Percent":
                    alert_price = notification["min_price"] * (1 + notification["trailing_value"] / 100)
                if trailing_type == "Volatility":
                    alert_price = notification["min_price"] * (1 + volatility[notification["symbol"]])

                if alert_price is None:
                    logger.warning("Could not find alert price for notification {}. Skipping.".format(notification["guid"]))
                    continue

                if last_price > alert_price:
                    trigger_notification(notification, price=last_price)

            if notification_type == "movingavgcross":
                last_checked = notification.get("last_checked", 0)
                if time.time() - int(last_checked) < 3600:
                    continue

                time_units = MOVING_AVG_UNITS[notification.get("moving_avg_units", "day")]

                num_days = max(int(notification["days_a"]), int(notification["days_b"]))
                min_date = (datetime.now() - time_units["time_unit"] * num_days).strftime("%Y%m%d")
                max_date = datetime.now().strftime("%Y%m%d")

                if "symbol" in notification:
                    symbol_str = notification["symbol"]

                history = barchart_accessor.get_history(None, time_units["time_type"], None, min_date, max_date, symbol_str)

                prices_a = [i["close"] for i in history[-int(notification["days_a"]):]]
                prices_b = [i["close"] for i in history[-int(notification["days_b"]):]]
                avg_a = sum(prices_a) / len(prices_a)
                avg_b = sum(prices_b) / len(prices_b)

                if "last_avg_diff" in notification:
                    if (avg_a - avg_b) * float(notification["last_avg_diff"]) < 0:
                        trigger_notification(notification, price=last_price)

                notification["last_avg_diff"] = avg_a - avg_b
                notification["last_checked"] = time.time()
                dynamo_accessor._save(TABLE_NAME, notification)

            if notification_type == "volume":
                volume = quote["previousVolume"]
                if volume > notification["alert_volume"]:
                    trigger_notification(notification, volume=volume)

        except Exception as e:
            if notification:
                mark_error_notification(notification, str(e))
            logger.exception("Error checking notification {}: {}".format(notification.get("guid", "(no GUID found!)"), str(e)))
            continue

# Checks for any notifications that have been triggered and need to be sent
def send_triggered_notifications():
    conditions = And(Attr("completed").not_exists(), Attr("environment").eq(config["environment"]))
    for send in dynamo_accessor._scan_table(SEND_TABLE_NAME, conditions):
        try:
            send_notification(send)
        except:
            logger.exception("Could not send notification {}".format(send["notification_guid"]))

# Loads all active notifications from DynamoDB table
def scan_table():
    notifications.clear()
    conditions = And(And(Attr("completed").not_exists(), Attr("expired").not_exists()), Attr("environment").eq(config["environment"]))
    for notification in dynamo_accessor._scan_table(TABLE_NAME, conditions):
        notifications[notification["guid"]] = notification

    logger.info("Scanned table; found {} active notifications".format(len(notifications)))

# Sets up streams to notify of changes to DynamoDB table
def setup_streams():
    response = streams_client.list_streams(TableName=TABLE_NAME)

    streams.clear()
    for stream in response["Streams"]:
        stream_desc = streams_client.describe_stream(StreamArn=stream["StreamArn"])
        stream["iterators"] = []

        for shard in stream_desc["StreamDescription"]["Shards"]:
            shard_iterator = streams_client.get_shard_iterator(
                StreamArn=stream["StreamArn"],
                ShardId=shard["ShardId"],
                ShardIteratorType="LATEST",
            )

            stream["iterators"].append(shard_iterator["ShardIterator"])

        streams.append(stream)

# Reads DynamoDB stream and updates any changed notifications
def read_streams():
    record_guids = set()

    for stream in streams:
        new_iterators = []

        for iterator in stream["iterators"]:
            try:
                response = streams_client.get_records(ShardIterator=iterator)
                for record in response["Records"]:
                    record_guids.add(record["dynamodb"]["Keys"]["guid"]["S"])

                new_iterators.append(response.get("NextShardIterator", iterator))

            except (streams_client.exceptions.ExpiredIteratorException, streams_client.exceptions.TrimmedDataAccessException):
                logger.info("Stream iterator expired, re-scanning table")
                setup_streams()
                scan_table()
                return

        stream["iterators"] = new_iterators

    logger.info("read_streams found {} updated records".format(len(record_guids)))

    for guid in record_guids:
        response = dynamo_accessor._query_table(TABLE_NAME, "guid", guid)
        if len(response) > 0:
            if response[0].get("environment") == config["environment"]:
                notifications[guid] = response[0]
        elif guid in notifications:
            del notifications[guid]

# Sends metrics to CloudWatch
def send_metrics():
    dimensions = [{"Name": "environment", "Value": config["environment"]}]
    metric_data = [
        {
            "MetricName": k,
            "Dimensions": dimensions,
            "Timestamp": datetime.now(),
            "Value": v,
        }
        for k, v in metrics.items()
    ]

    cw_client.put_metric_data(
        Namespace="SBT_Alerts",
        MetricData=metric_data,
    )


if __name__ == "__main__":
    logger.info("Starting up.")

    scan_table()
    setup_streams()

    price_stream.start()

    while True:
        try:
            for k in metrics.keys():
                metrics[k] = 0

            read_streams()
            check_notifications()
            send_triggered_notifications()
            send_metrics()
        except Exception as e:
            logger.exception("Error checking notifications")

        time.sleep(notification_config["sleep_time"])
