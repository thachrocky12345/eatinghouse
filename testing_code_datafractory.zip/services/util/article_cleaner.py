import copy

from article_helper import ArticleHelper
from cerberus import Validator


# Coercion methods for cerberus normalizer
def to_lowercase(value):
  if isinstance(value, str):
    return value.lower()
  return value


def to_uppercase(value):
  if isinstance(value, str):
    return value.upper()
  return value

# SCHEMAS for cerberus validation module
# see http://docs.python-cerberus.org/en/stable/schemas.html
publication_schema = \
  {'level': {'type': 'integer', 'required': True},
   'publicationCode': {'type': 'string',
                       'coerce': to_lowercase,
                       'required': True}}

symbols_schema = \
  {'symbol': {'type': 'string', 'coerce': to_uppercase, 'required': True},
   'analysis': {'type': 'string', 'required': True},
   'top_recommended': {'type': 'boolean', 'default': False, 'required': True},
   'best_buy': {'type': 'boolean', 'default': False, 'required': True},
   'closed': {'type': 'boolean', 'default': False, 'required': True},
   'initiated': {'type': 'boolean', 'default': False, 'required': True}}

base_schema = \
  {'wordpressId': {'type': 'integer', 'required': True, 'coerce': int},
   'type': {'type': 'string', 'allowed': ['post', 'page', 'daily_wealth'], 'required': True},
   'title': {'type': 'string', 'maxlength': 200, 'required': True},
   'canonicalUrl': {'type': 'string', 'maxlength': 300, 'required': False},
   'slug': {'type': 'string', 'default': '',
            'maxlength': 200, 'required': True},
   'status': {'type': 'string', 'required': True,
              'allowed': ['publish', 'draft', 'trash']},
   'content': {'type': 'string', 'required': True},
   'contentText': {'type': 'string', 'required': True},
   'createdAt': {'type': 'integer', 'minlength': 1,
                 'maxlength': 13, 'required': True},
   'modifiedAt': {'type': 'integer',
                  'minlength': 1,
                  'maxlength': 13,
                  'required': True}}

article_schema = \
  {'excerpt': {'type': 'string', 'default': '', 'required': True},
   'imageUrl': {'type': 'string', 'default': ''},
   'pdfId': {'type': 'string', 'default': ''},
   'pdfUrl': {'type': 'string', 'default': ''},
   'pdfOnly': {'type': 'boolean', 'default': False},
   'analysts': {'type': 'list',
                'required': True,
                'minlength': 1,
                'schema': {'type': 'string',
                           'coerce': to_lowercase}},
   'defaultAnalyst': {'type': 'string',
                      'required': True,
                      'coerce': to_lowercase},
   'categories': {'type': 'list',
                  'required': True,
                  'minlength': 1,
                  'schema': {'type': 'string',
                             'coerce': to_lowercase}},
   'defaultCategory': {'type': 'string',
                       'coerce': to_lowercase,
                       'required': True},
   'tickers': {'type': 'list',
               'default': [],
               'required': True,
               'schema': {'type': 'string',
                          'coerce': to_uppercase}},
   'tickersText': {'type': 'string',
                   'default': '',
                   'required': True,
                   'coerce': to_uppercase},
   'publications': {'type': 'list',
                    'minlength': 1,
                    'required': True,
                    'schema': {
                      'type': 'dict',
                      'required': True,
                      'schema': publication_schema}},
   'defaultPublication': {'type': 'dict',
                          'required': True,
                          'schema': publication_schema},
   'symbols': {'type': 'list',
               'required': True,
               'minlength': 0,
               'schema': {
                 'type': 'dict',
                 'schema': symbols_schema}}}

# combine base and article schema
schema = base_schema.copy()
schema.update(article_schema)

# known issues with lists and dicts that are empty being mistyped
# as boolean:False
normalized_keys = [{'key_name': 'categories', 'key_value': []},
                   {'key_name': 'defaultCategory', 'key_value': None},
                   {'key_name': 'analysts', 'key_value': []},
                   {'key_name': 'defaultAnalyst', 'key_value': None},
                   {'key_name': 'publications', 'key_value': []},
                   {'key_name': 'defaultPublication', 'key_value': None},
                   {'key_name': 'symbols', 'key_value': []}]

process_stages = ['remove_extra_keys',
                  'normalization',
                  'base_validation',
                  'base_identification',
                  'article_validation',
                  'article_base_type_identification',
                  'article_sub_types_identification',
                  'finish',
                  'done']


class ArticleCleaner():
  def __init__(self, article_json):
    self.stage = process_stages[0]
    self.valid = False
    self.failed = False
    self.errors = {}
    self.warnings = {}
    self.raw = article_json
    self.article = copy.deepcopy(article_json)

  def clean(self):
    self._process()

  def get_article(self):
    return copy.deepcopy(self.article)

  def to_log_str(self):
    return "\nStage: " + str(self.stage) \
           + "\nErrors: " + str(self.errors) \
           + "\nWarnings: " + str(self.warnings) \
           + "\nOriginal Article:: \n" + str(self.raw) \
           + "\nProcessed Article: \n" + str(self.article)

  def _process(self):
    while self.failed is False and self.stage is not 'done':
      instance_function_name = '_process_' + self.stage
      instance_function = getattr(self, instance_function_name)
      instance_function()  # calling dynamic instance method

  def _next_stage(self):
    stage_index = process_stages.index(self.stage)
    self.stage = process_stages[stage_index + 1]

  def _process_finish(self):
    # Last step in the process, valid if we make it here.
    if not self.failed:
      self.valid = True
    self._next_stage()

  def _process_normalization(self):
    # Named normalize to emphasize that it will not validate the schema
    # will only run the 'coerce' helpers
    normalizer = Validator()
    normalizer.allow_unknown = True
    self.article = normalizer.normalized(self.article, schema)

    # fix known issues processing articles
    for key in normalized_keys:
      # TODO: figure out how to create non references to blank lists and dicts
      self.article.setdefault(key['key_name'], copy.copy(key['key_value']))

      # TODO: can this be handled by custom cerberus normalizer
      # solves issue with article being sent having boolean values
      # for lists or dictionaries
      if isinstance(self.article.get(key['key_name'], None), bool):
        self.warnings[key['key_name']] = \
          ['incorrect boolean type was normalized']
        self.article[key['key_name']] = key['key_value']
    self._next_stage()

  def _process_base_validation(self):
    validator = Validator()
    validator.allow_unknown = True

    if validator.validate(self.article, base_schema):
      self.article = validator.document
      self._next_stage()
    else:
      self.failed = True
      self.errors = validator.errors

  def _process_article_validation(self):
    validator = Validator(schema)
    validator.allow_unknown = False

    if validator.validate(self.article, schema):
      self.article = validator.document
      self._next_stage()
    else:
      self.failed = True
      self.errors = validator.errors

  def _process_base_identification(self):
    if ArticleHelper.is_article(self.article):
      self._next_stage()
    else:
      self.failed = True
      self.errors['type'] = ['could not be identified']

  def _process_remove_extra_keys(self):
    keys_to_remove = []

    # find extra keys in the article and populate keys_to_remove list
    for key in self.article.keys():
      if key not in schema.keys():
        keys_to_remove.append(key)

    # remove extra keys from the article
    for key in keys_to_remove:
      self.article.pop(key, None)

    self._next_stage()

  def _process_article_base_type_identification(self):
    base_type = ArticleHelper.get_base_type(self.article)
    self.article['base_type'] = base_type
    self.article['sub_types'] = []
    self.article['sub_types'].append(base_type)
    self._next_stage()

  def _process_article_sub_types_identification(self):
    sub_types = ArticleHelper.get_sub_types(self.article)
    for sub_type in sub_types:
      self.article['sub_types'].append(sub_type)
    self._next_stage()
