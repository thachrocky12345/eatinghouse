from functools import wraps
from bottle import request
import base64
import re
import logging

from sbt_common import SbtGlobalCommon
from redis_manager import RedisManager
from ttl_utils import str_to_ttl

env = SbtGlobalCommon.get_cfg_env()
redis_client = RedisManager()
logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)

# Module level variables
is_cache_enabled = SbtGlobalCommon.get_sbt_config()['cache']['enabled']

CACHE_SKIP_TOKEN = SbtGlobalCommon.get_sbt_config()['cache']['skip_token']
CACHE_REFRESH_TOKEN = SbtGlobalCommon.get_sbt_config()['cache']['refresh_token']


def _request_has_skip_token():
    """
    Determines if a request has a valid 'X-Cache-Token' that matches the skip token.

    :return: If a valid token was found
    :rtype: bool
    """
    should_skip_cache = False
    try:
        if request.headers.get('X-Cache-Token') == CACHE_SKIP_TOKEN:
            logger.info("CACHE: CACHE_SKIP_TOKEN {}".format(request.url))
            should_skip_cache = True
    except:
        logger.info("request.headers.get('X-Cache-Token') not found")

    return should_skip_cache

def _request_has_refresh_token():
    """
    Determines if a request has a valid 'X-Cache-Token' that matches the refresh token.

    :return: If a valid token was found
    :rtype: bool
    """
    has_refresh_token = False
    try:
        if request.headers.get('X-Cache-Token') == CACHE_REFRESH_TOKEN:
            logger.info("CACHE: CACHE_REFRESH_TOKEN {}".format(request.url))
            has_refresh_token = True
    except:
        logger.info("request.headers.get('X-Cache-Token') not found")

    return has_refresh_token


def _generate_env_cache_key(non_env_cache_key: str):
    """
    Generates an environment specific cache key.

    :return: Cache key prefixed with the current env (ie. DEV_, PROD_)
    :rtype: str
    """
    cache_key: str = env.upper() + '_' + non_env_cache_key
    return cache_key


def _should_request_use_cache() -> bool:
    """
    Private: Determines if a request should use the cache by checking global settings
    and if the request has a skip cache token

    :return: Should the request use the cache
    :rtype: bool
    """
    use_cache = True if is_cache_enabled is True else False
    if use_cache and _request_has_skip_token() is True:
        use_cache = False
    return use_cache

def _should_request_refresh_cache_only() -> bool:
    """
    Private: Determines if a request should bust the cache
    and if the request has a skip cache token

    :return: Should the request use the cache
    :rtype: bool
    """
    should_refresh_cache_only = False
    if is_cache_enabled and _request_has_refresh_token() is True:
        should_refresh_cache_only = True

    return should_refresh_cache_only


def _generate_cache_hash(text: str) -> str:
    """
    Private: Generates a base64 string from text.  Used for converting a querystring
    to a unique key that can be used for caching

    :type text: str
    :param text: The string to reduce to a base64 version
    :return: String of a base64 representation
    :rtype: str
    """
    cache_key = re.sub('[\s\W]', '', text)
    cache_key = str(base64.b64encode(cache_key.encode('utf-8')), 'utf-8')
    return cache_key


def _get_cached_by_key(non_env_cache_key: str) -> any:
    results = None
    if non_env_cache_key:
        results = redis_client.get(_generate_env_cache_key(non_env_cache_key))

    return results


def _set_cached_by_key(non_env_cache_key: str, data, ttl: str or int ='1min') -> bool:
    ttl_seconds = str_to_ttl(ttl) if type(ttl) is str else ttl
    results = redis_client.set(_generate_env_cache_key(non_env_cache_key), data, ttl_seconds)
    return results

# PUBLIC Methods

def get_cached_by_key(non_env_cache_key):
    """
    Gets cached value by key.  Checks if cache is enabled and if a skip / refresh token
    is valid in the request header

    :type non_env_cache_key: str
    :param non_env_cache_key: The string to reduce to a base64 version
    :return: Value from the cache
    :rtype: str or list or dict
    """
    results = None
    if non_env_cache_key and _should_request_use_cache() and not _should_request_refresh_cache_only():
        results = _get_cached_by_key(non_env_cache_key)
        logger.info("CACHE:{}, {}, {}".format("HIT" if results else "MISS",
                                              "NON-ENDPOINT",
                                              _generate_env_cache_key(non_env_cache_key)))
    return results


def set_cached_by_key(non_env_cache_key: str, data: dict or list or str, ttl: str or int = '1min') -> bool:
    results = False
    if non_env_cache_key and _should_request_use_cache():
        results = _set_cached_by_key(non_env_cache_key, data, ttl)
        logger.info("CACHE:{}, {}, {}".format("SET" if results is True else "SET_FAILED",
                                              "NON-ENDPOINT",
                                              _generate_env_cache_key(non_env_cache_key)))

    return results


def cached(suffix: str, ttl: str or int, *, keys: list = None, key: str = None):
    def outer_fn(fn):
        @wraps(fn)
        def inner_fn(*args, **kwargs):
            use_cache = _should_request_use_cache()

            if use_cache:
                cache_key = suffix  # General cache key
                should_save_to_cache = False  # Should inner function results be saved to cache
                results = None  # Default value for response from cache or inner function

                # Generate cache_key from a single key
                if key:
                    logger.info("ERROR: Deprecated call of @cached key.")

                # Generate cache_key from multiple route keys
                if keys:
                    for key_item in keys:
                        # Special cache key generation from request path
                        if key_item == "PATH":
                            cache_key += '_' + _generate_cache_hash(request.url)

                        # Special cache key generation from request querystring
                        elif key_item == "QS":
                            cache_key += '_' + _generate_cache_hash(request.query_string)

                        # Special cache key generation from post request json
                        elif key_item == "JSON":
                            request_json = request.json
                            json_cache_key = ""
                            for json_key in sorted(request_json.keys()):
                                json_cache_key = '{json_cache_key}_{json_key}{cache_key_add}'.format(
                                    json_key=json_key,
                                    json_cache_key=json_cache_key,
                                    cache_key_add=request_json[json_key])
                            logger.info("CACHE: POST_JSON - {} {}".format(request.url, json_cache_key))
                            cache_key += '_' + _generate_cache_hash(json_cache_key)

                        elif key_item in kwargs:
                            # Individualized cached value is
                            cache_key = '{cache_key}_{cache_key_add}'.format(
                                cache_key=cache_key,
                                cache_key_add=kwargs[key_item])
                        else:
                            logger.info("WARNING: key not found in @cached decotator")

                # Get from cache if refresh key not in request header
                if not _should_request_refresh_cache_only():
                    try:
                        # Get cached value from redis
                        results = _get_cached_by_key(cache_key)
                        if results:
                            logger.info("CACHE: HIT - {} {}".format(request.url, cache_key))
                            return results
                        else:
                            logger.info("CACHE: MISS - {} {}".format(request.url, cache_key))

                    except Exception as e:
                        logger.error("ERROR: during get_cached_by_key: {}".format(e))

                # Cache miss proceed with original function
                try:
                    results = fn(*args, **kwargs)
                except Exception as e:
                    logger.error("ERROR: during endpoint execution: {} {}".format(request.url, e))

                if results:
                    try:
                        if type(results) is dict:
                            # Most common response format
                            if 'success' in results:
                                should_save_to_cache = results['success']

                            # Uncommon response format
                            elif 'status' in results and results['status']['code'] == 200:
                                should_save_to_cache = True

                        if should_save_to_cache:
                            logger.info("CACHE: SET - {} {}".format(request.url, cache_key))
                            _set_cached_by_key(cache_key, results, ttl)

                    except:
                        print('CACHE: Error caching response')

                    # Send response
                    return results
                else:
                    return {'success': False,
                            'error': 'An unexpected error occured'}
            else:
                # Caching disabled proceed with original function
                return fn(*args, **kwargs)

        return inner_fn
    return outer_fn

