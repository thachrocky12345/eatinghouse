import requests
import urllib
import datetime
import json
from datetime import timedelta
from sbt_common import SbtGlobalCommon
from redis_manager import RedisManager
from dateutil.parser import parse

config = SbtGlobalCommon.get_sbt_config()
cc_config = config["api_feeds"]["benzinga_api"]
base_url = cc_config["base_url"]
api_key = cc_config["api_key"]
redis_manager = RedisManager()


def get_expire_at():
    current_datetime = datetime.datetime.utcnow()
    current_time = timedelta(hours=current_datetime.hour, minutes=current_datetime.minute,
                             seconds=current_datetime.second)
    if current_datetime.hour < 13:
        difference = timedelta(hours=13, minutes=00, seconds=00) - current_time
        return difference
    else:
        difference = timedelta(days=1, hours=7, minutes=00, seconds=00) - current_time
        return difference

def general_filters(query_params, filtered_events):
    if query_params['eps'] is not None:
        eps = float(query_params['eps'])
        filtered_events = list(filter(lambda event: event['eps'] >= eps, filtered_events))

    if query_params['revenue'] is not None:
        revenue = float(query_params['revenue'])
        filtered_events = list(filter(lambda event: event['revenue'] >= revenue, filtered_events))

    if query_params['importance'] is not None:
        filtered_events = list(filter(lambda event: event['importance'] == query_params['importance'], filtered_events))

    return filtered_events

def convert_str_to_float(events):
    for event in events:
        for key in event:
            if key == 'eps' or key == 'revenue':
                try:
                    event[key] = float(event[key])
                except Exception as e:
                    event[key] = 0.0

    return events

def date_filters(query_params, events):
    if query_params['date_from'] is not None and query_params['date_to'] is None:
        filtered_events = list(filter(lambda event: parse(event['date']) >= parse(query_params['date_from']), events))
    elif query_params['date_to'] is not None and query_params['date_from'] is None:
        filtered_events = list(filter(lambda event: parse(event['date']) <= parse(query_params['date_to']), events))
    elif query_params['date_to'] is not None and query_params['date_from'] is not None:
        filtered_events = list(filter(lambda event: parse(query_params['date_from']) <= parse(event['date']) <= parse(query_params['date_to']), events))
    else:
        filtered_events = list(filter(lambda event: parse(event['date']) >= datetime.datetime.today(), events))

    return filtered_events


class BenzingaApi(object):
    # query_param = {'parameters[date]': '2019-11-22'}
    # data = calendar_events('calendar/earnings', query_param)

    def _calendar_events(self, urlpart, params={}, method="GET"):
        q_params = {}
        q_params['token'] = api_key
        q_params['pagesize'] = 1000
        page = 0
        result = []

        if 'date_from' in params.keys():
            q_params['parameters[date_from]'] = params['date_from']

        if 'date_to' in params.keys():
            q_params['parameters[date_to]'] = params['date_to']

        if 'symbols' in params.keys():
            q_params['parameters[tickers]'] = params['symbols']

        calendar_name = urlpart.split('/')[-1]
        url = urllib.parse.urljoin(base_url, urlpart)

        while True:
          q_params['page'] = page
          req = requests.request(method, url, params=q_params, headers={"accept": "application/json"})
          response = req.json()
          if calendar_name in response:
            result.extend(response[calendar_name])
            page += 1
          else:
            break
            
        return result

    def fetch_events(self, key_name, urlpart):
        if redis_manager.cache_key_exists(key_name):
          return redis_manager.get_value(key_name).decode()
        else:
          today = datetime.date.today()
          coming_monday = today + datetime.timedelta(days=-today.weekday(), weeks=1)
          previous_moday = today - datetime.timedelta(days=today.weekday(), weeks=1)
          date_from = previous_moday - datetime.timedelta(days=1)
          date_to = coming_monday + datetime.timedelta(days=5)
          calendar_name = urlpart.split('/')[-1]
          events = self._calendar_events(urlpart, {'date_from': date_from, 'date_to': date_to})
          if len(events) > 0:
            events = convert_str_to_float(events)
            key_name = calendar_name + '_events'
            redis_manager.set_value(key_name, json.dumps(events), 14400)
            return json.dumps(events)
          else:
            return json.dumps([])

    def fetch_symbols(self, urlpart, key, q_params):
      if redis_manager.cache_key_exists(key):
        return redis_manager.get_value(key).decode()
      else:
        events = self._calendar_events(urlpart, q_params)
        if len(events) > 0:
          events = convert_str_to_float(events)
          redis_manager.set_value(key, json.dumps(events), 14400)
          return json.dumps(events)
        else:
          return json.dumps([])

    def get_symbol_events(self, calendar_name, symbols, filter_params={}):

        actual_symbols = []
        q_symbols = symbols.split(',')
        for symbol in q_symbols:
            sym = symbol.split('~')[0]
            actual_symbols.append(sym.upper())
        symbols = "".join(actual_symbols)
        key_name = symbols + '_events'
        url = 'calendar/' + calendar_name
        query_params = {}
        query_params['symbols'] = symbols

        events = self.fetch_symbols(url, key_name, query_params)
        filtered_events = json.loads(events)
        filtered_events = date_filters(filter_params, filtered_events)
        filtered_events = general_filters(filter_params, filtered_events)

        return filtered_events

    def get_calendar_events(self, calendar_name, query_params={}):
        filtered_events = None
        key_name = calendar_name + '_events'

        events = self.fetch_events(key_name, 'calendar/' + calendar_name)
        events = json.loads(events)
        filtered_events = date_filters(query_params, events)
        filtered_events = general_filters(query_params, filtered_events)

        return filtered_events
