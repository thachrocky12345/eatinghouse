import os
import sys
import json
import cherrypy
import bottle
import logging

from time import sleep
from sbt_common import SbtGlobalCommon, Singleton

bottle.BaseRequest.MEMFILE_MAX = 2048 * 1024 * 512

lname   = os.path.splitext(os.path.basename(__file__))[0]
logger  = SbtGlobalCommon.get_logger(logging.INFO, lname)
xapikey = SbtGlobalCommon.get_api_token_value()

def strip_path():
  """
  IGNORE TRAILING SLASHES IN BOTTLE ROUTES
  """
  bottle.request.environ['PATH_INFO'] = bottle.request.environ['PATH_INFO'].\
    rstrip('/')

def add_cors_headers():
  bottle.response.headers['Access-Control-Allow-Origin']  = '*'
  bottle.response.headers['Access-Control-Allow-Methods'] = \
      'GET, POST, PUT, OPTIONS'
  bottle.response.headers['Access-Control-Allow-Headers'] = \
      'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token, ApiKey, X-Api-Key'

def json_error(error, additional_params=None):
  """
  :param error:
  :return:
  """
  error.content_type = 'application/json'
  rval = {'success': False, 'error': error.args[1]}
  
  if additional_params and isinstance(additional_params, dict) :
    rval.update(additional_params)

  #use : https... to specify redirect url TODO: remove
  if 'https' in error.args[1]:
    parts = (error.args[1].split(': '))
    url   = parts[1]
    msg   = parts[0]
    rval['error']    = msg
    rval['redirect'] = url

  return json.dumps(rval)

class ServiceUtils(object, metaclass=Singleton):
  """
    ServiceUtils
  """
  def __init__ (self):
    """
      Constructor
    """
    self.configured = False
    self.services   = dict()
    self.configure()

  def configure(self):
    logger.info('ServiceUtils configured')
    self.configured = True

  def register(self, name, service):
    self.services[name] = service

  def log_headers(self, req):
    """
    :param req:
    :return:
    """
    headers = ''
    for k, v in req.headers.items():
      headers += 'k: ' + str(k) + ', v: ' + str(v) + '\n'

    logger.debug('Request headers\n' + headers)

  def validate_xapikey(self, req):
    """
    Validate the x-api-key header
    :param req: Request containing headers
    :return: True if present and valid
    """
    logger.info('Validating x-api-key for raddr:' + str(req.remote_addr) +
                ' rroute:' + str(req.remote_route))
    #TODO: If properly configured in apigateway AWS rejects and deprecate this

    reqkey = req.headers.get('X-Api-Key')

    if reqkey:
      authorized = reqkey == xapikey
      if not authorized: logger.info('X-Api-Key Invalid')
    else:
      #TODO: disabled because of constant ping
      #logger.debug('Request does not contain X-Api-Key')
      #self.log_headers(req)
      authorized = False

    return authorized

  def get_api_key(self, req):
      return req.headers.get('apikey')

  @staticmethod
  def sig_handler(service, _signo, _stack_frame):
    """
    Handle termination signals and clean up service resources
    :param _signo:
    :param _stack_frame
    """
    logger.info('Received signal ' + str(_signo) + '\nstack frame: ' +
                str(_stack_frame) + ' service: ' + service)

    inst = None
    if service in ServiceUtilsGlobal.services:
      inst = ServiceUtilsGlobal.services[service]
      inst.fin = True
      sleep(0.5)
      inst.clean()


    if inst:
      bottle.response.headers['Connection'] = 'close'
      #del ServiceUtilsGlobal.services[service] #unregister?
      sleep(0.5)
    else:
      logger.info('No service: ' + service + ' registered' )

    cherrypy.engine.stop()
    cherrypy.engine.exit()

    logger.info("System exiting now...")
    sys.exit(0)

ServiceUtilsGlobal = ServiceUtils()
