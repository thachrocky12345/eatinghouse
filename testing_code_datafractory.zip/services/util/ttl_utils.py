import re
from decimal import Decimal
import time


SECOND = 1
MINUTE = 60
HOUR = 3600
DAY = 86400
WEEK = 604800
MONTH = 2628000
YEAR = 31536000


def _parse( value: str or int, unit='seconds' ):
    if type(value) is int:
        return value
    try:
        duration_unit = re.sub('[\s.0-9\W]', '', value)
        duration = Decimal(''.join(i for i in value if i.isdigit() or i == '.'))
    except:
        raise Exception('Cannot parse invalid duration string.')

    # Allow milliseconds
    if unit is 'milliseconds':
        duration = duration * 1000

    if duration_unit.startswith('s'):
        return int(duration * SECOND)
    elif duration_unit.startswith('mi'):
        return int(duration * MINUTE)
    elif duration_unit.startswith('h'):
        return int(duration * HOUR)
    elif duration_unit.startswith('d'):
        return int(duration * DAY)
    elif duration_unit.startswith('w'):
        return int(duration * WEEK)
    elif duration_unit.startswith('mo'):
        return int(duration * MONTH)
    elif duration_unit.startswith('y'):
        return int(duration * YEAR)

    # FALLBACKS
    elif duration_unit.startswith('mt'):
        return int(duration * MONTH)
    elif duration_unit.startswith('m'):
        return int(duration * MINUTE)


def str_to_epoch(text, units='seconds'):
    if units.startswith('m'):
        return time.time() + _parse(text) * 1000
    else:
        return time.time() + _parse(text)


def str_to_ttl(text, units='seconds'):
    if units.startswith('m'):
        return _parse(text, 'milliseconds')
    else:
        return _parse(text, 'seconds')


def str_to_seconds(text):
    return _parse(text, 'seconds')


def str_to_milliseconds(text):
    return _parse(text, 'milliseconds')
