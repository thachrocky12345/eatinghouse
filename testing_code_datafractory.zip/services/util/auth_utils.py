import cherrypy
import http
import logging
import bottle
from sbt_common import SbtGlobalCommon
from security_util import SecurityUtil
from bottle import request, response
from ws4py.websocket import WebSocket

um = SecurityUtil.get_up_manager()
logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
xapikey = SbtGlobalCommon.get_api_token_value()

def _create_entitlement_slugs(publication_code, user_level=0):
  slugs = []
  levels = [100, 200, 300, 400, 500, 600]
  code = publication_code.lower()

  for level in levels:
    if user_level >= level:
      slugs.append(str(level) + '-' + str(code))
    else:
      break
  return slugs


# Authenticated Decorator
def authenticated(original_function):
  def new_function(*args, **kwargs):
    rval = None
    is_authenticated = False

    # Authentication check
    try:
      if 'ApiKey' in request.headers and 'X-Api-Key' in request.headers :
        reqkey = request.headers.get('X-Api-Key')

        # If logged in with at minimum 1 entitlement
        if reqkey == xapikey and \
        len(um.get_entitlements_by_api_key(request.headers['ApiKey'])) > 0:
          rval = original_function(*args, **kwargs)
          is_authenticated = True
        else :
          logger.warn('Unauthorized access from raddr:' + 
                      str(request.remote_addr) +
                      ' rroute:' + str(request.remote_route))          
    except ValueError:
      logger.warn('Unauthorized access from raddr:' + 
                  str(request.remote_addr) +
                  ' rroute:' + str(request.remote_route))

    if not is_authenticated :
      bottle.abort(401, 
                   'Unauthorized access')
    
    return rval
  return new_function


# Authenticated decorator that passes the user's profile info to the function
def authenticated_profile(original_function):
  def new_function(*args, **kwargs):
    rval = {'success': False, 'error': 'User is not authenticated'}

    # Authentication check
    if 'ApiKey' not in request.headers:
      response.status = http.HTTPStatus.UNAUTHORIZED
      return {'success': False, 'error': 'ApiKey not found'}

    user = um.get_profile_by_api_key(request.headers['ApiKey'])
    if user and user.get("guid"):
      try:
        rval = original_function(user, *args, **kwargs)
      except Exception as e:
        logger.exception('Error in {}'.format(request.route))
        response.status = http.HTTPStatus.INTERNAL_SERVER_ERROR
        return {'success': False, 'error': str(e)}

    return rval
  return new_function


# Authenticated decorator that passes the user's profile info to the function
def userprofile(original_function):
  def new_function(*args, **kwargs):
    rval = {'success': False, 'error': 'Could not get profile.'}

    # Authentication check
    if 'ApiKey' not in request.headers:
      response.status = http.HTTPStatus.UNAUTHORIZED
      return {'success': False, 'error': 'ApiKey not found'}

    user = um.get_profile_by_api_key(request.headers['ApiKey'])
    if user and user.get("guid") or user.get("snaid"):
      try:
        rval = original_function(*args, user_profile=user, **kwargs)
      except Exception as e:
        logger.exception('Error in {}'.format(request.route))
        response.status = http.HTTPStatus.INTERNAL_SERVER_ERROR
        return {'success': False, 'error': str(e)}

    return rval
  return new_function

# Entitlements Decorator
def entitlements(original_function):
  def new_function(*args, **kwargs):
    user_entitlements = []

    try:
      if 'ApiKey' in request.headers:
        entitlements = um.get_entitlements_by_api_key(request.headers['ApiKey'])

        entitlements_list = []
        if isinstance(entitlements, list) : 
          entitlements_list = entitlements
        elif isinstance(entitlements, dict) :
          entitlements_list = entitlements.get('publication', [])
        
        if len(entitlements_list) > 0:
          # Manually add free publications
          user_entitlements += _create_entitlement_slugs('ipm', 100)
          user_entitlements += _create_entitlement_slugs('sdw', 100)
          user_entitlements += _create_entitlement_slugs('hwb', 100)
          user_entitlements += _create_entitlement_slugs('trd', 100)
          user_entitlements += _create_entitlement_slugs('crux', 100)
          user_entitlements += _create_entitlement_slugs('emp', 100)
          user_entitlements += _create_entitlement_slugs('eir', 100)
          user_entitlements += _create_entitlement_slugs('alt', 100)
          user_entitlements += _create_entitlement_slugs('empire-financial-daily', 100)
          user_entitlements += _create_entitlement_slugs('sow', 100)
          user_entitlements += _create_entitlement_slugs('tow', 100)
          user_entitlements += _create_entitlement_slugs('bpf', 100)
          user_entitlements += _create_entitlement_slugs('crf', 100)
          user_entitlements += _create_entitlement_slugs('pbf', 100)
          user_entitlements += _create_entitlement_slugs('jcf', 100)
          user_entitlements += _create_entitlement_slugs('lgf', 100)
          user_entitlements += _create_entitlement_slugs('amc', 100)

          for entitlement in entitlements_list:
            try:
              if entitlement['status'] == 'ACTIVE':
                user_entitlements = user_entitlements + \
                                    _create_entitlement_slugs(entitlement['id']['item']['itemNumber'],
                                                              entitlement['levelWeight'])
            except Exception as e:
              logger.error(str(e))

          rval = original_function(user_entitlements, *args, **kwargs)
        else:
          # A user should never have 0 entitlements
          rval = {'success': False, 'error': 'User has zero entitlements'}
      else:
        rval = {'success': False, 'error': 'Invalid or expired api key'}
    except ValueError as err:
      print(err)
      logger.error("Error in userentitlements: "+ str(err))
      rval = {'success': False, 'error': 'User is not authenticated'}
    return rval
  return new_function


# Authenticated class for Web Sockets
class AuthenticatedWebSocket(WebSocket):
  def opened(self):
    super().opened()

    headers = cherrypy.serving.request.headers
    if "ApiKey" in headers:
      self._user = um.get_profile_by_api_key(headers["ApiKey"])
