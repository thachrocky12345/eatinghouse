import bottle
import cherrypy
import logging
import logstash
import signal
import simplejson
import sys

from sbt_common import SbtGlobalCommon

bottle.BaseRequest.MEMFILE_MAX = 2**30
app = bottle.Bottle()

logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)
config = SbtGlobalCommon.get_sbt_config()

# Set up logging and start cherrypy
def start_app(config):
    signal.signal(signal.SIGTERM, sigterm_handler)

    if "logstash" in config:
        logger.info("configuring logstash")
        logger.addHandler(
            logstash.TCPLogstashHandler(
                config["logstash"]["domain"],
                config["logstash"]["port"],
                version=config["logstash"]["version"],
            )
        )

    cherrypy.tree.graft(app, config["root_endpoint"])
    cherrypy.server.unsubscribe()
    cherrypy.config.update(config["server"])
    cherrypy.server.subscribe()

    cherrypy.engine.start()

    logger.info("cherrypy running")

# Exit cleanly on SIGTERM
def sigterm_handler(self, signo, stack_frame):
    logger.info("received sigterm")

    cherrypy.engine.stop()
    cherrypy.engine.exit()

    bottle.response.headers["Connection"] = "close"

    sys.exit(0)

# Handle OPTIONS request on any URL
@app.route("/<:re:.*>", method="OPTIONS")
def options_method():
    pass

# Log uncaught exceptions and return a JSON response
def error_handler(func):
    def inner_func(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except bottle.HTTPError:
            raise
        except Exception as e:
            logger.exception("Exception in {} {}: {}".format(bottle.request.method, bottle.request.url, str(e)))
            return error_page(bottle.HTTPError(500, str(e)))

    return inner_func

app.install(error_handler)

# Return a valid JSON response with an error message when using bottle.abort
@app.error(400)
@app.error(401)
@app.error(500)
def error_page(error):
    bottle.response.add_header("Content-Type", "application/json")
    return simplejson.dumps({"success": False, "error": str(error.body)})

