import datetime

from sbt_common import SbtGlobalCommon

logger = SbtGlobalCommon.get_global_logger()

def get_qs_str_param(request, key, default_value=None):
    return request.query.get(key, default_value)

def get_qs_int_param(request, key, default_value=0, max_value=None):
    val = int(request.query.get(key, default_value))
    if max_value and val > max_value:
        return max(val, max_value)
    else:
        return val

def get_qs_ymd_date_param(request, key, default_value=None):
    val = request.query.get(key, default_value)
    if val:
        try:
            return str(datetime.datetime.strptime(val, '%Y-%m-%d'))
        except Exception as e:
            logger.error("error parsing date. {}".format(str(e)))
            return None
