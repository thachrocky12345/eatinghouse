from elasticsearch_dsl import Q
from article_utils import ArticleHelper

class ArticleQueryHelper():
  def __init__(self):
    self.configured = True

  def __enter__(self):
    """
    Entry Point
    """
    return self

  @staticmethod
  def add_entitlements_filter(es_filter, user_entitlements):
    if len(user_entitlements) > 0 and user_entitlements[0] != '':
      es_filter.append(Q('terms', **{'defaultPublication.slug':
                                     user_entitlements}))

  @staticmethod
  def add_newsletter_filter(es_filter):
    newsletter_categories = ArticleHelper.newsletter_categories()
    es_filter.append(Q('terms', categories=newsletter_categories))

  @staticmethod
  def add_article_categories_filter(es_filter):
    categories = ArticleHelper.article_categories()
    es_filter.append(Q('terms', categories=categories))

  @staticmethod
  def add_symbol_filter(es_filter, symbol):
    if symbol:
      es_filter.append(Q('term', **{'tickers.keyword': symbol}))

  @staticmethod
  def add_start_date_filter(es_filter, start_date):
    if start_date:
      es_filter.append(Q("range", createdAt={"gte": start_date,
                                             "format": "epoch_millis"}))

  @staticmethod
  def add_date_restriction_filter(es_filter):
    es_filter.append(Q("range", createdAt={"lte": "now-90d/m"}))







