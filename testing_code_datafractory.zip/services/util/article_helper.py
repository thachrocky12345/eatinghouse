import time

article_categories = (
  'newswire',
  'newsletters_weekly',
  'newsletters_monthly',
  'newsletters_daily',
  'market-extremes',
  'special_reports',
  'updates',
  'trades',
  'external_article')

newswire_categories = ('newswire',)

article_types = ('post',
                 'daily_wealth')

newsletter_categories = (
  'newsletters_weekly',
  'newsletters_monthly',
  'newsletters_daily',
  'market-extremes',
  'special_reports',
  'updates',
  'trades',
  'external_article')

streamable_article_types = (
  'newswire',
  'newsletter')

streamable_statuses = ('publish',)
savable_statuses = ('publish',)
deletable_statuses = ('trash',)

class ArticleHelper():
  def __init__(self):
    self.configured = True

  def __enter__(self):
    """
    Entry Point
    """
    return self

  @staticmethod
  def get_base_type(article):
    """
    Identify if the item passed is an article
    return: boolean
    """
    if ArticleHelper.is_newswire(article):
      return 'newswire'
    elif ArticleHelper.is_newsletter(article):
      return 'newsletter'
    return 'unknown'

  @staticmethod
  def should_save(validated_article):
    """
    Identify if the item passed is an article
    return: boolean
    """
    if validated_article.get('status', '') in savable_statuses:
      return True
    return False

  @staticmethod
  def should_stream(validated_article):
    """
    Identify if the item meets core criteria to stream
    return: boolean
    """
    should_stream_article = False

    try:
      if validated_article.get('status', '') in streamable_statuses \
        and validated_article.get('base_type', '') in streamable_article_types:
          if validated_article['createdAt'] > 9999999999:
            # 3 days in milliseconds
            min_stream_date = int(round(time.time() * 1000)) - 259200000
          else:
            # 3 days in seconds
            min_stream_date = int(round(time.time())) - 259200

          if validated_article['createdAt'] >= min_stream_date:
            should_stream_article = True

    except ValueError as e:
      should_stream_article = False
    return should_stream_article

  @staticmethod
  def should_stream_by_channel(validated_article, channel):
    """
    Identify if the should be streamed based on channel
    return: boolean
    """

    if ArticleHelper.should_stream(validated_article):
      if validated_article.get('base_type', '') == channel:
        return True
      if channel == 'stansberry-content':
        return True
    return False

  @staticmethod
  def has_publication_code(article, publication_code=''):
    """
    Identify if the article passed is a newsletter article
    return: boolean
    """
    has_code = False

    # Return if not empty publication_code
    if publication_code == '':
      return has_code

    for publication in article.get('publications', []):
      if isinstance(publication, dict) \
        and publication.get('publicationCode', '') == publication_code:
        has_code = True

    return has_code

  @staticmethod
  def get_sub_types(article):
    """
    Identify if the article passed is a newsletter article
    return: boolean
    """
    sub_types = []
    if article.get('title', '') \
       .find('Morning Market Preview') >= 0:
         sub_types.append('morning_market_preview')

    if article.get('title', '') \
       .find('Morning Market Headlines') >= 0:
         sub_types.append('morning_market_headlines')

    if article.get('title', '') \
       .find('Morning Market Comments, Calendars') >= 0:
         sub_types.append('morning_market_comments')

    if article.get('title', '') \
       .find('Afternoon Market Recap') >= 0:
         sub_types.append('afternoon_market_recap')

    return sub_types

  @staticmethod
  def is_article(article):
    """
    Identify if the item passed is an article
    return: boolean
    """
    valid_article_categories = ArticleHelper.article_categories()

    # article must be a post
    if article.get('type', '') not in article_types:
      return False

    # article categories must include at least one valid article category
    categories = article.get('categories', [])
    for category in categories:
      if category in valid_article_categories:
        return True

    # category match in valid categories not found
    return False

  @staticmethod
  def is_newswire(article):
    """
    Identify if the article passed is a newswire article
    return: boolean
    """
    # TODO: Do we need to check newswire category?
    passed = False

    if ArticleHelper.is_article(article):

      for publication in article.get('publications', []):
        if isinstance(publication, dict) \
           and publication.get('publicationCode', '') == 'new':
            passed = True

      if passed:
        for category in article.get('categories', []):
          if category in ArticleHelper.newswire_categories():
            return True

      return False


    return False

  @staticmethod
  def is_newsletter(article):
    """
    Identify if the article passed is a newsletter article
    return: boolean
    """
    if ArticleHelper.is_article(article) \
       and ArticleHelper.is_newswire(article) is False:
      categories = article.get('categories', [])

      for category in categories:
        if category in ArticleHelper.newsletter_categories():
          return True
        else:
          return False
    return False

  @staticmethod
  def newsletter_categories():
    """
    Returns a list of valid newsletter categories
    """
    return newsletter_categories

  @staticmethod
  def newswire_categories():
    """
    Returns a list of valid newswire categories
    """
    return newswire_categories

  @staticmethod
  def article_categories():
    """
    Returns a list of valid article categories categories
    """
    return article_categories
