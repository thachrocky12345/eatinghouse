
class ArticleRequestHelper:
  def __init__(self):
    self.configured = True

  def __enter__(self):
    """
    Entry Point
    """
    return self



  @staticmethod
  def extract_days_params(request):
    """
    Identify if the item passed is an article
    return: boolean
    """
    try:
      days = int(request.query.get('days', '0'))
    except:
      days = 0

    return days

  @staticmethod
  def extract_paging_params(request):
    """
    Identify if the item passed is an article
    return: boolean
    """
    # Paging
    try:
      page = int(request.query.get('page', '1'))
      count = int(request.query.get('count', '25'))

      if count > 50:
        count = 50
    except:
      page = 1
      count = 25

    start_record = (page - 1) * count
    end_record = page * count

    paging = {'page': page,
              'count': count,
              'start': start_record,
              'end': end_record}

    return paging

  @staticmethod
  def extract_param_list(request, param_name=''):
    """
    Identify if the item passed is an article
    return: boolean
    """
    res_list = []

    if param_name != '':
      try:
        res_list = request.query.get(param_name, '').lower()
        res_list = res_list.split(',')
        if len(res_list) == 0 or res_list[0] == '':
          res_list = []
      except:
        res_list = []

    return res_list

  @staticmethod
  def extract_boolean_param(request, param_name=''):
    """
    Identify if the item passed is an article
    return: boolean
    """
    res_list = []

    if param_name != '':
      try:
        res_boolean = request.query.get(param_name, None).lower()
        if res_boolean == 'true':
          res_boolean = True
        elif res_boolean == 'false':
          res_boolean = False
      except:
        res_boolean = None

    return res_boolean
