import datetime

def get_current_timestamp_iso():
    return str(datetime.datetime.now().isoformat())