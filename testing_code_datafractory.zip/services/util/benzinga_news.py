import uuid
import bs4
import simplejson
from datetime import datetime
from decimal import Decimal
from dateutil.parser import parse
from dd_accessor import DynamoAccessor
from mongo_accessor import MongoAccessor
from redis_manager import RedisManager
from process_external_articles import EsexternalArticles
from external_article import ExternalArticle
from bson.json_util import dumps
from bson.json_util import loads

redis_manager = RedisManager()
dd = DynamoAccessor()
es = EsexternalArticles()
mongo_accessor = MongoAccessor('benzinga_articles')
channel_name = "news"


def arry_hash_to_arry_string(array_of_hash, key):
    data = []
    if len(array_of_hash) > 0:
        for hsh in array_of_hash:
            data.append(hsh[key])

    return data


def parse_date(str_date):
    if str_date:
        try:
            return parse(str_date).timestamp()
        except ValueError:
            print(str_date)
            print("Invalid Date String")
    else:
        print("Invalid Date String")

    return datetime.utcnow().timestamp()


def external_article_schema(news_json):
    db_structure = {
        'uuid': str(uuid.uuid4()),
        'external_id': str(news_json['id']),
        'created_at': str(datetime.utcnow().timestamp()),
        'updated_at': str(datetime.utcnow().timestamp()),
        'source': 'benzinga_news',
        'external': True
    }

    if 'published' in news_json.keys():
        db_structure['published_at'] = Decimal(parse_date(news_json['published']))
    else:
        db_structure['published_at'] = Decimal(datetime.utcnow().timestamp())

    if 'title' in news_json.keys():
        db_structure['title'] = news_json['title']

    if 'body' in news_json.keys() and news_json['body'].strip() != '':
        text = bs4.BeautifulSoup(news_json['body'], "html.parser").text[:200]
        db_structure['description'] = text
        db_structure['content'] = news_json['body']

    if 'link' in news_json.keys() and news_json['link'] is not None:
        db_structure['article_url'] = news_json['link']

    if 'authors' in news_json.keys():
        authors = arry_hash_to_arry_string(news_json['authors'], 'name')
        if len(authors) > 0:
            db_structure['authors'] = authors

    if 'tickers' in news_json.keys():
        db_structure['tickers'] = [ticker.lower() for ticker in arry_hash_to_arry_string(news_json['tickers'], 'name')]

    if 'channels' in news_json.keys():
        db_structure['channels'] = [channel.lower() for channel in news_json['channels']]

    return db_structure


# Class to restructure new as per dynamodb
class BenzingaNews(object):
    def __init__(self, bz_news_json):
        self.bz_news_json = bz_news_json

    def process_message(self):
        self.benzinga_article(self.bz_news_json)

    def benzinga_article(self, news_json):
        if news_json:
            es_data = external_article_schema(news_json)

            self.upsert_mongo(news_json)
            self.upsert_es(es_data, news_json)

            if news_json['status'].lower() != 'removed':
                article_item = dd.articles_json([es_data])
                redis_manager.publish(channel_name, simplejson.dumps(article_item[0]))

    @staticmethod
    def upsert_es(es_data, news_json):
        es_conditions = [
        {'external_id': es_data['external_id']},
        {'source': 'benzinga_news'}]
        response = ExternalArticle.find_by(es_conditions)

        if 'articles' in response.keys() and len(response['articles']) > 0:
            if 'id' in response['articles'][0].keys():
                print('Updating' + response['articles'][0]['id'])
                es_data['uuid'] = response['articles'][0]['id']
            else:
                es_data['uuid'] = str(uuid.uuid4())
            es_data['updated_at'] = str(datetime.utcnow().timestamp())

        if news_json['status'].lower() == 'removed':
            if len(response['articles']) > 0:
                es.remove_document(es_data['uuid'])
        else:
            try:
                es.process(es_data)
            except:
                print('Unable to process indexing')

    @staticmethod
    def upsert_mongo(mongo_data):
        condition = {'id': mongo_data['id']}
        existing_data = mongo_accessor.find(condition)

        if existing_data.count() > 0:
            # When status is Removed we are updating only the status field, instead updating complete response from socket.
            if mongo_data['status'].lower() == 'removed':
                # 1. Convert the cursor object into JSON
                # 2. Delete the existing '_id'
                # 3. Update the status
                db_data = loads(dumps(existing_data))[0]
                del db_data['_id']
                db_data['status'] = mongo_data['status']
                mongo_data = db_data

            mongo_accessor._replace_data(condition, mongo_data)
        else:
            mongo_accessor._insert_data(mongo_data)
 
