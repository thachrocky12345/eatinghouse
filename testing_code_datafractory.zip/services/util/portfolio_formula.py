

class PortfolioFormula:

    def __init__(self, position):
        convert = lambda i: i or 0
        self.current_price = convert(position['current_price'])
        self.close_price = convert(position['close_price'])
        self.entry_price = convert(position['entry_price'])
        self.dividend_total = convert(position['dividend_total'])
        self.num_shares = convert(position['num_shares'])
        self.closed_position = (position['status_type'].lower() == 'close')
        self.trade_type = position['trade_type']
        self.latest_close = convert(position['latest_close'])

    def get_daily_gain_formula(self):
        formula = ''

        if not self.closed_position:
            formula = '(Current Price - Latest Close) * Number of Shares \n ({current_price} - {latest_close}) * ' \
                      '{num_shares}'.format(current_price=self.current_price,
                                            latest_close=self.latest_close,
                                            num_shares=self.num_shares)

        return formula

    def get_daily_percentage_formula(self):
        formula = ''

        if not self.closed_position:
            formula = '((Current Price - Latest Close) / Latest Close) * 100 \n (({current_price} - {latest_close}) /' \
                      ' {latest_close}) * 100'.format(current_price=self.current_price, latest_close=self.latest_close)

        return formula

    def get_total_gain_formula(self):

        if self.trade_type.lower() == 'long':
            if self.closed_position:
                formula = '(Close Price - Entry Price + Dividend Total) * Number of Shares \n ({close_price} - ' \
                          '{entry_price} + {dividend_total}) * {num_shares}'.format(close_price=self.close_price,
                                                                                    entry_price=self.entry_price,
                                                                                    dividend_total=self.dividend_total,
                                                                                    num_shares=self.num_shares)
            else:

                formula = '(Current Price - Entry Price + Dividend Total) * Number of Shares \n ({current_price} - ' \
                          '{entry_price} + {dividend_total}) * {num_shares}'.format(current_price=self.current_price,
                                                                                    entry_price=self.entry_price,
                                                                                    dividend_total=self.dividend_total,
                                                                                    num_shares=self.num_shares)
        else:
            if self.closed_position:
                formula = '(Entry Price - Close Price - Dividend Total) * Number of Shares \n ({entry_price} - ' \
                          '{close_price} - {dividend_total}) * {num_shares}'.format(entry_price=self.entry_price,
                                                                                    close_price=self.close_price,
                                                                                    dividend_total=self.dividend_total,
                                                                                    num_shares=self.num_shares)
            else:
                formula = '(Entry Price - Current Price - Dividend Total) * Number of Shares \n ({entry_price} - ' \
                          '{current_price} - {dividend_total}) * {num_shares}'.format(entry_price=self.entry_price,
                                                                                      current_price=self.current_price,
                                                                                      dividend_total=self.dividend_total,
                                                                                      num_shares=self.num_shares)
        return formula

    def get_total_percentage_formula(self):

        if self.trade_type.lower() == 'long':
            if self.closed_position:
                formula = '((Close Price - Entry Price + Dividend Total) / Entry Price) * 100 \n (({close_price} - ' \
                          '{entry_price} + {dividend_total}) / {entry_price}) * 100'.format(
                               close_price=self.close_price,
                               entry_price=self.entry_price,
                               dividend_total=self.dividend_total
                          )
            else:
                formula = '((Current Price - Entry Price + Dividend Total) / Entry Price) * 100 \n (({current_price}' \
                          ' - {entry_price} + {dividend_total}) / {entry_price}) * 100'.format(
                               current_price=self.current_price,
                               entry_price=self.entry_price,
                               dividend_total=self.dividend_total
                          )
        else:
            if self.closed_position:
                formula = '((Entry Price - Close Price - Dividend Total) / Entry Price) * 100 \n (({entry_price} - ' \
                          '{close_price} - {dividend_total}) / {entry_price}) * 100'.format(
                               entry_price=self.entry_price,
                               close_price=self.close_price,
                               dividend_total=self.dividend_total
                          )
            else:
                formula = '((Entry Price - Current Price - Dividend Total) / Entry Price) * 100 \n (({entry_price} - ' \
                          '{current_price} - {dividend_total}) / {entry_price}) * 100'.format(
                               entry_price=self.entry_price,
                               current_price=self.current_price,
                               dividend_total=self.dividend_total
                          )

        return formula
