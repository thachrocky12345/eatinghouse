import logging
import re
from boto3.dynamodb.conditions import Key, Attr
from bs4 import BeautifulSoup
from datetime import datetime
from sbt_common import SbtCommon
from dd_accessor import DynamoAccessor
from elasticsearch_manager import ElasticsearchManager

sbtcommon = SbtCommon()
config = sbtcommon.raw_sbt_config

logger = sbtcommon.get_logger(logging.DEBUG, 'apmanager')

# ES cluster environments to be updated when a change occurs
ES_CLUSTER_ENVS = ['dev', 'qa', 'prod']

# get ES manager & client
es_manager = {env: ElasticsearchManager(None, config[env]["elasticsearch"])
              for env in ES_CLUSTER_ENVS}
es_client = {k: v._es for k, v in es_manager.items()}

# DynamoDB accessor & client & streams
dynamo_accessor = DynamoAccessor()
session = dynamo_accessor._session
dynamodb_client = session.client("dynamodb")

# get the DynamoDB table name where the articles are
DYNAMO_TABLE_NAME = config['services']['process_external_articles']['dynamo_table_name']
# get the DynamoDB primary key's name
ES_DYNAMO_PK = config['services']['process_external_articles']['dynamo_pk']
# get the elasticsearch index and doc type to be used
ES_INDEX = config['services']['process_external_articles']['es_index_name']
ES_DOCTYPE = config['services']['process_external_articles']['es_doctype']


def get_tags_list(soup, tag):
    all_tags = soup.find_all(tag)
    tags_list = [x.get_text() for x in all_tags if len(x.get_text()) > 0]
    return tags_list


def get_symbols_list(text):
    # use the following regex: \(\b[A-Z]{1,5}\b\)
    pattern = re.compile(r'\(\b[A-Z]{1,5}\b\)')
    symbols_list = pattern.findall(text)
    symbols_list = [re.sub("\(|\)", "", x) for x in symbols_list]
    return symbols_list


class EsexternalArticles(object):

    def process(self, article):
        logger.info("Processing article {}".format(article[ES_DYNAMO_PK]))

        if 'created_at' in article.keys():
            article['created_at'] = float(article['created_at'])
        else:
            article['created_at'] = float(datetime.utcnow().timestamp())

        if 'updated_at' in article.keys():
            article['updated_at'] = float(article['updated_at'])
        else:
            article['updated_at'] = float(datetime.utcnow().timestamp())


        if "content" in article:
            soup = BeautifulSoup(article["content"], "html")
            htags = ["h1", "h2", "h3", "h4", "h5", "h6"]

            article["extracted_paragraphs"] = get_tags_list(soup, "p")
            article["extracted_headerTags"] = get_tags_list(soup, htags)
            article["extracted_boldTags"] = get_tags_list(soup, "b")

        # indexing processed doc into Elasticsearch
        for env in ES_CLUSTER_ENVS:
            try:
                if not es_client[env].indices.exists(ES_INDEX):
                    logging.info("Create missing index: " + ES_INDEX)
                    # es.indices.create(table, body=get_index_settings())
                    es_client[env].indices.create(ES_INDEX)
                    logging.info("Index created: " + ES_INDEX)
                    
                es_client[env].index(
                    index=ES_INDEX,
                    doc_type=ES_DOCTYPE,
                    body=article,
                    id=article[ES_DYNAMO_PK],
                    refresh=True,
                )
            except Exception as e:
                es_client['prod'].index(
                    index=ES_INDEX,
                    doc_type=ES_DOCTYPE,
                    body=article,
                    id=article[ES_DYNAMO_PK],
                    refresh=True,
                )

    def remove_document(self, doc_id):
        logger.info("REMOVING article ID={}.".format(doc_id))
        [es_client[env].delete(
            index=ES_INDEX,
            doc_type=ES_DOCTYPE,
            id=doc_id,
            refresh=True
        ) for env in ES_CLUSTER_ENVS]
        logger.info("doc_id={} DELETED.".format(doc_id))

    def reindex_all_data(self, type, table_name, lek=None):
        filter_exp = Key('source').eq(type)
        if lek is not None:
            response = dynamodb_client._scrolling_scan_table(table_name, filter_exp, lek)
            for item in response['items']:
                logger.info("Indexing article ID={}.".format(item['uuid']))
                self.process(item)
            if response['last_evaluated_key'] is not None:
                reindex_all_data(type, table_name, response['last_evaluated_key'])
            else:
                return
