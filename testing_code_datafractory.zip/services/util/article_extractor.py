import ast
import calendar
import re
import time
import xml.etree.ElementTree as ElementTree
from datetime import datetime


def remove_img_tags(data):
  p = re.compile(r'<img.*?/>')
  return p.sub('', data)

class ArticleExtractor():
  def __init__(self):
    self.configured = True

  def __enter__(self):
    """
    Entry Point
    """
    return self

  @staticmethod
  def extract_daily_market_notes(article):
    """
    Extracts the data needed from an article to create daily market notes
    :param article:
    :return: dict
    """
    dmn_dict = {}

    # Extract only if it's from a publication that include chart of the day.
    if isinstance(article.get("defaultPublication", {}), dict) \
      and article['defaultPublication'].get("publicationCode", "") == "sdw" \
      and article.get("marketNotes", ""):

      # Make sure market notes field is populated
      # Field is specific to SDW Articles
      if article.get("marketNotes", "") != "":
        market_notes = "<div>" + article.get("marketNotes", "") + "</div>"

        #End date for the chart should be published date of the article
        end_date = article.get('createdAt',
                               calendar.timegm(time.gmtime()))

        # if using a time from webteam (is in ms) convert to epoc time
        if len(str(end_date)) == 13:
          end_date = end_date / 1000

        # Set the returnable dictionary.
        dmn_dict['date'] = time.strftime('%Y-%m-%d', time.localtime(end_date))
        dmn_dict['timestamp'] = end_date
        dmn_dict['content'] = remove_img_tags(market_notes)

        # Parse html for chart image
        root_element = ElementTree.fromstring(market_notes)
        cod_img_tag = root_element.findall(".//img")

        try:
          # If image tags found in chart of the day
          if len(cod_img_tag) > 0:
            # Chart of the day is always the last image.
            cod_img_dict = cod_img_tag[len(cod_img_tag) - 1].attrib

            if cod_img_dict.get('cod'):
              cod_tag_attribute = cod_img_dict.get('cod')
              cod_dict = ast.literal_eval(cod_tag_attribute)

              # pull start_date attribute
              start_date = cod_dict.get('start_date', datetime.now()
                                   .strftime("%m%d%Y"))
              start_month = int(start_date[0:2])
              start_year = int(start_date[-4:])
              start_day = int(start_date[2:4])

              # url for chart image if symbol is not know
              cod_dict['image_url'] = cod_img_tag[0].attrib['src']

              # format start and end dates in epoch
              cod_dict['end_date'] = end_date
              cod_dict['start_date'] = datetime(start_year, start_month,
                                          start_day, 0, 0).timestamp()

              dmn_dict['chart_of_the_day'] = cod_dict
        except:
          pass

        return dmn_dict
    else:
      return None