from mongo_accessor import MongoAccessor
from suggestion import Suggestion

class PublicationRecommendationQueryManager:
    def __init__(self):
        self.mongo_accessor = MongoAccessor('portfolio_buy_sell')
        self.symbol_exchange_map = {}

    def get_portfolio_buy_sell_status(self, page, page_size, from_dt, to_dt, publication_codes):
        skip_cnt = page_size * (page - 1)

        latest_rec = self.mongo_accessor.find_one_sort({}, [("ProcessDt", -1)] )
        retItems = []
        if latest_rec:
            process_dt = latest_rec[0]["ProcessDt"]
            filter_criteria = {}
            filter_criteria["ProcessDt"] = process_dt

            if from_dt and to_dt:
                filter_criteria["$and"] = [{ "OpenDate": { "$gte": from_dt } }, { "OpenDate": { "$lte": to_dt } }]
            elif from_dt:
                filter_criteria["OpenDate"] = { "$gte": from_dt }
            elif to_dt:
                filter_criteria["OpenDate"] = { "$lte": from_dt }

            if len(publication_codes) > 0:
                filter_criteria["PublicationCode"] = { "$in": publication_codes }

            # count = self.mongo_accessor.find(filter_criteria).count()
            data = self.mongo_accessor.find(filter_criteria).sort("OpenDate", -1).skip(skip_cnt).limit(page_size)
            for item in data:
                symbol = item["Symbol"]
                if self.symbol_exchange_map.get(symbol):
                    exchange = self.symbol_exchange_map.get(symbol)
                else:
                    exchange = self.get_symbol_exchange_info(symbol)
                    if exchange is None:
                        exchange = item["ExchangeMarket"]
                    else:
                        self.symbol_exchange_map[symbol] = exchange

                rec = {
                        "portfolio_id": item["PortfolioId"],
                        "portfolio_name": item["PortfolioName"],
                        "publications": [
                                            {
                                                "pub_code": item["PublicationCode"]
                                            }
                                        ],
                        "name": item["Name"],
                        "symbol": symbol,
                        "exchange": exchange,
                        "open_date": item["OpenDate"],
                        "open_price": item["OpenPrice"],
                        "current_price": item["CurrentPrice"],
                        "close_price": item["ClosePrice"],
                        "close_date": item["CloseDate"],
                        "gain": item["Gain"],
                        "days_held": item["HoldPeriod"],
                        "sector_name": item["SectorName"],
                        "open": item["IsOpened"],
                        "stop_price": item["StopPrice"],
                        "high_close_price": item["HighClosePrice"],
                        "high_close_date": item["HighCloseDate"],
                        "income": item["Income"],
                        "dividends": item["Dividends"]
                }
                subtrades = item["Subtrades"] if "Subtrades" in item else None
                if subtrades:
                    rec["st_stop"] = subtrades[0]["SubtradeSetting"]["SmartStop"]
                else:
                    rec["st_Stop"] = None

                trade_grp = item["TradeGroup"]
                if trade_grp and "Name" in trade_grp:
                    rec["trade_group"] = trade_grp["Name"]
                else:
                    rec["trade_group"] = ""

                retItems.append(rec)

        return retItems

    def get_symbol_exchange_info(self, symbol):
        result = Suggestion.get_unique_item(symbol).get('result')
        if len(result) > 0:
            exchange = result.get('exchange') if len(result) else None
            return exchange
        else:
            return None