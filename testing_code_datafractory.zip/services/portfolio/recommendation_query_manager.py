import datetime

from mongo_accessor import MongoAccessor

class RecommendationQueryManager:
    def __init__(self):
        self.conviction_buy_mongo_accessor = MongoAccessor('conviction_buys')

    def get_conviction_buys(self, filter_type, page, page_size, from_dt, to_dt):
        skip_cnt = page_size * (page - 1)

        filter_criteria = {}
        if filter_type == "latest":
            latest_rec = self.conviction_buy_mongo_accessor.find_one_sort({}, [("process_date", -1)] )
            if latest_rec:
                from_dt = latest_rec[0]["process_date"]
                filter_criteria["process_date"] = { "$eq": from_dt }
        elif filter_type == "date_range":
            has_from_dt = False
            if from_dt and from_dt != "":
                has_from_dt = True
                filter_criteria["process_date"] = { "$gte": from_dt }

            has_to_dt = False
            if to_dt and to_dt != "":
                has_to_dt = True
                filter_criteria["process_date"] = { "$lte": to_dt }

            if has_from_dt and has_to_dt:
                filter_criteria = { "$and": [{ "process_date": { "$gte": from_dt } }, { "process_date": { "$lte": to_dt } }] }

        ret_items = []
        data = self.conviction_buy_mongo_accessor.find(filter_criteria).sort("process_date", -1).skip(skip_cnt).limit(page_size)
        for item in data:
            process_date = item["process_date"]
            rec = {
                    "symbol": item["symbol"],
                    "exchange": item["exchange"],
                    "stock_price": item["stock_price"],
                    "process_dt":  process_date,
                    "exchange_currency": item["exchange_currency"],
                    "change_percentage": item["change_percentage"],
                    "name": item["company_name"],
                    "guid": item["id"],
                    "rank": item["rank"],
                    "publications": item["publications"],
                    "timestamp": item["timestamp"]
            }
            ret_items.append(rec)

        return ret_items