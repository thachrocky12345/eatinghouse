import re
import json
import simplejson
from scipy import stats
import pandas as pd
from enum import Enum
from decimal import Decimal

from pg_accessor import PostgresAccessor
from sbt_model_accessor import ModelAccessor
from fs_accessor import FinancialVendors
from fs_accessor import FinancialAccessor
from sbt_common import SbtGlobalCommon
from sbt_common import DecimalStringEncoder
from dd_accessor import DynamoAccessor
import numpy as np
import logging

logger_level = 'CRITICAL'


# read scoring system for the models
# scoring_system = pd.read_json("./models_scoring_system.json", orient="records")


def rate(model_id, calculated_data):
    # If nothing is passed in pass 'N/A' back
    if not calculated_data:
        return 'N/A'

    # appending the A-F rating (replacement for the star rating)
    if model_id == 'MOMENTUM':
        # breakdown as suggested by Brett
        # http://wiki.cloudsna.com:8090/display/TERM/Breakdown+of+Momentum+Model
        # N.B.: 'rank_value' is the model score, which is a natural number.
        x = calculated_data
        if x['rank_value'] >= 86:
            grade = 'A'
        elif (x['rank_value'] >= 66) and (x['rank_value'] <= 85):
            grade = 'B'
        elif (x['rank_value'] >= 50) and (x['rank_value'] <= 65):
            grade = 'C'
        elif (x['rank_value'] >= 25) and (x['rank_value'] <= 49):
            grade = 'D'
        elif (x['rank_value'] <= 24):
            grade = 'F'
        else:
            grade = 'N/A'

        return grade

    if model_id == 'MD_SCORE':
        # based on the model conception, we can organized the model score
        # into 5 regularly separated ratings category
        # N.B.: 'rank_value' is the percentile rank from the MD score
        # (i.e., its score) model, so it is a rational number.
        x = calculated_data
        if x['rank_value'] >= 80:
            grade = 'A'
        elif (x['rank_value'] >= 60) and (x['rank_value'] < 80):
            grade = 'B'
        elif (x['rank_value'] >= 40) and (x['rank_value'] < 60):
            grade = 'C'
        elif (x['rank_value'] >= 20) and (x['rank_value'] < 40):
            grade = 'D'
        elif (x['rank_value'] < 20):
            grade = 'F'
        else:
            grade = 'N/A'

        return grade

    if model_id == 'CAPITAL_EFFICIENCY':
        # CE grading is based on a point system for each metric used
        # in the model
        # points = [get_points_ce_model({x['calculation_id']: x['rank_value']})
        #           for x in [calculated_data]]
        # x = sum(points)
        x = calculated_data
        if x['rank_value'] >= 80 and x['rank_value'] <= 100:
            grade = 'A'
        elif x['rank_value'] >= 70 and x['rank_value'] < 80:
            grade = 'B'
        elif x['rank_value'] >= 40 and x['rank_value'] < 70:
            grade = 'C'
        elif x['rank_value'] >= 20 and x['rank_value'] < 40:
            grade = 'D'
        elif x['rank_value'] <= 20:
            grade = 'F'
        else:
            grade = 'N/A'

        return grade

    # Return 'N/A' if self._model_id is not supported by the method
    return 'N/A'


def get_points_ce_model(metric_dict):
    k, v = list(metric_dict.keys())[0], list(metric_dict.values())[0]

    if k == 'FIVE_YEAR_FCF_REVENUE_AVERAGE':
        if v > 40 and v < 1e6:
            p = 100
        elif v > 31 and v < 40:
            p = 95
        elif v > 22 and v < 31:
            p = 90
        elif v > 15 and v < 22:
            p = 80
        elif v > 8 and v < 15:
            p = 70
        elif v > 0 and v < 8:
            p = 60
        elif v > -8 and v < 0:
            p = 50
        elif v > -16 and v < -8:
            p = 40
        elif v > -25 and v < -16:
            p = 30
        elif v > -34 and v < -25:
            p = 20
        elif v > -1e4 and v < 34:
            p = 10
        elif v > -1e6 and v < -1e4:
            p = np.nan

        # weighted point
        wp = p * 0.35

    elif k == 'FIVE_YEAR_ROA':
        if v > 15 and v < 1e6:
            p = 100
        elif v > 12 and v < 15:
            p = 95
        elif v > 8 and v < 12:
            p = 90
        elif v > 6 and v < 8:
            p = 80
        elif v > 3 and v < 6:
            p = 70
        elif v > 0 and v < 3:
            p = 60
        elif v > -3 and v < 0:
            p = 50
        elif v > -5 and v < -3:
            p = 40
        elif v > -9 and v < -5:
            p = 30
        elif v > -12 and v < -9:
            p = 20
        elif v > -100 and v < -12:
            p = 10
        elif v > -1e6 and v < -100:
            p = np.nan

        # weighted point
        wp = p * 0.25

    elif k == 'FIVE_YEAR_REVENUE_GROWTH':
        if v > 54 and v < 1e6:
            p = 100
        elif v > 43 and v < 54:
            p = 95
        elif v > 32 and v < 43:
            p = 90
        elif v > 24 and v < 32:
            p = 80
        elif v > 16 and v < 24:
            p = 70
        elif v > 8 and v < 16:
            p = 60
        elif v > 1 and v < 8:
            p = 50
        elif v > -8 and v < 1:
            p = 40
        elif v > -19 and v < -8:
            p = 30
        elif v > -30 and v < -19:
            p = 20
        elif v > -100 and v < -30:
            p = 10
        elif v > -1e6 and v < -100:
            p = np.nan

        # weighted point
        wp = p * 0.10

    elif k == 'FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE':
        if v > 25 and v < 1e6:
            p = 100
        elif v > 19 and v < 25:
            p = 95
        elif v > 12 and v < 19:
            p = 90
        elif v > 7 and v < 12:
            p = 80
        elif v > 1 and v < 7:
            p = 70
        elif v > -1 and v < 1:
            p = 60
        elif v > -7 and v < -1:
            p = 50
        elif v > -12 and v < -7:
            p = 40
        elif v > -19 and v < -12:
            p = 30
        elif v > -25 and v < -19:
            p = 20
        elif v > -100 and v < -25:
            p = 10
        elif v > -1e6 and v < -100:
            p = np.nan

        # weighted point
        wp = p * 0.30

    else:
        wp, p = v, v

    return {'weighted_points': wp, 'points': p}


class ModelException(Exception):
    def __init__(self, message, exception_code=None):
        Exception.__init__(self, message)
        self._exception_code = exception_code

    def get_exception_code(self):
        return self._exception_code


class ModelId(Enum):
    MD_SCORE = 'MD_SCORE'
    CAPITAL_EFFICIENCY = 'CAPITAL_EFFICIENCY'
    MOMENTUM = 'MOMENTUM'
    MD_SCORE_FIN = 'MD_SCORE_FIN'
    MD_SCORE_EAR = 'MD_SCORE_EAR'
    MD_SCORE_AVG = 'MD_SCORE_AVG'
    MM_MOMENTUM = 'MM_MOMENTUM'
    DIVIDEND = "DIVIDEND"
    COMPOSITE = "COMPOSITE"


class Ranker(object):
    """
      Calculator class is used to rank model values.
    """

    def __init__(self, model_id, calculator, companies):
        """
          Constructor

          Args :
            model_id(str)           : Model Identifier
            calculator (Calculator) : Instance of a calculator object
            companies(List)         : List containing company model dictionaries
        """
        logging.getLogger('botocore').setLevel(logging.CRITICAL)
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_global_logger()
        self._logger.setLevel(logger_level)
        self._model_id = model_id
        self._calculator = calculator
        self._companies = companies
        self._companies_dictionary = {}
        self._set_company_dictionary()
        self._model_accessor = ModelAccessor()

    def _set_company_dictionary(self):
        """
          Creates the _companies_dictionary instance variable.
        """
        for company in self._companies:
            self._companies_dictionary[company['guid']] = company

    def rank(self):
        """
          Ranks company data.
        """
        parent_model_attr = 'parent_model'
        is_a_parent_model = True if \
            (parent_model_attr in self._calculator._calculation_def.keys() and
             self._calculator._calculation_def[
                 parent_model_attr] == True) else False
        if is_a_parent_model:
            child_calulations = [Calculator(
                [x for x in
                 self._model_accessor.query_model_calculation('MD_SCORE{}'.
                                                              format(suffix))
                 if 'parent_model_id' in x.keys()][0]) for suffix in
                ['_FIN', '_EAR', '']]
        else:
            child_calulations = self._calculator.get_child_calculations()

        for child in child_calulations:
            if child.get_rank_type() == 'value':
                self._set_child_value_rank(child)
            elif child.get_rank_type() == 'percentile_rank':
                self._set_child_percentile_rank(child)
            elif child.get_rank_type() == 'N/A':
                self._logger.warning('No ranking is required for ' +
                                     child.get_id())
            else:
                raise Exception('invalid rank formula for child "' +
                                child.get_id() + '".')

        return self._rank_parent()

    def _set_child_value_rank(self, child):
        """
          Sets value based company rankings for specified child calculator

          Args :
            child(Calculator) : Child Calculator Object
        """
        ord_data = self.get_ordered_data(child.get_id(), self._companies,
                                         child.is_rank_desc_order())

        counter = 1
        for o in ord_data:
            guid = o['guid']
            data = self._companies_dictionary[guid]
            data['calculated_data'][child.get_id()]['rank'] = counter
            if 'calulation_id' in data['calculated_data'][
                child.get_id()].keys():
                data['calculated_data'][child.get_id()]['calculation_id'] = \
                    data['calculated_data'][child.get_id()]['calulation_id']
                data['calculated_data'][child.get_id()].pop('calulation_id')
            counter = counter + 1

    def _set_child_percentile_rank(self, child):
        """
          Sets percentile based company rankings for specified child calculator

          Args :
            child(Calculator) : Child Calculator Object
        """
        parent_model_attr = 'parent_model'
        is_a_parent_model = True if \
            (parent_model_attr in self._calculator._calculation_def.keys() and
             self._calculator._calculation_def[
                 parent_model_attr] == True) else False

        ord_data = self.get_ordered_data(child.get_id(), self._companies,
                                         child.is_rank_desc_order())
        rank_data = []
        # if it's a model, then use the rank instead of the score (rank_value)
        rank_name = 'rank' if is_a_parent_model else 'rank_value'
        [rank_data.append(o['calculated_data'][child.get_id()][rank_name])
         for o in ord_data]

        for v in list(self._companies_dictionary.values()):
            rank = stats.percentileofscore(rank_data,
                                           v['calculated_data'][
                                               child.get_id()][rank_name])

            v['calculated_data'][child.get_id()]['rank'] = rank
            if 'calulation_id' in v['calculated_data'][child.get_id()].keys():
                v['calculated_data'][child.get_id()]['calculation_id'] = \
                    v['calculated_data'][child.get_id()]['calulation_id']
            if 'calulation_id' in v['calculated_data'][child.get_id()].keys():
                v['calculated_data'][child.get_id()].pop('calulation_id')

    def _rank_parent(self):
        """
          Ranks data for the parent calculator
        """
        form = self._calculator.get_rank_formula()
        rules = self._calculator.get_rank_rules()

        for v in list(self._companies_dictionary.values()):
            field_replacement = {}
            for child_key, child_data in v['calculated_data'].items():
                field_replacement[child_key] = child_data[
                    'rank'] if self._model_id \
                               is not 'CAPITAL_EFFICIENCY' else \
                    get_points_ce_model({child_key: child_data['value']})[
                        'points']
            self._adjust_field_replacements(rules, field_replacement)
            new = form.format(**field_replacement)
            calculated_value = v['value']
            if new != 'N/A':
                calculated_value = self._eval(new)
            v['rank_formula'] = form
            v['rank_calculation'] = new
            v['rank_value'] = calculated_value

        parent_sort_desc = self._calculator.is_rank_desc_order()

        sorted_data = sorted(list(self._companies_dictionary.values()),
                             key=lambda k: k['rank_value'],
                             reverse=parent_sort_desc)

        if self._calculator.get_rank_type() == 'value':
            counter = 1
            for o in sorted_data:
                self._companies_dictionary[o['guid']]['rank'] = counter
                self._clean_calculation_id(
                    self._companies_dictionary[o['guid']])
                counter = counter + 1
        elif self._calculator.get_rank_type() == 'percentile_rank':
            rank_data = []

            for o in sorted_data:
                if (parent_sort_desc):
                    rank_data.append(100 - o['rank_value'])
                else:
                    rank_data.append(o['rank_value'])

            for o in sorted_data:
                rank = None
                if (parent_sort_desc):
                    rank = stats.percentileofscore(rank_data,
                                                   100 - o['rank_value'])
                else:
                    rank = stats.percentileofscore(rank_data,
                                                   o['rank_value'])
                self._companies_dictionary[o['guid']]['rank'] = rank
                self._clean_calculation_id(
                    self._companies_dictionary[o['guid']])
        else:
            raise Exception('invalid rank formula type for parent "' +
                            self._calculator.get_id() + '".')

        return list(self._companies_dictionary.values())

    def _adjust_field_replacements(self,
                                   rules,
                                   field_replacement):

        if self._sbtcommon.collectionsutil.is_not_empty(rules) and \
                self._sbtcommon.collectionsutil.is_not_empty(
                    field_replacement) and \
                'adjusted_average' in rules.keys() and \
                rules['adjusted_average']:

            counter = 0
            for value in list(field_replacement.values()):
                if value > 0:
                    counter = counter + 1

            field_replacement['adjusted_average'] = counter

    def _clean_calculation_id(self, calc):
        if 'calulation_id' in calc.keys():
            calc['calculation_id'] = \
                calc['calulation_id']
            calc.pop('calulation_id')

    def _eval(self, eval_string):
        """
          Evaluates the string and returns the value.

          Args :
            eval_string(str) : String to be evaluated

          Returns :
            float : Result of string evaluation
        """
        clean_eval = re.sub(r'[^0-9 | ( | ) | / | * | \- | + | .]', r'',
                            str(eval_string))
        return eval(clean_eval, {'__builtins__': {}})

    def get_ordered_data(self, calc_id, data, reverse_order):
        """
          Order the data in the list based on the rank_value

          Args :
            calc_id(str)        : Calculator ID
            data(list)          : Data to be sorted.
            reverse_order(bool) : Indicates data should be sorted in reverse order

          Returns :
            list : Order list of data
        """
        return sorted(data, key=lambda k: k['calculated_data'][calc_id][
            'rank_value'], reverse=reverse_order)


class Calculator(object):
    """
      Calculator class is used to calculate model values.
    """

    def __init__(self, calculation_def):
        """
          Constructor

          Args :
            calculation_def(dict) : Calculator configuration
        """
        logging.getLogger('botocore').setLevel(logging.CRITICAL)
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_global_logger()
        self._logger.setLevel(logger_level)
        self._calculation_def = calculation_def
        self._financial_data = {}
        self._calculated_value = 0
        self._calculation = None
        self._child_calculations = []
        self._pre_conditions = []
        self._use_rank_value = False
        self._criteria = {}

    def get_pre_conditions(self):
        """
          Returns preconditions

          Return :
            list : Preconditions Calculators
        """
        return self._pre_conditions

    def set_pre_conditions(self, pre_conditions):
        """
          Sets pre_conditions calculators

          Args :
            child_calculations(list) : Pre Condition Calculators
        """
        self._pre_conditions = []
        for pre in pre_conditions:
            if self.get_id() == pre.get_parent_id():
                self._pre_conditions.append(pre)

    def get_child_calculations(self):
        """
          Returns child calculators

          Return :
            list : Child Calculators
        """
        return self._child_calculations

    def set_child_calculations(self, child_calculations):
        """
          Sets child calculators

          Args :
            child_calculations(list) : Child Calculators
        """
        self._child_calculations = []
        for child in child_calculations:
            if self.get_id() == child.get_parent_id():
                self._child_calculations.append(child)

    def is_parent(self):
        """
          Returns true if calculation is a parent calculation.  Which means it
          requires other calculations to be performed before it can determine
          its value.

          Return :
            bool : true is calculation is a parent
        """
        return self.get_parent_id() is None

    def is_pre_condition(self):
        """
          Returns true if calculator is pre-condition

          Return :
            bool : true if calculator is pre-condition
        """
        return 'pre_condition' in self._calculation_def.keys() and \
               self._calculation_def['pre_condition']

    def is_active(self):
        """
          Returns true if calculator is active

          Return :
            bool : true if calculator is active
        """
        return self._calculation_def['active']

    def get_rank_formula(self):
        """
          Returns the formula used by the calculator

          Return :
            str : Formula used by the calculator
        """
        return self._calculation_def['rank']['formula']

    def get_rules(self):
        """
          Returns the rules dictionary

          Return :
            dict : rules
        """
        if 'rules' in self._calculation_def.keys():
            return self._calculation_def['rules']
        else:
            return None

    def get_rank_rules(self):
        """
          Returns the rank rules dictionary

          Return :
            dict : Rank rules
        """
        if 'rank' in self._calculation_def.keys() and \
                'rules' in self._calculation_def['rank'].keys():
            return self._calculation_def['rank']['rules']
        else:
            return None

    def get_rank_type(self):
        """
          Returns rank type.  (value or percentile_rank)

          Return :
            str : formula
        """
        return self._calculation_def['rank']['type']

    def is_rank_listing_desc_order(self):
        """
          Returns true if data is to be ranks are listed in desc order

          bool : true indicates data is to be ranked descending order
        """
        return 'listing_order_desc' in self._calculation_def['rank'].keys() and \
               self._calculation_def['rank']['listing_order_desc']

    def is_rank_desc_order(self):
        """
          Returns true if data is to be ranks in desc order

          bool : true indicates data is to be ranked descending order
        """
        return self._calculation_def['rank']['order_desc']

    def get_display_value(self, conversion_form, value):
        """
          Converts value to a display value

          Args :
            conversion_form(str) : Conversion Formula
            value(any) : Value to be converted

          Returns :
            (any) Converted Value
        """
        ret_value = None
        if value is not None:
            if 'display_conversion' in self._calculation_def.keys() and \
                    self._sbtcommon.stringutil.is_not_empty(
                        self._calculation_def['display_conversion']):
                field_replacement = {"value": value}
                new = conversion_form.format(**field_replacement)
                ret_value = self._eval(new)
            else:
                ret_value = value
        else:
            ret_value = 'N/A'

        return ret_value

    def get_rank_units(self):
        """
          Returns rank units.

          Return :
            str : rank units
        """
        if 'rank' in self._calculation_def.keys() and \
                'units' in self._calculation_def['rank'].keys():
            return self._calculation_def['rank']['units']
        else:
            return 'N/A'

    def get_display_conversion(self):
        """
          Returns display conversion.

          Return :
            str : display conversion
        """
        if 'display_conversion' in self._calculation_def.keys() and \
                self._sbtcommon.stringutil.is_not_empty(
                    self._calculation_def['display_conversion']):
            return self._calculation_def['display_conversion']
        else:
            return None

    def get_units(self):
        """
          Returns units.

          Return :
            str : units
        """
        if 'units' in self._calculation_def.keys():
            return self._calculation_def['units']
        else:
            return 'N/A'

    def get_description(self):
        """
          Returns calculator description.

          Return :
            str : Description
        """
        return self._calculation_def['description']

    def get_parent_id(self):
        """
          Returns parent id if calculator if it a child calculation

          Return :
            str : Parent Calculator ID
        """
        if 'parent_calculation_id' in self._calculation_def.keys():
            return self._calculation_def['parent_calculation_id']
        else:
            return None

    def get_id(self):
        """
          Returns calculator id

          Return :
            str : ID
        """
        return self._calculation_def['calculation_id']

    def get_timeframe(self):
        return self._sbtcommon.dateutil.get_current_date_string()

    def has_financial_data(self, field_name):
        return field_name in self._financial_data

    def set_pre_conditions_financial_data(self, field_name, data):
        for pre in self.get_pre_conditions():
            for field in pre.get_field_mappings():
                if field_name == field['field_name']:
                    pre._financial_data[field_name] = data

    def set_child_financial_data(self, field_name, data):
        for child in self.get_child_calculations():
            for field in child.get_field_mappings():
                if field_name == field['field_name']:
                    child._financial_data[field_name] = data

    def get_child_raw_data(self):
        data = {}
        for child in self.get_child_calculations():
            data.update(child.get_limited_financial_data())
        return data

    def get_child_financial_data(self):
        data = {}
        for child in self.get_child_calculations():
            data.update(child.get_financial_data())
        return data

    def get_limited_financial_data(self):
        data = {}

        for f, v in self.get_financial_data().items():
            if len(v) == 0:
                data[f] = v
                continue

            f_id = v[0]['fiscal_id']
            compare_value = 20
            if 'FY' in f_id.upper():
                compare_value = 6

            s = sorted(v, key=lambda k: k['fiscal_id'], reverse=True)
            if len(s) > compare_value:
                data[f] = s[:(compare_value + 1)]
            else:
                data[f] = v

        return data

    def get_financial_data(self):
        return self._financial_data

    def set_financial_data(self, field_name, data):
        self._financial_data[field_name] = data

    def get_all_pre_conditions_field_mappings(self):
        fields = []

        for pre in self.get_pre_conditions():
            fields.extend(pre.get_field_mappings())

        return fields

    def get_all_child_field_mappings(self):
        fields = []

        for child in self.get_child_calculations():
            fields.extend(child.get_field_mappings())

        return fields

    def get_field_mappings(self):
        fields = []

        calculator_def = self._calculation_def

        if 'formula_mapping' not in calculator_def:
            return

        for replacement_value, info in calculator_def[
            'formula_mapping'].items():
            field_name = info['field_name']

            field = info

            field['replacement_value'] = replacement_value

            if 'source_mapping' in calculator_def.keys():
                field['vendor_field_name'] = calculator_def['source_mapping'][
                    field_name]['sbt_intrinio'][
                    'vendor_field_name']

                field['vendor_fiscal_period'] = \
                calculator_def['source_mapping'][
                    field_name]['sbt_intrinio'][
                    'vendor_fiscal_period']

            fields.append(field)

        return fields

    def check_for_valid_data(self):
        if self.is_parent():
            for pre in self.get_pre_conditions():
                pre._is_valid_precondition()

    def get_calculated_data(self):
        """
          Returns the calculated information to the caller as a dictionary

          Return :
            dict : Calculated Data
        """
        calc_data = {}
        if self.is_parent():
            non_zero_counter = 0
            positive_counter = 0
            for child in self.get_child_calculations():
                calc_data = child.get_calculated_data()
                if child._calculated_value != 0:
                    non_zero_counter = non_zero_counter + 1
                if child._calculated_value > 0:
                    positive_counter = positive_counter + 1
                self.set_financial_data(child.get_id(), calc_data)

            rules = self.get_rules()

            if self._sbtcommon.collectionsutil.is_not_empty(rules) and \
                    'nonzero_child_values' in rules.keys() and \
                    non_zero_counter < rules['nonzero_child_values']:
                raise ModelException('At least ' +
                                     str(rules['nonzero_child_values']) +
                                     ' child calculations can not be zero ' +
                                     self.get_id(), self.get_id())

            if self._sbtcommon.collectionsutil.is_not_empty(rules) and \
                    'positive_child_values' in rules.keys() and \
                    positive_counter < rules['positive_child_values']:
                raise ModelException('At least ' +
                                     str(rules['positive_child_values']) +
                                     ' child calculations must be greater than zero ' +
                                     self.get_id(), self.get_id())

        if len(calc_data) > 0:
            self._use_rank_value = True

        self._calculate_value()

        value = self._calculated_value

        str_date = self.get_timeframe()

        calc_data = dict(calculation_id=self.get_id(),
                         formula=self._calculation_def['formula'], \
                         calculation=self._calculation, \
                         date_calculated=str_date, \
                         description=self.get_description(), \
                         display_value=self.get_display_value( \
                             self.get_display_conversion(), \
                             value), \
                         rank_value=Decimal(str(value)) \
                             if self._calculation_def[
                                    'model_id'] != 'CAPITAL_EFFICIENCY' \
                             else Decimal(str(get_points_ce_model(
                             {self._calculation_def['calculation_id']: value})[
                                                  'points'])),
                         rank=Decimal('0'), \
                         rank_units=self.get_rank_units(), \
                         units=self.get_units(), \
                         value=Decimal(str(value))
                         )

        return calc_data

    def _is_valid_precondition(self):
        if not self.is_pre_condition():
            return False

        form = self._calculation_def['formula']

        if form == 'N/A' or self.get_field_mappings() is None or \
                len(self.get_field_mappings()) == 0:
            return False

        field_replacement = {}

        for field in self.get_field_mappings():
            aev = False
            if 'accept_empty_value' in field.keys():
                aev = field['accept_empty_value']

            aet = False
            if 'accept_empty_total' in field.keys():
                aet = field['accept_empty_total']

            fin = []
            if isinstance(self._financial_data[field['field_name']], dict):
                fin.append(self._financial_data[field['field_name']])
            else:
                fin.extend(self._financial_data[field['field_name']])

            f_data = self.get_ordered_data(fin,
                                           field['sort_desc'])

            result_value = self._get_result(f_data,
                                            int(field['start_position']),
                                            int(field['end_position']),
                                            accept_empty_value=aev)

            if not aet and result_value == 0:
                self._logger.critical('Result Total can not be empty for : ' +
                                      self.get_id(), self.get_id())

            field_replacement[field['replacement_value']] = result_value

        new = form.format(**field_replacement)
        # deal with multiple conditionals
        if 'and' in new.lower():
            condition_result_list = [self._eval(x) for x in
                                     new.lower().split('and')]
            result = sum(1 for x in condition_result_list if x is False) == 0
        else:
            result = self._eval(new)

        self.update_criteria_list(result)

    def update_criteria_list(self, result):
        self._criteria['met_criteria'] = result

    def get_pre_condition_results(self):
        '''
        Return the results for each pre-condition, whether it was met or not
        :return:
        '''
        pre_condition_results = [{
            'description': x._calculation_def['description'],
            'calculation_id': x._calculation_def['calculation_id'],
            'met_criteria': x._criteria['met_criteria'],
            'financial_data': x._financial_data
        } for x in self._pre_conditions]

        return pre_condition_results

    def _calculate_value(self):
        """
          Calculates a value based on the formula and data and sets the calculator
          instance variable.
        """
        form = self._calculation_def['formula']

        if form == 'N/A' or self.get_field_mappings() is None or \
                len(self.get_field_mappings()) == 0:
            self._calculation = 'N/A'
            self._calculated_value = 0
            return

        field_replacement = {}

        for field in self.get_field_mappings():
            aev = False
            if 'accept_empty_value' in field.keys():
                aev = field['accept_empty_value']

            aet = False
            if 'accept_empty_total' in field.keys():
                aet = field['accept_empty_total']

            fin = []
            if isinstance(self._financial_data[field['field_name']], dict):
                fin.append(self._financial_data[field['field_name']])
            else:
                fin.extend(self._financial_data[field['field_name']])

            f_data = self.get_ordered_data(fin,
                                           field['sort_desc'])

            result_value = self._get_result(f_data,
                                            int(field['start_position']),
                                            int(field['end_position']),
                                            accept_empty_value=aev,
                                            use_rank_value=self._use_rank_value)

            if not aet and result_value == 0:
                raise ModelException('Result Total can not be empty for: ' +
                                     self.get_id(), self.get_id())

            field_replacement[field['replacement_value']] = result_value

        new = form.format(**field_replacement)
        self._calculation = new
        self._calculated_value = self._eval(new)

    def _get_result(self,
                    data,
                    start_position,
                    end_position,
                    accept_empty_value=False, use_rank_value=False):
        result = 0

        if len(data) - 1 < end_position:
            raise ModelException(
                'Underlying data does not support calculation for "' +
                self.get_description() + '".')

        counter = start_position
        while counter >= start_position and counter <= end_position:
            cur_value = float(
                data[counter]['rank_value']) if use_rank_value else float(
                data[counter]['value'])
            if not accept_empty_value and cur_value == 0:
                raise ModelException('Zero value was encounter in raw data "' +
                                     self.get_description() + '".')
            result = result + float(cur_value)
            counter = counter + 1

        return str(result)

    def _eval(self, eval_string):
        """
          Evaluates the string and returns the value.

          Args :
            eval_string(str) : String to be evaluated

          Returns :
            float : Result of string evaluation
        """
        clean_eval = re.sub(
            r'[^0-9 | ( | ) | / | * | \- | + | . | > | < | <= | >= | abs | if | else ]',
            r'', str(eval_string))
        return eval(clean_eval, {'__builtins__': {'abs': abs}})

    def get_ordered_data(self, data, reverse_order):
        """
          Order the data in the list based on the rank_value

          Args :
            data(list)          : Data to be sorted.
            reverse_order(bool) : Indicates data should be sorted in reverse order

          Returns :
            list : Order list of data
        """
        newlist = []
        if self.is_parent():
            newlist = sorted(data, key=lambda k: k['date_calculated'],
                             reverse=reverse_order)
        else:
            newlist = sorted(data, key=lambda k: k['fiscal_id'],
                             reverse=reverse_order)

        return newlist


class Formula(object):
    def percent_rank_inc(self, values, compare_value):
        above = list(filter(lambda x: x > compare_value, values))
        below = list(filter(lambda x: x < compare_value, values))
        return len(below) / (len(above) + len(below))


class CompanyModel(DynamoAccessor):
    """
      CompanyModel class represents a single company within the model.
    """

    def __init__(self, model_id, guid, ticker, exchange, calculator):
        super().__init__()
        self._model_id = model_id
        self._model = {}
        logging.getLogger('botocore').setLevel(logging.CRITICAL)
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_global_logger()
        self._logger.setLevel(logger_level)
        self._guid = guid
        self._ticker = ticker
        self._exchange = exchange
        self.calculator = calculator
        self._company_repository = CompanyDataRepository()
        self._financial_data = {}
        self._calculated_financial_data = {}
        self._models_suffix = ['_FIN', '_EAR', '']
        # get scoring system for Capital Efficiency only
        # self.scoring_system = scoring_system['ce']
        # points to be deducted from total points each time a criteria IS NOT met
        self.penalty_value = 5

    def convert_to_dictionary(self):
        parent_model_attr = 'parent_model'
        is_a_parent_model = True if \
            (parent_model_attr in self.calculator._calculation_def.keys() and
             self.calculator._calculation_def[
                 parent_model_attr] == True) else False
        company = {}
        company['model_id'] = self._model_id
        company['guid'] = self._guid
        company['symbol'] = self._ticker

        if self._exchange:
            company['exchange'] = self._exchange
        else:
            company['exchange'] = 'N/A'

        company.update(self._model)
        company['raw_data'] = self.calculator.get_child_raw_data()
        if is_a_parent_model:
            company['calculated_data'] = self._get_models_data()
        else:
            company['calculated_data'] = self.calculator.get_financial_data()

        # this should be added only if there are pre_conditions in the model
        pre_condition_results = self.calculator.get_pre_condition_results()
        if len(pre_condition_results):
            company['pre_conditions'] = pre_condition_results
            company['total_penalty'] = 5 * sum(
                [1 for x in pre_condition_results
                 if x['met_criteria'] is False])
            penalty = company['total_penalty']
            company['original_value'] = company['rank_value']
            # update values
            company.update(rank_value=company['original_value'] - penalty)
            company.update(value=company['original_value'] - penalty)
            company.update(
                display_value=float(company['original_value'] - penalty))

        simplejson.dumps(company)

        return company

    def _get_models_data(self):
        model_data = {}
        for suffix in self._models_suffix:
            temp = self._query_table('SBT_MODEL', 'guid', self._guid,
                                     'model_id', 'MD_SCORE{}'.format(suffix))
            model_data.update({
                'MD_SCORE{}'.format(suffix): {
                    'rank': temp[0]['rank'],
                    'rank_value': temp[0]['rank_value']
                }
            })

        return model_data

    def populate(self):
        parent_model_attr = 'parent_model'
        is_a_parent_model = True if \
            (parent_model_attr in self.calculator._calculation_def.keys() and
             self.calculator._calculation_def[
                 parent_model_attr] == True) else False
        if is_a_parent_model:
            self._populate_models()
        else:
            self._populate_calculations()

    def _populate_models(self):

        data = [{'MD_SCORE{}'.format(suffix): self._query_table('SBT_MODEL',
                                                                'guid',
                                                                self._guid,
                                                                'model_id',
                                                                'MD_SCORE{}'.format(
                                                                    suffix))}
                for suffix in self._models_suffix]

        # count number of not empty lists
        m = [[len(y) for y in x.values()][0] for x in data].count(1)
        if m >= 2:
            # using average of ranks
            rank_list = [[y[0]['rank'] for y in x.values()][0] for x in data]
            rank_avg = Decimal(sum(rank_list) / m)
        else:
            rank_avg = None

        # ranking system's main dictionary
        self._model = dict(
            calculation_id='N/A',
            formula=self.calculator._calculation_def['formula'],
            criteria=self.calculator._calculation_def['criteria'],
            calculation=self.calculator._calculation,
            date_calculated=self.calculator.get_timeframe(),
            description=None,
            display_value=
            self.calculator.get_display_value(
                self.calculator.get_display_conversion(), rank_avg
            ),
            rank_value=Decimal(str(rank_avg)),
            rank=Decimal('0'),
            rank_units=None,
            units=None,
            value=Decimal(str(rank_avg))
        )
        self._logger.info("DONE.")

    def _populate_calculations(self):
        preconditions = self.calculator.get_all_pre_conditions_field_mappings()

        for field in preconditions:
            if not self.calculator.has_financial_data(field['field_name']):
                key = self._populate_financial_data(field['vendor_field_name'],
                                                    field[
                                                        'vendor_fiscal_period'])

                self.calculator.set_pre_conditions_financial_data(
                    field['field_name'],
                    self._get_financial_data(key))

        self.calculator.check_for_valid_data()

        fields = self.calculator.get_all_child_field_mappings()

        for field in fields:
            if not self.calculator.has_financial_data(field['field_name']):
                key = self._populate_financial_data(field['vendor_field_name'],
                                                    field[
                                                        'vendor_fiscal_period'])

                self.calculator.set_child_financial_data(field['field_name'],
                                                         self._get_financial_data(
                                                             key))

        self._model = self.calculator.get_calculated_data()

    def _get_financial_data(self, key):
        return self._financial_data[key]

    def _get_financial_data_key(self, vendor_field_name, vendor_fiscal_period):
        return vendor_field_name + ':::' + vendor_fiscal_period

    def _populate_financial_data(self, vendor_field_name,
                                 vendor_fiscal_period):

        key = self._get_financial_data_key(vendor_field_name,
                                           vendor_fiscal_period)

        if key not in self._financial_data.keys():
            fin_data = self._company_repository.get_data(self._ticker,
                                                         self._exchange,
                                                         vendor_field_name,
                                                         vendor_fiscal_period)
            self._financial_data[key] = fin_data
        else:
            self._logger.info('Pulled ' + key + ' from cache.')
            fin_data = self._financial_data[key]

        return key


class CompanyDataRepository(object):
    """
      CompantDataRepository class is used to pull financial data.
    """

    sbt_zfmanager = 'SBT_ZFMANAGER'
    sbt_zfmanager_intrinio = 'SBT_ZFMANAGER_INTRINIO'
    sbt_intrionio = 'SBT_INTRINIO'

    def __init__(self):
        """
          CompanyDataRepository Constructor
        """
        logging.getLogger('botocore').setLevel(logging.CRITICAL)
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_global_logger()
        self._logger.setLevel(logger_level)
        self._vendor = FinancialVendors.INTRINIO.value

        env_conf = self._sbtcommon.get_sbt_config()

        if 'financials' in env_conf and 'vendor' in env_conf['financials']:
            self._vendor = env_conf['financials']['vendor']

        self._logger.info(
            'Company Data Repository with vendor : ' + self._vendor)

        self._history_financial_accessor = FinancialAccessor(self._vendor)
        self._stock_financial_accessor = FinancialAccessor(self._vendor)
        self._formula = Formula()

    def get_data(self, ticker,
                 exchange,
                 vendor_field_name,
                 vendor_fiscal_period):
        """
          Retrieve vendor data from the database.

          Args :
            ticker (str)                : Company Ticker
            vendor_field_name (str)     : Vendor Field Name
            vendor_fiscal_period (str)  : Vendor Fiscal Period

          Returns :
            list : Financial data
        """
        data_list = []

        if vendor_field_name.startswith('stock_price_'):
            data_list = self._get_stock_price(ticker,
                                              exchange,
                                              vendor_field_name,
                                              vendor_fiscal_period)
        elif vendor_field_name.startswith('~calculated_'):
            data_list = self._calculated_value(ticker,
                                               exchange,
                                               vendor_field_name,
                                               vendor_fiscal_period)
        else:
            data_list = self._get_history(ticker,
                                          exchange,
                                          vendor_field_name,
                                          vendor_fiscal_period)

        return data_list

    def _calculated_value(self, ticker, exchange, item, timeframe):
        calc_value = []

        field = item[12:]

        if field.lower() == 'percent_rank_inc':
            calc_value = self._get_st_scores(ticker, exchange)

        return calc_value

    def _get_st_scores(self, ticker, exchange):
        calc_value = []
        stock_prices = sorted(
            self._get_stock_price(ticker, exchange,
                                  'stock_price_adj_close', '1y'),
            key=lambda k: k['fiscal_id'], reverse=True)

        if self._sbtcommon.collectionsutil.is_not_empty(stock_prices) and \
                len(stock_prices) > 150:
            first_hundred = stock_prices[:100]
            counter = 0
            current_values = []
            for s in first_hundred:
                tmp_fifty = [float(x['value']) for x in
                             stock_prices[counter:counter + 50]]
                value = float(s['value']) / (
                            sum(tmp_fifty) / float(len(tmp_fifty)))

                current_values.append(value)
                counter = counter + 1

            counter = 0
            first_fifty = first_hundred = stock_prices[:50]
            for s in first_fifty:
                temp_fifty = current_values[counter:counter + 50]
                value = self._formula.percent_rank_inc(temp_fifty,
                                                       temp_fifty[counter])
                value = round((value * 100) / 2)
                st_score = {}
                st_score['date'] = s['date']
                st_score['fiscal_id'] = s['fiscal_id']
                st_score['fiscal_year'] = s['fiscal_year']
                st_score['fiscal_period'] = s['fiscal_period']
                st_score['value'] = value
                calc_value.append(st_score)
                counter = counter + 1

        return calc_value

    def _get_stock_price(self, ticker, exchange, item, timeframe):
        """
          Retrieve vendor data from the database.

          Args :
            ticker (str)                : Company Ticker
            item (str)                  : Vendor Field Name
            timeframe (str)             : Vendor Fiscal Period

          Returns :
            list : Financial data
        """
        field = item[12:]
        conv_data = []
        data = self._stock_financial_accessor.query_stock_price(ticker,
                                                                timeframe,
                                                                standardized_format=True,
                                                                exchange=exchange)

        if not data:
            return conv_data

        if self._vendor == 'snp':
            self._process_snp_stock_data(field, data, conv_data)
        else:
            json_str = json.dumps(data, cls=DecimalStringEncoder)
            json_data = json.loads(json_str)
            if 'results' in json_data.keys():
                for sp in json_data['results']:
                    if field not in sp['values']:
                        continue
                    stock_price = {}
                    stock_price['date'] = sp['date']
                    stock_price['fiscal_id'] = sp['timestamp']
                    stock_price['fiscal_year'] = sp['date'][:4]
                    stock_price['fiscal_period'] = 'D'
                    stock_price['value'] = sp['values'][field]

                    conv_data.append(stock_price)

        return conv_data

    def _process_snp_stock_data(self, field, data, conv_data):
        for price in data:
            if len(price['values']) > 0 and field in price['values']:
                stock_price = {}
                stock_price['date'] = price['date']
                stock_price['fiscal_id'] = str(price['timestamp'])
                stock_price['fiscal_year'] = price['date'][:4]
                stock_price['fiscal_period'] = 'D'
                stock_price['value'] = str(price['values'][field])

                conv_data.append(stock_price)

    def _get_history(self, ticker, exchange, item, timeframe):
        """
          Retrieve vendor data from the database.

          Args :
            ticker (str)                : Company Ticker
            item (str)                  : Vendor Field Name
            timeframe (str)             : Vendor Fiscal Period

          Returns :
            list : Financial data
        """
        conv_data = []
        data = self._history_financial_accessor.query_history_data(ticker,
                                                                   item,
                                                                   timeframe,
                                                                   'asc',
                                                                   exchange=exchange)
        json_str = json.dumps(data, cls=DecimalStringEncoder)
        json_data = json.loads(json_str)
        if 'data' in json_data.keys():
            conv_data = json_data['data']
        return conv_data


class Model(PostgresAccessor):
    """
      Model Class is used to construct and populate a model with calculations
      and rankings.
    """

    def __init__(self, model_id):
        """
          Model Constructor

          Args :
             model_id (str)  : Model ID
        """

        logging.getLogger('botocore').setLevel(logging.CRITICAL)
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_global_logger()
        self._logger.setLevel(logger_level)
        self._logger.setLevel('CRITICAL')

        self._model_id = model_id
        self._model_accessor = ModelAccessor()
        self._model_data = []
        self._model_ranks = []
        self._companies = []
        self._calculation_def = \
            self._model_accessor.query_model_calculation(self._model_id)

        # PG TABLES TO BE USED FOR RETRIEVING THE MODELS
        if self._model_id == 'CAPITAL_EFFICIENCY':
            self._model_tablename = 'sbt_indicator_capeff'
        elif self._model_id == 'MD_SCORE':
            self._model_tablename = 'development_sbt_models_dcf'
        elif self._model_id == 'MD_SCORE_FIN':
            self._model_tablename = 'development_sbt_models_merton'
        elif self._model_id == 'MOMENTUM':
            self._model_tablename = 'development_sbt_models_momentum'
        elif self._model_id == 'MM_MOMENTUM':
            self._model_tablename = 'sbt_indicator_mmmomentum'
        elif self._model_id == 'DIVIDEND':
            self._model_tablename = 'development_sbt_models_dividend_rankings'
        elif self._model_id == 'COMPOSITE':
            self._model_tablename = 'sbt_indicator_composite'
        else:
            self._model_tablename = None

        # PG DB
        self.pg = SbtGlobalCommon.get_sbt_config()['postgres']['datafactory']
        super().__init__(self.pg)

    def get_model_accessor(self):
        return self._model_accessor

    def get_rankings(self, guid=None, limit=None):
        """
          Return company rankings

          Return :
            list : Company Rankings in order
        """
        try:
            base_sql_query = """
                SELECT * FROM {}
            """.format(self._model_tablename)

            if guid is not None:
                sql_query = base_sql_query + " WHERE guid = '{}'".format(guid)

            if limit is not None:
                sql_query = base_sql_query + " LIMIT {}".format(limit)
            else:
                # return only the top 10 results
                # if self._model_id == "MM_MOMENTUM":
                #     base_sql_query = base_sql_query + """
                #         WHERE rating = 'BUY'
                #         ORDER BY model -> 'model' ->> 'last_recommendation_date' desc
                #     """
                sql_query = base_sql_query + " LIMIT 10"

            rankings = pd.read_sql_query(sql_query,
                                         self._engine,
                                         coerce_float=True
                                         )
            # add SYM & EXCH
            rankings['symbol'] = [sym.split(':')[0]
                                  for sym in rankings['composite_pk_id']]
            rankings['exchange'] = [sym.split(':')[1]
                                  for sym in rankings['composite_pk_id']]

            if self._model_id.startswith("MD_SCORE"):
                rankings['rank'] = rankings['rank'] * 100
                rankings['score'] = rankings['score'] * 100

            rankings.pop('composite_pk_id')
            rankings.pop('model')

            result = rankings.to_dict(orient='records')

            return result
        except Exception as e:
            return []

    # def get_company_model(self, symbol, exchange=None):
    #     """
    #       Returns the model associated with a company.
    #
    #       Args :
    #         symbol : Company Symbol
    #
    #       Returns :
    #         dict : Requested company information.
    #     """
    #     company_model = self._model_accessor.query_company_model(
    #         self._model_id,
    #         symbol,
    #         exchange=exchange)
    #
    #     # adding model rating
    #     if company_model:
    #         company_model['rating'] = \
    #             self.get_rankings(guid=company_model['guid']).get('rating',
    #                                                               'N/A')
    #
    #     parent = self._get_parent_calculator()
    #
    #     # This code will override calculated descriptions with latest descriptions
    #     for child in parent.get_child_calculations():
    #         if 'calculated_data' in company_model.keys() and \
    #                 child.get_id() in company_model[
    #             'calculated_data'].keys() and \
    #                 'description' in company_model['calculated_data'][
    #             child.get_id()].keys() and \
    #                 company_model['calculated_data'][child.get_id()][
    #                     'description'] != \
    #                 child.get_description():
    #             company_model['calculated_data'][child.get_id()][
    #                 'description'] = \
    #                 child.get_description()
    #
    #     # This code insert descriptions for the raw_data if it does not exist
    #     descriptions = []
    #     for mapping in parent.get_all_child_field_mappings():
    #         descriptions.append({'field_name': mapping['field_name'],
    #                              'description': mapping['description']})
    #
    #     # remove duplicates descriptions
    #     unique_fields = {x['field_name']: x['description'] for x in
    #                      descriptions}
    #     descriptions = [{'field_name': k, 'description': v} for k, v in
    #                     unique_fields.items()]
    #
    #     if company_model and 'raw_data' in company_model.keys() and \
    #             'descriptions' not in company_model['raw_data'].keys():
    #         company_model['raw_data']['descriptions'] = descriptions
    #
    #     if company_model and self._model_id == ModelId.MD_SCORE.value and \
    #             company_model['value'] == 0 and \
    #             company_model['rank_value'] != 0:
    #         company_model['value'] = company_model['rank_value']
    #
    #     return company_model

    def get_company_model(self, guid):
        sql_query = "SELECT * FROM {} WHERE composite_pk_id = '{}'".format(
            self._model_tablename, guid
        )
        # get calculations
        df = pd.read_sql_query(sql_query, self._engine)
        if len(df):
            # get model results and convert it into dict and return only the model
            if 'model' in df['model'].to_dict()[0]:
                company_model = df['model'].to_dict()[0]['model']
            else:
                company_model = df['model'].to_dict()[0]

            if self._model_id.startswith("MD_SCORE"):
                # show in percentile-ranking
                if self._model_id == "MD_SCORE_FIN":
                    company_model['rank'] = company_model['rank'] * 100
                else:
                    company_model['score'] = company_model['score'] * 100
                    company_model['value'] = company_model['value'] * 100
                    company_model['rank'] = company_model['rank'] * 100
        else:
            # the UI should never see this message because it should only call
            # the models based on the results from the /valid endpoint
            company_model = "No model available for GUID {}.".format(guid)

        return company_model

    def process_companies(self, mappings):
        """
          Processes all the company mappings that are provided and saves
          the information to the database.

          Args :
             mappings (list)  : Company mappings
        """
        for mapping in mappings:
            guid = mapping['guid']
            compare_date = self._sbtcommon.dateutil.add_months(
                self._sbtcommon.dateutil.get_current_timestamp(),
                -12)
            lastest_filing_date = mapping.get('latest_filing_date',
                                              '0000-00-00')

            if self._model_id != ModelId.MOMENTUM.value and \
                    (lastest_filing_date == '0000-00-00' or
                     lastest_filing_date == 'N/A' or
                     self._sbtcommon.dateutil.get_date(lastest_filing_date) <
                     compare_date):
                self._model_accessor.save_model_exception(guid, self._model_id,
                                                          mapping['symbol'],
                                                          'SEC Filings are not available for ' +
                                                          'last 12 months.',
                                                          exchange=mapping.get(
                                                              'exchange',
                                                              None))
                continue

            company = CompanyModel(self._model_id, guid,
                                   mapping['symbol'],
                                   mapping.get('exchange', None),
                                   self._get_parent_calculator())

            try:
                company.populate()
                self._model_data.append(company.convert_to_dictionary())
            except ModelException as me:
                self._model_accessor.save_model_exception(guid, self._model_id,
                                                          mapping['symbol'],
                                                          str(me),
                                                          exception_code=me.get_exception_code(),
                                                          exchange=mapping.get(
                                                              'exchange',
                                                              None))
            except Exception as e:
                self._model_accessor.save_model_exception(guid, self._model_id,
                                                          mapping['symbol'],
                                                          str(e),
                                                          exchange=mapping.get(
                                                              'exchange',
                                                              None))
            self._logger.critical(
                " DONE PROCESSING FOR {}".format(mapping['symbol']))

        self._save_calculations()

    def _save_ranks(self):
        """
          Saves ranks to the database
        """
        self._model_accessor.save_models(self._model_ranks,
                                         exclude_exception_delete=True)

    def _save_calculations(self):
        """
          Saves calculations to the database
        """
        self._model_accessor.save_models(self._model_data)

    def rank(self, company_info=None):
        """
          Ranks all data associated with the model and saves the results.
        """
        company_data = []
        if company_info:
            temp_list = []
            [temp_list.append(
                self._model_accessor.query_company_model(self._model_id,
                                                         symbol, exchange)
            ) for symbol, exchange in
                zip(company_info['symbols'], company_info['exchanges'])]
            # removing empty entries
            [company_data.append(x) for x in temp_list if len(x)]
        else:
            company_data = self._model_accessor.query_company_models(
                self._model_id)
        ranker = Ranker(self._model_id, self._get_parent_calculator(),
                        company_data)
        self._model_ranks = ranker.rank()
        self._save_ranks()
        parent = self._get_parent_calculator()
        rank_list = sorted(self._model_ranks,
                           key=lambda k: k['rank'],
                           reverse=parent.is_rank_listing_desc_order())

        final_listing = []
        for r in rank_list:
            item = {}
            item['guid'] = r['guid']
            item['ticker'] = r['symbol']
            item['exchange'] = r.get('exchange', 'N/A')
            # add info about penalties (if applicable)
            if 'total_penalty' in r:
                item.update(original_value=r['original_value'],
                            penalty=r['total_penalty'])
            item['value'] = r['value']
            item['rank_value'] = r['rank_value']
            item['rank'] = r['rank']
            item['rating'] = rate(self._model_id, r)
            final_listing.append(item)

        rankings = {'model_id': self._model_id,
                    'rankings': final_listing,
                    'ranking_date':
                        self._sbtcommon.dateutil.get_current_date_string()}

        self._model_accessor.save_model_rankings(rankings)

    def _get_parent_calculator(self):
        """
          Retrieves the parent calculator from the database and sets up
          the model for calculations.
        """
        parent_calculator = None

        calculations = self._calculation_def
        children = []
        pre_conditions = []
        for calculation in calculations:
            if calculation['active'] == False or \
                    calculation['model_id'] != self._model_id:
                continue

            if 'parent_calculation_id' in calculation.keys():
                if 'pre_condition' in calculation.keys() and \
                        calculation['pre_condition'] == True:
                    pre_conditions.append(Calculator(calculation))
                else:
                    children.append(Calculator(calculation))
            elif parent_calculator is None:
                parent_calculator = Calculator(calculation)

        if parent_calculator is not None:
            parent_calculator.set_child_calculations(children)
            parent_calculator.set_pre_conditions(pre_conditions)

        return parent_calculator
