import datetime
from decimal import Decimal
from decimal import ROUND_UP
from pg_accessor import PostgresAccessor
from sbt_common import SbtCommon

class ModelAccessor (PostgresAccessor) :
  def __init__ (self):
    self._sbtcommon = SbtCommon()
    config = self._sbtcommon.get_sbt_config()['postgres']['models']
    super().__init__(config)
  
  def get_default_model_information (self, modeltypeid):
    """
      Returns a listing containing the default model for the specified type .
      
      Args :
        modeltypeid (int) : Model Type ID
  
      Returns :
        list : List containing the default model for the specified model type     

    """
    query = self.create_django_query_builder('model_information', 
          return_columns=['id', 'name', 'model_type_id', 'status_id', 
                       'created_by', 'created_timestamp', 
                       'last_updated_timestamp', 'last_updated_by'], 
          and_conditions=[{'model_type_id__eq' : modeltypeid}, 
                          {'status_id__eq' : 1}])

    return self._execute_django_query(query)  
  
  
  def get_model_rankings (self, model_information_id):
    """
      Returns a listing of model rankings sorted in ascending order.
      
      Args :
        model_information_id (int) : Model Information ID
  
      Returns :
        list : List of dictionaries representing model ranking     
    """
    args = [model_information_id]
    sql = "SELECT ticker, value, rank_raw_value as rank_value, rank FROM model_company " + \
          "WHERE model_information_id = %s ORDER BY rank ASC"
  
    return self._execute_query(sql, args)
    
  def get_model_template (self, modeltypeid, ticker):
    """
      Retrieves a model by the ticker and model type id
    """
    results = None

    query = self.create_django_query_builder('model_information', 
              return_columns=['id'], 
              and_conditions=[{'model_type_id__eq' : modeltypeid}, 
                              {'status_id__eq' : 1}])

    template_results = self._execute_django_query(query)
    if template_results is None or len(template_results)  != 1 :
      template_fields = ['name', 'model_type_id', 'created_by', 
                         'last_updated_by']
      template_args = ['BASE TEMPLATE', modeltypeid, 'system', 'system']
      self._execute_django_dml(self.create_django_insert_builder(
        'model_information', template_fields, template_args))


    template_results = self._execute_django_query(query)

    if template_results and len(template_results) == 1 :
      results = self.get_model (template_results[0]['id'], ticker=ticker)

    return results

  def get_model (self, modelid, ticker=None):
    """
      Retrieves a model by the model id and ticker.
      if no ticker is provided all models should be returned (Functionality 
      not implemented yet)
    """
    results = None

    info_query = self.create_django_query_builder('model_information', 
                  return_columns=['id', 'name', 'model_type_id', 
                  'last_updated_timestamp'], 
                  and_conditions=[{'id__eq' : modelid}])
    info_results = self._execute_django_query(info_query)

    if info_results and len(info_results) > 0 :
      results = info_results[0]

      results['last_updated'] = \
        '{:%m/%d/%Y %H:%M:%S}'.format(results['last_updated_timestamp'])

      results.pop("last_updated_timestamp", None)

      type_query = self.create_django_query_builder('model_type', 
                    return_columns=[{'model_type' : 'name'}, 
                    {'description' : 'description'}], 
                    and_conditions=[
                    {'id__eq' : info_results[0]['model_type_id']}])
      type_results = self._execute_django_query(type_query)
      results.update(type_results[0])

      results.pop("model_type_id", None)

      company_results = self._execute_django_query(
                          self._get_company_query(ticker, modelid))

      if company_results and len(company_results) > 0 :
        for company in company_results :
          company_data_query = self.create_django_query_builder(
            'model_company_data', return_columns=[{'name' : 'name'}, 
            {'description' : 'description'}, {'value' : 'value'}, 
            {'rank' : 'rank'}, {'timeframe' : 'timeframe'}, 
            {'calculated' : 'calculated'} ], 
            and_conditions=[
            {'model_company_id__eq' : company['model_company_id']}])
          company_data_results = self._execute_django_query(
                                  company_data_query)
          company.pop("model_company_id", None)
          if company_data_results and len(company_data_results) > 0 :
            company['financial_data'] = company_data_results
          else :
            company['financial_data'] = []

          results['companies'] = {ticker : company}
      else :
        results['companies'] = {ticker : {}}

    return results


  def save_model (self, modelid, ticker, model_value, model_rank, 
                  financial_data, reload = False):
    """
      Saves a model to the underlying data repository.
    """    
    
    self._logger.info('Reload data ' + str(reload))
    
    company_query = self.create_django_query_builder('model_company', 
      return_columns=[{'id' : 'id'}, {'ticker' : 'ticker'}, 
                      {'value' : 'value'}, 
                      {'rank' : 'rank'} ], 
                      and_conditions=[
                        {'model_information_id__eq' : modelid}, 
                        {'ticker' : ticker}])
    company_results = self._execute_django_query(company_query)

    decimal_model_value = Decimal(str(model_value)).quantize(
                            Decimal('.00001'), rounding=ROUND_UP)

    if company_results is None or len(company_results) == 0 :
      company_fields = ['model_information_id', 'ticker', 'value', 
                        'rank']
      company_args = [modelid, ticker, decimal_model_value, model_rank]
      self._execute_django_dml(self.create_django_insert_builder(
        'model_company', company_fields, company_args))
      company_results = self._execute_django_query(company_query)
    elif decimal_model_value != company_results[0]['value']:
      company_fields = ['value', 'rank']
      company_args = [decimal_model_value, model_rank]
      self._execute_django_dml(self.create_django_update_builder(
        'model_company', company_fields, company_args, 'id', 
        company_results[0]['id']))
      company_results = self._execute_django_query(company_query)

    model_company_id = company_results[0]['id']

    company_data_query = self.create_django_query_builder(
      'model_company_data', return_columns=['id'], 
      and_conditions=[{'model_company_id__eq' : company_results[0]['id']}])
    company_data_results = self._execute_django_query(company_data_query)

    if company_data_results is None or len(company_data_results) == 0 :
      self._execute_django_dml(self.create_django_delete_builder(
        'model_company_data','model_company_id',model_company_id))

    for fin in financial_data :
      company_data_fields = None
      company_data_args = None
      value = fin['value']
      if value and fin['calculated'] :
        value = Decimal(str(fin['value'])).quantize(Decimal('.00001'), 
                                                      rounding=ROUND_UP)
      if fin['rank'] is None :
        company_data_fields = ['model_company_id', 'name', 
                               'description', 'value', 'timeframe', 
                               'calculated',]
        company_data_args = [model_company_id, fin['name'], 
                             fin['description'], value, 
                             fin['timeframe'], fin['calculated']]
      else :
        company_data_fields = ['model_company_id', 'name', 
                               'description', 'value', 'timeframe', 
                               'calculated', 'rank']
        company_data_args = [model_company_id, fin['name'], 
                             fin['description'], value, 
                             fin['timeframe'], fin['calculated'], 
                             fin['rank']]
      self._execute_django_dml(self.create_django_insert_builder(
        'model_company_data', company_data_fields, company_data_args))

    self._update_model_information_timestamp('system', modelid)

  def rank_model_company (self, modelid, direction = 'ASC'):
    """
      Ranks all the companies related to a specific model.
    """
    
    self._logger.info('Model ID ' + str(modelid))
    
    sql = 'SELECT model_company.id FROM model_company ' + \
          'ORDER BY rank_raw_value ' + direction.upper()
    ranks = self._execute_query(sql, None)
    rank_counter = 1
    for rank in ranks :
      update_fields = ['rank']
      update_args = [rank_counter]
      self._execute_django_dml(self.create_django_update_builder(
        'model_company', update_fields, update_args, 'id', rank['id']))
      rank_counter += 1

  def rank_model_company_data (self, modelid, company_data, 
                               model_rank_type = None):
    """
      Ranks any company specific model data that is not the main model.
    """
    rank_raw_values = None
    if model_rank_type and model_rank_type.upper() == 'AVERAGE' :
      rank_raw_values = {}

    for k,v in company_data.items() :
      args = [modelid, k]
      sql = 'SELECT model_company.ticker, ' + \
            'model_company_data.model_company_id, ' + \
            'model_company_data.id FROM ' + \
            'model_company INNER JOIN model_company_data ON ' + \
            '(model_company.id = model_company_data.model_company_id) '
      sql += 'WHERE model_company.model_information_id = %s AND ' + \
              'model_company_data.name = %s ' + \
              'ORDER BY model_company_data.value ' + v

      ranks = self._execute_query(sql, args)

      rank_counter = 1
      for rank in ranks :
        data_update_fields = ['rank']
        data_update_args = [rank_counter]
        self._execute_django_dml(self.create_django_update_builder(
          'model_company_data', data_update_fields, data_update_args, 
          'id', rank['id']))
        self._update_rank_raw_values (rank_raw_values, rank, rank_counter)
        rank_counter += 1

    if rank_raw_values is not None:
      num_ranks = len(company_data)
      for k,v in rank_raw_values.items() :
        rank_raw_value = v / num_ranks
        model_update_fields = ['rank_raw_value']
        model_update_args = [Decimal(
          rank_raw_value).quantize(Decimal('.00001'), 
                                   rounding=ROUND_UP)]
        self._execute_django_dml(self.create_django_update_builder(
          'model_company', model_update_fields, 
          model_update_args, 'id', k))

    self._update_model_information_timestamp('system', modelid)

  def _get_company_query (self, ticker, modelid):
    
    company_query =  None
    if ticker and len(ticker) > 0 :
      company_query = self.create_django_query_builder(
        'model_company', return_columns=[{'model_company_id' : 'id'}, 
        {'ticker' : 'ticker'}, {'value' : 'value'}, 
        {'rank' : 'rank'} ], 
        and_conditions=[{'model_information_id__eq' : modelid}, 
                        {'ticker' : ticker}])
    else :
      company_query = self.create_django_query_builder(
        'model_company', return_columns=[{'model_company_id' : 'id'}, 
        {'ticker' : 'ticker'}, {'value' : 'value'}, 
        {'rank' : 'rank'} ], 
        and_conditions=[{'model_information_id__eq' : modelid}])  
    
    return company_query  

  def _update_rank_raw_values (self, rank_raw_values, rank, rank_counter): 
    if rank_raw_values is not None:
      #print ('CALC')
      if rank['model_company_id'] in rank_raw_values.keys() :
        rank_raw_values[rank['model_company_id']] += \
        rank_counter
      else :
        rank_raw_values[rank['model_company_id']] = \
        rank_counter
        
  def _update_model_information_timestamp (self, user, modelid) :
    """
      Updates the timestamp on the model
    """
    model_update_fields = ['last_updated_by', 'last_updated_timestamp']
    model_update_args = [user, datetime.datetime.now()]
    self._execute_django_dml(self.create_django_update_builder(
      'model_information', model_update_fields, model_update_args, 
      'id', modelid))