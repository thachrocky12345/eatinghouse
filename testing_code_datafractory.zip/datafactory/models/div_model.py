from snp_accessor import SNPAccessor
from dd_accessor import DynamoAccessor
# import statsmodels.formula.api as sm
import pandas as pd
# import numpy as np

class DivModel():
  def __init__(self):
    self.sp = SNPAccessor()

  def special_growth(self, new_val, old_val):
    if new_val >= old_val:
      multiplier = 1
    else:
      multiplier = -1
    if old_val == 0 and new_val == 0:
      return 0
    elif old_val == 0:
      return 1
    else:
      return multiplier * abs((new_val-old_val)/old_val)

  def dividend_growth(self, new_group, old_group):
    new_flag = ''
    new_val = 0
    old_val = 0
    if new_group['annual_flag'] == 1:
      new_flag = 'annual'
      new_val = new_group['cashdividendspershare'] / 4
    elif new_group['semiannual_flag'] == 1:
      new_flag = 'semi'
      new_val = new_group['cashdividendspershare'] / 2
    else:
      new_flag = 'quarter'

    old_flag = ''
    if old_group['annual_flag'] == 1:
      old_flag = 'annual'
      old_val = old_group['cashdividendspershare'] / 4
    elif old_group['semiannual_flag'] == 1:
      old_flag = 'semi'
      old_val = old_group['cashdividendspershare'] / 2
    else:
      old_flag = 'quarter'


    if new_flag == old_flag:
      return self.special_growth(new_group['cashdividendspershare'], old_group['cashdividendspershare'])
    else:
      return self.special_growth(new_val, old_val)



  def special_division(self, numerator, denominator):
    if denominator == 0:
      return 0
    else:
      return numerator/denominator

  def binary(self, val):
    # 1 is no change or increase, 0 is cut
    if val < 0:
      return 0
    else:
      return 1

  def get_data(self, symbol_mapping):
    div_hist  = self.sp.query_history_data(symbol_mapping, "cashdividendspershare", 'q')
    if len(div_hist['data'])< 10:
      return None
    pe_hist   = self.sp.query_history_data(symbol_mapping, "pricetoearnings", 'q')
    ocf_hist  = self.sp.query_history_data(symbol_mapping, "netcashfromoperatingactivities", 'q')
    fcf_hist  = self.sp.query_history_data(symbol_mapping, "freecashflow", 'q')
    fcf_growth_hist  = self.sp.query_history_data(symbol_mapping, "fcffgrowth", 'q')
    evtoebitda_hist  = self.sp.query_history_data(symbol_mapping, "evtoebitda", 'q')
    ebit_hist  = self.sp.query_history_data(symbol_mapping, "ebit", 'q')
    ebitda_hist  = self.sp.query_history_data(symbol_mapping, "ebitda", 'q')
    ebitgrowth_hist  = self.sp.query_history_data(symbol_mapping, "ebitgrowth", 'q')
    ebitdagrowth_hist  = self.sp.query_history_data(symbol_mapping, "ebitdagrowth", 'q')
    netincome = self.sp.query_history_data(symbol_mapping, "netincome", "q")
    # augmentedpayoutratio = self.sp.query_history_data(symbol_mapping, "augmentedpayoutratio", "q")
    debttoebitda = self.sp.query_history_data(symbol_mapping, "debttoebitda", "q")
    # divpayoutratio = self.sp.query_history_data(symbol_mapping, "divpayoutratio", "q")
    dilutedeps = self.sp.query_history_data(symbol_mapping, "dilutedeps", "q")

    pan = pd.DataFrame(div_hist["data"])
    pan['timestamp'] = [x['timestamp'] for x in pan['ex']]
    pan[div_hist['data_tag']] = [x['value'] for x in div_hist["data"]]
    dels = []
    for i in range(1, len(pan)):
      if pan['cashdividendspershare'][i] == 0:
        if pan['cashdividendspershare'][i - 1] != 0 and pan['cashdividendspershare'][i + 1] != 0:
          dels.append(i)
    pan[pe_hist['data_tag']] = [x['value'] for x in pe_hist["data"]]
    pan[pe_hist['data_tag']+ "_growth"] = [0] + [self.special_growth(pe_hist['data'][i]['value'], pe_hist['data'][i-1]['value']) for i in range(1, len(pe_hist["data"]))]
    pan['pe_binary'] = [self.binary(x) for x in pan['pricetoearnings_growth']]

    pan[ocf_hist['data_tag']] = [x['value'] for x in ocf_hist["data"]]
    pan[ocf_hist['data_tag']+ "_growth"] = [0] + [self.special_growth(ocf_hist['data'][i]['value'], ocf_hist['data'][i-1]['value']) for i in range(1, len(ocf_hist["data"]))]
    pan['ocf_binary'] = [self.binary(x) for x in pan['netcashfromoperatingactivities_growth']]


    pan[fcf_hist['data_tag']] = [x['value'] for x in fcf_hist["data"]]
    pan[fcf_hist['data_tag']+ "_growth"] = [0] + [self.special_growth(fcf_hist['data'][i]['value'], fcf_hist['data'][i-1]['value']) for i in range(1, len(fcf_hist["data"]))]
    pan['fcf_binary'] = [self.binary(x) for x in pan['freecashflow_growth']]


    pan[fcf_growth_hist['data_tag']] = [x['value'] for x in fcf_growth_hist["data"]]
    pan[evtoebitda_hist['data_tag']] = [x['value'] for x in evtoebitda_hist["data"]]
    pan[evtoebitda_hist['data_tag']+ "_growth"] = [0] + [self.special_growth(evtoebitda_hist['data'][i]['value'], evtoebitda_hist['data'][i-1]['value']) for i in range(1, len(evtoebitda_hist["data"]))]
    pan['evtoebitda_binary'] = [self.binary(x) for x in pan['evtoebitda_growth']]


    pan[ebit_hist['data_tag']] = [x['value'] for x in ebit_hist["data"]]
    pan[ebit_hist['data_tag']+ "_growth"] = [0] + [self.special_growth(ebit_hist['data'][i]['value'], ebit_hist['data'][i-1]['value']) for i in range(1, len(ebit_hist["data"]))]
    pan['ebit_binary'] = [self.binary(x) for x in pan['ebit_growth']]

    pan[ebitda_hist['data_tag']] = [x['value'] for x in ebitda_hist["data"]]
    pan[ebitda_hist['data_tag']+ "_growth"] = [0] + [self.special_growth(ebitda_hist['data'][i]['value'], ebitda_hist['data'][i-1]['value']) for i in range(1, len(ebitda_hist["data"]))]
    pan['ebitda_binary'] = [self.binary(x) for x in pan['ebitda_growth']]
    pan['divpayoutratio'] = [self.special_division(div_hist['data'][i]['value'],dilutedeps['data'][i]['value']) for i in range(len(dilutedeps['data']))]
    pan['divpayoutratio_growth'] = [self.special_growth(pan['divpayoutratio_growth'][i],pan['divpayoutratio_growth'][i - 1]) for i in range(len(dilutedeps['data']))]
    pan.drop(['value'], 1, inplace=True)
    pan.sort_values(by=['timestamp'], inplace=True)
    pan.drop(dels, inplace=True)
    pan.reset_index(inplace=True)
    pan[div_hist['data_tag'] + "_growth"] = [0] + [
      self.special_growth(pan['cashdividendspershare'][i], pan['cashdividendspershare'][i - 1]) for i in
      range(1, len(pan['cashdividendspershare']))]
    pan['div_binary'] = [self.binary(pan['cashdividendspershare_growth'][i + 1]) for i in range(len(pan['cashdividendspershare_growth']) - 1)] + [1]

    # pan[ebitgrowth_hist['data_tag']] = [x['value'] for x in ebitgrowth_hist["data"]]
    # pan[ebitdagrowth_hist['data_tag']] = [x['value'] for x in ebitdagrowth_hist["data"]]
    # pan['log_fcfgrowth'] = np.log(pan['fcffgrowth'])
    return pan
    # # R^2 = 0.237
    # result = sm.ols(formula="div_binary ~ pricetoearnings_growth + netcashfromoperatingactivities_growth + freecashflow_growth + evtoebitda_growth + ebit_growth + ebitda_growth", data=pan).fit()
    # print(result.summary())
    # # R^2 = 0.234
    # result = sm.ols(
    #   formula="div_binary ~ pricetoearnings_growth + netcashfromoperatingactivities_growth",
    #   data=pan).fit()
    # print(result.summary())
    # # R^2 = 0.075
    # # result = sm.ols(
    # #   formula="div_binary ~ pe_binary + ocf_binary + fcf_binary + evtoebitda_binary + ebit_binary + ebitda_binary",
    # #   data=pan).fit()
    #
    # result = sm.ols(
    #   formula="div_binary ~ pricetoearnings_growth + ebitda_growth",
    #   data=pan).fit()
    # print(result.summary())
    #
    # result = sm.ols(
    #   formula="div_binary ~ pricetoearnings_growth + netcashfromoperatingactivities_growth+ ebitda_growth",
    #   data=pan).fit()
    #
    # print(result.summary())
    #
    # print()

  def create_dataframe(self):
    symbols = ["AAPL", "AXP", "BA", "CAT", "CSCO", "CVX", "XOM", "GS", "HD", "IBM", "INTC", "JNJ", "KO", "JPM", "MCD", "MMM", "MRK", "MSFT", "NKE", "PFE", "PG", "TRV", "UNH", "UTX", "VZ", "V", "WBA", "WMT", "DIS", "DOW"]
    dd = DynamoAccessor()
    s = []
    big_df = pd.DataFrame()
    for symbol in symbols:
      add = dd._query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NYSE")
      if add:
        ret_val = self.get_data(add[0])
      else:
        ret_val = self.get_data(dd._query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NSDQ")[0])
      if ret_val is not None:
        big_df = pd.concat([big_df, ret_val])
    # import numpy as np
    # import statsmodels.api as sm
    # import statsmodels.formula.api as smf
    # from scipy import stats
    # glm_binom = smf.glm(formula="div_binary ~ pricetoearnings_growth + netcashfromoperatingactivities_growth + freecashflow_growth + evtoebitda_growth + ebit_growth + ebitda_growth + divpayoutratio", data=big_df, family=sm.families.Binomial())
    # res = glm_binom.fit()
    # print(res.summary())
    print()


if __name__ == '__main__':
  div = DivModel()
  div.create_dataframe()
  # symbols = []
  # dd = DynamoAccessor()
  # symbols.append(dd._query_table_response('DEV_SBT_SYMBOL_EXCHANGE_MAPPING', 'guid', '0b0e58dd-5d63-4309-a255-d24b53e213ca', index_name='GUIDidx')['Items'][0])
  # for symbol in symbols:
  #   div.get_data(symbol)

