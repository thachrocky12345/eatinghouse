from datetime import datetime
import pandas as pd
import numpy as np

from dd_accessor import DynamoAccessor
from fs_accessor import FinancialAccessor, FinancialVendors
from pg_accessor import PostgresAccessor
from sqlalchemy.types import JSON, VARCHAR, FLOAT
from sbt_common import SbtGlobalCommon
from sbt_model_accessor import ModelAccessor

g_logger = SbtGlobalCommon.get_global_logger()

# environment to update
env = 'models'

# get the config
config = SbtGlobalCommon.raw_sbt_config[env]['postgres']['datafactory']
# create an instance of the PG accessor
pg = PostgresAccessor(config)

# get the config for S&P
config = SbtGlobalCommon.raw_sbt_config[env]['postgres']['snpcompanyfinancials']
# create an instance of the PG accessor
pg_sbtcompanyfin = PostgresAccessor(config)

# read scoring system for the models
# scoring_system = pd.read_json("./models_scoring_system.json", orient="records")
scoring_system = {
  "ce": {
    "fcf_to_revenue": {
    "to": [1000000, 40, 31, 22, 15, 8, 0, -8, -16, -25, -34, -10000],
    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
    "weight": 0.35
    },
    "roa": {
      "to": [1000000, 15, 12, 8, 6, 3, 0, -3, -5, -9, -12, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.25
    },
    "revenue_growth": {
      "to": [1000000, 54, 43, 32, 24, 16, 9, 1, -8, -19, -30, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.10
    },
    "sh_return": {
      "to": [1000000, 25, 19, 12, 7, 1, -1, -7, -12, -19, -25, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.30
    },
    "FIVE_YEAR_FCF_REVENUE_AVERAGE": {
    "to": [1000000, 40, 31, 22, 15, 8, 0, -8, -16, -25, -34, -10000],
    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
    "weight": 0.35
    },
    "FIVE_YEAR_ROA": {
      "to": [1000000, 15, 12, 8, 6, 3, 0, -3, -5, -9, -12, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.25
    },
    "FIVE_YEAR_REVENUE_GROWTH": {
      "to": [1000000, 54, 43, 32, 24, 16, 9, 1, -8, -19, -30, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.10
    },
    "FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE": {
      "to": [1000000, 25, 19, 12, 7, 1, -1, -7, -12, -19, -25, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.30
    },
    "rating": {
      "to": [100, 80, 75, 70, 63, 55, 48, 40, 30, 20, 0, -99],
      "grade": ["A", "B", "B", "C", "C", "C", "C", "D", "D", "F", "F", "N/A"]
    }
  },
  "mom": {},
  "md_score": {}
}
scoring_system = pd.DataFrame.from_dict(scoring_system)

# prefix to add to the name of the tables that will contain the results
RESULT_TABLENAME_PREFIX = 'development_sbt_models'

# # table name to read the symbols from
SYMBOL_MAPPING_TABLENAME = 'DEV_SBT_SYMBOL_EXCHANGE_MAPPING'


class CapEff(DynamoAccessor):

    def __init__(self):
        super().__init__()
        self.financial = FinancialAccessor(
            FinancialVendors.STANDARD_AND_POORS.value)
        self.model_accessor = ModelAccessor()
        # get scoring system for Capital Efficiency only
        self.scoring_system = scoring_system['ce']
        # points to be deducted from total points each time a criteria IS NOT met
        self.penalty_value = 5

        # self.all_symbols = SbtGlobalCommon.all_symbols
        g_logger.critical(" CAPEFF: READING SYMBOL EXCHANGE MAPPING TABLE...")
        tic = datetime.now()
        # scan
        self.all_symbols_list = self._scan_table_with_filter_str(
           SYMBOL_MAPPING_TABLENAME , 'symbol ne mairan'
        )
        # query by GUID
        # self.all_symbols_list = self._query_table(
        #     SYMBOL_MAPPING_TABLENAME,
        #     'guid', '0b0e58dd-5d63-4309-a255-d24b53e213ca',
        #     index_name='GUIDidx'
        # )
        g_logger.critical(" CAPEFF: READING TABLE FINISHED IN Dt = {}.".format(
            datetime.now() - tic
        ))
        # converting to a dataframe
        self.all_symbols = pd.DataFrame(self.all_symbols_list)
        # list of calculated items and its description to be used in the UI
        self.calc_data_item_description = {}

    def read_control_data(self, filename, tickers_only=True):
        print("Importing data from: {}".format(filename))

        if tickers_only:
            # return a list of the tickers to be used
            df = pd.read_excel(filename, sheet_name="Russell 3000-->",
                               header=0)
            tickers_list = [x.split(' US Equity')[0] for x in
                            df['Bloomberg Ticker']]
            data = tickers_list

        else:
            # return a DF with the raw data used in Mike's analysis
            # (have to specify columns to be used)
            df = pd.read_excel(filename, sheet_name="Data", header=10)
            data = df

        return data

    def _add_item_description(self, item_description_dict):
        # add calculated item's description
        self.calc_data_item_description.update(item_description_dict)

    def _get_data(self, symbol, params, type='a', start=0, end=5):
        data_list = [
            self.financial.query_history_data(symbol, par, type, 'desc')
            for par in params]
        # keep only past 5 years
        data_dict = {x['data_tag']: [v['value'] for v in x['data'][start:end]] \
            if len(x['data']) > 0 else None for x in data_list}
        if len(data_dict):
            # add time to data
            data_dict.update(date=[x['date']
                                   for x in data_list[0]['data'][start:end]])
            data_dict.update(timestamp=[x['timestamp']
                                        for x in
                                        data_list[0]['data'][start:end]])
            data_dict.update(fiscal_id=[x['fiscal_id']
                                        for x in
                                        data_list[0]['data'][start:end]])
            data_dict.update(fiscal_year=[x['fiscal_year']
                                          for x in
                                          data_list[0]['data'][start:end]])
            data_dict.update(fiscal_period=[x['fiscal_period']
                                            for x in
                                            data_list[0]['data'][start:end]])

        return data_dict

    def _save_model_results(self, data):
        g_logger.critical(' CAPITAL EFFICIENCY: SAVING RESULTS INTO PG...')
        tic = datetime.now()
        res_transf = {}
        # items for which we have do add a description to
        item_list = []
        # list of items to be removed from the formatted schema
        no_list = ['date', 'timestamp', 'fiscal_id',
                   'fiscal_year', 'fiscal_period']
        # transform data schema to comply with final schema for models
        for k, v in data.items():
            try:
                res_transf[k] = {}
                res_transf[k]['model'] = {}
                res_transf[k]['model']['raw_data'] = {}
                res_transf[k]['model']['calculated_data'] = {}
                # additional parameters
                res_transf[k]['model'].update({
                    "pre_conditions": v['criteria'],
                    "score": v['weighted_value'],
                    "value": v['weighted_value'],
                    "total_penalty": v['total_penalty'],
                    "final_points": v['final_points'],
                    "rank": v['final_points'],
                    "rating": v['rating'],
                    "date_calculated": datetime.now().strftime("%Y-%m-%d"),
                    "composite_pk_id": v['composite_pk_id']
                })
                for calc_item, x in v.items():
                    if isinstance(x, dict) and 'raw' in x:
                        # add calculated data
                        res_transf[k]['model']['calculated_data'][calc_item] = {
                            "value":
                                x['value'],
                            "calculation":
                                x['value'],
                            "date_calculated":
                                datetime.now().strftime("%Y-%m-%d"),
                            "points":
                                x['points'],
                            "rank":
                                x['points'],
                            "description":
                                self.calc_data_item_description[calc_item]['label'],
                            "display_value_as":
                                self.calc_data_item_description[calc_item]['format']
                        }
                        for k1, v1, in x.get('raw').items():
                            item_list.append(k1)
                            # add raw data
                            res_transf[k]["model"]["raw_data"][k1] = []
                            for v2, d, ts, fi, fy, fp in zip(
                                    v1,
                                    x['raw']['date'],
                                    x['raw']['timestamp'],
                                    x['raw']['fiscal_id'],
                                    x['raw']['fiscal_year'],
                                    x['raw']['fiscal_period']
                            ):
                                # update results
                                res_transf[k]["model"]["raw_data"][k1].append(
                                                {"date": d,
                                                 "timestamp": ts,
                                                 "value": v2,
                                                 "fiscal_id": fi,
                                                 "fiscal_year": fy,
                                                 "fiscal_period": fp
                                                 }
                                )

                        # remove unnecessary attributes
                        # ('date', 'timestamp', 'fiscal_id', 'fiscal_year', 'fiscal_period')
                        [res_transf[k]["model"]["raw_data"].pop(item)
                         for item in no_list]
            except Exception as e:
                g_logger.critical(
                    " An exception occurred in formating results "
                    "for GUID {}: {}".format(k, e))
                continue

        # remove duplicate entries
        unique_items = "', '".join(list({x for x in item_list \
                                         if x not in no_list})
                                   )
        # get descriptions from the sbt_data_item_id table
        query = """
            select * from dev_snp_data_item where sbt_data_item_id in ('{}')
        """.format(unique_items)
        descriptions = pd.read_sql_query(
            query.format(item_list), pg_sbtcompanyfin._engine
        )
        # formatting dict containing item name and its description from S&P
        # (also removing anything that's template specific)
        description_list = [{'field': v[1], 'description': v[2]}
                            for v in descriptions.values
                            if not v[2].lower().count('template')]
        # add description for the raw data
        [res_transf[x]["model"]["raw_data"].update(descriptions=description_list)
         for x in res_transf.keys()]

        # add new cols: rank (based on score), rating, score (final_points)
        final_res = {
            k: {'model': v,
                'score': v['model']['score'],
                'rank': v['model']['rank'],
                'rating': v['model']['rating'],
                'composite_pk_id': v['model']['composite_pk_id']
                } for k, v in res_transf.items()
        }

        df = pd.DataFrame(final_res).T
        # sorting df by rank (final # of points, which is what matters for CE)
        df.sort_values(by=['rank'], ascending=False, inplace=True)

        # save to PG
        df.to_sql(
            "{}_capeff".format(
                RESULT_TABLENAME_PREFIX
            ),
            pg._engine,
            if_exists='replace',
            index_label='guid',
            dtype={'model': JSON,
                   'score': FLOAT,
                   'rank': FLOAT,
                   'rating': VARCHAR,
                   'composite_pk_id': VARCHAR
                   }
        )

        g_logger.critical(' CAPITAL EFFICIENCY RESULTS SAVED IN Dt = {}'.format(
            datetime.now() - tic)
        )

        return df

    def _create_model_stats_table(self, model_id=None, data=None):
        g_logger.critical(' CAPEFF: CAPITAL EFFICIENCY CREATING STATS TABLE IN PG...')
        tic = datetime.now()
        model_id = "".join(model_id.lower().split("_"))
        # rating stats table
        TABLE_NAME = "{}_{}_rating_stats".format(RESULT_TABLENAME_PREFIX,
                                                    model_id
                                                    )
        # get the min/max for the model's rank (:= total number of points),
        # which is the most important result for CE
        df_stats = pd.DataFrame(
            ((x[1]['model']['rating'],
              x[1]['model']['rank']) for x in data.values),
            columns=['rating', 'rank']).groupby(by='rating')\
            .agg({"rank": [min, max, "count"]})
        # rename columns
        df_stats.columns = ['minRank', 'maxRank', 'total']
        # save rating stats
        df_stats.to_sql(TABLE_NAME,
                        pg._engine,
                        if_exists='replace',
                        index_label='rating'
                        )

        # rank stats table
        TABLE_NAME = "{}_{}_score_stats".format(RESULT_TABLENAME_PREFIX,
                                                 model_id
                                                 )
        model_stat_df = data.agg({'rank': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minrank', 'maxrank', 'total']
        # stats per model (total within each rank bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['rank'], [-1000, 0, 20, 40, 60, 80, 100])
        )['rank'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        model_score_stat_df.to_sql(TABLE_NAME,
                                   pg._engine,
                                   if_exists='replace'
                                   )

        g_logger.critical(
            ' CAPEFF: CAPITAL EFFICIENCY TABLE CREATED IN Dt = {}'.format(
                datetime.now() - tic)
        )

    def get_fcf_to_revenue(self, symbol):
        # add description
        self._add_item_description({'fcf_to_revenue': {
            'label': 'FCF-to-revenue ratio',
            'format': 'percentage'}
        })
        params = ['totalrevenue', 'capex', 'netcashfromoperatingactivities',
                  'debt']
        start, end = 1, 6
        data = {}
        data['raw'] = self._get_data(symbol, params, start=start, end=end)
        data['raw'].update(
            freecashflow=[x + y for x, y in zip(
                data['raw']['capex'],
                data['raw']['netcashfromoperatingactivities'])])
        params.append('freecashflow')
        # data['raw'].update(debt=self._get_data(symbol, ['debt'], start=start, end=end))
        data['avg'] = {k: pd.DataFrame(v).mean().values[0]
                       for k, v in data['raw'].items() if k in params}
        data['value'] = data['avg']['freecashflow'] / data['avg'][
            'totalrevenue'] \
                        * 100
        # get the total points
        mask = self.scoring_system.fcf_to_revenue['to'] >= data['value']
        data['points'] = min(
            pd.Series(self.scoring_system.fcf_to_revenue['points'])
                .values[mask].tolist())
        return data

    def get_roa(self, symbol):
        # add description
        self._add_item_description({'roa': {
            'label': 'Return on asset',
            'format': 'ratio'}
        })
        params = ['roa']
        start, end = 1, 6
        data = {}
        data['raw'] = self._get_data(symbol, params, start=start, end=end)
        data['avg'] = {k: pd.DataFrame(v).mean().values[0]
                       for k, v in data['raw'].items() if k in params}
        data['value'] = data['avg']['roa']
        # get the total points
        mask = self.scoring_system.roa['to'] >= data['value']
        data['points'] = min(pd.Series(
            self.scoring_system.roa['points']).values[mask].tolist())
        return data

    def get_revenue_growth(self, symbol):
        # add description
        self._add_item_description({'revenue_growth': {
            'label': 'Revenue growth',
            'format': 'percentage'}
        })
        params = ['totalrevenue', 'revenuegrowth']
        start, end = 1, 7
        dt = abs(start - end) - 1
        data = {}
        data['raw'] = self._get_data(symbol, params, start=start, end=end)
        # data['raw'].update(self._get_data(symbol, ['revenuegrowth'], start=start, end=end))
        data['avg'] = {k: pd.DataFrame(v).mean().values[0]
                       for k, v in data['raw'].items() if k in params}
        # ( (first_year_rev / last_year_rev)**(1/5) - 1 ) * 100
        trev = data['raw']['totalrevenue']
        data['value'] = np.float64(
            ((trev[0] / trev[-1]) ** (1 / dt) - 1) * 100)
        # get the total points
        mask = self.scoring_system.revenue_growth['to'] >= data['value']
        data['points'] = min(
            pd.Series(self.scoring_system.revenue_growth['points'])
                .values[mask].tolist())
        return data

    def get_shareholder_return(self, symbol):
        # add description
        self._add_item_description({'sh_return': {
            'label': 'Shareholder return',
            'format': 'percentage'}
        })
        params = [
            'paymentofdividends', 'issuanceofpreferredequity',
            'issuanceofcommonequity', 'repurchaseofcommonequity',
            'repurchaseofpreferredequity', 'totalrevenue'
        ]
        start, end = 1, 6
        data = {}
        data['raw'] = self._get_data(symbol, params, start=start, end=end)
        # ({paymentofdividends} + {issuanceofpreferredequity} +
        # {paymentofdividends} + {repurchaseofcommonequity} +
        # {repurchaseofpreferredequity}) / {revenue}
        data['avg'] = {k: pd.DataFrame(v).mean().values[0]
                       for k, v in data['raw'].items() if k in params}
        data['value'] = np.sum(
            [v for k, v in data['avg'].items() if k is not 'totalrevenue']) / \
                        data['avg']['totalrevenue'] * (-100)
        # get the total points
        mask = self.scoring_system.sh_return['to'] >= data['value']
        data['points'] = min(pd.Series(
            self.scoring_system.sh_return['points']).values[mask].tolist())
        return data

    def run_scoring_system(self, symbols):
        data = {}
        batch_size = 3
        counter = 1
        for guid, composite_pk_id in symbols.items():
            # DATA
            # store raw data
            try:
                data[guid] = {
                    'fcf_to_revenue': self.get_fcf_to_revenue(guid),
                    'roa': self.get_roa(guid),
                    'revenue_growth': self.get_revenue_growth(guid),
                    'sh_return': self.get_shareholder_return(guid)
                    }

                # validating data (no +/-inf)
                invalid_value = False
                for k, v in data[guid].items():
                    if v['value'] == float("-inf") \
                            or v['value'] == float("inf"):
                        invalid_value = True
                        continue

                if invalid_value:
                    # skip this item if there is an invalid value (+/-inf)
                    g_logger.critical(
                        " CAPEFF: SKIPPING GUID {} BECAUSE OF "
                        "INVALID CALCULATIONS (+/-inf).".format(guid)
                    )
                    # remove item from results
                    data.pop(guid)
                    continue

                # SCORING SYSTEM
                # weighted value based on the value of all financial parameters
                wvalue = sum(
                    [data[guid][p]['value'] * self.scoring_system[p][
                        'weight'] \
                     for p in data[guid]])
                # weighted points
                wpoints = sum(
                    [data[guid][p]['points'] * self.scoring_system[p][
                        'weight'] \
                     for p in data[guid]])
                # update data object
                data[guid].update(weighted_value=wvalue,
                                    weighted_points=wpoints)

                # PENALTIES
                # criteria for penalties
                criteria = []
                criteria.append({
                    'definition': 'FCF not negative in the last 5 yr.',
                    'met_criteria':
                        str(sum(1 for i in
                            data[guid]['fcf_to_revenue']['raw'][
                                'freecashflow']
                            if i < 0) == 0).lower()
                })
                criteria.append({
                    'definition': 'Revenue growth not negative in the last 5 yr.',
                    'met_criteria':
                        str(sum(1 for i in
                            data[guid]['revenue_growth']['raw'][
                                'revenuegrowth']
                            if i < 0) == 0).lower()
                })
                criteria.append({
                    'definition': 'Revenue growth > -15% in the last 5 yr.',
                    'met_criteria':
                        str(sum(1 for i in
                            data[guid]['revenue_growth']['raw'][
                                'revenuegrowth']
                            if i * 100 < -15) == 0).lower()
                })
                criteria.append({
                    'definition': '<FCF> x 10 > ST/LT Debt.',
                    'met_criteria':
                        str((pd.DataFrame(
                            data[guid]['fcf_to_revenue']['raw'][
                                'freecashflow'])
                         .mean().values * 10 >
                         data[guid]['fcf_to_revenue']['raw']['debt'])[0]).lower()
                })

                data[guid].update(criteria=[x for x in criteria])

                data[guid].update(
                    met_all_criteria=all(
                        [True if x['met_criteria'] == 'true' else False
                         for x in data[guid]['criteria']]
                    )
                )
                # apply penalties
                data[guid]['final_points'] = data[guid]['weighted_points']
                [data[guid].update(
                    final_points=data[guid]['final_points']
                                 - self.penalty_value)
                    for x in data[guid]['criteria']
                    if x['met_criteria'] == 'false'
                ]
                # add total penalty to the dict
                data[guid]['total_penalty'] = \
                    data[guid]['weighted_points'] \
                    - data[guid]['final_points']

                # RATING
                # use the final points for rating
                mask = self.scoring_system.rating['to'] >= np.float64(
                    data[guid]['final_points'])
                # get the last True item
                rating = pd.Series(self.scoring_system.rating['grade']).values[
                    mask].tolist()[-1]
                data[guid].update(rating=rating,
                                  composite_pk_id=composite_pk_id
                                  )

                # # save data if counter reaches limit
                # if not counter % batch_size:
                #   # save batch
                #   print("counter = {}; save data now.".format(counter))
                #   # clear variable
                #   data = {}
                # elif counter == len(symbols):
                #   # save remaining data
                #   print("counter = {}; save remaining data now.".format(counter))

                counter += 1

            except Exception as e:
                g_logger.critical(
                    " CAPEFF: An exception occurred in formating results "
                    "for GUID {}: {}".format(guid, e))
                continue

        # print("run_ranking_system DONE.")

        return data

    def run_it(self):
        g_logger.critical(" RUNNING CAPITAL EFFICIENCY NOW...")
        tic = datetime.now()
        # new scoring file path:
        # /Users/mteodoro/Google Drive/SB_MODELS/CE/new_ce_scoring.xlsx
        # read data in
        # data = self.read_control_data(filename)
        model_id = "capeff"
        symbols_data = self.all_symbols[
            (self.all_symbols.exchange_type == 'STOCK')
            & (self.all_symbols.exchange_country == 'USA')
            & ((self.all_symbols.exchange.str.startswith('NYSE'))
               | (self.all_symbols.exchange.str.startswith('NSDQ'))
               )
            ]
        # get all composite_pk_id, snp_id, and index info
        # (ignore snp_id = NaN)
        # symbols_data = [x for x in symbols_data['guid']]

        # keep GUID and SYMBOL:EXCHANGE
        symbols_data = {k: v for k, v in
                        zip(symbols_data['guid'],
                            symbols_data['composite_pk_id']
                            )
                        }

        # restrict local calculations to a smaller number
        # symbols = {k: v for i, (k, v) in enumerate(symbols_data.items())
        #            if i + 1 <= 10
        #            }
        # run for the full dataset
        symbols = symbols_data

        # execute the ranking system
        data = self.run_scoring_system(symbols)

        g_logger.critical(' CAPITAL EFFICIENCY CALCULATED IN Dt = {}'.format(
            datetime.now() - tic)
        )

        # format and save the results
        res = self._save_model_results(data)

        self._create_model_stats_table(model_id=model_id,
                                       data=res
                                       )

        g_logger.critical(' CAPITAL EFFICIENCY FINISHED.')


if __name__ == "__main__":
    ce = CapEff()

    ce.run_it()

    print("Done.")
