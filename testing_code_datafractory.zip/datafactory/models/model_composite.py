from datetime import datetime
import pandas as pd
import numpy as np

from dd_accessor import DynamoAccessor
from fs_accessor import FinancialAccessor, FinancialVendors
from pg_accessor import PostgresAccessor
from sqlalchemy.types import JSON, VARCHAR, FLOAT
from sbt_common import SbtGlobalCommon
from sbt_model_accessor import ModelAccessor

g_logger = SbtGlobalCommon.get_global_logger()

# environment to update
env = 'models'

# get the config
config = SbtGlobalCommon.raw_sbt_config[env]['postgres']['datafactory']
config_qa = SbtGlobalCommon.raw_sbt_config['qa']['postgres']['datafactory']
config_prod = SbtGlobalCommon.raw_sbt_config['prod']['postgres']['datafactory']
# create an instance of the PG accessor
pg = PostgresAccessor(config)
pg_qa = PostgresAccessor(config_qa)
pg_prod = PostgresAccessor(config_prod)

# get the config for S&P
config = SbtGlobalCommon.raw_sbt_config[env]['postgres']['snpcompanyfinancials']
# create an instance of the PG accessor
pg_sbtcompanyfin = PostgresAccessor(config)

# read scoring system for the models
# scoring_system = pd.read_json("./models_scoring_system.json", orient="records")
scoring_system = {
  "ce": {
    "fcf_to_revenue": {
    "to": [1000000, 40, 31, 22, 15, 8, 0, -8, -16, -25, -34, -10000],
    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
    "weight": 0.35
    },
    "roa": {
      "to": [1000000, 15, 12, 8, 6, 3, 0, -3, -5, -9, -12, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.25
    },
    "revenue_growth": {
      "to": [1000000, 54, 43, 32, 24, 16, 9, 1, -8, -19, -30, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.10
    },
    "sh_return": {
      "to": [1000000, 25, 19, 12, 7, 1, -1, -7, -12, -19, -25, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.30
    },
    "FIVE_YEAR_FCF_REVENUE_AVERAGE": {
    "to": [1000000, 40, 31, 22, 15, 8, 0, -8, -16, -25, -34, -10000],
    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
    "weight": 0.35
    },
    "FIVE_YEAR_ROA": {
      "to": [1000000, 15, 12, 8, 6, 3, 0, -3, -5, -9, -12, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.25
    },
    "FIVE_YEAR_REVENUE_GROWTH": {
      "to": [1000000, 54, 43, 32, 24, 16, 9, 1, -8, -19, -30, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.10
    },
    "FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE": {
      "to": [1000000, 25, 19, 12, 7, 1, -1, -7, -12, -19, -25, -100],
      "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10, -999],
      "weight": 0.30
    },
    "rating": {
      "to": [100, 80, 75, 70, 63, 55, 48, 40, 30, 20, 0, -99],
      "grade": ["A", "B", "B", "C", "C", "C", "C", "D", "D", "F", "F", "N/A"]
    }
  },
  "mom": {},
  "md_score": {}
}
scoring_system = pd.DataFrame.from_dict(scoring_system)

# prefix to add to the name of the tables that will contain the results
RESULT_TABLENAME_PREFIX = 'development_sbt_models'

# # table name to read the symbols from
SYMBOL_MAPPING_TABLENAME = 'DEV_SBT_SYMBOL_EXCHANGE_MAPPING'


class Composite(DynamoAccessor):

    def __init__(self):
        super().__init__()
        self.financial = FinancialAccessor(
            FinancialVendors.STANDARD_AND_POORS.value)
        self.model_accessor = ModelAccessor()

    def _save_model_results(self, data):
        g_logger.critical(' COMPOSITE INDICATOR: SAVING RESULTS INTO PG...')
        tic = datetime.now()

        raw_data_descriptions = {
            'capeff': 'Total points on Capital Efficiency indicator',
            'val': 'Percentile rank on Valuation indicator',
            'fin': 'Percentile rank on Financial indicator',
            'mom': 'Trending score on Momentum'
        }

        calculated_data_descriptions = {
            "average_rank": {"value": "Average rank", "units": "ratio"},
            "percentile_rank": {"value": "Percentile rank", "units": "percentage"},
            "rank": {"value": "Rank", "units": "integer"}
        }

        # add new cols: rank (based on score), rating, score (final_points)
        final_res = {
            v['guid']: {
                'model': {
                    'composite_raw_data': {
                        k1: v1 for k1, v1 in v.items()
                            if k1 in ['capeff',
                                      'val',
                                      'fin',
                                      'mom']
                    },
                    'calculated_data': {
                        k1: {
                            'value': v1,
                            'calculation': v1,
                            'date_calculated': datetime.now().strftime("%Y-%m-%d"),
                            'rank': v1,
                            'description': calculated_data_descriptions[k1]['value'],
                            'display_value_as': calculated_data_descriptions[k1]['units']
                        } for k1, v1 in v.items()
                            if k1 in ['average_rank',
                                  'percentile_rank',
                                  'rank']
                    },
                    'date_calculated': datetime.now().strftime('%Y-%m-%d'),
                    'guid': v['guid'],
                    'score': v['average_rank'],
                    'value': v['average_rank'],
                    'rank': int(v['rank']),
                    'rating': 'N/A'
                },
                'score': v['average_rank'],
                'rank': v['rank'],
                'rating': 'N/A',
                'composite_pk_id': v['composite_pk_id']
                } for v in data.T.to_dict().values()
        }

        # update model attribute with raw data descriptions
        {k: v['model']['composite_raw_data'].update(descriptions=raw_data_descriptions)
         for k, v in final_res.items()}

        df = pd.DataFrame(final_res).T
        # sorting df by rank (final # of points, which is what matters for CE)
        df.sort_values(by=['score'], ascending=False, inplace=True)

        # save to PG
        for engine in [pg._engine, pg_qa._engine, pg_prod._engine]:
            df.to_sql(
                "{}_composite".format(
                    RESULT_TABLENAME_PREFIX
                ),
                engine,
                if_exists='replace',
                index_label='guid',
                dtype={'model': JSON,
                       'score': FLOAT,
                       'rank': FLOAT,
                       'rating': VARCHAR,
                       'composite_pk_id': VARCHAR
                       }
            )

        g_logger.critical(' COMPOSITE INDICATOR RESULTS SAVED IN Dt = {}'.format(
            datetime.now() - tic)
        )

        return df

    def _create_model_stats_table(self, model_id=None, data=None):
        g_logger.critical(' COMPOSITE INDICATOR: CREATING STATS TABLE IN PG...')
        tic = datetime.now()
        model_id = "".join(model_id.lower().split("_"))
        # rank stats table
        TABLE_NAME = "{}_{}_score_stats".format(RESULT_TABLENAME_PREFIX,
                                                 model_id
                                                 )
        model_stat_df = data.agg({'score': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minscore', 'maxscore', 'total']
        # stats per model (total within each rank bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['score'], [-1000, 0, 20, 40, 60, 80, 100])
        )['score'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        for engine in [pg._engine, pg_qa._engine, pg_prod._engine]:
            model_score_stat_df.to_sql(TABLE_NAME,
                                       engine,
                                       if_exists='replace'
                                       )

        g_logger.critical(
            ' COMPOSITE INDICATOR TABLE CREATED IN Dt = {}'.format(
                datetime.now() - tic)
        )

    def run_it(self):
        g_logger.critical(" RUNNING COMPOSITE INDICATOR NOW...")
        model_id = "composite"
        sql_query = """
            select ce.guid guid,
                   ce.composite_pk_id composite_pk_id, 
                   ce.rank capeff,
                   val.score val ,
                   fin.score fin,
                   mom.score mom
            from development_sbt_models_capeff ce
                inner join development_sbt_models_mdscore_valuation val
                    using ("composite_pk_id")
                inner join development_sbt_models_mdscore_financial fin
                    using ("composite_pk_id")
                inner join development_sbt_models_mmmomentum mom
                    using ("composite_pk_id")
            where
                ce.rank is not null
                and val.score is not null
                and fin.score is not null
                and mom.score is not null
        """

        df = pd.read_sql(sql_query, pg._engine)
        # capeff's rank
        df['capeff'] = df.capeff
        # valuation's percentile rank
        df['val'] = 100 * df.val
        # financial's percentile rank
        df['fin'] = 100 * df.fin
        # mmmomentum's score
        df['mom'] = df.mom

        df['average_rank'] = (df.capeff + df.val + df.fin + df.mom) / 4.
        df['percentile_rank'] = 100 * df.average_rank.rank(pct=True)
        df['rank'] = df.percentile_rank.rank(ascending=False)

        # return only the top 10 companies if full_list == None
        df = df.sort_values(by='rank')

        # format and save the results
        res = self._save_model_results(data=df)

        self._create_model_stats_table(model_id=model_id,
                                       data=res
                                       )

        g_logger.critical(' COMPOSITE INDICATOR FINISHED.')


if __name__ == "__main__":
    composite = Composite()

    composite.run_it()

    print("Done.")
