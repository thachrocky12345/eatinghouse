import warnings
warnings.simplefilter(action='ignore', category=Warning)
import pandas as pd
# import sqlalchemy
# import boto3
import os
from sbt_common import SbtGlobalCommon
from sbt_common import SbtCommon
from pg_accessor import PostgresAccessor
from dd_accessor import DynamoAccessor
import numpy as np
from div_model import DivModel
# import statsmodels.api as sm
# import statsmodels.formula.api as smf
from sklearn.model_selection import train_test_split
from statistics import mean
from joblib import dump, load
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import export_graphviz
import pydot
import datetime
from sklearn.metrics import roc_curve, auc, classification_report
from sqlalchemy.types import JSON, VARCHAR, FLOAT
# from sklearn.tree import _tree
# import statistics
# import math
# import matplotlib.pyplot as plt
import boto3
from boto3.dynamodb.conditions import Key, Attr


class DivLoader():
    def __init__(self):
        session = boto3.session.Session(profile_name='profilename')
        self.ddb = session.resource('dynamodb')
        self.client = session.client('dynamodb')
        # get a list of all available tables
        self.dynamo_table_list = self.client.list_tables()['TableNames']
        self.config = SbtGlobalCommon.raw_sbt_config
        # self._host = self.config[self.ENV]['postgres']['datafactory']['host']
        # self._port = self.config[self.ENV]['postgres']['datafactory']['port']
        # self._credentials = self.config[self.ENV]['postgres']['datafactory']['credentials']
        # self._user = self.config[self.ENV]['postgres']['datafactory']['user']
        # self._dbname = self.config[self.ENV]['postgres']['datafactory']['database']
        # self._connection_string = "dbname='" + self._dbname + "' user='" + \
        #                           self._user + "' host='" + self._host + \
        #                           "' password=" + self._credentials
        # # dialect+driver://username:password@host:port/database
        # self._engine = sqlalchemy.create_engine(
        #   'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
        #     user=self._user, password=self._credentials,
        #     host=self._host, db=self._dbname))
        self.ENV = "dev"
        self.pgconfig = {self.ENV: self.config[self.ENV]['postgres']['datafactory']}
        self.pg = PostgresAccessor(self.pgconfig[self.ENV])
        self.dd = DynamoAccessor()

    def load(self, companyid, symbol):
        divmodel = DivModel()
        sbtcommon = SbtCommon()
        config = sbtcommon.get_sbt_config()
        pg_snp = PostgresAccessor(config['postgres']['snpsource'])

        # companyid = 24937
        dataitemids = [3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 368, 2042]
        dataitemdict = {'3058': 'cashdividendspershare', '100003': 'pricetoearnings',
                        '2006': 'netcashfromoperatingactivities', '4424': 'fcffgrowth', '4422': 'freecashflow',
                        '100063': 'evtoebitda', '400': 'ebit', '100689': 'ebitda', '15': 'netincome',
                        '4192': 'debttoebitda', '8': 'dilutedeps', '1096': 'cashandcashequiv',
                        '368': 'totalinterestexpense', '2042': 'saleofppe'}

        sql_query = """SELECT c.companyname, c.reportingtemplatetypeid, lp.filingdate, lp.fiscalyear, 
        pt.periodtypeid, pt.periodtypename,
                lp.fiscalquarter, lp.calendaryear, lp.calendarquarter,
                lp.periodenddate, un.unittypeid, un.unittypename, di.dataitemid,
                di.dataitemname, di.dataitemdescription, fd.dataitemvalue
            FROM public.ciqfinancialdata fd
                INNER JOIN public.ciqlatestinstancefinperiod lp ON fd.financialperiodid = lp.financialperiodid
                INNER JOIN public.ciqcompany c ON lp.companyid = c.companyid
                INNER JOIN public.ciqdataitem di ON fd.dataitemid = di.dataitemid
                INNER JOIN public.ciqfinunittype un ON un.unittypeid = fd.unittypeid
                INNER JOIN public.ciqperiodtype pt ON pt.periodtypeid = lp.periodtypeid
            WHERE lp.companyid = {}
                AND lp.periodtypeid = 1
                AND di.dataitemid in (3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 368)
                ORDER BY lp.fiscalyear desc, lp.fiscalquarter desc
            """.format(companyid)
        df = pd.read_sql(sql_query, con=pg_snp._engine, coerce_float=True)
        annual_div = df[df['dataitemid'] == 3058]

        # sql_query = """SELECT de.exdate, de.paydate, de.recorddate, de.announceddate, de.divamount,
        #                        cur.isocode, ex.exchangesymbol, defreq.divfreqtypename
        #                 FROM ciqdividend de
        #                     JOIN ciqtradingitem tii ON tii.tradingitemid = de.tradingitemid AND
        #                     tii.tradingitemstatusid in (15) AND tii.primaryflag = 1
        #                     JOIN ciqsecurity s ON s.securityid = tii.securityid AND s.primaryflag = 1
        #                     join ciqexchange ex on de.exchangeid = ex.exchangeid
        #                     join ciqcurrency cur on de.currencyid = cur.currencyid
        #                     left outer join ciqdividendfrequencytype defreq on de.divfreqtypeid = defreq.divfreqtypeid
        #                 WHERE s.companyid = {}
        #                     AND s.primaryflag = 1
        #                 ORDER BY exdate desc""".format(companyid)
        # df2 = pd.read_sql(sql_query, con=pg_snp._engine, coerce_float=True)
        # print()

        sql_query = """SELECT c.companyname, c.reportingtemplatetypeid, lp.filingdate, lp.fiscalyear, 
        pt.periodtypeid, pt.periodtypename, 
                        lp.fiscalquarter, lp.calendaryear, lp.calendarquarter, 
                        lp.periodenddate, un.unittypeid, un.unittypename, di.dataitemid, 
                        di.dataitemname, di.dataitemdescription, fd.dataitemvalue 
                    FROM public.ciqfinancialdata fd 
                        INNER JOIN public.ciqlatestinstancefinperiod lp ON fd.financialperiodid = lp.financialperiodid 
                        INNER JOIN public.ciqcompany c ON lp.companyid = c.companyid 
                        INNER JOIN public.ciqdataitem di ON fd.dataitemid = di.dataitemid 
                        INNER JOIN public.ciqfinunittype un ON un.unittypeid = fd.unittypeid 
                        INNER JOIN public.ciqperiodtype pt ON pt.periodtypeid = lp.periodtypeid 
                    WHERE lp.companyid = {}
                        AND lp.periodtypeid = 2
                        AND di.dataitemid in (3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 
                        368, 2042)
                        ORDER BY lp.fiscalyear desc, lp.fiscalquarter desc
    """.format(companyid)
        df = pd.read_sql(sql_query, con=pg_snp._engine, coerce_float=True)
        df_transformed = df[df['dataitemid'] == 8]
        df_transformed.drop(columns=['dataitemid', 'dataitemdescription', 'dataitemname', 'dataitemvalue'],
                            inplace=True)
        df_transformed.set_index('periodenddate', inplace=True)
        df_transformed.sort_index(inplace=True)
        meta = {}
        for id in dataitemids:
            df1 = df[df['dataitemid'] == id]
            if len(df1) > 0:
                meta[str(id)] = {'dataitemname': df1.at[df1.index[0], 'dataitemname'],
                                 'dataitemdescription': df1.at[df1.index[0], 'dataitemdescription']}
                df1.set_index('periodenddate', inplace=True)
                df_transformed = df_transformed.loc[~df_transformed.index.duplicated(keep='first')]
                df1 = df1.loc[~df1.index.duplicated(keep='first')]
                df_transformed = pd.concat([df_transformed, df1['dataitemvalue']], axis=1)
                # df_transformed.drop(columns=['dataitemid', 'dataitemdescription', 'dataitemname'], inplace=True)
                df_transformed.rename(columns={'dataitemvalue': dataitemdict[str(id)]}, inplace=True)
            else:
                df_transformed[dataitemdict[str(id)]] = np.nan
            if id in [100003, 2006, 4422, 100063, 400, 100689, 1096, 2042]:
                df_transformed[dataitemdict[str(id)] + "_growth"] = [0] + [
                    divmodel.special_growth(df_transformed.at[df_transformed.index[i], dataitemdict[str(id)]],
                                            df_transformed.at[df_transformed.index[i - 1], dataitemdict[str(id)]]) for i
                    in
                    range(1, len(df_transformed[dataitemdict[str(id)]]))]

                if len(df_transformed[dataitemdict[str(id)]]) > 4:
                    df_transformed[dataitemdict[str(id)] + "_1ygrowth"] = [0, 0, 0, 0] + [
                        divmodel.special_growth(
                            df_transformed.at[df_transformed.index[i], dataitemdict[str(id)]],
                            df_transformed.at[df_transformed.index[i - 4], dataitemdict[str(id)]])
                        for i in
                        range(4, len(df_transformed[dataitemdict[str(id)]]))]

                if len(df_transformed[dataitemdict[str(id)]]) > 20:
                    df_transformed[dataitemdict[str(id)] + "_5ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                           0, 0, 0, 0,
                                                                           0] + [
                                                                              divmodel.special_growth(
                                                                                  df_transformed.at[
                                                                                      df_transformed.index[i],
                                                                                      dataitemdict[str(id)]],
                                                                                  df_transformed.at[
                                                                                      df_transformed.index[i - 20],
                                                                                      dataitemdict[str(id)]])
                                                                              for i in
                                                                              range(20, len(df_transformed[dataitemdict[
                                                                                  str(id)]]))]

                if len(df_transformed[dataitemdict[str(id)]]) > 40:
                    df_transformed[dataitemdict[str(id)] + "_10ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                            0, 0, 0, 0,
                                                                            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                            0, 0, 0, 0,
                                                                            0, 0] + [
                                                                               divmodel.special_growth(
                                                                                   df_transformed.at[
                                                                                       df_transformed.index[i],
                                                                                       dataitemdict[str(id)]],
                                                                                   df_transformed.at[
                                                                                       df_transformed.index[i - 40],
                                                                                       dataitemdict[str(id)]])
                                                                               for i in
                                                                               range(40, len(df_transformed[
                                                                                                 dataitemdict[
                                                                                                     str(id)]]))]

                df_transformed[dataitemdict[str(id)] + "_binary"] = [divmodel.binary(x) for x in
                                                                     df_transformed[dataitemdict[str(id)] + "_growth"]]
            elif id == 3058:
                df_transformed['cashdividendspershare_growth'] = [0] + [
                    divmodel.special_growth(df_transformed[dataitemdict[str(id)]][i],
                                            df_transformed[dataitemdict[str(id)]][i - 1]) for i in
                    range(1, len(df_transformed[dataitemdict[str(id)]]))]
                df_transformed['div_binary'] = [divmodel.binary(df_transformed['cashdividendspershare_growth'][i + 1])
                                                for i in
                                                range(len(df_transformed['cashdividendspershare_growth']) - 1)] + [1]

        df_transformed['div_payout_ratio'] = [
            divmodel.special_division(df_transformed.at[df_transformed.index[i], 'cashdividendspershare'],
                                      df_transformed.at[df_transformed.index[i], 'dilutedeps']) for i in
            range(len(df_transformed['dilutedeps']))]
        df_transformed["div_payout_ratio_growth"] = [0] + [
            divmodel.special_growth(df_transformed.at[df_transformed.index[i], 'div_payout_ratio'],
                                    df_transformed.at[df_transformed.index[i - 1], 'div_payout_ratio']) for i in
            range(1, len(df_transformed['div_payout_ratio']))]
        if len(df_transformed['div_payout_ratio']) > 4:
            df_transformed['div_payout_ratio' + "_1ygrowth"] = [0, 0, 0, 0] + [
                divmodel.special_growth(
                    df_transformed.at[df_transformed.index[i], 'div_payout_ratio'],
                    df_transformed.at[df_transformed.index[i - 4], 'div_payout_ratio'])
                for i in
                range(4, len(df_transformed['div_payout_ratio']))]

        if len(df_transformed['div_payout_ratio']) > 20:
            df_transformed['div_payout_ratio' + "_5ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                0] + [
                                                                   divmodel.special_growth(
                                                                       df_transformed.at[
                                                                           df_transformed.index[i], 'div_payout_ratio'],
                                                                       df_transformed.at[df_transformed.index[
                                                                                             i - 20],
                                                                                         'div_payout_ratio'])
                                                                   for i in
                                                                   range(20, len(df_transformed['div_payout_ratio']))]

        if len(df_transformed['div_payout_ratio']) > 40:
            df_transformed['div_payout_ratio' + "_10ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                 0,
                                                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                 0,
                                                                 0, 0] + [
                                                                    divmodel.special_growth(
                                                                        df_transformed.at[df_transformed.index[
                                                                                              i], 'div_payout_ratio'],
                                                                        df_transformed.at[df_transformed.index[
                                                                                              i - 40],
                                                                                          'div_payout_ratio'])
                                                                    for i in
                                                                    range(40, len(df_transformed['div_payout_ratio']))]

        df_transformed['int/income'] = [
            divmodel.special_division(abs(df_transformed.at[df_transformed.index[i], 'totalinterestexpense']),
                                      df_transformed.at[df_transformed.index[i], 'netincome']) for i in
            range(len(df_transformed))]
        df_transformed['int/cash'] = [
            divmodel.special_division(abs(df_transformed.at[df_transformed.index[i], 'totalinterestexpense']),
                                      df_transformed.at[df_transformed.index[i], 'cashandcashequiv']) for i in
            range(len(df_transformed))]

        # formula = 'div_binary ~ pricetoearnings + netcashfromoperatingactivities + freecashflow + ebit + ebitda +
        # netincome + debttoebitda + dilutedeps + pricetoearnings_growth + netcashfromoperatingactivities_growth +
        # freecashflow_growth + ebit_growth + ebitda_growth + div_payout_ratio + div_payout_ratio_growth'
        # model = smf.glm(formula=formula,data=df_transformed, family=sm.families.Binomial()).fit()
        # print(model.summary())
        dic = {}
        df_transformed['annual_dividend'] = np.nan
        df_transformed['annual_flag'] = 0
        df_transformed['semiannual_flag'] = 0
        df_transformed['quarter_flag'] = 0
        for row in annual_div.iterrows():
            dic[row[1]['fiscalyear']] = row[1]['dataitemvalue']
        count = 0
        non_nan_count = 0
        for row2 in df_transformed.iterrows():
            try:
                df_transformed.at[df_transformed.index[count], 'annual_dividend'] = dic[row2[1]['fiscalyear']]
            except KeyError:
                df_transformed.at[df_transformed.index[count], 'annual_dividend'] = np.nan
            if not np.isnan(row2[1]['fiscalyear']):
                try:
                    if (count == 0 or non_nan_count == 0) and row2[1]['cashdividendspershare'] == dic[
                        int(row2[1]['fiscalyear'])]:
                        df_transformed.at[df_transformed.index[count], 'quarter_flag'] = 1
                    else:
                        if row2[1]['cashdividendspershare'] == dic[int(row2[1]['fiscalyear'])]:
                            df_transformed.at[df_transformed.index[count], 'annual_flag'] = 1
                        elif row2[1]['cashdividendspershare'] + df_transformed.at[
                            df_transformed.index[count - 2], 'cashdividendspershare'] == dic[
                            int(row2[1]['fiscalyear'])]:
                            df_transformed.at[df_transformed.index[count], 'semiannual_flag'] = 1
                            df_transformed.at[df_transformed.index[count - 2], 'semiannual_flag'] = 1
                            df_transformed.at[df_transformed.index[count - 2], 'quarter_flag'] = 0
                            df_transformed.at[df_transformed.index[count - 2], 'annual_flag'] = 0
                        else:
                            df_transformed.at[df_transformed.index[count], 'quarter_flag'] = 1
                except KeyError:
                    df_transformed.at[df_transformed.index[count], 'semiannual_flag'] = df_transformed.at[
                        df_transformed.index[count - 1], 'semiannual_flag']
                    df_transformed.at[df_transformed.index[count], 'annual_flag'] = df_transformed.at[
                        df_transformed.index[count - 1], 'annual_flag']
                    df_transformed.at[df_transformed.index[count], 'quarter_flag'] = df_transformed.at[
                        df_transformed.index[count - 1], 'quarter_flag']
                finally:
                    non_nan_count += 1
            else:
                df_transformed.at[df_transformed.index[count], 'semiannual_flag'] = df_transformed.at[
                    df_transformed.index[count - 1], 'semiannual_flag']
                df_transformed.at[df_transformed.index[count], 'annual_flag'] = df_transformed.at[
                    df_transformed.index[count - 1], 'annual_flag']
                df_transformed.at[df_transformed.index[count], 'quarter_flag'] = df_transformed.at[
                    df_transformed.index[count - 1], 'quarter_flag']

            count += 1

        nans = df_transformed[np.isnan(df_transformed['cashdividendspershare'])].index
        zs = df_transformed[df_transformed['cashdividendspershare'] == 0].index
        # print(len(nans))
        df_transformed.drop(nans, inplace=True)
        df_transformed.drop(zs, inplace=True)
        divmodel = DivModel()
        updated_df = pd.DataFrame()
        df_transformed['composite_pk_id'] = symbol
        for group in df_transformed.groupby(['composite_pk_id']):
            growth_lst = []
            binary_lst = []
            # print(group[0])
            group = group[1]
            group.reset_index(inplace=True)
            # print(group['cashdividendspershare'])

            growth_lst.append([0] + [divmodel.dividend_growth(group.iloc[i],
                                                              group.iloc[i - 1]) for i in
                                     range(1, len(group['cashdividendspershare']))])
            group['cashdividendspershare_growth'] = growth_lst[0]

            binary_lst.append([divmodel.binary(group['cashdividendspershare_growth'][i + 1])
                               for i in range(len(group['cashdividendspershare_growth']) - 1)] + [1])

            group['div_binary'] = binary_lst[0]
            updated_df = pd.concat([updated_df, group])

        ever_cut = 0
        last_5 = 0
        last_10 = 0
        last_index = 0
        quick = 0
        count = 0
        last_cut = 0
        borrowed = 0
        updated_df["ever_cut"] = 0
        updated_df["last5cut"] = 0
        updated_df["last10cut"] = 0
        updated_df['quick_recover'] = 0
        updated_df['borrowed'] = 0
        for row in updated_df.iterrows():
            if np.sign(row[1]['cashdividendspershare_growth']) < 0:
                last_cut = count
                ever_cut = 1
                last_5 = 1
                last_10 = 1
                quick = 0
            if last_index - count > 20 and last_5 == 1:
                last_5 = 0
            if last_index - count > 40 and last_10 == 1:
                last_10 = 0
            if last_5 == 1 and row[1]['cashdividendspershare'] >= updated_df.at[
                updated_df.index[last_cut], 'cashdividendspershare']:
                quick = 1

            if row[1]['dilutedeps'] <= row[1]['cashdividendspershare'] and row[1]['cashdividendspershare'] > 0 and \
                row[1]['cashandcashequiv_1ygrowth'] < 0:
                updated_df.at[row[0], "borrowed"] = 1

            updated_df.at[row[0], "quick_recover"] = quick
            updated_df.at[row[0], "ever_cut"] = ever_cut
            updated_df.at[row[0], "last5cut"] = last_5
            updated_df.at[row[0], "last10cut"] = last_10
            count += 1
        return updated_df

    def to_pg(self):
        symbols = ["AAPL", "AXP", "BA", "CAT", "CSCO", "CVX", "XOM", "GS", "HD", "IBM", "INTC", "JNJ", "KO", "JPM",
                   "MCD",
                   "MMM", "MRK", "MSFT", "NKE", "PFE", "PG", "TRV", "UNH", "UTX", "VZ", "V", "WBA", "WMT", "DIS", "DOW",
                   "GM", "JCP", "RAD", "BP", "AIG", "F", "RIG", "NE", "SDRL", "KMI", "C", "JPM", "HOPE", "NVDA", "MDLZ",
                   "TEVA", "M", "L", "MSFT", "IBM", "MTCH", "CBRE", "AMZN",
                   "LMT", "SPR", "NUV", "RECN", "KL", "TMUS", "WF", "LOW", "AAPL", "CAT", "GOLD", "DHI", "SLB", "BRK.B",
                   "IR", "JPM", "MSI", "RMD", "HII", "BHC", "ROL", "JPS", "EMD"]

        sp500 = [{"Name": "3M Company", "Sector": "Industrials", "Symbol": "MMM"},
                 {"Name": "A.O. Smith Corp", "Sector": "Industrials", "Symbol": "AOS"},
                 {"Name": "Abbott Laboratories", "Sector": "Health Care", "Symbol": "ABT"},
                 {"Name": "AbbVie Inc.", "Sector": "Health Care", "Symbol": "ABBV"},
                 {"Name": "Accenture plc", "Sector": "Information Technology", "Symbol": "ACN"},
                 {"Name": "Activision Blizzard", "Sector": "Information Technology", "Symbol": "ATVI"},
                 {"Name": "Acuity Brands Inc", "Sector": "Industrials", "Symbol": "AYI"},
                 {"Name": "Adobe Systems Inc", "Sector": "Information Technology", "Symbol": "ADBE"},
                 {"Name": "Advance Auto Parts", "Sector": "Consumer Discretionary", "Symbol": "AAP"},
                 {"Name": "Advanced Micro Devices Inc", "Sector": "Information Technology", "Symbol": "AMD"},
                 {"Name": "AES Corp", "Sector": "Utilities", "Symbol": "AES"},
                 {"Name": "Aetna Inc", "Sector": "Health Care", "Symbol": "AET"},
                 {"Name": "Affiliated Managers Group Inc", "Sector": "Financials", "Symbol": "AMG"},
                 {"Name": "AFLAC Inc", "Sector": "Financials", "Symbol": "AFL"},
                 {"Name": "Agilent Technologies Inc", "Sector": "Health Care", "Symbol": "A"},
                 {"Name": "Air Products & Chemicals Inc", "Sector": "Materials", "Symbol": "APD"},
                 {"Name": "Akamai Technologies Inc", "Sector": "Information Technology", "Symbol": "AKAM"},
                 {"Name": "Alaska Air Group Inc", "Sector": "Industrials", "Symbol": "ALK"},
                 {"Name": "Albemarle Corp", "Sector": "Materials", "Symbol": "ALB"},
                 {"Name": "Alexandria Real Estate Equities Inc", "Sector": "Real Estate", "Symbol": "ARE"},
                 {"Name": "Alexion Pharmaceuticals", "Sector": "Health Care", "Symbol": "ALXN"},
                 {"Name": "Align Technology", "Sector": "Health Care", "Symbol": "ALGN"},
                 {"Name": "Allegion", "Sector": "Industrials", "Symbol": "ALLE"},
                 {"Name": "Allergan, Plc", "Sector": "Health Care", "Symbol": "AGN"},
                 {"Name": "Alliance Data Systems", "Sector": "Information Technology", "Symbol": "ADS"},
                 {"Name": "Alliant Energy Corp", "Sector": "Utilities", "Symbol": "LNT"},
                 {"Name": "Allstate Corp", "Sector": "Financials", "Symbol": "ALL"},
                 {"Name": "Alphabet Inc Class A", "Sector": "Information Technology", "Symbol": "GOOGL"},
                 {"Name": "Alphabet Inc Class C", "Sector": "Information Technology", "Symbol": "GOOG"},
                 {"Name": "Altria Group Inc", "Sector": "Consumer Staples", "Symbol": "MO"},
                 {"Name": "Amazon.com Inc.", "Sector": "Consumer Discretionary", "Symbol": "AMZN"},
                 {"Name": "Ameren Corp", "Sector": "Utilities", "Symbol": "AEE"},
                 {"Name": "American Airlines Group", "Sector": "Industrials", "Symbol": "AAL"},
                 {"Name": "American Electric Power", "Sector": "Utilities", "Symbol": "AEP"},
                 {"Name": "American Express Co", "Sector": "Financials", "Symbol": "AXP"},
                 {"Name": "American International Group, Inc.", "Sector": "Financials", "Symbol": "AIG"},
                 {"Name": "American Tower Corp A", "Sector": "Real Estate", "Symbol": "AMT"},
                 {"Name": "American Water Works Company Inc", "Sector": "Utilities", "Symbol": "AWK"},
                 {"Name": "Ameriprise Financial", "Sector": "Financials", "Symbol": "AMP"},
                 {"Name": "AmerisourceBergen Corp", "Sector": "Health Care", "Symbol": "ABC"},
                 {"Name": "AMETEK Inc.", "Sector": "Industrials", "Symbol": "AME"},
                 {"Name": "Amgen Inc.", "Sector": "Health Care", "Symbol": "AMGN"},
                 {"Name": "Amphenol Corp", "Sector": "Information Technology", "Symbol": "APH"},
                 {"Name": "Anadarko Petroleum Corp", "Sector": "Energy", "Symbol": "APC"},
                 {"Name": "Analog Devices, Inc.", "Sector": "Information Technology", "Symbol": "ADI"},
                 {"Name": "Andeavor", "Sector": "Energy", "Symbol": "ANDV"},
                 {"Name": "ANSYS", "Sector": "Information Technology", "Symbol": "ANSS"},
                 {"Name": "Anthem Inc.", "Sector": "Health Care", "Symbol": "ANTM"},
                 {"Name": "Aon plc", "Sector": "Financials", "Symbol": "AON"},
                 {"Name": "Apache Corporation", "Sector": "Energy", "Symbol": "APA"},
                 {"Name": "Apartment Investment & Management", "Sector": "Real Estate", "Symbol": "AIV"},
                 {"Name": "Apple Inc.", "Sector": "Information Technology", "Symbol": "AAPL"},
                 {"Name": "Applied Materials Inc.", "Sector": "Information Technology", "Symbol": "AMAT"},
                 {"Name": "Aptiv Plc", "Sector": "Consumer Discretionary", "Symbol": "APTV"},
                 {"Name": "Archer-Daniels-Midland Co", "Sector": "Consumer Staples", "Symbol": "ADM"},
                 {"Name": "Arconic Inc.", "Sector": "Industrials", "Symbol": "ARNC"},
                 {"Name": "Arthur J. Gallagher & Co.", "Sector": "Financials", "Symbol": "AJG"},
                 {"Name": "Assurant Inc.", "Sector": "Financials", "Symbol": "AIZ"},
                 {"Name": "AT&T Inc.", "Sector": "Telecommunication Services", "Symbol": "T"},
                 {"Name": "Autodesk Inc.", "Sector": "Information Technology", "Symbol": "ADSK"},
                 {"Name": "Automatic Data Processing", "Sector": "Information Technology", "Symbol": "ADP"},
                 {"Name": "AutoZone Inc", "Sector": "Consumer Discretionary", "Symbol": "AZO"},
                 {"Name": "AvalonBay Communities, Inc.", "Sector": "Real Estate", "Symbol": "AVB"},
                 {"Name": "Avery Dennison Corp", "Sector": "Materials", "Symbol": "AVY"},
                 {"Name": "Baker Hughes, a GE Company", "Sector": "Energy", "Symbol": "BHGE"},
                 {"Name": "Ball Corp", "Sector": "Materials", "Symbol": "BLL"},
                 {"Name": "Bank of America Corp", "Sector": "Financials", "Symbol": "BAC"},
                 {"Name": "Baxter International Inc.", "Sector": "Health Care", "Symbol": "BAX"},
                 {"Name": "Becton Dickinson", "Sector": "Health Care", "Symbol": "BDX"},
                 {"Name": "Berkshire Hathaway", "Sector": "Financials", "Symbol": "BRK.B"},
                 {"Name": "Best Buy Co. Inc.", "Sector": "Consumer Discretionary", "Symbol": "BBY"},
                 {"Name": "Biogen Inc.", "Sector": "Health Care", "Symbol": "BIIB"},
                 {"Name": "BlackRock", "Sector": "Financials", "Symbol": "BLK"},
                 {"Name": "Block H&R", "Sector": "Financials", "Symbol": "HRB"},
                 {"Name": "Boeing Company", "Sector": "Industrials", "Symbol": "BA"},
                 {"Name": "Booking Holdings Inc", "Sector": "Consumer Discretionary", "Symbol": "BKNG"},
                 {"Name": "BorgWarner", "Sector": "Consumer Discretionary", "Symbol": "BWA"},
                 {"Name": "Boston Properties", "Sector": "Real Estate", "Symbol": "BXP"},
                 {"Name": "Boston Scientific", "Sector": "Health Care", "Symbol": "BSX"},
                 {"Name": "Brighthouse Financial Inc", "Sector": "Financials", "Symbol": "BHF"},
                 {"Name": "Bristol-Myers Squibb", "Sector": "Health Care", "Symbol": "BMY"},
                 {"Name": "Broadcom", "Sector": "Information Technology", "Symbol": "AVGO"},
                 {"Name": "Brown-Forman Corp.", "Sector": "Consumer Staples", "Symbol": "BF.B"},
                 {"Name": "C. H. Robinson Worldwide", "Sector": "Industrials", "Symbol": "CHRW"},
                 {"Name": "CA, Inc.", "Sector": "Information Technology", "Symbol": "CA"},
                 {"Name": "Cabot Oil & Gas", "Sector": "Energy", "Symbol": "COG"},
                 {"Name": "Cadence Design Systems", "Sector": "Information Technology", "Symbol": "CDNS"},
                 {"Name": "Campbell Soup", "Sector": "Consumer Staples", "Symbol": "CPB"},
                 {"Name": "Capital One Financial", "Sector": "Financials", "Symbol": "COF"},
                 {"Name": "Cardinal Health Inc.", "Sector": "Health Care", "Symbol": "CAH"},
                 {"Name": "Carmax Inc", "Sector": "Consumer Discretionary", "Symbol": "KMX"},
                 {"Name": "Carnival Corp.", "Sector": "Consumer Discretionary", "Symbol": "CCL"},
                 {"Name": "Caterpillar Inc.", "Sector": "Industrials", "Symbol": "CAT"},
                 {"Name": "Cboe Global Markets", "Sector": "Financials", "Symbol": "CBOE"},
                 {"Name": "CBRE Group", "Sector": "Real Estate", "Symbol": "CBRE"},
                 {"Name": "Centene Corporation", "Sector": "Health Care", "Symbol": "CNC"},
                 {"Name": "CenterPoint Energy", "Sector": "Utilities", "Symbol": "CNP"},
                 {"Name": "CenturyLink Inc", "Sector": "Telecommunication Services", "Symbol": "CTL"},
                 {"Name": "Cerner", "Sector": "Health Care", "Symbol": "CERN"},
                 {"Name": "CF Industries Holdings Inc", "Sector": "Materials", "Symbol": "CF"},
                 {"Name": "Charles Schwab Corporation", "Sector": "Financials", "Symbol": "SCHW"},
                 {"Name": "Charter Communications", "Sector": "Consumer Discretionary", "Symbol": "CHTR"},
                 {"Name": "Chevron Corp.", "Sector": "Energy", "Symbol": "CVX"},
                 {"Name": "Chipotle Mexican Grill", "Sector": "Consumer Discretionary", "Symbol": "CMG"},
                 {"Name": "Chubb Limited", "Sector": "Financials", "Symbol": "CB"},
                 {"Name": "Church & Dwight", "Sector": "Consumer Staples", "Symbol": "CHD"},
                 {"Name": "CIGNA Corp.", "Sector": "Health Care", "Symbol": "CI"},
                 {"Name": "Cimarex Energy", "Sector": "Energy", "Symbol": "XEC"},
                 {"Name": "Cincinnati Financial", "Sector": "Financials", "Symbol": "CINF"},
                 {"Name": "Cintas Corporation", "Sector": "Industrials", "Symbol": "CTAS"},
                 {"Name": "Cisco Systems", "Sector": "Information Technology", "Symbol": "CSCO"},
                 {"Name": "Citigroup Inc.", "Sector": "Financials", "Symbol": "C"},
                 {"Name": "Citizens Financial Group", "Sector": "Financials", "Symbol": "CFG"},
                 {"Name": "Citrix Systems", "Sector": "Information Technology", "Symbol": "CTXS"},
                 {"Name": "CME Group Inc.", "Sector": "Financials", "Symbol": "CME"},
                 {"Name": "CMS Energy", "Sector": "Utilities", "Symbol": "CMS"},
                 {"Name": "Coca-Cola Company (The)", "Sector": "Consumer Staples", "Symbol": "KO"},
                 {"Name": "Cognizant Technology Solutions", "Sector": "Information Technology", "Symbol": "CTSH"},
                 {"Name": "Colgate-Palmolive", "Sector": "Consumer Staples", "Symbol": "CL"},
                 {"Name": "Comcast Corp.", "Sector": "Consumer Discretionary", "Symbol": "CMCSA"},
                 {"Name": "Comerica Inc.", "Sector": "Financials", "Symbol": "CMA"},
                 {"Name": "Conagra Brands", "Sector": "Consumer Staples", "Symbol": "CAG"},
                 {"Name": "Concho Resources", "Sector": "Energy", "Symbol": "CXO"},
                 {"Name": "ConocoPhillips", "Sector": "Energy", "Symbol": "COP"},
                 {"Name": "Consolidated Edison", "Sector": "Utilities", "Symbol": "ED"},
                 {"Name": "Constellation Brands", "Sector": "Consumer Staples", "Symbol": "STZ"},
                 {"Name": "Corning Inc.", "Sector": "Information Technology", "Symbol": "GLW"},
                 {"Name": "Costco Wholesale Corp.", "Sector": "Consumer Staples", "Symbol": "COST"},
                 {"Name": "Coty, Inc", "Sector": "Consumer Staples", "Symbol": "COTY"},
                 {"Name": "Crown Castle International Corp.", "Sector": "Real Estate", "Symbol": "CCI"},
                 {"Name": "CSRA Inc.", "Sector": "Information Technology", "Symbol": "CSRA"},
                 {"Name": "CSX Corp.", "Sector": "Industrials", "Symbol": "CSX"},
                 {"Name": "Cummins Inc.", "Sector": "Industrials", "Symbol": "CMI"},
                 {"Name": "CVS Health", "Sector": "Consumer Staples", "Symbol": "CVS"},
                 {"Name": "D. R. Horton", "Sector": "Consumer Discretionary", "Symbol": "DHI"},
                 {"Name": "Danaher Corp.", "Sector": "Health Care", "Symbol": "DHR"},
                 {"Name": "Darden Restaurants", "Sector": "Consumer Discretionary", "Symbol": "DRI"},
                 {"Name": "DaVita Inc.", "Sector": "Health Care", "Symbol": "DVA"},
                 {"Name": "Deere & Co.", "Sector": "Industrials", "Symbol": "DE"},
                 {"Name": "Delta Air Lines Inc.", "Sector": "Industrials", "Symbol": "DAL"},
                 {"Name": "Dentsply Sirona", "Sector": "Health Care", "Symbol": "XRAY"},
                 {"Name": "Devon Energy Corp.", "Sector": "Energy", "Symbol": "DVN"},
                 {"Name": "Digital Realty Trust Inc", "Sector": "Real Estate", "Symbol": "DLR"},
                 {"Name": "Discover Financial Services", "Sector": "Financials", "Symbol": "DFS"},
                 {"Name": "Discovery Inc. Class A", "Sector": "Consumer Discretionary", "Symbol": "DISCA"},
                 {"Name": "Discovery Inc. Class C", "Sector": "Consumer Discretionary", "Symbol": "DISCK"},
                 {"Name": "Dish Network", "Sector": "Consumer Discretionary", "Symbol": "DISH"},
                 {"Name": "Dollar General", "Sector": "Consumer Discretionary", "Symbol": "DG"},
                 {"Name": "Dollar Tree", "Sector": "Consumer Discretionary", "Symbol": "DLTR"},
                 {"Name": "Dominion Energy", "Sector": "Utilities", "Symbol": "D"},
                 {"Name": "Dover Corp.", "Sector": "Industrials", "Symbol": "DOV"},
                 {"Name": "DowDuPont", "Sector": "Materials", "Symbol": "DWDP"},
                 {"Name": "Dr Pepper Snapple Group", "Sector": "Consumer Staples", "Symbol": "DPS"},
                 {"Name": "DTE Energy Co.", "Sector": "Utilities", "Symbol": "DTE"},
                 {"Name": "Duke Energy", "Sector": "Utilities", "Symbol": "DUK"},
                 {"Name": "Duke Realty Corp", "Sector": "Real Estate", "Symbol": "DRE"},
                 {"Name": "DXC Technology", "Sector": "Information Technology", "Symbol": "DXC"},
                 {"Name": "E*Trade", "Sector": "Financials", "Symbol": "ETFC"},
                 {"Name": "Eastman Chemical", "Sector": "Materials", "Symbol": "EMN"},
                 {"Name": "Eaton Corporation", "Sector": "Industrials", "Symbol": "ETN"},
                 {"Name": "eBay Inc.", "Sector": "Information Technology", "Symbol": "EBAY"},
                 {"Name": "Ecolab Inc.", "Sector": "Materials", "Symbol": "ECL"},
                 {"Name": "Edison Int'l", "Sector": "Utilities", "Symbol": "EIX"},
                 {"Name": "Edwards Lifesciences", "Sector": "Health Care", "Symbol": "EW"},
                 {"Name": "Electronic Arts", "Sector": "Information Technology", "Symbol": "EA"},
                 {"Name": "Emerson Electric Company", "Sector": "Industrials", "Symbol": "EMR"},
                 {"Name": "Entergy Corp.", "Sector": "Utilities", "Symbol": "ETR"},
                 {"Name": "Envision Healthcare", "Sector": "Health Care", "Symbol": "EVHC"},
                 {"Name": "EOG Resources", "Sector": "Energy", "Symbol": "EOG"},
                 {"Name": "EQT Corporation", "Sector": "Energy", "Symbol": "EQT"},
                 {"Name": "Equifax Inc.", "Sector": "Industrials", "Symbol": "EFX"},
                 {"Name": "Equinix", "Sector": "Real Estate", "Symbol": "EQIX"},
                 {"Name": "Equity Residential", "Sector": "Real Estate", "Symbol": "EQR"},
                 {"Name": "Essex Property Trust, Inc.", "Sector": "Real Estate", "Symbol": "ESS"},
                 {"Name": "Estee Lauder Cos.", "Sector": "Consumer Staples", "Symbol": "EL"},
                 {"Name": "Everest Re Group Ltd.", "Sector": "Financials", "Symbol": "RE"},
                 {"Name": "Eversource Energy", "Sector": "Utilities", "Symbol": "ES"},
                 {"Name": "Exelon Corp.", "Sector": "Utilities", "Symbol": "EXC"},
                 {"Name": "Expedia Inc.", "Sector": "Consumer Discretionary", "Symbol": "EXPE"},
                 {"Name": "Expeditors International", "Sector": "Industrials", "Symbol": "EXPD"},
                 {"Name": "Express Scripts", "Sector": "Health Care", "Symbol": "ESRX"},
                 {"Name": "Extra Space Storage", "Sector": "Real Estate", "Symbol": "EXR"},
                 {"Name": "Exxon Mobil Corp.", "Sector": "Energy", "Symbol": "XOM"},
                 {"Name": "F5 Networks", "Sector": "Information Technology", "Symbol": "FFIV"},
                 {"Name": "Facebook, Inc.", "Sector": "Information Technology", "Symbol": "FB"},
                 {"Name": "Fastenal Co", "Sector": "Industrials", "Symbol": "FAST"},
                 {"Name": "Federal Realty Investment Trust", "Sector": "Real Estate", "Symbol": "FRT"},
                 {"Name": "FedEx Corporation", "Sector": "Industrials", "Symbol": "FDX"},
                 {"Name": "Fidelity National Information Services", "Sector": "Information Technology",
                  "Symbol": "FIS"},
                 {"Name": "Fifth Third Bancorp", "Sector": "Financials", "Symbol": "FITB"},
                 {"Name": "FirstEnergy Corp", "Sector": "Utilities", "Symbol": "FE"},
                 {"Name": "Fiserv Inc", "Sector": "Information Technology", "Symbol": "FISV"},
                 {"Name": "FLIR Systems", "Sector": "Information Technology", "Symbol": "FLIR"},
                 {"Name": "Flowserve Corporation", "Sector": "Industrials", "Symbol": "FLS"},
                 {"Name": "Fluor Corp.", "Sector": "Industrials", "Symbol": "FLR"},
                 {"Name": "FMC Corporation", "Sector": "Materials", "Symbol": "FMC"},
                 {"Name": "Foot Locker Inc", "Sector": "Consumer Discretionary", "Symbol": "FL"},
                 {"Name": "Ford Motor", "Sector": "Consumer Discretionary", "Symbol": "F"},
                 {"Name": "Fortive Corp", "Sector": "Industrials", "Symbol": "FTV"},
                 {"Name": "Fortune Brands Home & Security", "Sector": "Industrials", "Symbol": "FBHS"},
                 {"Name": "Franklin Resources", "Sector": "Financials", "Symbol": "BEN"},
                 {"Name": "Freeport-McMoRan Inc.", "Sector": "Materials", "Symbol": "FCX"},
                 {"Name": "Gap Inc.", "Sector": "Consumer Discretionary", "Symbol": "GPS"},
                 {"Name": "Garmin Ltd.", "Sector": "Consumer Discretionary", "Symbol": "GRMN"},
                 {"Name": "Gartner Inc", "Sector": "Information Technology", "Symbol": "IT"},
                 {"Name": "General Dynamics", "Sector": "Industrials", "Symbol": "GD"},
                 {"Name": "General Electric", "Sector": "Industrials", "Symbol": "GE"},
                 {"Name": "General Growth Properties Inc.", "Sector": "Real Estate", "Symbol": "GGP"},
                 {"Name": "General Mills", "Sector": "Consumer Staples", "Symbol": "GIS"},
                 {"Name": "General Motors", "Sector": "Consumer Discretionary", "Symbol": "GM"},
                 {"Name": "Genuine Parts", "Sector": "Consumer Discretionary", "Symbol": "GPC"},
                 {"Name": "Gilead Sciences", "Sector": "Health Care", "Symbol": "GILD"},
                 {"Name": "Global Payments Inc.", "Sector": "Information Technology", "Symbol": "GPN"},
                 {"Name": "Goldman Sachs Group", "Sector": "Financials", "Symbol": "GS"},
                 {"Name": "Goodyear Tire & Rubber", "Sector": "Consumer Discretionary", "Symbol": "GT"},
                 {"Name": "Grainger (W.W.) Inc.", "Sector": "Industrials", "Symbol": "GWW"},
                 {"Name": "Halliburton Co.", "Sector": "Energy", "Symbol": "HAL"},
                 {"Name": "Hanesbrands Inc", "Sector": "Consumer Discretionary", "Symbol": "HBI"},
                 {"Name": "Harley-Davidson", "Sector": "Consumer Discretionary", "Symbol": "HOG"},
                 {"Name": "Harris Corporation", "Sector": "Information Technology", "Symbol": "HRS"},
                 {"Name": "Hartford Financial Svc.Gp.", "Sector": "Financials", "Symbol": "HIG"},
                 {"Name": "Hasbro Inc.", "Sector": "Consumer Discretionary", "Symbol": "HAS"},
                 {"Name": "HCA Holdings", "Sector": "Health Care", "Symbol": "HCA"},
                 {"Name": "Helmerich & Payne", "Sector": "Energy", "Symbol": "HP"},
                 {"Name": "Henry Schein", "Sector": "Health Care", "Symbol": "HSIC"},
                 {"Name": "Hess Corporation", "Sector": "Energy", "Symbol": "HES"},
                 {"Name": "Hewlett Packard Enterprise", "Sector": "Information Technology", "Symbol": "HPE"},
                 {"Name": "Hilton Worldwide Holdings Inc", "Sector": "Consumer Discretionary", "Symbol": "HLT"},
                 {"Name": "Hologic", "Sector": "Health Care", "Symbol": "HOLX"},
                 {"Name": "Home Depot", "Sector": "Consumer Discretionary", "Symbol": "HD"},
                 {"Name": "Honeywell Int'l Inc.", "Sector": "Industrials", "Symbol": "HON"},
                 {"Name": "Hormel Foods Corp.", "Sector": "Consumer Staples", "Symbol": "HRL"},
                 {"Name": "Host Hotels & Resorts", "Sector": "Real Estate", "Symbol": "HST"},
                 {"Name": "HP Inc.", "Sector": "Information Technology", "Symbol": "HPQ"},
                 {"Name": "Humana Inc.", "Sector": "Health Care", "Symbol": "HUM"},
                 {"Name": "Huntington Bancshares", "Sector": "Financials", "Symbol": "HBAN"},
                 {"Name": "Huntington Ingalls Industries", "Sector": "Industrials", "Symbol": "HII"},
                 {"Name": "IDEXX Laboratories", "Sector": "Health Care", "Symbol": "IDXX"},
                 {"Name": "IHS Markit Ltd.", "Sector": "Industrials", "Symbol": "INFO"},
                 {"Name": "Illinois Tool Works", "Sector": "Industrials", "Symbol": "ITW"},
                 {"Name": "Illumina Inc", "Sector": "Health Care", "Symbol": "ILMN"},
                 {"Name": "Incyte", "Sector": "Health Care", "Symbol": "INCY"},
                 {"Name": "Ingersoll-Rand PLC", "Sector": "Industrials", "Symbol": "IR"},
                 {"Name": "Intel Corp.", "Sector": "Information Technology", "Symbol": "INTC"},
                 {"Name": "Intercontinental Exchange", "Sector": "Financials", "Symbol": "ICE"},
                 {"Name": "International Business Machines", "Sector": "Information Technology", "Symbol": "IBM"},
                 {"Name": "International Paper", "Sector": "Materials", "Symbol": "IP"},
                 {"Name": "Interpublic Group", "Sector": "Consumer Discretionary", "Symbol": "IPG"},
                 {"Name": "Intl Flavors & Fragrances", "Sector": "Materials", "Symbol": "IFF"},
                 {"Name": "Intuit Inc.", "Sector": "Information Technology", "Symbol": "INTU"},
                 {"Name": "Intuitive Surgical Inc.", "Sector": "Health Care", "Symbol": "ISRG"},
                 {"Name": "Invesco Ltd.", "Sector": "Financials", "Symbol": "IVZ"},
                 {"Name": "IPG Photonics Corp.", "Sector": "Information Technology", "Symbol": "IPGP"},
                 {"Name": "IQVIA Holdings Inc.", "Sector": "Health Care", "Symbol": "IQV"},
                 {"Name": "Iron Mountain Incorporated", "Sector": "Real Estate", "Symbol": "IRM"},
                 {"Name": "J. B. Hunt Transport Services", "Sector": "Industrials", "Symbol": "JBHT"},
                 {"Name": "Jacobs Engineering Group", "Sector": "Industrials", "Symbol": "J"},
                 {"Name": "JM Smucker", "Sector": "Consumer Staples", "Symbol": "SJM"},
                 {"Name": "Johnson & Johnson", "Sector": "Health Care", "Symbol": "JNJ"},
                 {"Name": "Johnson Controls International", "Sector": "Industrials", "Symbol": "JCI"},
                 {"Name": "JPMorgan Chase & Co.", "Sector": "Financials", "Symbol": "JPM"},
                 {"Name": "Juniper Networks", "Sector": "Information Technology", "Symbol": "JNPR"},
                 {"Name": "Kansas City Southern", "Sector": "Industrials", "Symbol": "KSU"},
                 {"Name": "Kellogg Co.", "Sector": "Consumer Staples", "Symbol": "K"},
                 {"Name": "KeyCorp", "Sector": "Financials", "Symbol": "KEY"},
                 {"Name": "Kimberly-Clark", "Sector": "Consumer Staples", "Symbol": "KMB"},
                 {"Name": "Kimco Realty", "Sector": "Real Estate", "Symbol": "KIM"},
                 {"Name": "Kinder Morgan", "Sector": "Energy", "Symbol": "KMI"},
                 {"Name": "KLA-Tencor Corp.", "Sector": "Information Technology", "Symbol": "KLAC"},
                 {"Name": "Kohl's Corp.", "Sector": "Consumer Discretionary", "Symbol": "KSS"},
                 {"Name": "Kraft Heinz Co", "Sector": "Consumer Staples", "Symbol": "KHC"},
                 {"Name": "Kroger Co.", "Sector": "Consumer Staples", "Symbol": "KR"},
                 {"Name": "L Brands Inc.", "Sector": "Consumer Discretionary", "Symbol": "LB"},
                 {"Name": "L-3 Communications Holdings", "Sector": "Industrials", "Symbol": "LLL"},
                 {"Name": "Laboratory Corp. of America Holding", "Sector": "Health Care", "Symbol": "LH"},
                 {"Name": "Lam Research", "Sector": "Information Technology", "Symbol": "LRCX"},
                 {"Name": "Leggett & Platt", "Sector": "Consumer Discretionary", "Symbol": "LEG"},
                 {"Name": "Lennar Corp.", "Sector": "Consumer Discretionary", "Symbol": "LEN"},
                 {"Name": "Leucadia National Corp.", "Sector": "Financials", "Symbol": "LUK"},
                 {"Name": "Lilly (Eli) & Co.", "Sector": "Health Care", "Symbol": "LLY"},
                 {"Name": "Lincoln National", "Sector": "Financials", "Symbol": "LNC"},
                 {"Name": "LKQ Corporation", "Sector": "Consumer Discretionary", "Symbol": "LKQ"},
                 {"Name": "Lockheed Martin Corp.", "Sector": "Industrials", "Symbol": "LMT"},
                 {"Name": "Loews Corp.", "Sector": "Financials", "Symbol": "L"},
                 {"Name": "Lowe's Cos.", "Sector": "Consumer Discretionary", "Symbol": "LOW"},
                 {"Name": "LyondellBasell", "Sector": "Materials", "Symbol": "LYB"},
                 {"Name": "M&T Bank Corp.", "Sector": "Financials", "Symbol": "MTB"},
                 {"Name": "Macerich", "Sector": "Real Estate", "Symbol": "MAC"},
                 {"Name": "Macy's Inc.", "Sector": "Consumer Discretionary", "Symbol": "M"},
                 {"Name": "Marathon Oil Corp.", "Sector": "Energy", "Symbol": "MRO"},
                 {"Name": "Marathon Petroleum", "Sector": "Energy", "Symbol": "MPC"},
                 {"Name": "Marriott Int'l.", "Sector": "Consumer Discretionary", "Symbol": "MAR"},
                 {"Name": "Marsh & McLennan", "Sector": "Financials", "Symbol": "MMC"},
                 {"Name": "Martin Marietta Materials", "Sector": "Materials", "Symbol": "MLM"},
                 {"Name": "Masco Corp.", "Sector": "Industrials", "Symbol": "MAS"},
                 {"Name": "Mastercard Inc.", "Sector": "Information Technology", "Symbol": "MA"},
                 {"Name": "Mattel Inc.", "Sector": "Consumer Discretionary", "Symbol": "MAT"},
                 {"Name": "McCormick & Co.", "Sector": "Consumer Staples", "Symbol": "MKC"},
                 {"Name": "McDonald's Corp.", "Sector": "Consumer Discretionary", "Symbol": "MCD"},
                 {"Name": "McKesson Corp.", "Sector": "Health Care", "Symbol": "MCK"},
                 {"Name": "Medtronic plc", "Sector": "Health Care", "Symbol": "MDT"},
                 {"Name": "Merck & Co.", "Sector": "Health Care", "Symbol": "MRK"},
                 {"Name": "MetLife Inc.", "Sector": "Financials", "Symbol": "MET"},
                 {"Name": "Mettler Toledo", "Sector": "Health Care", "Symbol": "MTD"},
                 {"Name": "MGM Resorts International", "Sector": "Consumer Discretionary", "Symbol": "MGM"},
                 {"Name": "Michael Kors Holdings", "Sector": "Consumer Discretionary", "Symbol": "KORS"},
                 {"Name": "Microchip Technology", "Sector": "Information Technology", "Symbol": "MCHP"},
                 {"Name": "Micron Technology", "Sector": "Information Technology", "Symbol": "MU"},
                 {"Name": "Microsoft Corp.", "Sector": "Information Technology", "Symbol": "MSFT"},
                 {"Name": "Mid-America Apartments", "Sector": "Real Estate", "Symbol": "MAA"},
                 {"Name": "Mohawk Industries", "Sector": "Consumer Discretionary", "Symbol": "MHK"},
                 {"Name": "Molson Coors Brewing Company", "Sector": "Consumer Staples", "Symbol": "TAP"},
                 {"Name": "Mondelez International", "Sector": "Consumer Staples", "Symbol": "MDLZ"},
                 {"Name": "Monsanto Co.", "Sector": "Materials", "Symbol": "MON"},
                 {"Name": "Monster Beverage", "Sector": "Consumer Staples", "Symbol": "MNST"},
                 {"Name": "Moody's Corp", "Sector": "Financials", "Symbol": "MCO"},
                 {"Name": "Morgan Stanley", "Sector": "Financials", "Symbol": "MS"},
                 {"Name": "Motorola Solutions Inc.", "Sector": "Information Technology", "Symbol": "MSI"},
                 {"Name": "Mylan N.V.", "Sector": "Health Care", "Symbol": "MYL"},
                 {"Name": "Nasdaq, Inc.", "Sector": "Financials", "Symbol": "NDAQ"},
                 {"Name": "National Oilwell Varco Inc.", "Sector": "Energy", "Symbol": "NOV"},
                 {"Name": "Navient", "Sector": "Financials", "Symbol": "NAVI"},
                 {"Name": "Nektar Therapeutics", "Sector": "Health Care", "Symbol": "NKTR"},
                 {"Name": "NetApp", "Sector": "Information Technology", "Symbol": "NTAP"},
                 {"Name": "Netflix Inc.", "Sector": "Information Technology", "Symbol": "NFLX"},
                 {"Name": "Newell Brands", "Sector": "Consumer Discretionary", "Symbol": "NWL"},
                 {"Name": "Newfield Exploration Co", "Sector": "Energy", "Symbol": "NFX"},
                 {"Name": "Newmont Mining Corporation", "Sector": "Materials", "Symbol": "NEM"},
                 {"Name": "News Corp. Class A", "Sector": "Consumer Discretionary", "Symbol": "NWSA"},
                 {"Name": "News Corp. Class B", "Sector": "Consumer Discretionary", "Symbol": "NWS"},
                 {"Name": "NextEra Energy", "Sector": "Utilities", "Symbol": "NEE"},
                 {"Name": "Nielsen Holdings", "Sector": "Industrials", "Symbol": "NLSN"},
                 {"Name": "Nike", "Sector": "Consumer Discretionary", "Symbol": "NKE"},
                 {"Name": "NiSource Inc.", "Sector": "Utilities", "Symbol": "NI"},
                 {"Name": "Noble Energy Inc", "Sector": "Energy", "Symbol": "NBL"},
                 {"Name": "Nordstrom", "Sector": "Consumer Discretionary", "Symbol": "JWN"},
                 {"Name": "Norfolk Southern Corp.", "Sector": "Industrials", "Symbol": "NSC"},
                 {"Name": "Northern Trust Corp.", "Sector": "Financials", "Symbol": "NTRS"},
                 {"Name": "Northrop Grumman Corp.", "Sector": "Industrials", "Symbol": "NOC"},
                 {"Name": "Norwegian Cruise Line", "Sector": "Consumer Discretionary", "Symbol": "NCLH"},
                 {"Name": "NRG Energy", "Sector": "Utilities", "Symbol": "NRG"},
                 {"Name": "Nucor Corp.", "Sector": "Materials", "Symbol": "NUE"},
                 {"Name": "Nvidia Corporation", "Sector": "Information Technology", "Symbol": "NVDA"},
                 {"Name": "O'Reilly Automotive", "Sector": "Consumer Discretionary", "Symbol": "ORLY"},
                 {"Name": "Occidental Petroleum", "Sector": "Energy", "Symbol": "OXY"},
                 {"Name": "Omnicom Group", "Sector": "Consumer Discretionary", "Symbol": "OMC"},
                 {"Name": "ONEOK", "Sector": "Energy", "Symbol": "OKE"},
                 {"Name": "Oracle Corp.", "Sector": "Information Technology", "Symbol": "ORCL"},
                 {"Name": "PACCAR Inc.", "Sector": "Industrials", "Symbol": "PCAR"},
                 {"Name": "Packaging Corporation of America", "Sector": "Materials", "Symbol": "PKG"},
                 {"Name": "Parker-Hannifin", "Sector": "Industrials", "Symbol": "PH"},
                 {"Name": "Paychex Inc.", "Sector": "Information Technology", "Symbol": "PAYX"},
                 {"Name": "PayPal", "Sector": "Information Technology", "Symbol": "PYPL"},
                 {"Name": "Pentair Ltd.", "Sector": "Industrials", "Symbol": "PNR"},
                 {"Name": "People's United Financial", "Sector": "Financials", "Symbol": "PBCT"},
                 {"Name": "PepsiCo Inc.", "Sector": "Consumer Staples", "Symbol": "PEP"},
                 {"Name": "PerkinElmer", "Sector": "Health Care", "Symbol": "PKI"},
                 {"Name": "Perrigo", "Sector": "Health Care", "Symbol": "PRGO"},
                 {"Name": "Pfizer Inc.", "Sector": "Health Care", "Symbol": "PFE"},
                 {"Name": "PG&E Corp.", "Sector": "Utilities", "Symbol": "PCG"},
                 {"Name": "Philip Morris International", "Sector": "Consumer Staples", "Symbol": "PM"},
                 {"Name": "Phillips 66", "Sector": "Energy", "Symbol": "PSX"},
                 {"Name": "Pinnacle West Capital", "Sector": "Utilities", "Symbol": "PNW"},
                 {"Name": "Pioneer Natural Resources", "Sector": "Energy", "Symbol": "PXD"},
                 {"Name": "PNC Financial Services", "Sector": "Financials", "Symbol": "PNC"},
                 {"Name": "Polo Ralph Lauren Corp.", "Sector": "Consumer Discretionary", "Symbol": "RL"},
                 {"Name": "PPG Industries", "Sector": "Materials", "Symbol": "PPG"},
                 {"Name": "PPL Corp.", "Sector": "Utilities", "Symbol": "PPL"},
                 {"Name": "Praxair Inc.", "Sector": "Materials", "Symbol": "PX"},
                 {"Name": "Principal Financial Group", "Sector": "Financials", "Symbol": "PFG"},
                 {"Name": "Procter & Gamble", "Sector": "Consumer Staples", "Symbol": "PG"},
                 {"Name": "Progressive Corp.", "Sector": "Financials", "Symbol": "PGR"},
                 {"Name": "Prologis", "Sector": "Real Estate", "Symbol": "PLD"},
                 {"Name": "Prudential Financial", "Sector": "Financials", "Symbol": "PRU"},
                 {"Name": "Public Serv. Enterprise Inc.", "Sector": "Utilities", "Symbol": "PEG"},
                 {"Name": "Public Storage", "Sector": "Real Estate", "Symbol": "PSA"},
                 {"Name": "Pulte Homes Inc.", "Sector": "Consumer Discretionary", "Symbol": "PHM"},
                 {"Name": "PVH Corp.", "Sector": "Consumer Discretionary", "Symbol": "PVH"},
                 {"Name": "Qorvo", "Sector": "Information Technology", "Symbol": "QRVO"},
                 {"Name": "QUALCOMM Inc.", "Sector": "Information Technology", "Symbol": "QCOM"},
                 {"Name": "Quanta Services Inc.", "Sector": "Industrials", "Symbol": "PWR"},
                 {"Name": "Quest Diagnostics", "Sector": "Health Care", "Symbol": "DGX"},
                 {"Name": "Range Resources Corp.", "Sector": "Energy", "Symbol": "RRC"},
                 {"Name": "Raymond James Financial Inc.", "Sector": "Financials", "Symbol": "RJF"},
                 {"Name": "Raytheon Co.", "Sector": "Industrials", "Symbol": "RTN"},
                 {"Name": "Realty Income Corporation", "Sector": "Real Estate", "Symbol": "O"},
                 {"Name": "Red Hat Inc.", "Sector": "Information Technology", "Symbol": "RHT"},
                 {"Name": "Regency Centers Corporation", "Sector": "Real Estate", "Symbol": "REG"},
                 {"Name": "Regeneron", "Sector": "Health Care", "Symbol": "REGN"},
                 {"Name": "Regions Financial Corp.", "Sector": "Financials", "Symbol": "RF"},
                 {"Name": "Republic Services Inc", "Sector": "Industrials", "Symbol": "RSG"},
                 {"Name": "ResMed", "Sector": "Health Care", "Symbol": "RMD"},
                 {"Name": "Robert Half International", "Sector": "Industrials", "Symbol": "RHI"},
                 {"Name": "Rockwell Automation Inc.", "Sector": "Industrials", "Symbol": "ROK"},
                 {"Name": "Rockwell Collins", "Sector": "Industrials", "Symbol": "COL"},
                 {"Name": "Roper Technologies", "Sector": "Industrials", "Symbol": "ROP"},
                 {"Name": "Ross Stores", "Sector": "Consumer Discretionary", "Symbol": "ROST"},
                 {"Name": "Royal Caribbean Cruises Ltd", "Sector": "Consumer Discretionary", "Symbol": "RCL"},
                 {"Name": "S&P Global, Inc.", "Sector": "Financials", "Symbol": "SPGI"},
                 {"Name": "Salesforce.com", "Sector": "Information Technology", "Symbol": "CRM"},
                 {"Name": "SBA Communications", "Sector": "Real Estate", "Symbol": "SBAC"},
                 {"Name": "SCANA Corp", "Sector": "Utilities", "Symbol": "SCG"},
                 {"Name": "Schlumberger Ltd.", "Sector": "Energy", "Symbol": "SLB"},
                 {"Name": "Seagate Technology", "Sector": "Information Technology", "Symbol": "STX"},
                 {"Name": "Sealed Air", "Sector": "Materials", "Symbol": "SEE"},
                 {"Name": "Sempra Energy", "Sector": "Utilities", "Symbol": "SRE"},
                 {"Name": "Sherwin-Williams", "Sector": "Materials", "Symbol": "SHW"},
                 {"Name": "Simon Property Group Inc", "Sector": "Real Estate", "Symbol": "SPG"},
                 {"Name": "Skyworks Solutions", "Sector": "Information Technology", "Symbol": "SWKS"},
                 {"Name": "SL Green Realty", "Sector": "Real Estate", "Symbol": "SLG"},
                 {"Name": "Snap-On Inc.", "Sector": "Consumer Discretionary", "Symbol": "SNA"},
                 {"Name": "Southern Co.", "Sector": "Utilities", "Symbol": "SO"},
                 {"Name": "Southwest Airlines", "Sector": "Industrials", "Symbol": "LUV"},
                 {"Name": "Stanley Black & Decker", "Sector": "Consumer Discretionary", "Symbol": "SWK"},
                 {"Name": "Starbucks Corp.", "Sector": "Consumer Discretionary", "Symbol": "SBUX"},
                 {"Name": "State Street Corp.", "Sector": "Financials", "Symbol": "STT"},
                 {"Name": "Stericycle Inc", "Sector": "Industrials", "Symbol": "SRCL"},
                 {"Name": "Stryker Corp.", "Sector": "Health Care", "Symbol": "SYK"},
                 {"Name": "SunTrust Banks", "Sector": "Financials", "Symbol": "TFC"},
                 {"Name": "SVB Financial", "Sector": "Financials", "Symbol": "SIVB"},
                 {"Name": "Synchrony Financial", "Sector": "Financials", "Symbol": "SYF"},
                 {"Name": "Synopsys Inc.", "Sector": "Information Technology", "Symbol": "SNPS"},
                 {"Name": "Sysco Corp.", "Sector": "Consumer Staples", "Symbol": "SYY"},
                 {"Name": "T. Rowe Price Group", "Sector": "Financials", "Symbol": "TROW"},
                 {"Name": "Take-Two Interactive", "Sector": "Information Technology", "Symbol": "TTWO"},
                 {"Name": "Tapestry, Inc.", "Sector": "Consumer Discretionary", "Symbol": "TPR"},
                 {"Name": "Target Corp.", "Sector": "Consumer Discretionary", "Symbol": "TGT"},
                 {"Name": "TE Connectivity Ltd.", "Sector": "Information Technology", "Symbol": "TEL"},
                 {"Name": "TechnipFMC", "Sector": "Energy", "Symbol": "FTI"},
                 {"Name": "Texas Instruments", "Sector": "Information Technology", "Symbol": "TXN"},
                 {"Name": "Textron Inc.", "Sector": "Industrials", "Symbol": "TXT"},
                 {"Name": "The Bank of New York Mellon Corp.", "Sector": "Financials", "Symbol": "BK"},
                 {"Name": "The Clorox Company", "Sector": "Consumer Staples", "Symbol": "CLX"},
                 {"Name": "The Cooper Companies", "Sector": "Health Care", "Symbol": "COO"},
                 {"Name": "The Hershey Company", "Sector": "Consumer Staples", "Symbol": "HSY"},
                 {"Name": "The Mosaic Company", "Sector": "Materials", "Symbol": "MOS"},
                 {"Name": "The Travelers Companies Inc.", "Sector": "Financials", "Symbol": "TRV"},
                 {"Name": "The Walt Disney Company", "Sector": "Consumer Discretionary", "Symbol": "DIS"},
                 {"Name": "Thermo Fisher Scientific", "Sector": "Health Care", "Symbol": "TMO"},
                 {"Name": "Tiffany & Co.", "Sector": "Consumer Discretionary", "Symbol": "TIF"},
                 {"Name": "Time Warner Inc.", "Sector": "Consumer Discretionary", "Symbol": "TWX"},
                 {"Name": "TJX Companies Inc.", "Sector": "Consumer Discretionary", "Symbol": "TJX"},
                 {"Name": "Torchmark Corp.", "Sector": "Financials", "Symbol": "TMK"},
                 {"Name": "Total System Services", "Sector": "Information Technology", "Symbol": "TSS"},
                 {"Name": "Tractor Supply Company", "Sector": "Consumer Discretionary", "Symbol": "TSCO"},
                 {"Name": "TransDigm Group", "Sector": "Industrials", "Symbol": "TDG"},
                 {"Name": "TripAdvisor", "Sector": "Consumer Discretionary", "Symbol": "TRIP"},
                 {"Name": "Twenty-First Century Fox Class A", "Sector": "Consumer Discretionary", "Symbol": "FOXA"},
                 {"Name": "Twenty-First Century Fox Class B", "Sector": "Consumer Discretionary", "Symbol": "FOX"},
                 {"Name": "Tyson Foods", "Sector": "Consumer Staples", "Symbol": "TSN"},
                 {"Name": "U.S. Bancorp", "Sector": "Financials", "Symbol": "USB"},
                 {"Name": "UDR Inc", "Sector": "Real Estate", "Symbol": "UDR"},
                 {"Name": "Ulta Beauty", "Sector": "Consumer Discretionary", "Symbol": "ULTA"},
                 {"Name": "Under Armour Class A", "Sector": "Consumer Discretionary", "Symbol": "UAA"},
                 {"Name": "Under Armour Class C", "Sector": "Consumer Discretionary", "Symbol": "UA"},
                 {"Name": "Union Pacific", "Sector": "Industrials", "Symbol": "UNP"},
                 {"Name": "United Continental Holdings", "Sector": "Industrials", "Symbol": "UAL"},
                 {"Name": "United Health Group Inc.", "Sector": "Health Care", "Symbol": "UNH"},
                 {"Name": "United Parcel Service", "Sector": "Industrials", "Symbol": "UPS"},
                 {"Name": "United Rentals, Inc.", "Sector": "Industrials", "Symbol": "URI"},
                 {"Name": "United Technologies", "Sector": "Industrials", "Symbol": "UTX"},
                 {"Name": "Universal Health Services, Inc.", "Sector": "Health Care", "Symbol": "UHS"},
                 {"Name": "Unum Group", "Sector": "Financials", "Symbol": "UNM"},
                 {"Name": "V.F. Corp.", "Sector": "Consumer Discretionary", "Symbol": "VFC"},
                 {"Name": "Valero Energy", "Sector": "Energy", "Symbol": "VLO"},
                 {"Name": "Varian Medical Systems", "Sector": "Health Care", "Symbol": "VAR"},
                 {"Name": "Ventas Inc", "Sector": "Real Estate", "Symbol": "VTR"},
                 {"Name": "Verisign Inc.", "Sector": "Information Technology", "Symbol": "VRSN"},
                 {"Name": "Verisk Analytics", "Sector": "Industrials", "Symbol": "VRSK"},
                 {"Name": "Verizon Communications", "Sector": "Telecommunication Services", "Symbol": "VZ"},
                 {"Name": "Vertex Pharmaceuticals Inc", "Sector": "Health Care", "Symbol": "VRTX"},
                 {"Name": "Visa Inc.", "Sector": "Information Technology", "Symbol": "V"},
                 {"Name": "Vornado Realty Trust", "Sector": "Real Estate", "Symbol": "VNO"},
                 {"Name": "Vulcan Materials", "Sector": "Materials", "Symbol": "VMC"},
                 {"Name": "Wal-Mart Stores", "Sector": "Consumer Staples", "Symbol": "WMT"},
                 {"Name": "Walgreens Boots Alliance", "Sector": "Consumer Staples", "Symbol": "WBA"},
                 {"Name": "Waste Management Inc.", "Sector": "Industrials", "Symbol": "WM"},
                 {"Name": "Waters Corporation", "Sector": "Health Care", "Symbol": "WAT"},
                 {"Name": "Wec Energy Group Inc", "Sector": "Utilities", "Symbol": "WEC"},
                 {"Name": "Wells Fargo", "Sector": "Financials", "Symbol": "WFC"},
                 {"Name": "Welltower Inc.", "Sector": "Real Estate", "Symbol": "WELL"},
                 {"Name": "Western Digital", "Sector": "Information Technology", "Symbol": "WDC"},
                 {"Name": "Western Union Co", "Sector": "Information Technology", "Symbol": "WU"},
                 {"Name": "WestRock Company", "Sector": "Materials", "Symbol": "WRK"},
                 {"Name": "Weyerhaeuser Corp.", "Sector": "Real Estate", "Symbol": "WY"},
                 {"Name": "Whirlpool Corp.", "Sector": "Consumer Discretionary", "Symbol": "WHR"},
                 {"Name": "Williams Cos.", "Sector": "Energy", "Symbol": "WMB"},
                 {"Name": "Willis Towers Watson", "Sector": "Financials", "Symbol": "WLTW"},
                 {"Name": "Wyndham Worldwide", "Sector": "Consumer Discretionary", "Symbol": "WYN"},
                 {"Name": "Wynn Resorts Ltd", "Sector": "Consumer Discretionary", "Symbol": "WYNN"},
                 {"Name": "Xcel Energy Inc", "Sector": "Utilities", "Symbol": "XEL"},
                 {"Name": "Xerox Corp.", "Sector": "Information Technology", "Symbol": "XRX"},
                 {"Name": "Xilinx Inc", "Sector": "Information Technology", "Symbol": "XLNX"},
                 {"Name": "XL Capital", "Sector": "Financials", "Symbol": "XL"},
                 {"Name": "Xylem Inc.", "Sector": "Industrials", "Symbol": "XYL"},
                 {"Name": "Yum! Brands Inc", "Sector": "Consumer Discretionary", "Symbol": "YUM"},
                 {"Name": "Zimmer Biomet Holdings", "Sector": "Health Care", "Symbol": "ZBH"},
                 {"Name": "Zions Bancorp", "Sector": "Financials", "Symbol": "ZION"},
                 {"Name": "Zoetis", "Sector": "Health Care", "Symbol": "ZTS"}]

        for sym in sp500:
            symbols.append(sym['Symbol'])

        symbols = list(set(symbols))
        # correct_symbols = ['OXY']
        correct_symbols = ['CLNY', 'RGR', 'BHP', 'TOT', 'MAS', 'MSFT', 'ADI', 'LEN', 'AGN', 'AVB', 'FLS', 'J', 'DXC',
                           'ZTS', 'RAD', 'FMC', 'XYL', 'LH', 'ADS', 'MO', 'EW', 'DHI', 'FLR', 'MRK', 'IVZ', 'DTE',
                           'GWW', 'TFC', 'MKC', 'ATVI', 'BLL', 'KIM', 'V', 'PFE', 'RMD', 'DIS', 'MNST', 'GPC', 'LKQ',
                           'MET', 'CTSH', 'DGX', 'AFL', 'JPS', 'ABT', 'PFG', 'EQIX', 'AEP', 'ECL', 'COO', 'HOPE', 'CVS',
                           'XEL', 'VFC', 'RSG', 'UHS', 'FAST', 'TEVA', 'SEE', 'ICE', 'HRB', 'SRCL', 'ADSK', 'MDT',
                           'DAL', 'GPS', 'MYL', 'XRX', 'BA', 'AMG', 'AXP', 'RL', 'PNC', 'JCI', 'PPG', 'KLAC', 'MAC',
                           'WELL', 'C', 'URI', 'MAR', 'AMGN', 'AYI', 'KO', 'ACN', 'HOLX', 'HSY', 'AME', 'D', 'MS',
                           'IPGP', 'AMT', 'TMUS', 'WHR', 'VAR', 'LLY', 'CNC', 'WYNN', 'SPGI', 'M', 'MGM', 'CMA', 'IRM',
                           'PVH', 'JNPR', 'VMC', 'WFC', 'RE', 'TDG', 'PM', 'ETFC', 'WAT', 'F', 'K', 'BXP', 'TXT',
                           'VRTX', 'PSA', 'CTAS', 'AMD', 'AIZ', 'PEG', 'WU', 'MMM', 'BHF', 'NVDA', 'GD', 'TSCO', 'WM',
                           'REGN', 'GOLD', 'MAA', 'EMN', 'HII', 'UAA', 'FL', 'NUE', 'CSCO', 'WF', 'FRT', 'INTC', 'PH',
                           'NOC', 'CPB', 'BDX', 'EFX', 'O', 'NI', 'KL', 'HBI', 'MU', 'KSS', 'PRGO', 'LB', 'NDAQ', 'CMI',
                           'TRV', 'DUK', 'CAH', 'RJF', 'NTAP', 'MTB', 'AOS', 'CF', 'DISH', 'COST', 'PEP', 'TAP', 'SWKS',
                           'DRI', 'STT', 'SLG', 'ORCL', 'ALLE', 'AAL', 'BK', 'UNH', 'WMT', 'TTWO', 'NFLX', 'SO', 'EMD',
                           'KMX', 'UA', 'TEL', 'IBM', 'CERN', 'TXN', 'JWN', 'AMZN', 'ADP', 'BLK', 'WLTW', 'TGT', 'EXPE',
                           'HCA', 'DVA', 'SIVB', 'GS', 'VZ', 'BMY', 'EBAY', 'DFS', 'CHRW', 'BWA', 'APTV', 'FOX', 'AZO',
                           'APD', 'LEG', 'CL', 'FCX', 'ETN', 'PKG', 'BHC', 'PG', 'DOV', 'SYF', 'HSIC', 'CHTR', 'WEC',
                           'ESS', 'EQR', 'ROST', 'ALXN', 'KEY', 'SCHW', 'AON', 'DG', 'NKE', 'MCK', 'SPR', 'PLD', 'GLW',
                           'ULTA', 'LNC', 'NLSN', 'MLM', 'BP', 'ALB', 'VTR', 'T', 'IFF', 'TPR', 'HST', 'PKI', 'ANSS',
                           'ORLY', 'GT', 'IR', 'IDXX', 'CNP', 'TIF', 'EXR', 'NCLH', 'BBY', 'JCP', 'INTU', 'TROW', 'UNM',
                           'OMC', 'KR', 'STX', 'NEM', 'FE', 'GOOG', 'XLNX', 'AAP', 'DE', 'WRK', 'MTD', 'PCAR', 'PAYX',
                           'AIG', 'BAC', 'NUV', 'CB', 'NSC', 'EA', 'NWS', 'EMR', 'CSX', 'PPL', 'ARE', 'RF', 'BIIB',
                           'SHW', 'WBA', 'RCL', 'HOG', 'FLIR', 'HLT', 'FOXA', 'ALGN', 'AEE', 'CMS', 'FFIV', 'KSU',
                           'KMB', 'GRMN', 'AVY', 'LUV', 'CI', 'MCHP', 'INCY', 'FBHS', 'MOS', 'WY', 'PBCT', 'PNW',
                           'GILD', 'QCOM', 'ARNC', 'ABBV', 'BSX', 'MDLZ', 'RTN', 'HD', 'NKTR', 'EXPD', 'AMP', 'RHI',
                           'HBAN', 'XRAY', 'LOW', 'AWK', 'JPM', 'VNO', 'AIV', 'MTCH', 'UDR', 'MA', 'UTX', 'GE', 'SPG',
                           'ETR', 'DHR', 'CINF', 'ILMN', 'HRL', 'LRCX', 'NTRS', 'REG', 'ED', 'NEE', 'FIS', 'PYPL',
                           'MCO', 'IPG', 'CRM', 'BF.B', 'PHM', 'EXC', 'UNP', 'NAVI', 'HPE', 'NWL', 'A', 'ALL', 'CBRE',
                           'HUM', 'CCL', 'SYK', 'MAT', 'ITW', 'KHC', 'HON', 'TJX', 'VRSK', 'EIX', 'IQV', 'COF', 'EL',
                           'ROL', 'ROK', 'SBAC', 'UAL', 'ROP', 'LNT', 'IP', 'FITB', 'BAX', 'SJM', 'ES', 'SYY', 'AJG',
                           'CAG', 'GIS', 'ADM', 'SWK', 'MSI', 'MMC', 'STZ', 'SNA', 'BEN', 'DOW', 'ZBH', 'TRIP', 'ABC',
                           'YUM', 'PNR', 'CFG', 'UPS', 'WDC', 'IT', 'BRK.B', 'PRU', 'ADBE', 'DLTR', 'JBHT', 'LMT',
                           'HAS', 'GM', 'MCD', 'DLR', 'FTV', 'TMO', 'CAT', 'CTL', 'PGR', 'AAPL', 'SNPS', 'VIAC', 'CTXS',
                           'BKNG', 'INFO', 'GPN', 'HIG', 'CME', 'VRSN', 'CMG', 'AMAT', 'HPQ', 'FDX', 'SRE', 'CLX',
                           'ISRG', 'APH', 'JNJ', 'RECN', 'USB', 'COTY', 'NWSA', 'CDNS', 'QRVO', 'AKAM', 'ALK', 'AVGO',
                           'FB', 'MHK', 'SBUX', 'FISV', 'TSN', 'LYB', 'CHD', 'ZION', 'L', 'DRE', 'PWR', 'ANTM', 'CCI']
        dd = DynamoAccessor()
        s = []
        big_df = pd.DataFrame()
        for symbol in correct_symbols:
            print(symbol)
            add = self.dd._query_table("QA_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NYSE")
            if add:
                retval = self.load(add[0]['snp_id'], add[0]['composite_pk_id'])
            else:
                add = self.dd._query_table("QA_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NSDQ")
                retval = self.load(add[0]['snp_id'], add[0]['composite_pk_id'])
            if retval is not None:
                # retval['symbol'] = symbol
                big_df = pd.concat([big_df, retval])
                # print()
        big_df.to_sql('dev_dividend_model',
                      self.pg._engine,
                      if_exists='replace',
                      index=False
                      # index_label='periodenddate'
                      )
        self.rankings()

    def run_logit_model(self):
        select = "SELECT * FROM dev_dividend_model_banks;"
        big_df = pd.read_sql(select, self.pg._engine)
        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)
        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)
        print(len(zeros), len(newdf))
        # to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
        #              'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
        #              'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
        #              'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
        #              'ebit_10ygrowth']
        # all_columns = set(newdf.columns.tolist()) - set(to_remove)
        # for col in list(all_columns):
        #   # zeros.hist(col, bins=100, alpha=.5)
        #   print("0_" + col, statistics.median(zeros[col]))
        #   print(zeros[col].quantile([0.25, 0.5, 0.75]))
        #   # plt.title("0_" + col)
        #   # plt.show()
        #
        #   # ones.hist(col, bins=100, alpha=.5)
        #   print("1_" + col, statistics.median(ones[col]))
        #   print(ones[col].quantile([0.25, 0.5, 0.75]))
        # plt.title("1_" + col)
        #
        # plt.show()

        accuracy_lst = []
        succ0 = []
        succ1 = []
        falsepos = []
        falseneg = []
        for i in range(1):

            # from sklearn.model_selection import train_test_split

            train, test = train_test_split(newdf, test_size=0.2)
            # formula = 'div_binary ~ 0 + netcashfromoperatingactivities + freecashflow + ebitda +
            # div_payout_ratio_growth + pricetoearnings_binary + ever_cut + last5cut + last10cut +
            # cashandcashequiv_growth + cashandcashequiv_1ygrowth + cashandcashequiv_5ygrowth +
            # cashandcashequiv_10ygrowth'
            # model = smf.glm(formula=formula, data=train, family=sm.families.Binomial()).fit()
            to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend', 'saleofppe_growth', 'saleofppe_1ygrowth',
                     'saleofppe_5ygrowth', 'saleofppe_10ygrowth', 'saleofppe_binary', 'saleofppe', 'int/cash',
                         'int/income', 'pricetoearnings', 'ebitda_5ygrowth', 'netcashfromoperatingactivities_10ygrowth',
                         'ebit_binary', 'freecashflow', 'freecashflow_binary', 'freecashflow_5ygrowth',
                         'netcashfromoperatingactivities_binary', 'ebit_5ygrowth', 'pricetoearnings_growth',
                         'totalinterestexpense', 'freecashflow_10ygrowth', 'ebitda_growth', 'ebit', 'ebitda_1ygrowth',
                         'freecashflow_1ygrowth', 'debttoebitda', 'ebit_growth', 'ebitda', 'pricetoearnings_binary',
                         'last10cut', 'div_payout_ratio', 'netcashfromoperatingactivities_growth',
                         'netcashfromoperatingactivities_1ygrowth', 'cashandcashequiv_binary',
                         'pricetoearnings_10ygrowth', 'ebitda_10ygrowth', 'div_payout_ratio_1ygrowth',
                         'cashandcashequiv_growth', 'cashandcashequiv_1ygrowth', 'ebit_1ygrowth', 'cashandcashequiv_binary',
                         'netcashfromoperatingactivities_5ygrowth', 'div_payout_ratio_growth', 'fcffgrowth',
                         'netcashfromoperatingactivities', 'div_payout_ratio_10ygrowth', 'cashandcashequiv',
                         'div_payout_ratio_5ygrowth', 'dilutedeps', 'pricetoearnings_1ygrowth',
                         'pricetoearnings_5ygrowth', 'freecashflow_growth']
            all_columns = " + ".join(set(train.columns.tolist()) - set(to_remove))
            formula = 'div_binary ~  ' + all_columns
            train.fillna(0, inplace=True)
            model = smf.glm(formula=formula, data=train, family=sm.families.Binomial()).fit()
            print(model.summary())
            # print(model.pvalues)
            # for i, value in enumerate(model.pvalues):
            #   if value > 0.05:
            #     if model.pvalues.index[i] != "Intercept":
            #       to_remove.append(model.pvalues.index[i])
            # else:
            # print(model.pvalues.index[i])
            modifytest = test.copy()
            pred = model.predict(exog=modifytest.drop(columns=to_remove, inplace=True))
            threshold = 0.5

            predictions = (pd.Series(pred) >= threshold).astype('int')

            # Use the forest's predict method on the test data
            # predictions = rf.predict(modifytest)
            #test.loc[:, 'predictions'] = predictions
            print(classification_report(train['div_binary'], predictions))

            # p = model.params
            # print(p)
            # start = int(len(big_df) * (3 / 4))
        #     count_succ0 = 0
        #     count_succ1 = 0
        #     count_falsepos = 0
        #     count_falseneg = 0
        #     count = 0
        #     for row in test.iterrows():
        #         val = pred[count]
        #         # val = row[1]['netcashfromoperatingactivities_binary'] * 10 + row[1]['div_payout_ratio_growth'] *
        #         # -10 + row[1][
        #         #   'debttoebitda'] * 0 + row[1]['last5cut'] * -10 + row[1]['last10cut'] * -.5 + row[1]['ever_cut'] *
        #         #   -.5 + row[1][
        #         #         'cashandcashequiv_1ygrowth'] * 0 + row[1]['freecashflow_binary'] * 0 + row[1][
        #         #         'quick_recover'] * 5
        #         # val = math.exp(val) / (1 + math.exp(val))
        #         # print(val)
        #         if val >= .5:
        #             model_predict = 1
        #         elif val <= .5:
        #             model_predict = 0
        #         else:
        #             model_predict = -1
        #
        #         if np.isnan(row[1]['div_binary']) or np.isnan(val):
        #             pass
        #         elif model_predict == row[1]['div_binary']:
        #             if model_predict == 0:
        #                 # print("Successfully Guessed Decrease")
        #                 # print("Success")
        #                 count_succ0 += 1
        #             else:
        #                 count_succ1 += 1
        #         # elif model_predict == -1:
        #         #   print("skipping")
        #         else:
        #             # print(model_predict)
        #             # print(model_predict, row[1]['div_binary'])
        #             # print("Failure")
        #             if model_predict == 0:
        #                 count_falseneg += 1
        #             elif model_predict == 1:
        #                 count_falsepos += 1
        #         count += 1
        #     # print(count_fail, count_succ)
        #     succ1.append(count_succ1)
        #     succ0.append(count_succ0)
        #     falsepos.append(count_falsepos)
        #     falseneg.append(count_falseneg)
        #     accuracy = (count_succ1 + count_succ0) / ((count_succ1 + count_succ0) + (count_falseneg + count_falsepos))
        #     print("Accuracy:", accuracy)
        #     print("succ0: ", count_succ0)
        #     print("succ1: ", count_succ1)
        #     print("falsepos: ", count_falsepos)
        #     print("falseneg: ", count_falseneg)
        #     accuracy_lst.append(accuracy)
        # print("Mean Accuracy:", mean(accuracy_lst))
        # print("Mean succ0: ", mean(succ0))
        # print("Mean succ1: ", mean(succ1))
        # print("Mean falsepos: ", mean(falsepos))
        # print("Mean falseneg: ", mean(falseneg))
        # train = big_df.iloc[0:int(len(big_df) * (3 / 4))]
        # test = big_df.iloc[int(len(big_df) * (3 / 4)):len(big_df)]
        # formula = 'div_binary ~ pricetoearnings + netcashfromoperatingactivities + freecashflow + ebit + ebitda +
        # netincome + debttoebitda + dilutedeps + pricetoearnings_growth + netcashfromoperatingactivities_growth +
        # freecashflow_growth + ebit_growth + ebitda_growth + div_payout_ratio + div_payout_ratio_growth'
        # model = smf.glm(formula=formula,data=big_df, family=sm.families.Binomial()).fit()
        # print(model.summary())

        # p = model.params
        # pos = 2972
        # print(big_df['netcashfromoperatingactivities'].iloc[pos], big_df['freecashflow'].iloc[pos],
        # big_df['ebit'].iloc[pos],
        #       big_df['ebitda'].iloc[pos], big_df['div_payout_ratio_growth'].iloc[pos])
        # val = p['Intercept'] + p['netcashfromoperatingactivities'] * big_df['netcashfromoperatingactivities'].iloc[
        # pos] + p[
        #   'freecashflow'] * big_df['freecashflow'].iloc[pos] + p['ebit'] * big_df['ebit'].iloc[pos] + p['ebitda'] * \
        #       big_df['ebitda'].iloc[pos] + p['div_payout_ratio_growth'] * big_df['div_payout_ratio_growth'].iloc[pos]
        # print(val / (1 + val), big_df['div_binary'].iloc[pos])
        print()

    def run_rf_model(self, big_df):
        nans = big_df[np.isnan(big_df['cashdividendspershare'])].index
        zs = big_df[big_df['cashdividendspershare'] == 0].index
        # print(len(nans))
        big_df.drop(nans, inplace=True)
        big_df.drop(zs, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend', 'saleofppe_growth', 'saleofppe_1ygrowth',
                     'saleofppe_5ygrowth', 'saleofppe_10ygrowth', 'saleofppe_binary', 'saleofppe']
        to_remove_plot = ["calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                          'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                          'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                          'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                          'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision trees
        rf = RandomForestClassifier(n_estimators=50, max_depth=5, max_features=1.0)
        # Train the model on training data
        rf.fit(modifytrain, train['div_binary'])

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        threshold = 0.55

        predicted_proba = rf.predict_proba(modifytest)
        predictions = (predicted_proba[:, 1] >= threshold).astype('int')

        # Use the forest's predict method on the test data
        # predictions = rf.predict(modifytest)
        test.loc[:, 'predictions'] = predictions
        test['probs'] = predicted_proba[:, 1]

        # Create a scatter matrix from the dataframe, color by y_train
        import seaborn as sns
        sns.set_style("white")

        # Import data
        # df = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/diamonds.csv')
        x1 = test.loc[test.div_binary == 0, 'probs']
        x2 = test.loc[test.div_binary == 1, 'probs']
        # x3 = test.loc[test.cut=='Good', 'probs']

        # Plot
        kwargs = dict(hist_kws={'alpha': .6}, kde_kws={'linewidth': 2})

        plt.figure(figsize=(10, 7), dpi=80)
        sns.distplot(x1, color="dodgerblue", label="0", bins=50, **kwargs)
        sns.distplot(x2, color="orange", label="1", bins=50, **kwargs)
        # sns.distplot(x3, color="deeppink", label="minivan", **kwargs)
        plt.xlim(0, 1)
        plt.legend()

        # modifyplot = train.copy()
        # modifyplot.drop(columns=to_remove_plot, inplace=True)
        # g = sns.pairplot(modifyplot, hue="div_binary")

        # Calculate the absolute errors
        errors = abs(predictions - test['div_binary'])
        # Print out the mean absolute error (mae)
        print('Mean Absolute Error:', np.mean(errors))

        print(classification_report(test['div_binary'], test['predictions']))

        feature_names = ['borrowed', 'calendarquarter', 'calendaryear', 'cashandcashequiv',
                         'cashandcashequiv_10ygrowth', 'cashandcashequiv_1ygrowth',
                         'cashandcashequiv_5ygrowth', 'cashandcashequiv_binary',
                         'cashandcashequiv_growth', 'cashdividendspershare',
                         'cashdividendspershare_growth', 'companyname', 'debttoebitda',
                         'dilutedeps', 'div_binary', 'div_payout_ratio',
                         'div_payout_ratio_10ygrowth', 'div_payout_ratio_1ygrowth',
                         'div_payout_ratio_5ygrowth', 'div_payout_ratio_growth', 'ebit',
                         'ebit_10ygrowth', 'ebit_1ygrowth', 'ebit_5ygrowth', 'ebit_binary',
                         'ebit_growth', 'ebitda', 'ebitda_10ygrowth', 'ebitda_1ygrowth',
                         'ebitda_5ygrowth', 'ebitda_binary', 'ebitda_growth', 'ever_cut',
                         'evtoebitda', 'evtoebitda_10ygrowth', 'evtoebitda_1ygrowth',
                         'evtoebitda_5ygrowth', 'evtoebitda_binary', 'evtoebitda_growth',
                         'fcffgrowth', 'filingdate', 'fiscalquarter', 'fiscalyear',
                         'freecashflow', 'freecashflow_10ygrowth', 'freecashflow_1ygrowth',
                         'freecashflow_5ygrowth', 'freecashflow_binary', 'freecashflow_growth',
                         'last10cut', 'last5cut', 'netcashfromoperatingactivities',
                         'netcashfromoperatingactivities_10ygrowth',
                         'netcashfromoperatingactivities_1ygrowth',
                         'netcashfromoperatingactivities_5ygrowth',
                         'netcashfromoperatingactivities_binary',
                         'netcashfromoperatingactivities_growth', 'netincome', 'periodtypeid',
                         'periodtypename', 'pricetoearnings', 'pricetoearnings_10ygrowth',
                         'pricetoearnings_1ygrowth', 'pricetoearnings_5ygrowth',
                         'pricetoearnings_binary', 'pricetoearnings_growth', 'quick_recover',
                         'reportingtemplatetypeid', 'unittypeid', 'unittypename']
        feature_list = list(set(feature_names) - set(to_remove))
        # print(feature_list)
        importances = list(rf.feature_importances_)
        # List of tuples with variable and importance
        feature_importances = [(feature, round(importance, 2)) for feature, importance in
                               zip(feature_list, importances)]
        # Sort the feature importances by most important first
        feature_importances = sorted(feature_importances, key=lambda x: x[1], reverse=True)
        # Print out the feature and importances
        # [print('Variable: {:20} Importance: {}'.format(*pair)) for pair in feature_importances]
        dump(rf, 'div_rf_7.joblib')
        return classification_report(test['div_binary'], test['predictions'], output_dict=True)['accuracy']

        # count_succ0 = 0
        # count_succ1 = 0
        # count_falsepos = 0
        # count_falseneg = 0
        # count = 0
        # for row in test.iterrows():
        #     val = row[1]['predictions']
        #     if val > .5:
        #         model_predict = 1
        #     else:
        #         model_predict = 0
        #
        #     if np.isnan(row[1]['div_binary']) or np.isnan(val):
        #         pass
        #     elif model_predict == row[1]['div_binary']:
        #         if model_predict == 0:
        #             # print("Successfully Guessed Decrease")
        #             # print("Success")
        #             count_succ0 += 1
        #         else:
        #             count_succ1 += 1
        #     # elif model_predict == -1:
        #     #   print("skipping")
        #     else:
        #         # print(model_predict)
        #         # print(model_predict, row[1]['div_binary'])
        #         # print("Failure")
        #         if model_predict == 0:
        #             count_falseneg += 1
        #         elif model_predict == 1:
        #             count_falsepos += 1
        #     count += 1
        #
        # accuracy = (count_succ1 + count_succ0) / ((count_succ1 + count_succ0) + (count_falseneg + count_falsepos))
        # acc_0 = count_succ0 / (count_succ0 + count_falsepos)
        # acc_1 = count_succ1 / (count_succ1 + count_falseneg)
        # print("Accuracy:", accuracy)
        # print("Accuracy 0's:", acc_0)
        # print("Accuracy  1's:", acc_1)
        # print("succ0: ", count_succ0)
        # print("succ1: ", count_succ1)
        # print("falsepos: ", count_falsepos)
        # print("falseneg: ", count_falseneg)
        # print(rf.score(modifytest, test['div_binary']))

    # def load_trained_model(self):
    #     rf = load('div_rf_2.joblib')
    #
    #     select = "SELECT * FROM dev_dividend_model;"
    #     big_df = pd.read_sql(select, self.pg._engine)
    #     # print(big_df.columns)
    #     nans = big_df[np.isnan(big_df['div_binary'])].index
    #     big_df.drop(nans, inplace=True)
    #     big_df.fillna(0, inplace=True)
    #     # train, test = train_test_split(big_df, test_size=0.2)
    #     # train.fillna(0, inplace=True)
    #     # modifytrain = train.copy()
    #     to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
    #                  'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
    #                  'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
    #                  'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
    #                  'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']
    #
    #     # modifytrain.drop(columns=to_remove, inplace=True)
    #     # Import the model we are using
    #     # Instantiate model with 1000 decision trees
    #     # rf = RandomForestRegressor(n_estimators=10)
    #     # Train the model on training data
    #     # rf.fit(modifytrain, train['div_binary'])
    #
    #     # test.fillna(0, inplace=True)
    #     modifydf = big_df.copy()
    #     modifydf.drop(columns=to_remove, inplace=True)
    #
    #     # Use the forest's predict method on the test data
    #     predictions = rf.predict(modifydf)
    #     big_df['predictions'] = predictions
    #     # Calculate the absolute errors
    #     errors = abs(predictions - big_df['div_binary'])
    #     # Print out the mean absolute error (mae)
    #     print('Mean Absolute Error:', round(np.mean(errors), 2))
    #
    #
    #
    #     count_succ0 = 0
    #     count_succ1 = 0
    #     count_falsepos = 0
    #     count_falseneg = 0
    #     count = 0
    #     for row in big_df.iterrows():
    #         val = row[1]['predictions']
    #         # val = row[1]['netcashfromoperatingactivities_binary'] * 10 + row[1]['div_payout_ratio_growth'] * -10
    #         + row[1][
    #         #   'debttoebitda'] * 0 + row[1]['last5cut'] * -10 + row[1]['last10cut'] * -.5 + row[1]['ever_cut'] *
    #         -.5 + row[1][
    #         #         'cashandcashequiv_1ygrowth'] * 0 + row[1]['freecashflow_binary'] * 0 + row[1][
    #         'quick_recover'] * 5
    #         # val = math.exp(val) / (1 + math.exp(val))
    #         # print(val)
    #         if val > .5:
    #             model_predict = 1
    #         else:
    #             model_predict = 0
    #
    #         if np.isnan(row[1]['div_binary']) or np.isnan(val):
    #             pass
    #         elif model_predict == row[1]['div_binary']:
    #             if model_predict == 0:
    #                 # print("Successfully Guessed Decrease")
    #                 # print("Success")
    #                 count_succ0 += 1
    #             else:
    #                 count_succ1 += 1
    #         # elif model_predict == -1:
    #         #   print("skipping")
    #         else:
    #             # print(model_predict)
    #             # print(model_predict, row[1]['div_binary'])
    #             # print("Failure")
    #             if model_predict == 0:
    #                 count_falseneg += 1
    #             elif model_predict == 1:
    #                 count_falsepos += 1
    #         count += 1
    #
    #     accuracy = (count_succ1 + count_succ0) / ((count_succ1 + count_succ0) + (count_falseneg + count_falsepos))
    #     acc_0 = count_succ0 / (count_succ0 + count_falsepos)
    #     acc_1 = count_succ1 / (count_succ1 + count_falseneg)
    #     print("Accuracy:", accuracy)
    #     print("Accuracy 0's:", acc_0)
    #     print("Accuracy  1's:", acc_1)
    #     print("succ0: ", count_succ0)
    #     print("succ1: ", count_succ1)
    #     print("falsepos: ", count_falsepos)
    #     print("falseneg: ", count_falseneg)

    @staticmethod
    def tree_to_code():
        feature_names = ['borrowed', 'calendarquarter', 'calendaryear', 'cashandcashequiv',
                         'cashandcashequiv_10ygrowth', 'cashandcashequiv_1ygrowth',
                         'cashandcashequiv_5ygrowth', 'cashandcashequiv_binary',
                         'cashandcashequiv_growth', 'cashdividendspershare',
                         'cashdividendspershare_growth', 'companyname', 'debttoebitda',
                         'dilutedeps', 'div_binary', 'div_payout_ratio',
                         'div_payout_ratio_10ygrowth', 'div_payout_ratio_1ygrowth',
                         'div_payout_ratio_5ygrowth', 'div_payout_ratio_growth', 'ebit',
                         'ebit_10ygrowth', 'ebit_1ygrowth', 'ebit_5ygrowth', 'ebit_binary',
                         'ebit_growth', 'ebitda', 'ebitda_10ygrowth', 'ebitda_1ygrowth',
                         'ebitda_5ygrowth', 'ebitda_binary', 'ebitda_growth', 'ever_cut',
                         'evtoebitda', 'evtoebitda_10ygrowth', 'evtoebitda_1ygrowth',
                         'evtoebitda_5ygrowth', 'evtoebitda_binary', 'evtoebitda_growth',
                         'fcffgrowth', 'filingdate', 'fiscalquarter', 'fiscalyear',
                         'freecashflow', 'freecashflow_10ygrowth', 'freecashflow_1ygrowth',
                         'freecashflow_5ygrowth', 'freecashflow_binary', 'freecashflow_growth',
                         'last10cut', 'last5cut', 'netcashfromoperatingactivities',
                         'netcashfromoperatingactivities_10ygrowth',
                         'netcashfromoperatingactivities_1ygrowth',
                         'netcashfromoperatingactivities_5ygrowth',
                         'netcashfromoperatingactivities_binary',
                         'netcashfromoperatingactivities_growth', 'netincome', 'periodtypeid',
                         'periodtypename', 'pricetoearnings', 'pricetoearnings_10ygrowth',
                         'pricetoearnings_1ygrowth', 'pricetoearnings_5ygrowth',
                         'pricetoearnings_binary', 'pricetoearnings_growth', 'quick_recover',
                         'reportingtemplatetypeid', 'unittypeid', 'unittypename']
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']
        feature_list = list(set(feature_names) - set(to_remove))
        rf = load('div_rf_2.joblib')

        # Pull out one tree from the forest
        tree = rf.estimators_[5]
        # Export the image to a dot file
        export_graphviz(tree, out_file='tree2.dot', feature_names=feature_list, rounded=True, precision=1, filled=True)
        # Use dot file to create a graph
        (graph,) = pydot.graph_from_dot_file('tree2.dot')
        # Write graph to a png file
        graph.write_png('tree2.png')

        # Get numerical feature importances
        importances = list(rf.feature_importances_)
        # List of tuples with variable and importance
        feature_importances = [(feature, round(importance, 2)) for feature, importance in
                               zip(feature_list, importances)]
        # Sort the feature importances by most important first
        feature_importances = sorted(feature_importances, key=lambda x: x[1], reverse=True)
        # Print out the feature and importances
        [print('Variable: {:20} Importance: {}'.format(*pair)) for pair in feature_importances]

    def n_estimators(self):
        n_estimators = range(1, 200)
        train_results = []
        test_results = []

        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        for estimator in n_estimators:
            rf = RandomForestClassifier(n_estimators=estimator, n_jobs=-1)
            # Train the model on training data
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(n_estimators, train_results, 'b', label="Train AUC")
        line2, = plt.plot(n_estimators, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('n_estimators')
        plt.show()

    def max_depth(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        max_depths = np.linspace(1, 32, 32, endpoint=True)
        train_results = []
        test_results = []
        for max_depth in max_depths:
            rf = RandomForestClassifier(max_depth=max_depth, n_jobs=-1)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(max_depths, train_results, 'b', label="Train AUC")
        line2, = plt.plot(max_depths, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('Tree Depth')
        plt.show()

    def min_samples_split(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        min_samples_splits = np.linspace(0.1, 1.0, 10, endpoint=True)
        train_results = []
        test_results = []
        for min_samples_split in min_samples_splits:
            rf = RandomForestClassifier(min_samples_split=min_samples_split)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(min_samples_splits, train_results, 'b', label="Train AUC")
        line2, = plt.plot(min_samples_splits, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('min samples split')
        plt.show()

    def min_samples_leaf(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        min_samples_leafs = np.linspace(0.1, 0.5, 5, endpoint=True)
        train_results = []
        test_results = []
        for min_samples_leaf in min_samples_leafs:
            rf = RandomForestClassifier(min_samples_leaf=min_samples_leaf)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(min_samples_leafs, train_results, 'b', label="Train AUC")
        line2, = plt.plot(min_samples_leafs, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('min samples leaf')
        plt.show()

    def max_features(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        max_features = np.linspace(0.1, 1.0, 10, endpoint=True)
        print(max_features)
        train_results = []
        test_results = []
        for max_feature in max_features:
            rf = RandomForestClassifier(max_features=max_feature)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(max_features, train_results, 'b', label="Train AUC")
        line2, = plt.plot(max_features, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('max features')
        plt.show()

    @staticmethod
    def download_resources(file):
        if not os.path.exists('dividend-model-resources'):
            print('creating directory...')
            os.makedirs('dividend-model-resources')

        # files = ['not_freq_updated_80.joblib']

        bucket = 'dividend-model-resources'

        # credentials = boto3.Session().get_credentials()

        # s3 = boto3.client('s3', aws_access_key_id=credentials.access_key,
        # aws_secret_access_key=credentials.secret_key)

        s3 = boto3.client('s3', region_name='us-east-1')

        s3.download_file(bucket, file,
                         'dividend-model-resources/{}'.format(file))

    def predict_single(self, composite_pk_id, date):
        try:
            rf = load('not_freq_updated_80.joblib')
        except Exception:
            self.download_resources('not_freq_updated_80.joblib')
            rf = load('dividend-model-resources/not_freq_updated_80.joblib')

        # select = "SELECT * FROM dev_dividend_model WHERE symbol='{}' AND periodenddate>='{}';".format(symbol, date)
        select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id='{}' AND periodenddate = (SELECT MAX(" \
                 "periodenddate) FROM dev_dividend_model WHERE composite_pk_id='{}')".format(
            composite_pk_id, composite_pk_id)
        big_df = pd.read_sql(select, self.pg._engine)
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend', 'saleofppe', 'int/cash', 'int/income',
                     'totalinterestexpense', 'saleofppe_growth', 'saleofppe_1ygrowth',
                     'saleofppe_5ygrowth', 'saleofppe_10ygrowth', 'saleofppe_binary']
        if len(big_df) > 0:
            if big_df['cashdividendspershare'].iloc[0] is None:
                return None
            else:
                big_df.fillna(0, inplace=True)
                modifydf = big_df.copy()
                modifydf.drop(columns=to_remove, inplace=True)
                predicted_proba = rf.predict_proba(modifydf)
                return predicted_proba[0][1]
        else:
            return None

    def rankings(self):
        correct_symbols = ['CLNY', 'RGR', 'BHP', 'TOT', 'MAS', 'MSFT', 'ADI', 'LEN', 'AGN', 'AVB', 'FLS', 'J', 'DXC',
                           'ZTS', 'RAD', 'FMC', 'XYL', 'LH', 'ADS', 'MO', 'EW', 'DHI', 'FLR', 'MRK', 'IVZ', 'DTE',
                           'GWW', 'TFC', 'MKC', 'ATVI', 'BLL', 'KIM', 'V', 'PFE', 'RMD', 'DIS', 'MNST', 'GPC',
                           'LKQ', 'MET', 'CTSH', 'DGX', 'AFL', 'JPS', 'ABT', 'PFG', 'EQIX', 'AEP', 'ECL', 'COO', 'HOPE',
                           'CVS', 'XEL', 'VFC', 'RSG', 'UHS', 'FAST', 'TEVA', 'SEE', 'ICE', 'HRB', 'SRCL', 'ADSK',
                           'MDT', 'DAL', 'GPS', 'MYL', 'XRX', 'BA', 'AMG', 'AXP', 'RL', 'PNC', 'JCI', 'PPG', 'KLAC',
                           'MAC', 'WELL', 'C', 'URI', 'MAR', 'AMGN', 'AYI', 'KO', 'ACN', 'HOLX', 'HSY', 'AME', 'D',
                           'MS', 'IPGP', 'AMT', 'TMUS', 'WHR', 'VAR', 'LLY', 'CNC', 'WYNN', 'SPGI', 'M', 'MGM', 'CMA',
                           'IRM', 'PVH', 'JNPR', 'VMC', 'WFC', 'RE', 'TDG', 'PM', 'ETFC', 'WAT', 'F', 'K', 'BXP', 'TXT',
                           'VRTX', 'PSA', 'CTAS', 'AMD', 'AIZ', 'PEG', 'WU', 'MMM', 'BHF', 'NVDA', 'GD', 'TSCO', 'WM',
                           'REGN', 'GOLD', 'MAA', 'EMN', 'HII', 'UAA', 'FL', 'NUE', 'CSCO', 'WF', 'FRT', 'INTC', 'PH',
                           'NOC', 'CPB', 'BDX', 'EFX', 'O', 'NI', 'KL', 'HBI', 'MU', 'KSS', 'PRGO', 'LB', 'NDAQ', 'CMI',
                           'TRV', 'DUK', 'CAH', 'RJF', 'NTAP', 'MTB', 'AOS', 'CF', 'DISH', 'COST', 'PEP', 'TAP', 'SWKS',
                           'DRI', 'STT', 'SLG', 'ORCL', 'ALLE', 'AAL', 'BK', 'UNH', 'WMT', 'TTWO', 'NFLX', 'SO', 'EMD',
                           'KMX', 'UA', 'TEL', 'IBM', 'CERN', 'TXN', 'JWN', 'AMZN', 'ADP', 'BLK', 'WLTW', 'TGT', 'EXPE',
                           'HCA', 'DVA', 'SIVB', 'GS', 'VZ', 'BMY', 'EBAY', 'DFS', 'CHRW', 'BWA', 'APTV', 'FOX', 'AZO',
                           'APD', 'LEG', 'CL', 'FCX', 'ETN', 'PKG', 'BHC', 'PG', 'DOV', 'SYF', 'HSIC', 'CHTR', 'WEC',
                           'ESS', 'EQR', 'ROST', 'ALXN', 'KEY', 'SCHW', 'AON', 'DG', 'NKE', 'MCK', 'SPR', 'PLD', 'GLW',
                           'ULTA', 'LNC', 'NLSN', 'MLM', 'BP', 'ALB', 'VTR', 'T', 'IFF', 'TPR', 'HST', 'PKI', 'ANSS',
                           'ORLY', 'GT', 'IR', 'IDXX', 'CNP', 'TIF', 'EXR', 'NCLH', 'BBY', 'JCP', 'INTU', 'TROW', 'UNM',
                           'OMC', 'KR', 'STX', 'NEM', 'FE', 'GOOG', 'XLNX', 'AAP', 'DE', 'WRK', 'MTD', 'PCAR', 'PAYX',
                           'AIG', 'BAC', 'NUV', 'CB', 'NSC', 'EA', 'NWS', 'EMR', 'CSX', 'PPL', 'ARE', 'RF', 'BIIB',
                           'SHW', 'WBA', 'RCL', 'HOG', 'FLIR', 'HLT', 'FOXA', 'ALGN', 'AEE', 'CMS', 'FFIV', 'KSU',
                           'KMB', 'GRMN', 'AVY', 'LUV', 'CI', 'MCHP', 'INCY', 'FBHS', 'MOS', 'WY', 'PBCT', 'PNW',
                           'GILD', 'QCOM', 'ARNC', 'ABBV', 'BSX', 'MDLZ', 'RTN', 'HD', 'NKTR', 'EXPD', 'AMP', 'RHI',
                           'HBAN', 'XRAY', 'LOW', 'AWK', 'JPM', 'VNO', 'AIV', 'MTCH', 'UDR', 'MA', 'UTX', 'GE', 'SPG',
                           'ETR', 'DHR', 'CINF', 'ILMN', 'HRL', 'LRCX', 'NTRS', 'REG', 'ED', 'NEE', 'FIS', 'PYPL',
                           'MCO', 'IPG', 'CRM', 'BF.B', 'PHM', 'EXC', 'UNP', 'NAVI', 'HPE', 'NWL', 'A', 'ALL', 'CBRE',
                           'HUM', 'CCL', 'SYK', 'MAT', 'ITW', 'KHC', 'HON', 'TJX', 'VRSK', 'EIX', 'IQV', 'COF', 'EL',
                           'ROL', 'ROK', 'SBAC', 'UAL', 'ROP', 'LNT', 'IP', 'FITB', 'BAX', 'SJM', 'ES', 'SYY', 'AJG',
                           'CAG', 'GIS', 'ADM', 'SWK', 'MSI', 'MMC', 'STZ', 'SNA', 'BEN', 'DOW', 'ZBH', 'TRIP', 'ABC',
                           'YUM', 'PNR', 'CFG', 'UPS', 'WDC', 'IT', 'BRK.B', 'PRU', 'ADBE', 'DLTR', 'JBHT', 'LMT',
                           'HAS', 'GM', 'MCD', 'DLR', 'FTV', 'TMO', 'CAT', 'CTL', 'PGR', 'AAPL', 'SNPS', 'VIAC', 'CTXS',
                           'BKNG', 'INFO', 'GPN', 'HIG', 'CME', 'VRSN', 'CMG', 'AMAT', 'HPQ', 'FDX', 'SRE', 'CLX',
                           'ISRG', 'APH', 'JNJ', 'RECN', 'USB', 'COTY', 'NWSA', 'CDNS', 'QRVO', 'AKAM', 'ALK', 'AVGO',
                           'FB', 'MHK', 'SBUX', 'FISV', 'TSN', 'LYB', 'CHD', 'ZION', 'L', 'DRE', 'PWR', 'ANTM', 'CCI']
        df = pd.DataFrame(columns=['composite_pk_id', 'score'])
        for symbol in correct_symbols:
            print(symbol)
            add = self.dd._query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NYSE")
            if add:
                prob = self.predict_single(add[0]['composite_pk_id'], '2019-09-01 00:00:00.000000')
            else:
                add = self.dd._query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NSDQ")
                prob = self.predict_single(add[0]['composite_pk_id'], '2019-09-01 00:00:00.000000')
            if prob is not None:
                df = df.append({'composite_pk_id': add[0]['composite_pk_id'], 'guid': add[0]['guid'], 'score': prob,
                                'rating': None, 'rank': None, 'model': {
                        'model': {'score': prob, 'composite_pk_id': add[0]['composite_pk_id'],
                                  'date_calculated': str(datetime.date.today())}}}, ignore_index=True)
        df = df.append(self.load_energy())
        df.sort_values(by='score', ascending=False, inplace=True)
        df.reset_index(inplace=True, drop=True)
        df['rank'] = -(df.index + 1 - len(df.index)) / (len(df.index) - 1)
        df.to_sql('development_sbt_models_dividend_rankings',
                  self.pg._engine,
                  if_exists='replace', dtype={'model': JSON,
                                              'score': FLOAT,
                                              'rank': FLOAT,
                                              'rating': VARCHAR,
                                              'composite_pk_id': VARCHAR
                                              }, index=False)
        self.create_model_stats_table('DIVIDEND', df)

    def predict_single_energy(self, composite_pk_id, date):
        try:
            rf = load('energy_model_79.joblib')
        except Exception:
            self.download_resources('energy_model_79.joblib')
            rf = load('dividend-model-resources/energy_model_79.joblib')

        # select = "SELECT * FROM dev_dividend_model WHERE symbol='{}' AND periodenddate>='{}';".format(symbol, date)
        select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id='{}' AND periodenddate = (SELECT MAX(" \
            "periodenddate) FROM dev_dividend_model WHERE composite_pk_id='{}')".format(
                                                                                    composite_pk_id, composite_pk_id)
        big_df = pd.read_sql(select, self.pg._engine)
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend']
        if len(big_df) > 0:
            if big_df['cashdividendspershare'].iloc[0] is None:
                return None
            else:
                big_df.fillna(0, inplace=True)
                modifydf = big_df.copy()
                modifydf.drop(columns=to_remove, inplace=True)
                predicted_proba = rf.predict_proba(modifydf)
                return predicted_proba[0][1]
        else:
            return None

    def energy_rankings(self):
        div = DivLoader()
        sbtcommon = SbtCommon()
        config = sbtcommon.get_sbt_config()
        pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
        select0 = "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Energy Equipment and Services', " \
        "'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels')"
        guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
        composites = []
        snp_ids = []
        valid_guids = []
        for guid in guids:
            response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING",
                                       **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})[
                'Items']
            if response:
                if 'NYSE' in response[0]['composite_pk_id'] or 'NSDQ' in response[0]['composite_pk_id'] or 'AMEX' in \
                    response[0]['composite_pk_id']:
                    composites.append(response[0]['composite_pk_id'])
                    snp_ids.append(response[0]['snp_id'])
                    valid_guids.append(guid)

        df = pd.DataFrame(columns=['composite_pk_id', 'score'])
        for (symbol, guid) in zip(composites, valid_guids):
            print(symbol)
            prob = self.predict_single_energy(symbol, '2019-09-01 00:00:00.000000')
            if prob is not None:
                df = df.append({'composite_pk_id': symbol, 'guid': guid, 'score': prob,
                                'rating': None, 'rank': None, 'model': {
                        'model': {'score': prob, 'composite_pk_id': symbol,
                                  'date_calculated': str(datetime.date.today())}}}, ignore_index=True)
        df.sort_values(by='score', ascending=False, inplace=True)
        # df.to_sql('development_sbt_models_dividend_rankings_energy',
        #               self.pg._engine,
        #               if_exists='replace', dtype={'model': JSON,
        #            'score': FLOAT,
        #            'rank': FLOAT,
        #            'rating': VARCHAR,
        #            'composite_pk_id': VARCHAR
        #            }, index=False)
        return df

    def count_div_paying_companies(self):
        # self.ENV = "dev"
        snp_pgconfig = {self.ENV: self.config[self.ENV]['postgres']['snpcompanyfinancials']}
        snp_pg = PostgresAccessor(snp_pgconfig[self.ENV])
        companies = pd.read_sql('SELECT * FROM snp_company', snp_pg._engine)
        count = 0
        us_count = 0
        for company in companies.iterrows():
            if company[1]['cash_div_per_share_f0'] > 0 and company[1]['latest_filing_date'] > '2019-06-01':
                count += 1
            if company[1]['cash_div_per_share_f0'] > 0 and company[1]['country_code'] == 'USA' and company[1][
                'latest_filing_date'] > '2019-06-01':
                us_count += 1
        print(count, us_count)

    def create_model_stats_table(self, model_id=None, data=None):
        print(
            ' DIVIDEND: CREATING STATS TABLE IN PG...')
        RESULT_TABLENAME_PREFIX = "development_sbt_models"
        tic = datetime.datetime.now()
        model_id = "".join(model_id.lower().split("_"))
        # # rating stats table
        # TABLE_NAME = "{}_{}_rating_stats".format(RESULT_TABLENAME_PREFIX,
        #                                          model_id
        #                                          )
        # # get the min/max for the model's rank (:= total number of points),
        # # which is the most important result for CE
        # df_stats = pd.DataFrame(
        #     (x for x in data),
        #     columns=['rating', 'score']).groupby(by='rating') \
        #     .agg({"score": [min, max, "count"]})
        # # rename columns
        # df_stats.columns = ['minRank', 'maxRank', 'total']
        # # save rating stats
        # df_stats.to_sql(TABLE_NAME,
        #                 self.pg._engine,
        #                 if_exists='replace',
        #                 index_label='rating'
        #                 )
        # # rank stats table
        TABLE_NAME = "{}_{}_score_stats".format(RESULT_TABLENAME_PREFIX,
                                                model_id
                                                )
        data = pd.DataFrame(data)
        model_stat_df = data.agg({'score': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minscore', 'maxscore', 'total']
        # stats per model (total within each rank bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['score'], [-1000, 0, .25, .45, .55, .75, 1])
        )['score'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        model_score_stat_df.to_sql(TABLE_NAME,
                                   self.pg._engine,
                                   if_exists='replace'
                                   )
        print(
            ' DIVIDEND: DIVIDEND TABLE CREATED IN Dt = {}'.format(
                datetime.datetime.now() - tic)
        )

    def query_table(self, table_name, **kwargs):
        # get table
        table = self.ddb.Table(table_name)
        # get query response
        response = table.query(
            IndexName=kwargs.get('index_name', ''),
            KeyConditionExpression=Key(kwargs.get('key'))
                .__getattribute__(kwargs.get('operator'))(kwargs.get('value'))
        )
        return response

    def load_energy(self):
        div = DivLoader()
        sbtcommon = SbtCommon()
        config = sbtcommon.get_sbt_config()
        pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
        select0 = "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Energy Equipment and Services', " \
        "'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels')"
        guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
        composites = []
        snp_ids = []
        for guid in guids:
            response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING",
                                       **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})[
                'Items']
            if response:
                if 'NYSE' in response[0]['composite_pk_id'] or 'NSDQ' in response[0]['composite_pk_id'] or 'AMEX' in \
                    response[0]['composite_pk_id']:
                    composites.append(response[0]['composite_pk_id'])
                    snp_ids.append(response[0]['snp_id'])
        big_df = pd.DataFrame()
        print(len(composites))
        for composite, snp_id in zip(composites, snp_ids):
            print(composite)
            try:
                retval = self.load(snp_id, composite)
            except Exception as e:
                print(e, composite)
            if retval is not None:
                # retval['symbol'] = symbol
                big_df = pd.concat([big_df, retval])

        big_df.to_sql('dev_dividend_model_energy',
                      self.pg._engine,
                      if_exists='replace',
                      index=False
                      # index_label='periodenddate'
                      )
        return self.energy_rankings()

    def load_banks(self):
        div = DivLoader()
        sbtcommon = SbtCommon()
        config = sbtcommon.get_sbt_config()
        pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
        select0 = "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Banks')"
        guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
        composites = []
        snp_ids = []
        for guid in guids:
            response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING",
                                       **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})[
                'Items']
            if response:
                if 'NYSE' in response[0]['composite_pk_id'] or 'NSDQ' in response[0]['composite_pk_id'] or 'AMEX' in \
                    response[0]['composite_pk_id']:
                    composites.append(response[0]['composite_pk_id'])
                    snp_ids.append(response[0]['snp_id'])
        big_df = pd.DataFrame()
        print(len(composites))
        for composite, snp_id in zip(composites, snp_ids):
            print(composite)
            try:
                retval = self.load(snp_id, composite)
            except Exception as e:
                print(e, composite)
            if retval is not None:
                # retval['symbol'] = symbol
                big_df = pd.concat([big_df, retval])

        big_df.to_sql('dev_dividend_model_banks',
                      self.pg._engine,
                      if_exists='replace',
                      index=False
                      # index_label='periodenddate'
                      )
        return self.energy_rankings()


if __name__ == '__main__':
    div = DivLoader()
    # div.count_div_paying_companies()
    # div.to_pg()
    # acc = 0

    # div.energy_rankings()
    # div.load_banks()

    # sbtcommon = SbtCommon()
    # config = sbtcommon.get_sbt_config()
    # pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
    # select0 =  "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Energy Equipment and Services', 'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels')"
    # guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
    # composites = []
    # for guid in guids:
    #     response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})['Items']
    #     if response:
    #         composites.append(response[0]['composite_pk_id'])
    # select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id IN ({});".format(str(composites)[1:-1])

    #
    # select = "SELECT * FROM dev_dividend_model_banks"
    # big_df = pd.read_sql(select, div.pg._engine)
    # div.run_rf_model(big_df)
    div.rankings()
    # acclst = []
    # for x in range(100):
    #     newacc = div.run_rf_model(big_df)
    #     print(newacc)
    #     acc = newacc
    #     acclst.append(newacc)
    # print(mean(acclst))
    # print(statistics.median(acclst))
    # print(max(acclst))
    # print(min(acclst))

    # div.load_trained_model()
    # div.tree_to_code()
    # div.n_estimators()
    # div.max_depth()
    # div.min_samples_split()
    # div.min_samples_leaf()
    # div.max_features()
    # print(div.predict_single('NVDA:NSDQ', '2019-09-01 00:00:00.000000'))
    # div.rankings()
