import pandas as pd
import numpy as np
from decimal import Decimal
from time_series_manager import TimeSeriesManager
from sbt_common import SbtGlobalCommon
from fs_accessor import FinancialAccessor, FinancialVendors
from mp_accessor import MappingAccessor, MPAccessor, TableMappingGuid
from data_mapper import SbtDataMapper
import ast
import simplejson
from dd_accessor import DynamoAccessor
import datetime
import time
from datetime import timedelta
from time_series_manager import TimeSeriesManager


class BuyIndicators(DynamoAccessor):
  def __init__(self):
    super().__init__(aws_profile_name=None,
             aws_region_name=None,
             aws_end_point_url=None)
    self.mapping_accessor = MappingAccessor()
    self._logger = self._sbtcommon.get_global_logger()

  def monthdelta(self, date, delta):
    m, y = (date.month+delta) % 12, date.year + ((date.month)+delta-1) // 12
    if not m: m = 12
    d = min(date.day, [31,
        29 if y%4==0 and not y%400==0 else 28,31,30,31,30,31,31,30,31,30,31][m-1])
    return date.replace(day=d,month=m, year=y)

  def load_prices(self):
    ts = TimeSeriesManager()
    mp_accessor = MappingAccessor()
    symbol_mappings = mp_accessor.scan_symbol_exchange_mapping()
    symbols = []
    # f = False
    for sm in symbol_mappings:
      try:
        # if sm['symbol'] == 'SHIP':
        #   f = True
        # if sm['source'] == 'S&P' and (sm['exchange'] == 'NYSE' or 'NSDQ' in sm['exchange']) and f:
        if sm['source'] == 'S&P' and (sm['exchange'] == 'NYSE' or 'NSDQ' in sm['exchange']):
          symbols.append(sm)
      except KeyError:
        pass
    kin_vq = []
    low_r = []
    for symbol in symbols:
      red_zone = 100000
      yellow_zone = 100000
      adj_close_data = ts._get_history_from_snp(symbol['symbol'], symbol['exchange'], symbol['exchange_country'], None, None)
      adj_close_df = pd.DataFrame([x['close'] for x in adj_close_data], [x['tradingDay'] for x in adj_close_data])
      adj_close_df = adj_close_df[~adj_close_df.index.duplicated(keep='first')]
      hv_timeseries = self.mapping_accessor._query_table('SBT_HISTORICAL_VOLATILITY', 'guid', symbol['guid'])
      hv_lst = [float(hv_timeseries[x]['values']['value']) for x in range(len(hv_timeseries))]
      hv_df = pd.DataFrame([x['values']['value'] for x in hv_timeseries], [x['date'] for x in hv_timeseries])
      self._logger.info(symbol['symbol'])
      if hv_lst and len(adj_close_df.values.tolist()) > 521:
        adj_close_df = adj_close_df.truncate(after=hv_timeseries[-1]['date'])
        adj_close_lst = adj_close_df[0].values.tolist()
        # averageVQ = np.convolve(hv_lst, np.ones((7560,)) / 7560, mode='valid') # used to be 756
        averageVQ = hv_df.rolling(7650).mean()
        if np.isnan(averageVQ[0].iloc[-1]):
          averageVQ = hv_df.rolling(len(hv_df)).mean()
        vq_ratio = (hv_lst[-1] - averageVQ[0].iloc[-1]) / averageVQ[0].iloc[-1]
        if len(hv_lst) >= 521:
          o3 = self.o3_timeseries(adj_close_lst, hv_lst, adj_close_df)
        #   # red_zone, yellow_zone = self.o3(adj_close_lst, hv_lst)
        #   # print()
          if self.kin_vq_calc(vq_ratio, o3) == 0 and hv_df[0].iloc[-1] < 1:
            kin_vq.append(symbol['symbol'])
            self._logger.info("Kinetic VQ " + str(kin_vq))
          if self.low_risk(o3) == 0:
            low_r.append(symbol['symbol'])
            self._logger.info("Low Risk " + str(low_r))
    self._logger.info("Kinetic VQ " + str(kin_vq))
    self._logger.info("Low Risk " + str(low_r))

  def kin_vq_calc(self, vq_ratio, o3):
        # last_day_str = adj_close_df.index[-1]
        # last_day = datetime.datetime.strptime(last_day_str, "%Y-%m-%d")
        # delta = self.monthdelta(last_day, -3)
        # count = 0
        # while count is not -1:
        #   try:
        #     three_month_trend = (adj_close_df.loc[last_day_str][0] - adj_close_df.loc[(delta - timedelta(days=-count)).strftime("%Y-%m-%d")][0])/(adj_close_df.loc[(delta - timedelta(days=-count)).strftime("%Y-%m-%d")][0])
        #     count = -1
        #   except KeyError:
        #     count += 1

      if isinstance(vq_ratio, float):
        if vq_ratio > 0 and o3['zone_classification'].iloc[-1] == 'green':
          return 0
        else:
          return 1

  def o3_timeseries(self, adj_close_lst, hv_lst, adj_close_df):
    o3_df = pd.DataFrame(index=adj_close_df.index, columns=['red_zone', 'yellow_zone', 'zone_classification'])
    count = 1
    while len(hv_lst) > 520 and len(adj_close_lst) > 520:
      red_zone, yellow_zone = self.o3(adj_close_lst, hv_lst)
      last_price = adj_close_df["close"][adj_close_df.index[-count]]
      if last_price < red_zone:
        o3_df['zone_classification'][adj_close_df.index[-count]] = 'red'
      elif last_price < yellow_zone:
        o3_df['zone_classification'][adj_close_df.index[-count]] = 'yellow'
      else:
        o3_df['zone_classification'][adj_close_df.index[-count]] = 'green'
      o3_df['red_zone'][adj_close_df.index[-count]] = red_zone
      o3_df['yellow_zone'][adj_close_df.index[-count]] = yellow_zone
      del hv_lst[-1]
      del adj_close_lst[-1]
      count += 1
    return o3_df

  def low_risk(self, o3):
    # is it currently green
    if o3['zone_classification'].iloc[-1] == 'green':
      count = 1
      # find first occurence of yellow
      while o3['zone_classification'].iloc[-count] != 'yellow':
        count += 1
        if count == len(o3):
          return 1
      yellow_count = 0
      # count how long it has been yellow
      while o3['zone_classification'].iloc[-count] == 'yellow':
        count += 1
        yellow_count += 1
      # did the zone change from green to yellow to green
      if o3['zone_classification'].iloc[-count] == 'green':
        green_count = 0
        # how long was it green before becoming yellow
        while o3['zone_classification'].iloc[-count] == 'green':
          count += 1
          green_count += 1
        if yellow_count <= 10 and green_count >= 5 and count <= 10:  # makes sure there was an extended green period
          #  followed by a short yellow period, followed by a green period that has not exceeded 2 trading weeks
          # (this last check may need to be adjusted)
          return 0
    return 1

  def o3(self, adj_close_lst, hv):
    max_price = 0
    minVQ = 1000
    for day in range(-521, 0):
      if adj_close_lst[day] > max_price:
        max_price = adj_close_lst[day]
      if hv[day] < minVQ:
        minVQ = hv[day]
    red_zone = float(1-minVQ) * float(max_price)
    yellow_zone = float(1-minVQ+(minVQ/2.5)) * float(max_price)
    # if adj_close_lst[-1] > yellow_zone:
    #   print()
    return red_zone, yellow_zone


if __name__ == '__main__':
    ind = BuyIndicators()
    ind.load_prices()
    # ind.o3()