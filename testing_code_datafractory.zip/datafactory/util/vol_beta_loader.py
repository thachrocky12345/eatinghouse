import pandas as pd
import numpy as np
from decimal import Decimal
from time_series_manager import TimeSeriesManager
from sbt_common import SbtGlobalCommon
from fs_accessor import FinancialAccessor, FinancialVendors
from mp_accessor import MappingAccessor, MPAccessor, TableMappingGuid
from data_mapper import SbtDataMapper
from barchart_accessor import BarchartAccessor
import ast
import simplejson
from dd_accessor import DynamoAccessor
import datetime
import time
from snp_accessor import SNPProcessor
from pg_accessor import PostgresAccessor


class VolBetaAccessor(DynamoAccessor):
  def __init__(self):
    super().__init__(aws_profile_name=None,
             aws_region_name=None,
             aws_end_point_url=None)
    self.mapping_accessor = MappingAccessor()
    self.ts = TimeSeriesManager()
    self._logger = self._sbtcommon.get_global_logger()
    self.env = 'dev'
    # get the config for S&P
    self.config = SbtGlobalCommon.raw_sbt_config[self.env]['postgres']['snpcompanyfinancials']
    # create an instance of the PG accessor
    self.pg_sbtcompanyfin = PostgresAccessor(self.config)

    # initial action to take when writing volatility to the database
    self.action_to_take = 'replace'

  # def clean_keys(self, request_json):
  #   request_json["entity_name"] = request_json["text"]
  #   del request_json["text"]
  #   request_json["guid"] = request_json["id"]
  #   del request_json["id"]

  # def get_filter_by_start_timestamp(self, results, start_timestamp, end_timestamp):
  #   """
  #     Filters time series response based on timestamp
  #
  #     Args :
  #     results(list)        : Result list to be filtered
  #     start_timestamp(int) : Starting Timestamp
  #     end_timestamp(int)   : Ending Timestamp
  #
  #     Returns :
  #     (list) : Filtered Results
  #   """
  #   filter_timestamps = results
  #
  #   if start_timestamp is not None and end_timestamp is not None:
  #     filter_timestamps = []
  #     for r in results:
  #       if r['timestamp'] >= start_timestamp and r['timestamp'] <= end_timestamp:
  #         filter_timestamps.append(r)
  #
  #   return filter_timestamps

  # def get_results(self, category_guid, request_json, start_timestamp, table_mapping):
  #   results = []
  #   env_conf = SbtGlobalCommon.get_sbt_config()
  #   vendor = SbtGlobalCommon.get_sbt_config()['services']['time_series_manager']['vendor']
  #
  #   if 'financials' in env_conf and 'vendor' in env_conf['financials']:
  #     vendor = env_conf['financials']['vendor']
  #
  #   fs_accessor = FinancialAccessor(vendor)
  #
  #   if category_guid == TableMappingGuid.US_COMPANY_STOCK_PRICE.value:
  #     results = fs_accessor.query_stock_price(request_json['symbol'],
  #                         None,
  #                         standardized_format=True,
  #                         timestamp=start_timestamp)
  #
  #   elif category_guid == \
  #       TableMappingGuid.US_FUNDAMENTALS_TIMESERIES_ANNUALLY.value:
  #     results = fs_accessor.query_financial_timeseries(
  #       request_json['symbol'], 'a')
  #   elif category_guid == \
  #       TableMappingGuid.US_FUNDAMENTALS_TIMESERIES_QUARTERLY.value:
  #     results = fs_accessor.query_financial_timeseries(
  #       request_json['symbol'], 'q')
  #
  #   if not results:
  #     results = self.mapping_accessor.query_table_by_mapping(
  #       table_mapping, request_json["guid"])
  #
  #   return results

  def calculate_vol(self, adj_close_series, response, beta_time_frame, daily_returns_lst, spx_daily_change=None,
            spx_start_pos=None, spx_var=None, adj_close_df_index=None):
    # OLD CODE THAT WORKS WITH ALGORITHMS. CHANGED PER REQUEST
    # periods = [756]  # in trading days
    # # (https://www.quandl.com/data/VOL-US-Equity-Historical-Option-Implied-Volatilities/documentation/methodology)
    # for period in periods:
    #   ddof = period / 5
    #   # ddof = 252/period
    #   # stdDeviation = pd.rolling_std(adj_close_series, window=period, ddof=0)
    #   roller = adj_close_series.rolling(period)
    #   vol_list = roller.std(ddof=ddof)
    #   for x in range(period, len(vol_list)):
    #     if period > 252:
    #       anualize_factor = period / 252
    #       inverse_anualize = 1 / anualize_factor
    #       sub_factor = (vol_list[x] * np.sqrt(252)) * inverse_anualize
    #       vol_list[x] = (vol_list[x] * np.sqrt(252)) - sub_factor
    #     else:
    #       vol_list[x] = vol_list[x] * np.sqrt(252)

    periods = [756]  # in trading days
    # (https://www.quandl.com/data/VOL-US-Equity-Historical-Option-Implied-Volatilities/documentation/methodology)
    for period in periods:
      ddof = period / 5
      roller = adj_close_series.rolling(756)

      vol_list = roller.std(ddof=ddof)
      new_vol = vol_list.copy()

      for x in range(period, len(vol_list)):
        new_vol[x] = ((vol_list[x] * .5) + (vol_list[x-252] * .3) + (vol_list[x-504] * .2)) * np.sqrt(252) * (2/3)
      vol_df = pd.DataFrame([x for x in new_vol], adj_close_df_index)
      # print(period, vol_df.iloc[-1].values)
      if not spx_daily_change:
        batch_items = []
        for date, value in vol_df.to_dict()[0].items():
          if not np.isnan(value):
            timestamp = Decimal(str(time.mktime(datetime.datetime.strptime(str(date),
                                             "%Y-%m-%d").timetuple())))
            item = {
              'guid': self.ts.get_guid_from_symbol_and_exchange(response, "FRED"),
              'date': str(date),
              'timestamp': timestamp,
              'values': {
                'value': Decimal(str(value))
              }
            }
            batch_items.append(item)
      else:
        batch_items = []
        for date, value in vol_df.to_dict()[0].items():
          if not np.isnan(value):
            timestamp = Decimal(str(time.mktime(datetime.datetime.strptime(str(date),
                                             "%Y-%m-%d").timetuple())))
            item = {
              'guid': response['guid'],
              'date': str(date),
              'timestamp': timestamp,
              'values': {
                'value': Decimal(str(value))
              }
            }
            batch_items.append(item)
      # self.mapping_accessor._batch_save('DEV_SBT_HISTORICAL_VOLATILITY', batch_items)
      # self.mapping_accessor._batch_save('SBT_HISTORICAL_VOLATILITY', batch_items)
      # self.mapping_accessor._batch_save('SBT_HISTORICAL_VOLATILITY_BARCHART', batch_items)

      # create volatility object
      current_volatility = pd.DataFrame(
        [{
          'composite_pk_id': response.get('composite_pk_id'),
          'guid': response.get('guid'),
          'date_calculated': datetime.datetime.now().strftime('%Y-%m-%d'),
          'volatility': list(vol_df.to_dict()[0].values())[-1]
        }]
      )
      # save volatility object to PG
      current_volatility.to_sql('volatility',
                                self.pg_sbtcompanyfin._engine,
                                if_exists=self.action_to_take,
                                index=False)
      self.action_to_take = 'append'

      insert = "UPDATE {} SET volatility = %s WHERE guid = %s;"
      self.pg_sbtcompanyfin._execute_dml(insert.format("dev_snp_company"),
                                         [batch_items[-1]['values']['value'], response['sbt_company_id']])
      self.pg_sbtcompanyfin._execute_dml(insert.format("qa_snp_company"),
                                         [batch_items[-1]['values']['value'], response['sbt_company_id']])
      self.pg_sbtcompanyfin._execute_dml(insert.format("prod_snp_company"),
                                         [batch_items[-1]['values']['value'], response['sbt_company_id']])

    if spx_daily_change is not None:
      start_pos = len(daily_returns_lst) - (beta_time_frame * 12) - 1
      self.calculate_beta(start_pos, spx_daily_change, spx_start_pos, spx_var, response, date, daily_returns_lst)

  def calculate_beta(self, start_pos, spx_daily_change, spx_start_pos, spx_var, response, date, daily_returns_lst):
    try:
      beta = np.cov(np.array(daily_returns_lst[start_pos:-1]), np.array(
        ast.literal_eval(simplejson.dumps(spx_daily_change[spx_start_pos:-1], use_decimal=True))))[0][
             1] / spx_var
      # expression_attribute_names = {'#values': 'values', '#timestamp': 'timestamp'}
      timestamp = Decimal(str(time.mktime(datetime.datetime.strptime(str(date),
                                       "%Y-%m-%d").timetuple())))

      item = {
        'guid': response['guid'],
        'date': str(date),
        'timestamp': timestamp,
        'values': {
          'value': Decimal(str(beta))
        }
      }
      self.mapping_accessor._save('SBT_BETA', item)
      insert = "UPDATE {} SET beta = %s WHERE guid = %s;"
      self.pg_sbtcompanyfin._execute_dml(insert.format("dev_snp_company"), [beta, response['sbt_company_id']])
      self.pg_sbtcompanyfin._execute_dml(insert.format("qa_snp_company"), [beta, response['sbt_company_id']])
      self.pg_sbtcompanyfin._execute_dml(insert.format("prod_snp_company"), [beta, response['sbt_company_id']])
      # dd._update('SBT_BETA', ['values', 'timestamp'], [{'value': Decimal(str(beta))}, timestamp],
      #            {'guid': response['guid'], 'date': str(date)}, expression_attribute_names)

      # print(response['symbol'] + ' beta: ' + str(beta))
    except ValueError:
      self._logger.info("Not enough data for " + str(response['symbol']))
    except AttributeError:
      beta = np.cov(np.array(
        ast.literal_eval(simplejson.dumps(daily_returns_lst[start_pos:-1], use_decimal=True))), np.array(
        ast.literal_eval(simplejson.dumps(spx_daily_change[spx_start_pos:-1], use_decimal=True))))[0][
             1] / spx_var
      # expression_attribute_names = {'#values': 'values', '#timestamp': 'timestamp'}
      timestamp = Decimal(str(time.mktime(datetime.datetime.strptime(str(date),
                                       "%Y-%m-%d").timetuple())))
      item = {
        'guid': response['guid'],
        'date': str(date),
        'timestamp': timestamp,
        'values': {
          'value': Decimal(str(beta))
        }
      }
      self.mapping_accessor._save('SBT_BETA', item)

  def get_prices(self, list_of_datamapping, fred=False):
    if fred:
      # tm = TimeSeriesManager()
      # NEED TO ADD IN S&P to calculate vol???
      for i, symbol in enumerate(list_of_datamapping):
        fred_data_lst = self.ts.get_fred_data(symbol)
        beta_time_frame = 3
        counter = 0
        if fred_data_lst:
          adj_close_df = pd.DataFrame([float(x['values']['value']) for x in fred_data_lst], [x['date'] for x in fred_data_lst])
          try:
            daily_returns1 = adj_close_df.pct_change(1)
            # adj_close_df_dates = pd.DataFrame(adj_close_df.values, [x['date'] for x in ad['results']])
            adj_close_df_index = adj_close_df.index
            adj_close_df.index = pd.to_datetime(adj_close_df.index)
            # adj_close_monthly = adj_close_df_dates.resample('1M').asfreq()
            adj_close_monthly = adj_close_df.groupby([lambda x: x.year, lambda x: x.month]).last()
            daily_returns_monthly = adj_close_monthly.pct_change(1)
            daily_returns_lst = [x for x in daily_returns_monthly[0]]
            # spx_daily_change = daily_returns_lst
            # spx_start_pos = len(daily_returns_lst) - (beta_time_frame*12) - 1
            # spx_var = np.var(ast.literal_eval(simplejson.dumps(spx_daily_change[spx_start_pos:-1])))
            adj_close_series = pd.Series([x for x in daily_returns1[0]])

            self.calculate_vol(adj_close_series, list_of_datamapping[i], beta_time_frame, daily_returns_lst, adj_close_df_index=adj_close_df_index)
          except:
            self._logger.info('error in calculating ' + str(list_of_datamapping[i]))

        else:
          self._logger.info("No data for " + str(list_of_datamapping[i]))
        self._logger.info(str(list_of_datamapping[i]) + " " + str(list_of_datamapping[i]))
        counter += 1
    else:
      barchart_accessor = BarchartAccessor()
      list_of_datamapping.insert(0, {"symbol": "$SPX", "exchange": "NYSE", "guid": "242025a9-37ac-42e4-919f-8a1810841e2f",
                                     "category": ['1f2fe84b-c3a8-4f36-a06d-598170264a6a'], "table_mapping": ['1f2fe84b-c3a8-4f36-a06d-598170264a6a']})
      for i in range(len(list_of_datamapping)):
        # self._logger.info(str(list_of_datamapping[i]['symbol']))
        # category_guid = list_of_datamapping[i].get("category_guid", "").strip()
        # tm = TimeSeriesManager()
        # adj_close_data = tm._get_history_from_snp(list_of_datamapping[i]['symbol'], list_of_datamapping[i]['exchange'], None, None)
        # if not adj_close_data:
        adj_close_data = barchart_accessor.get_history(None, "daily", 0, '19000101', None,
                                                         list_of_datamapping[i]['symbol'])
        self._logger.info(list_of_datamapping[i]['symbol'])
        print(list_of_datamapping[i]['symbol'])
        # self.calculate(adj_close_data, list_of_datamapping[i])

    # def calculate(self, adj_close_data, response):
        beta_time_frame = 3
        counter = 0
        if adj_close_data:
          adj_close_df = pd.DataFrame([x['close'] for x in adj_close_data], [x['tradingDay'] for x in adj_close_data])
          adj_close_df = adj_close_df[~adj_close_df.index.duplicated(keep='last')]
          try:
            daily_returns1 = adj_close_df.pct_change(1)
            # adj_close_df_dates = pd.DataFrame(adj_close_df.values, [x['date'] for x in ad['results']])
            adj_close_df_index = adj_close_df.index
            adj_close_df.index = pd.to_datetime(adj_close_df.index)
            # adj_close_monthly = adj_close_df_dates.resample('1M').asfreq()
            adj_close_monthly = adj_close_df.groupby([lambda x: x.year,lambda x: x.month]).last()
            daily_returns_monthly = adj_close_monthly.pct_change(1)
            daily_returns_lst = [x for x in daily_returns_monthly[0]]
            # spx_daily_change = daily_returns_lst
            # spx_start_pos = len(daily_returns_lst) - (beta_time_frame*12) - 1
            # spx_var = np.var(ast.literal_eval(simplejson.dumps(spx_daily_change[spx_start_pos:-1])))
            adj_close_series = pd.Series([x for x in daily_returns1[0]])

            if list_of_datamapping[i]['symbol'] == '$SPX':
              spx_daily_change = daily_returns_lst
              spx_start_pos = len(daily_returns_lst) - (beta_time_frame * 12) - 1
              spx_var = np.var(ast.literal_eval(simplejson.dumps(spx_daily_change[spx_start_pos:-1])))
            else:
              self.calculate_vol(adj_close_series, list_of_datamapping[i], beta_time_frame, daily_returns_lst,
                                 spx_daily_change, spx_start_pos, spx_var, adj_close_df_index)
          except:
            self._logger.info('error in calculating ' + str(list_of_datamapping[i]['symbol']))

        else:
          self._logger.info("No data for " + str(list_of_datamapping[i]['symbol']))
        self._logger.info(str(list_of_datamapping[i]['symbol']) + " " + str(list_of_datamapping[i]['guid']))
        counter += 1

  def init_download(self):
    # dd = DynamoAccessor()
    # item1 = dd._scan_table_with_filter_str('SBT_SYMBOL_EXCHANGE_MAPPING', 'exchange eq NYSE')
    # item2 = dd._scan_table_with_filter_str('SBT_SYMBOL_EXCHANGE_MAPPING', 'exchange contains NSDQ')
    # all_items = item1 + item2
    # len_all = len(all_items)
    # mp_accessor = MappingAccessor()
    # symbol_mappings = mp_accessor.scan_symbol_exchange_mapping()

    # symbols = []
    # fred_symbols = ['DGS10', 'GOLDPMGBD228NLBM', 'GOLDAMGBD228NLBM', 'DCOILBRENTEU', 'DCOILWTICO']
    # self.get_prices(fred_symbols, fred=True)
    # f = False
    SYMBOL_MAPPING_TABLENAME = 'DEV_SBT_SYMBOL_EXCHANGE_MAPPING'
    symbol_mappings = self._scan_table_with_filter_str(
      SYMBOL_MAPPING_TABLENAME, 'symbol ne mairan')

    # for sm in symbol_mappings:
    #   try:
    #     # if sm['symbol'] == 'OMP':
    #     #   f = True
    #     # if sm['source'] == 'S&P' and (sm['exchange'] == 'NYSE' or 'NSDQ' in sm['exchange']) and f:
    #     if sm['source'] == 'S&P' and ('NYSE' in sm['exchange'] or 'NSDQ' in sm['exchange']):
    #       symbols.append(sm)
    #   except KeyError:
    #     pass
    symbols = []
    for sm in symbol_mappings:
      try:
        # if sm['symbol'] == 'OMP':
        #   f = True
        # if sm['source'] == 'S&P' and (sm['exchange'] == 'NYSE' or 'NSDQ' in sm['exchange']) and f:
        if sm['source'] == 'S&P' and ('NYSE' in sm['exchange'] or 'NSDQ' in sm['exchange'] or 'AMEX' in sm['exchange']):
          symbols.append(sm)
      except KeyError:
        pass
    # symbols.append(self._query_table_response('DEV_SBT_SYMBOL_EXCHANGE_MAPPING', 'guid', '0b0e58dd-5d63-4309-a255-d24b53e213ca', index_name='GUIDidx')['Items'][0])
    inc = 0
    while inc <= len(symbols):
      self.get_prices(symbols[inc:inc+100])
      inc = inc + 100
    # proc = SNPProcessor()
    # proc.populate_snp_company_beta()
    # self._logger.info("Vol Beta Loader Complete")


if __name__ == '__main__':
  vol = VolBetaAccessor()
  vol.init_download()
