import importlib
import itertools
import time
import datetime
import traceback

from pymongo import MongoClient
from sqlalchemy import VARCHAR, FLOAT, TIMESTAMP, JSON, INTEGER, text

import requests

from fs_accessor import FinancialAccessor
from fs_accessor import FinancialVendors
from mp_accessor import SymbolMappingTemplateType
from mp_accessor import TableMappingGuid
from mp_accessor import MappingAccessor
from intrinio_api import IntrinioApi
from article_utils import ArticleHelper
from pg_accessor import PostgresAccessor
from portfolio_api import PortfolioApi
from collections import OrderedDict
from sbt_common import SbtCommon
from sbt_common import SbtGlobalCommon
from mp_accessor import Vendors
from dd_accessor import DynamoAccessor
from cots_sentiment_loader import CalculateSentiment
import xml.etree.ElementTree
import re

from snp_accessor import SNPWarehouseAccessor, SNPAccessor
import pandas as pd
from cbonds_dataload import CBondsDataLoad

class Evaluator:
    def eval(self, eval_string):
        """
          Evaluates the string and returns the value.

          Args :
            eval_string(str) : String to be evaluated

          Returns :
            float : Result of string evaluation
        """
        clean_eval = re.sub(
            r'[^0-9 | ( | ) | / | * | \- | + | . | > | < | <= | >= | abs | if | else ]',
            r'', str(eval_string))
        return eval(clean_eval, {'__builtins__': {'abs': abs}})


class DataLoadAccessor(DynamoAccessor):
    def __init__(self):
        super().__init__(aws_profile_name=None,
                         aws_region_name=None,
                         aws_end_point_url=None)
        self._table_sbt_metadata_table_data_load = \
            self._get_environment_table_name(
                'SBT_METADATA_TABLE_DATA_LOAD')

    def unique_data_load(self, table_mapping_guid,
                         symbol_exchange_guid):
        return self._unique_item(self._table_sbt_metadata_table_data_load,
                                 'table_mapping_guid', table_mapping_guid,
                                 range_name='symbol_mapping_guid',
                                 range_value=symbol_exchange_guid)

    def query_data_load(self, table_mapping_guid,
                        symbol_exchange_guid=None):
        if symbol_exchange_guid:
            return self._query_table(self._table_sbt_metadata_table_data_load,
                                     'table_mapping_guid', table_mapping_guid,
                                     range_name='symbol_mapping_guid',
                                     range_value=symbol_exchange_guid)
        else:
            return self._query_table(self._table_sbt_metadata_table_data_load,
                                     'table_mapping_guid', table_mapping_guid)

    def get_data_load_dictionary(self, table_mapping_guid,
                                 symbol_exchange_guid=None):
        return_value = {}

        dls = self.query_data_load(table_mapping_guid, symbol_exchange_guid)

        for dl in dls:
            return_value[dl['symbol_mapping_guid']] = dl

        return return_value

    def batch_save_dataloads(self, data_loads):
        self._batch_save(
            self._table_sbt_metadata_table_data_load,
            data_loads)

    def _set_data_load_process(self, data_load):
        """
          Sets the data load dictionary to indicate that it needs
          to be loaded into the system.

          Args :
            data_load(list) : List of data load dictionaries
        """
        for dl in data_load:
            process = False

            status_code = 0

            if 'vendor_mapping' in dl.keys():
                for v in dl['vendor_mapping']:
                    if dl['vendor_mapping'][v]['load_timestamp'] == \
                            '00-00-0000 00:00:00 GMT':
                        process = True
                        status_code = 1
                    elif dl['vendor_mapping'][v]['failed_to_load']:
                        status_code = 2

            dl['status_code'] = status_code

            if dl['process'] != process:
                dl['process'] = process

    def _set_vendor_timestamp(self, data_load, symbol_mapping_guids, vendor):
        """
          Sets the vendor timestamp after the load process is complete.
          Also, set the record in an error state if an error occurred.

          Args :
            data_load(list) : List of data load dictionaries
            symbol_mapping_guids(list) : List of dictionaries for processed symbols
            vendor(str) : Vendor Identifier
        """
        timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(
            datetime.datetime.utcnow())
        success_guids = [d['guid'] for d in list(filter(lambda x:
                                                        x['success'] == True,
                                                        symbol_mapping_guids))]

        failed_filter = list(filter(lambda x: x['success'] == False,
                                    symbol_mapping_guids))

        for dl in data_load:
            if 'vendor_mapping' not in dl.keys() or \
                    vendor not in dl['vendor_mapping'].keys() or \
                    dl['vendor_mapping'][vendor]['load_timestamp'] != \
                    '00-00-0000 00:00:00 GMT':
                continue

            failed = False
            failed_guid = []

            if dl['symbol_mapping_guid'] not in success_guids and \
                    len(failed_filter) > 0:
                failed_guid = list(
                    filter(lambda x: x['guid'] == dl['symbol_mapping_guid'],
                           failed_filter))

                failed = len(failed_guid) > 0

            if failed or dl['symbol_mapping_guid'] in success_guids:
                dl['vendor_mapping'][vendor]['load_timestamp'] = timestamp
                dl['vendor_mapping'][vendor]['failed_to_load'] = failed
                if failed:
                    dl['vendor_mapping'][vendor]['error_message'] = \
                        failed_guid[0]['error']

    def _get_vendor_symbol_mappings(self, data_load,
                                    symbol_mappings_dict,
                                    vendor):
        """
          Returns a list of symbols mappings based on the
          data load objects

          Args :
            data_load(list) : List of data load dictionaries
            symbol_mappings_dict(dict) : Dictionary of available symbol exch maps
            vendor(str) : Vendor ID

          Returns :
            (list) Symbol Exchange Mappings

        """
        symbol_mappings = []
        for dl in data_load:
            if 'vendor_mapping' in dl.keys() and \
                    vendor in dl['vendor_mapping'].keys() and \
                    dl['vendor_mapping'][vendor]['load_timestamp'] == \
                    '00-00-0000 00:00:00 GMT' and \
                    dl['symbol_mapping_guid'] in symbol_mappings_dict.keys():
                symbol_mappings.append(
                    symbol_mappings_dict[dl['symbol_mapping_guid']])

        return symbol_mappings

    def get_table_mapping_data_load(self, table_mapping, symbol_mappings_list):
        """
          Returns data load dictionaries associated with the table and symbol
          mappings

          Args :
            table_mapping(TableMapping) : Table Mapping Object
            symbol_mappings_list(list) : List of symbol exchange mappings

          Returns :
            (list) : List of Data Load Dictionaries
        """
        pull_date = self._sbtcommon.dateutil.get_current_date_string()
        vendors = table_mapping.get_vendor_mappings().keys()

        existing_data_load = self.query_data_load(table_mapping.get_guid())

        ret_data = []
        existing_data_load_dict = {}
        for dl in existing_data_load:
            if dl['process']:
                ret_data.append(dl)
            existing_data_load_dict[dl['symbol_mapping_guid']] = dl

        if self._sbtcommon.collectionsutil.is_not_empty(ret_data):
            return ret_data

        processed_guids = []
        for symbol_mapping in symbol_mappings_list:
            key = self._get_symbol_mapping_guid(table_mapping,
                                                symbol_mapping)

            if key in processed_guids or \
                    'table_mapping' not in symbol_mapping.keys() or \
                    table_mapping.get_guid() not in symbol_mapping[
                'table_mapping']:
                continue

            data_load = \
                self._get_data_load(table_mapping, symbol_mapping,
                                    existing_data_load_dict, vendors,
                                    pull_date)

            if self._sbtcommon.collectionsutil.is_not_empty(data_load):
                ret_data.append(data_load)

            processed_guids.append(key)

        return ret_data

    def _get_data_load(self, table_mapping, symbol_mapping,
                       existing_data_load_dict,
                       vendors, pull_date):
        """
          Returns a populated data load object.

          Args :
            table_mapping(TableMapping) : Table Mapping Object
            symbol_mapping(dict) : Symbol Exchange Mapping
            existing_data_load_dict(dict) : Existing dataload objects
            vendors(list) : Vendor ID's
            pull_date(str) : Date indicating when the data was retrieved

          Returns :
            (dict)
        """
        load = None
        data_load = None
        key = self._get_symbol_mapping_guid(table_mapping,
                                            symbol_mapping)

        if key in existing_data_load_dict.keys():
            data_load = existing_data_load_dict[key]

        temp_load = None
        if self._sbtcommon.collectionsutil.is_not_empty(data_load):
            temp_load = data_load
        else:
            temp_load = {}
            temp_load['table_mapping_guid'] = table_mapping.get_guid()
            temp_load['symbol_mapping_guid'] = key

        temp_load['symbol'] = symbol_mapping['symbol']
        temp_load['table_name'] = table_mapping.get_name()

        if 'vendor_mapping' not in temp_load.keys():
            temp_load['vendor_mapping'] = {}

        process = self._process_vendor_mappings(pull_date, table_mapping,
                                                symbol_mapping, vendors,
                                                temp_load)

        if process:
            temp_load['process'] = process
            temp_load['status_code'] = 1
            load = temp_load

        return load

    def _process_vendor_mappings(self, pull_date, table_mapping,
                                 symbol_mapping, vendors, temp_load):
        process = False
        for v in vendors:
            if self._skip_processing(table_mapping, symbol_mapping, v):
                continue

            process = True
            if v not in temp_load['vendor_mapping'].keys():
                vendor_load = {}
                temp_load['vendor_mapping'][v] = vendor_load

            if 'error_message' in temp_load['vendor_mapping'][v].keys():
                temp_load['vendor_mapping'][v].pop('error_message')

            if 'failed_to_load' in temp_load['vendor_mapping'][v].keys():
                temp_load['vendor_mapping'][v].pop('failed_to_load')

            temp_load['vendor_mapping'][v]['table_name'] = \
                table_mapping.get_table_name(vendor=v)
            temp_load['vendor_mapping'][v]['load_timestamp'] = \
                '00-00-0000 00:00:00 GMT'
            temp_load['vendor_mapping'][v]['pull_date'] = pull_date
            if table_mapping.requires_last_filing_date(vendor=v):
                temp_load['vendor_mapping'][v][
                    'latest_filing_date'] = '0000-00-00'

        return process

    def _skip_processing(self, table_mapping, symbol_mapping,
                         vend):
        """
          Checks to see if the symbol exchange mapping should be processed.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            boolean : True to skip processing
        """
        skip_processing = False
        load_only_if_values_exists = False
        vendor_mappings = None

        if vend in table_mapping.get_vendor_mappings().keys():
            vendor_mappings = table_mapping.get_vendor_mappings()[vend]

        if self._sbtcommon.collectionsutil.is_empty(vendor_mappings):
            skip_processing = True
        elif 'only_if_values_exists' in vendor_mappings['load'].keys():
            load_only_if_values_exists = vendor_mappings['load'][
                'only_if_values_exists']

        # If guid is not valid for the symbol exchange mapping
        if not skip_processing and \
                ('table_mapping' not in symbol_mapping.keys() or \
                 table_mapping.get_guid() not in symbol_mapping[
                     'table_mapping']):
            skip_processing = True

        # If the _load_only_if_values_exists attribute is true load only if data
        # is already available for the mapping
        if not skip_processing and load_only_if_values_exists:
            key = self._get_symbol_mapping_guid(table_mapping, symbol_mapping)

            check = self._mp_accessor._query_table(
                table_mapping.get_table_name(vendor=vend),
                table_mapping.get_key_attribute().get_id(),
                key)
            if self._sbtcommon.collectionsutil.is_empty(check):
                self._logger.info(symbol_mapping['symbol'] +
                                  ' has not been loaded into the table')
                skip_processing = True

        return skip_processing

    def _get_symbol_mapping_guid(self, table_mapping, symbol_mapping):
        symbol_mapping_guid = symbol_mapping['guid']
        if table_mapping.get_guid() == TableMappingGuid.COMPANY.value:
            symbol_mapping_guid = symbol_mapping['sbt_company_id']

        return symbol_mapping_guid


class CompanyLoader:
    def __init__(self, table_mapping=None, vendor=None):
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_global_logger()
        self._mp_accessor = MappingAccessor()
        if table_mapping is None:
            # get GUID for the COMPANY item that contains all the info about
            # how to process the companies
            table_mapping = \
                self._mp_accessor.get_table_mapping(
                    TableMappingGuid.COMPANY.value)

        self._table_mapping = table_mapping

        # get the default data vendor
        if self._sbtcommon.stringutil.is_empty(vendor):
            self._vendor = self._table_mapping.get_default_vendor()
        else:
            self._vendor = vendor

        # get the mappings for the default vendor
        self._vendor_mappings = None
        if self._vendor in table_mapping.get_vendor_mappings().keys():
            self._vendor_mappings = table_mapping.get_vendor_mappings()[
                self._vendor]

        # set the extraction, validation, and loading of the data
        # for the default vendor
        self._validation_type = self._vendor_mappings['validation']['type']
        self._extraction_type = self._vendor_mappings['extraction']['type']
        self._load_type = self._vendor_mappings['load']['type']

        self._standard_load = True
        self._standard_extraction = True
        self._standard_validation = True
        self._load_method = None
        self._load_parameters = None
        self._load_class_instance = None
        self._extract_method = None
        self._extract_parameters = None
        self._extraction_class_instance = None
        self._validation_method = None
        self._validation_parameters = None
        self._validation_class_instance = None
        if self._extraction_type.lower() != 'standard':
            self._standard_extraction = False
            extraction_module = self._vendor_mappings['extraction'][
                self._extraction_type]['module']
            extraction_class = self._vendor_mappings['extraction'][
                self._extraction_type]['class']
            self._extraction_method = self._vendor_mappings['extraction'][
                self._extraction_type]['method']
            self._extraction_parameters = self._vendor_mappings['extraction'][
                self._extraction_type]['parameters']
            module = importlib.import_module(extraction_module)
            my_class = getattr(module, extraction_class)
            self._extraction_class_instance = my_class()

        if self._load_type.lower() != 'standard':
            self._standard_load = False
            load_module = self._vendor_mappings['load'][
                self._load_type]['module']
            load_class = self._vendor_mappings['load'][
                self._load_type]['class']
            self._load_method = self._vendor_mappings['load'][
                self._load_type]['method']
            self._load_parameters = self._vendor_mappings['load'][
                self._load_type]['parameters']
            module = importlib.import_module(load_module)
            my_class = getattr(module, load_class)
            self._load_class_instance = my_class()
            self._data_load_accessor = DataLoadAccessor()

        if self._validation_type.lower() != 'standard':
            self._standard_validation = False
            validation_module = self._vendor_mappings['validation'][
                self._load_type]['module']
            validation_class = self._vendor_mappings['validation'][
                self._load_type]['class']
            self._validation_method = self._vendor_mappings['validation'][
                self._load_type]['method']
            self._validation_parameters = self._vendor_mappings['validation'][
                self._load_type]['parameters']
            module = importlib.import_module(validation_module)
            my_class = getattr(module, validation_class)
            self._validation_class_instance = my_class()

        self._pull_date = self._sbtcommon.dateutil.get_current_date_string()
        self._vendors = self._table_mapping.get_vendor_mappings().keys()
        self._evaluator = Evaluator()

    def load_data(self):
        start = 0
        process = 50

        last_start = start

        try:
            # get info about how to process companies
            # from the SBT_METADATA_TABLE_MAPPING table
            data_load_dict = \
                self._data_load_accessor.get_data_load_dictionary(
                    self._table_mapping.get_guid())

            filings_dates = self._get_filing_dates(data_load_dict)

            execute = True
            while execute:
                self._logger.info('Begin - CompanyLoader.loaddata (Start : '
                                  + str(start) + ' Process : ' +
                                  str(process) + ')')

                extracted_data = None
                if self._standard_extraction:
                    extracted_data = self._standard_extraction(start, process,
                                                               filings_dates)
                else:
                    extracted_data = self._non_standard_extraction(start,
                                                                   process,
                                                                   filings_dates)

                if len(extracted_data) == 0:
                    break

                symbol_mappings = []
                data_load_updates = {}
                update_to_date_mappings = []
                companies = []
                for data in extracted_data:
                    self._process_extracted_data(symbol_mappings, data,
                                                 data_load_updates,
                                                 companies,
                                                 update_to_date_mappings,
                                                 data_load_dict)

                loaded_data = None
                if self._standard_load:
                    loaded_data = self._standard_load(symbol_mappings,
                                                      companies)
                else:
                    loaded_data = self._non_standard_load(symbol_mappings,
                                                          companies)

                start = self._process_data_load_updates(loaded_data,
                                                        data_load_updates)

                self._logger.info('End - CompanyLoader.loaddata (Start : '
                                  + str(last_start) + ' Process : ' +
                                  str(process) + ')')

                # break

                if start < last_start:
                    self._logger
                    start = last_start + process

                last_start = start
        except Exception as exc:
            self._logger.error('Failed to execute company load method ' +
                               'Exception: ' + str(exc) +
                               'Trace: ' + traceback.format_exc())

    def _process_extracted_data(self, symbol_mappings, data, data_load_updates,
                                companies, update_to_date_mappings,
                                data_load_dict):
        try:
            v_company = self._get_validation(data)

            v_guid = None
            if v_company:
                v_guid = v_company.get('guid', None)

            company_sym_mapp = self._get_symbol_mappings_for_company(
                data_load_dict,
                data,
                v_guid=v_guid)
            if company_sym_mapp:
                symbol_mappings.extend(company_sym_mapp['update'])
                update_to_date_mappings.extend(company_sym_mapp['no_changes'])
                guid = company_sym_mapp['sbt_company_id']
                data_load_updates[guid] = company_sym_mapp['data_load_object']
                companies.append(self._create_company_record(guid, data))
        except Exception as e:
            self._logger.error(e)

    def _process_data_load_updates(self, loaded_data, data_load_updates):
        timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(
            datetime.datetime.utcnow())
        max_id = 0

        if not loaded_data:
            return max_id

        for ld in loaded_data:
            guid = ld['guid']
            if ld['id'] > max_id:
                max_id = ld['id']

            if not data_load_updates or guid not in data_load_updates:
                self._logger.error('Need to look at guid ' + guid)
                continue
            elif not data_load_updates[guid]:
                data_load_updates.pop(guid, None)
                self._logger.error(
                    'Removed entry, need to look at guid ' + guid)
                continue

            if not ld['success']:
                data_load_updates[guid]['vendor_mapping'][self._vendor][
                    'error_message'] = ld['error_message']
                data_load_updates[guid]['vendor_mapping'][self._vendor][
                    'failed_to_load'] = True
                data_load_updates[guid]['status_code'] = 2
            else:
                data_load_updates[guid]['status_code'] = 0

            data_load_updates[guid][
                'vendor_mapping'][self._vendor]['latest_filing_date'] = \
                ld['latest_filing_date']
            data_load_updates[guid][
                'vendor_mapping'][self._vendor]['id'] = \
                ld['id']
            data_load_updates[guid][
                'vendor_mapping'][self._vendor]['load_timestamp'] = timestamp
            data_load_updates[guid]['process'] = False

        if data_load_updates:
            self._data_load_accessor.batch_save_dataloads(
                list(data_load_updates.values()))

        return max_id

    def _standard_load(self, s_mapping, companies):
        """
          This method is called if the standard extraction process
          is used for a vendor.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            list : List of dictionaries derived from JSON
        """

        self._logger.error('Method is not implemented for Company data.')
        self._logger.error(s_mapping)
        self._logger.error(companies)
        return []

    def _non_standard_load(self, s_mapping, companies):
        """
          This method is called if code has been
          developed to extract vendor data.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            list : List of dictionaries derived from JSON
        """
        return_data = []

        available_param = {}
        available_param['symbol_exchange_mappings'] = s_mapping
        available_param['companies'] = companies
        method_params = self._create_parameters_dictionary(available_param,
                                                           self._load_parameters)
        self._logger.info('Execute Load ' +
                          self._load_class_instance.__class__.__name__ + '.' +
                          self._load_method)
        response = getattr(self._load_class_instance,
                           self._load_method)(**method_params)
        if self._sbtcommon.collectionsutil.is_not_empty(response):
            return_data = response

        return return_data

    def _standard_extraction(self, start, end, data_load_dict):
        """
          This method is called if the standard extraction process
          is used for a vendor.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            list : List of dictionaries derived from JSON
        """

        self._logger.error('Method is not implemented for Company data.')
        self._logger.error(start)
        self._logger.error(end)
        self._logger.error(data_load_dict)
        return []

    def _non_standard_extraction(self, start, end, filings_dates):
        """
          This method is called if code has been
          developed to extract vendor data.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            list : List of dictionaries derived from JSON
        """
        return_data = []

        available_param = {}
        available_param['start'] = start
        available_param['end'] = end
        available_param['filings_dates'] = filings_dates
        method_params = self._create_parameters_dictionary(available_param,
                                                           self._extraction_parameters)
        self._logger.info('Execute Extract ' +
                          self._extraction_class_instance.__class__.__name__ +
                          '.' + self._extraction_method)
        response = getattr(self._extraction_class_instance,
                           self._extraction_method)(**method_params)
        if self._sbtcommon.collectionsutil.is_not_empty(response):
            return_data = response

        return return_data

    def _get_converted_extract_data(self, s_mapping, extracted_data):
        """
          Converts all extracted values for a symbol exhange mapping into
          the time series format.

          Args :
            extracted_data(list) : Data extracted from a vendor
            s_mapping(dict) : Symbol exchange mapping

          Returns :
            (list) : Time Series Data
        """
        converted_data = []

        if self._sbtcommon.collectionsutil.is_not_empty(extracted_data):
            for e_data in extracted_data:
                ts_record = self._create_timeseries_record(s_mapping, e_data)
                if self._sbtcommon.collectionsutil.is_not_empty(ts_record):
                    converted_data.append(ts_record)

        return converted_data

    def _get_validation(self, company):
        """
          This method is called if code has been
          developed to extract vendor data.

          Args :
            company(dict) : Source Company Data

          Returns :
            dict : Destination Company Data
        """
        return_data = {}

        method_params = self._create_parameters_dictionary(company,
                                                           self._validation_parameters)
        response = getattr(self._validation_class_instance,
                           self._validation_method)(**method_params)
        if self._sbtcommon.collectionsutil.is_not_empty(response):
            return_data = response

        return return_data

    def _create_company_record(self, guid, extracted_company):
        company = {}

        company['guid'] = guid
        for value in self._table_mapping.get_value_attributes():
            v_attr = value.get_vendor_attribute_id(self._vendor)
            sbt_attr = value.get_id()
            if v_attr in extracted_company and extracted_company[v_attr]:
                company[sbt_attr] = extracted_company[v_attr]

        for calculation in self._table_mapping.get_calculated_attributes():
            v_ids = calculation.get_vendor_attribute_ids(self._vendor)
            v_ids_dict = {}
            for v_id in v_ids:
                if v_id in extracted_company and extracted_company[v_id]:
                    v_ids_dict[v_id] = extracted_company[v_id]
                else:
                    v_ids_dict[v_id] = 0

            form = calculation.get_vendor_attribute_formula(self._vendor)
            eval_string = form.format(**v_ids_dict)
            result = self._evaluator.eval(eval_string)
            company[calculation.get_id()] = result
            # add company's global identifier if present
            company['globalid'] = extracted_company.get('identifiervalue', '')
            company['is_etf'] = extracted_company.get('is_etf', False)
            # GICS
            company['gsector'] = extracted_company.get('gsector')
            company['ggroup'] = extracted_company.get('ggroup')
            company['gind'] = extracted_company.get('gind')
            company['gsubind'] = extracted_company.get('gsubind')

        return company

    def _create_parameters_dictionary(self, parameter_values, parameter_def):
        """
          Creates a dictionary of the parameters to be past to a method

          Args :
            parameter_values(dict) : Dictionary of parameters that can be used
            parameter_def(list) : List of parameter definitions associated with
                                  method
        """
        params = OrderedDict()
        parameter_values_keys = parameter_values.keys()
        if self._sbtcommon.collectionsutil.is_not_empty(parameter_def):
            for param in parameter_def:
                action = param['action'].lower()
                value = param['value']
                if (action == 'replace' or action == 'provided') and \
                        value in parameter_values_keys:
                    params[param['input']] = parameter_values[value]
                elif action == 'calculate':
                    params[param['input']] = \
                        self._get_parameter_calculated_value(param['input'],
                                                             param['type'],
                                                             param['value'])
                elif action == 'static':
                    params[param['input']] = value
                else:
                    raise Exception('Cannot map parameters')

        return params

    def _get_parameter_calculated_value(self, param, typ, value):
        """
          Performs a calculation on a parameter

          Args :
            param(str) : Parameter Name
            typ(str) : Parameter data type
            value : Value used in calculation

          Returns :
            (any) : Calculated Value
        """
        ret_value = None

        if param.endswith('_date') and \
                typ.lower() == 'string' and \
                (value.startswith('-') or value.startswith('+')):
            ret_value = self._sbtcommon.dateutil.get_relative_date(
                months=0, date_format='%Y%m%d', **{'days': int(value)})

        return ret_value

    def _get_symbol_mappings_for_company(self, data_load_dict, data,
                                         v_guid=None):
        if not data:
            return

        final_mappings = []
        skipped = []

        symbol_mappings = data.get('symbolexchangemappings', [])
        not_found_symbol_mappings = []
        sbt_com_id = None
        sb_portfolio_mapping = None
        if v_guid:
            sbt_com_id = v_guid

        dl_symbol_mapping = None

        for sym in symbol_mappings:
            exch = self._mp_accessor.get_exchange(self._vendor,
                                                  sym['exchange'])
            sym_mapping = self._mp_accessor.unique_stock_symbol_exchange_mapping(
                sym['symbol'], exchange=exch['code'],
                replace_alt_symbol=False)
            if sym_mapping:
                if not sb_portfolio_mapping and 'sb_portfolio_mapping' in sym_mapping:
                    sb_portfolio_mapping = sym_mapping['sb_portfolio_mapping']

                if not sbt_com_id:
                    sbt_com_id = sym_mapping['sbt_company_id']
                elif sbt_com_id != sym_mapping['sbt_company_id']:
                    raise Exception(
                        'SBT Company ids do not match for symbol ' +
                        sym_mapping['symbol'])

                if sym_mapping['exchange'] != sym['exchange'] or \
                        sym_mapping['symbol'] != sym['symbol']:
                    not_found_symbol_mappings.append(sym)

                self._update_final_symbol_mappings(exch, sym, sym_mapping,
                                                   exch['country_code'],
                                                   final_mappings,
                                                   skipped)

                if not dl_symbol_mapping and sym_mapping.get('primary', False):
                    dl_symbol_mapping = sym_mapping

            else:
                not_found_symbol_mappings.append(sym)

        for sym in not_found_symbol_mappings:
            exch = self._mp_accessor.get_exchange(self._vendor,
                                                  sym['exchange'])
            kwargs = {}
            kwargs['symbol_type'] = sym['symboltype']
            kwargs['third_party_codes'] = sym['thirdpartycodes']
            kwargs['primary'] = sym['primary']
            kwargs['sbt_company_id'] = sbt_com_id
            kwargs['globalid'] = sym['globalid']['value'] \
                if 'globalid' in sym else ''
            kwargs['is_etf'] = sym['is_etf'] if 'is_etf' in sym else False
            # GICS
            kwargs['gsector'] = sym.get('gsector', None)
            kwargs['ggroup'] = sym.get('ggroup', None)
            kwargs['gind'] = sym.get('gind', None)
            kwargs['gsubind'] = sym.get('gsubind', None)

            if sb_portfolio_mapping:
                kwargs['sb_portfolio_mapping'] = sb_portfolio_mapping

            new = self._mp_accessor.create_symbol_mapping(sym['symbol'],
                                                          exch['code'],
                                                          sym['entityname'],
                                                          sym[
                                                              'tablemappingtemplate'],
                                                          **kwargs)

            if not sbt_com_id:
                sbt_com_id = new['sbt_company_id']

            if not dl_symbol_mapping and new.get('primary', False):
                dl_symbol_mapping = new

            final_mappings.append(new)

        dl = self._data_load_accessor._get_data_load(self._table_mapping,
                                                     dl_symbol_mapping,
                                                     data_load_dict,
                                                     self._vendors,
                                                     self._pull_date)

        return_info = {}
        return_info['sbt_company_id'] = sbt_com_id
        return_info['globalid'] = sym.get('globalid', '')
        return_info['is_etf'] = sym.get('is_etf', False)
        # GICS
        return_info['gsector'] = sym.get('gsector', None)
        return_info['ggroup'] = sym.get('ggroup', None)
        return_info['gind'] = sym.get('gind', None)
        return_info['gsubind'] = sym.get('gsubind', None)

        return_info["update"] = final_mappings
        return_info["no_changes"] = skipped
        return_info["data_load_object"] = dl

        return return_info

    def _update_final_symbol_mappings(self, exch,
                                      sym, sym_mapping,
                                      country_code,
                                      final_mappings,
                                      skipped):
        update = False

        # print(sym_mapping)

        if sym['exchangename'] != sym_mapping['exchange_name']:
            sym_mapping['exchange_name'] = sym['exchangename']
            update = True

        if sym['entityname'] != sym_mapping['entity_name']:
            sym_mapping['entity_name'] = sym['entityname']
            update = True

        if sym.get('primary', False) != sym_mapping.get('primary', False):
            sym_mapping['primary'] = sym.get('primary', False)
            update = True

        if sym_mapping['exchange_name'] == 'Pink Sheets LLC':
            sym_mapping['exchange_name'] = 'Over the Counter Exchange'
            update = True

        if sym['symboltype'] != sym_mapping.get('symbol_type', 'UPDATE'):
            sym_mapping['symbol_type'] = sym['symboltype']
            update = True

        smtt = SymbolMappingTemplateType(sym['tablemappingtemplate'])
        sem_mapping = exch.get('template_mapping', {}).get(
            smtt.value, [])

        if not sem_mapping:
            raise Exception('No table symbol mapping found for ' +
                            sym['tablemappingtemplate'] + ' in ' +
                            country_code)

        current_sem_mapping = sym_mapping.get('table_mapping',
                                              sym_mapping.get('category', []))

        if TableMappingGuid.US_COMPANY.value in current_sem_mapping and \
                TableMappingGuid.COMPANY.value not in current_sem_mapping:
            sem_mapping.append(TableMappingGuid.COMPANY.value)

        sorted_sem_mapping = sorted(list(set(sem_mapping)))

        if sorted(current_sem_mapping) != sorted_sem_mapping:
            sym_mapping['category'] = sorted_sem_mapping
            sym_mapping['table_mapping'] = sorted_sem_mapping
            update = True

        for k, v in sym['thirdpartycodes'].items():
            if k not in sym_mapping or \
                    v != sym_mapping[k]:
                sym_mapping[k] = v
                update = True

        if update:
            final_mappings.append(sym_mapping)
        else:
            skipped.append(sym_mapping)

    def _get_data_load_dict(self, data_load_objects):
        data_load_dict = {}

        for dl in data_load_objects:
            if dl['symbol_mapping_guid'] not in data_load_dict:
                data_load_dict[dl['symbol_mapping_guid']] = dl

        return data_load_dict

    def _get_filing_dates(self, data_load_dict):
        filing_dates = {}
        for v in list(data_load_dict.values()):
            if 'id' in v['vendor_mapping'][self._vendor] and \
                    ((v['vendor_mapping'][self._vendor][
                          'id'] in filing_dates and \
                      filing_dates[v['vendor_mapping'][self._vendor]['id']] < \
                      v['vendor_mapping'][self._vendor][
                          'latest_filing_date']) or \
                     (v['vendor_mapping'][self._vendor][
                          'id'] not in filing_dates)):
                filing_dates[v['vendor_mapping'][self._vendor]['id']] = \
                    v['vendor_mapping'][self._vendor]['latest_filing_date']

        return filing_dates


# class PortfolioListLoader(DynamoAccessor):
#     def __init__(self):
#         super().__init__(aws_profile_name=None,
#                          aws_region_name=None,
#                          aws_end_point_url=None)
#         self._mp_accessor = MappingAccessor()
#         self._financial_accessor = FinancialAccessor(
#             FinancialVendors.STANDARD_AND_POORS.value)
#         self._intrinio_api = IntrinioApi()
#         self._portfolio_api = PortfolioApi()
#         self._table_sbt_symbol_exchange_mapping = \
#             self._get_environment_table_name('SBT_SYMBOL_EXCHANGE_MAPPING')
#         self._table_sbt_manual_portfolio = \
#             self._get_environment_table_name('SBT_MANUAL_PORTFOLIO')
#         # self._table_sbt_portfolio_list = \
#         #     self._get_environment_table_name('SBT_PORTFOLIO_LIST')
#         self._table_sbt_portfolio_list = 'PROD_SBT_PORTFOLIO_LIST'
#         self._populate_publication_lookup()
#         # self._table_sbt_symbol_exchange_mapping = 'SBT_SYMBOL_EXCHANGE_MAPPING'
#
#     def load_data(self):
#         try:
#             self._remove_old_lists()
#             self._load_symbol_exchanges()
#             self._create_portfolio_lists()
#             self._load_portfolio_list_stock_previous_day()
#             self._load_top_performers()
#             self._load_porters_list()
#
#         except Exception as exc:
#             self._logger.error('Failed to execute company load method ' +
#                                'Exception: ' + str(exc) +
#                                'Trace: ' + traceback.format_exc())
#
#     def all_recommended_symbols(self):
#         symbols = set()
#
#         filters = list()
#         filters.append(
#             self._create_filter_expression('symbols', "exists", None))
#         filters.append(self._create_filter_expression('defaultCategory', "ne",
#                                                       'external_article'))
#         filter_exp = self._build_filter_expression(filters)
#         articles = self._scan_table('articles', filter_exp)
#
#         for article in articles:
#             # ST-2275: Skip if Newswire or Ten Stock Trader
#             if (ArticleHelper.is_newswire(article)
#                     or ArticleHelper.has_publication_code(article, 'ttt')):
#                 continue
#
#             filtered_results = filter(lambda x: x['analysis'] == 'recommended',
#                                       article['symbols'])
#
#             for s in list(filtered_results):
#                 symbols.add(s['symbol'])
#
#         return symbols
#
#     def _populate_publication_lookup(self):
#         self._publication_lookup = OrderedDict()
#         data = self._portfolio_api.get_all_portfolio_info()
#         for d in data['tabinfo']:
#             pub_code = d.get('PubCode', {}).get('PubCode', 'N/A').upper()
#             pub_title = d.get('PubCode', {}).get('PubTitle', 'N/A')
#             portfolio_name = d['Name']
#             portfolio_id = d['Id']
#             if pub_code != 'N/A' and pub_title != 'NA' and \
#                     pub_code not in self._publication_lookup:
#                 self._publication_lookup[pub_code] = \
#                     {'portfolio_id': portfolio_id,
#                      'portfolio_name': portfolio_name,
#                      'pub_code': pub_code,
#                      'pub_title': pub_title}
#
#     def _remove_old_lists(self):
#         data = self._scan_table(self._table_sbt_portfolio_list, None)
#
#         list_dict = {}
#         for d in data:
#             if d['list_name'] not in list_dict:
#                 list_dict[d['list_name']] = []
#
#             list_dict[d['list_name']].append(d)
#
#         for v in list(list_dict.values()):
#             temp = sorted(v, key=lambda k: k['date'], reverse=True)
#             counter = 0
#             for t in temp:
#                 if counter > 4:
#                     self._logger.info('Deleting Old List : ' + t['list_name'] +
#                                       ' ' + t['date'])
#                     self._delete(self._table_sbt_portfolio_list,
#                                  'list_name',
#                                  t['list_name'],
#                                  range_name='date',
#                                  range_value=t['date'])
#                 counter = counter + 1
#
#     def _load_porters_list(self):
#         current_date = self._sbtcommon.dateutil.get_current_date_string()
#         timestamp = self._get_epoch_timestamp(current_date)
#
#         symbol_exchange_portfolios = \
#             self._mp_accessor.scan_symbol_exchange_mapping_for_sb_portfolios()
#
#         p_list = []
#         for sym in symbol_exchange_portfolios:
#             if sym['symbol'] == \
#                     sym['sb_portfolio_mapping'][0]['portfolio_symbol'] and \
#                     sym['exchange'] == \
#                     sym['sb_portfolio_mapping'][0]['portfolio_exchange']:
#                 sorted_pubs = self._get_formatted_publications(sym)
#
#                 stock_price = 0
#                 results = self._get_stock_prices(sym,
#                                                  '1d')
#                 if results:
#                     sorted_results = sorted(results,
#                                             key=lambda k: k['timestamp'],
#                                             reverse=True)
#                     temp_stock = sorted_results[0]
#                     if 'values' in temp_stock and 'adj_close' in temp_stock[
#                         'values']:
#                         stock_price = temp_stock['values']['adj_close']
#
#                 figi = None
#                 if sym.get('symbol', None) and sym.get('exchange', None):
#                     figi = self._financial_accessor.get_figi_code(
#                         sym['symbol'], sym['exchange'])
#
#                 if not figi:
#                     figi = 'NA'
#
#                 p_list.append({'guid': sym.get('sbt_company_id', sym['guid']),
#                                'symbol': sym['symbol'],
#                                'exchange': sym['exchange'],
#                                'exchange_currency': sym['exchange_currency'],
#                                'figi_code': figi,
#                                'name': sym['entity_name'],
#                                'stock_price': stock_price,
#                                'dividend': 0,
#                                'publications': sorted_pubs,
#                                'timestamp': timestamp})
#
#         sorted_p_list = sorted(p_list,
#                                key=lambda k: k['name'],
#                                reverse=False)
#
#         self._populate_rank_and_dividends(sorted_p_list)
#
#         self._delete(self._table_sbt_portfolio_list, 'list_name',
#                      'PORTERS_LIST',
#                      range_name='date',
#                      range_value=current_date)
#
#         self._save(self._table_sbt_portfolio_list,
#                    {'list_name': 'PORTERS_LIST',
#                     'date': current_date,
#                     'timestamp': timestamp,
#                     'values': sorted_p_list})
#
#     def _update_watch_symbols(self):
#         symbol_exchange_portfolios = \
#             self._mp_accessor.scan_symbol_exchange_mapping_for_sb_portfolios()
#
#         symbols = []
#         for symbol in symbol_exchange_portfolios:
#             if symbol.get('exchange_country', 'N/A') == 'USA' and \
#                     not symbol['symbol'].startswith('$'):
#                 symbols.append({'symbol': symbol['symbol']})
#
#         self._batch_save('BARCHART_STOCK_WATCH_LIST',
#                          symbols,
#                          overwrite_keys=['symbol'])
#
#     def _merge_na_portfolio_mappings(self, portfolio_mappings):
#         """
#         Args:
#             portfolio_mappings (dict): key pair values based on a compound symbol~exchange key.
#
#         Returns:
#             portfolio_mappings_merged (dict): deduplicated and merged symbol~exchange and
#             symbol~N/A portfolio mappings
#
#         Note:
#             This only accounts for "N/A" items.
#         """
#         portfolio_mappings_merged = {}
#         portfolio_mappings_na = {}
#
#         # Populate dict to be merged into with portfolio_mappings keys NOT ENDING in 'N/A'
#         for symbol, symbol_mapping_list in portfolio_mappings.items():
#             if not symbol.endswith('N/A'):
#                 portfolio_mappings_merged[symbol] = symbol_mapping_list
#
#         # Populate dict with portfolio_mappings keys NOT ENDING in 'N/A'
#         for symbol, symbol_mapping_list in portfolio_mappings.items():
#             if symbol.endswith('N/A'):
#                 portfolio_mappings_na[symbol] = symbol_mapping_list
#
#         # For all N/A items
#         for symbol, symbol_mapping_list in portfolio_mappings_na.items():
#             symbol_prefix = symbol.split('~')[0]
#             add_to_merged_symbols = True
#
#             # Attempt to merge in N/A items
#             for merged_symbol, merged_symbol_mapping_list in portfolio_mappings_merged.items():
#                 merged_symbol_prefix = merged_symbol.split('~')[0]
#
#                 if merged_symbol_prefix == symbol_prefix:
#                     merged_symbol_mapping_list.extend(symbol_mapping_list)
#                     add_to_merged_symbols = False
#
#             # If not mergeable add it back to the merged list
#             if add_to_merged_symbols == True:
#                 portfolio_mappings_merged[symbol] = symbol_mapping_list
#
#         return portfolio_mappings_merged
#
#     def _load_symbol_exchanges(self):
#         portfolio_mappings = {}
#         for t in list(self._publication_lookup.values()):
#             pub_code = t['pub_code']
#             pub_title = t['pub_title']
#             portfolio_name = t['portfolio_name']
#             portfolio_id = t['portfolio_id']
#
#             self._populate_portfolio_mappings(portfolio_id,
#                                               portfolio_name,
#                                               pub_code,
#                                               pub_title,
#                                               portfolio_mappings)
#
#         # Merge N/A mappings if a non N/A mapping of the same symbol exists
#         # ex SBUX~N/A data would be merged into SBUX~NSDQ data
#         portfolio_mappings = self._merge_na_portfolio_mappings(
#             portfolio_mappings)
#
#         symbol_exchange_portfolios = self._get_portfolio_symbol_exchange_mappings()
#
#         cur_symbol_mappings = list(symbol_exchange_portfolios.values())
#
#         for s in cur_symbol_mappings:
#             s.pop('sb_portfolio_mapping')
#
#         self._batch_save(self._table_sbt_symbol_exchange_mapping,
#                          cur_symbol_mappings)
#
#         updated_mappings = []
#         for k, v in portfolio_mappings.items():
#             sym_mapping = self._mp_accessor.unique_stock_symbol_exchange_mapping(
#                 k,
#                 exchange=None,
#                 replace_alt_symbol=True)
#
#             if sym_mapping:
#                 sym_mapping['sb_portfolio_mapping'] = v
#                 updated_mappings.append(sym_mapping)
#
#         self._batch_save(self._table_sbt_symbol_exchange_mapping,
#                          updated_mappings)
#
#         self._populate_portfolio_mapping_siblings()
#
#         self._logger.info('Processed Portfolios : ' +
#                           str(len(updated_mappings)))
#
#     def _populate_portfolio_mapping_siblings(self):
#         portfolios = \
#             self._mp_accessor.scan_symbol_exchange_mapping_for_sb_portfolios()
#
#         updates = []
#         processed = []
#
#         for p in portfolios:
#             guid = p.get('sbt_company_id', p['guid'])
#             siblings = \
#                 self._mp_accessor.query_symbol_exchange_mapping_by_company_id(
#                     guid)
#             if siblings:
#                 for sibling in siblings:
#                     if 'sb_portfolio_mapping' not in sibling and \
#                             sibling.get('composite_pk_id', 'SIB') != \
#                             p.get('composite_pk_id', 'SIB') and \
#                             sibling.get('composite_pk_id',
#                                         'SIB') not in processed:
#                         processed.append(sibling.get('composite_pk_id', 'SIB'))
#                         sibling['sb_portfolio_mapping'] = p[
#                             'sb_portfolio_mapping']
#                         updates.append(sibling)
#
#         if updates:
#             self._batch_save(self._table_sbt_symbol_exchange_mapping, updates)
#
#     def _process_portfolio_mapping(self, k, v, symbol_exchange_portfolios):
#         processed = True
#
#         if k in symbol_exchange_portfolios:
#             symbol_exchange_portfolios[k]['sb_portfolio_mapping'] = v
#         else:
#             key_parts = k.split('~')
#             sem = None
#             if key_parts[1] != 'N/A':
#                 sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(
#                     key_parts[0],
#                     key_parts[1])
#
#             if not sem:
#                 sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(
#                     key_parts[0])
#
#             if not sem and len(key_parts[0]) == 5 and key_parts[0].endswith(
#                     'Y'):
#                 sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(
#                     key_parts[0][0:4] + '.' + key_parts[0][4])
#
#             if sem:
#                 new_key = self._get_portfolio_key_from_sem(sem)
#                 sem['sb_portfolio_mapping'] = v
#                 symbol_exchange_portfolios[new_key] = sem
#             else:
#                 processed = False
#
#         return processed
#
#     def _get_portfolio_key_from_sem(self, sem):
#         key = sem['symbol'] + '~' + sem['exchange']
#
#         if sem['exchange'] == 'NYSEARCA' or sem['exchange'] == 'NSDQCM':
#             key = sem['symbol'] + '~' + sem['exchange'][:4]
#         elif sem['exchange'] == 'BATS':
#             key = sem['symbol'] + '~NYSE'
#
#         return key
#
#     def _get_portfolio_symbol_exchange_mappings(self):
#         ret_data = {}
#
#         portfolios = \
#             self._mp_accessor.scan_symbol_exchange_mapping_for_sb_portfolios()
#
#         for p in portfolios:
#             ret_data[self._get_portfolio_key_from_sem(p)] = dict(p)
#
#         return ret_data
#
#     def _populate_portfolio_mappings(self,
#                                      portfolio_id,
#                                      portfolio_name,
#                                      pub_code,
#                                      pub_title,
#                                      portfolio_mappings):
#
#         manual_portfolio = self._query_table(self._table_sbt_manual_portfolio,
#                                              'portfolio_id', portfolio_id)
#
#         if manual_portfolio:
#             self._populate_manual_portfolios(manual_portfolio,
#                                              portfolio_mappings)
#             return
#
#         p_data = self._portfolio_api.get_position_status_list(portfolio_id)
#
#         if 'position' not in p_data:
#             return
#
#         for p in p_data['position']:
#             # Cryto ExchangeMarket BraveNewCoin is currently not supported.
#             if not isinstance(p, dict) or 'Symbol' not in p or \
#                     p.get('ExchangeMarket', 'N/A') == 'BraveNewCoin':
#                 continue
#
#             portfolio_data = []
#             sub_trades = p.get('Subtrades', [])
#             if len(sub_trades) > 1 and '/' in p['Symbol']:
#                 for sub in sub_trades:
#                     portfolio_data.append(self._create_portfolio_mapping(
#                         portfolio_id,
#                         portfolio_name,
#                         pub_code,
#                         pub_title,
#                         sub))
#             else:
#                 portfolio_data.append(self._create_portfolio_mapping(
#                     portfolio_id,
#                     portfolio_name,
#                     pub_code,
#                     pub_title,
#                     p))
#
#             self._append_to_portfolio_mappings(portfolio_data,
#                                                portfolio_mappings)
#
#     def _append_to_portfolio_mappings(self, portfolio_data,
#                                       portfolio_mappings):
#         if not portfolio_data or portfolio_mappings == None:
#             return
#
#         for p in portfolio_data:
#             if p['portfolio_exchange'] == 'N/A' and \
#                     p['reference_price'] < 0:
#                 continue
#
#             key = p['portfolio_symbol'] + '~' + p['portfolio_exchange']
#             if key in portfolio_mappings:
#                 portfolio_mappings[key].append(p)
#             else:
#                 portfolio_mappings[key] = [p]
#
#     def _create_portfolio_mapping(self,
#                                   portfolio_id,
#                                   portfolio_name,
#                                   pub_code,
#                                   pub_title,
#                                   p):
#
#         if not portfolio_id or \
#                 not portfolio_name or \
#                 not pub_code or \
#                 not pub_title or \
#                 not p:
#             raise Exception(
#                 'Invalid data provided for _create_portfolio_mapping')
#
#         symbol = p['Symbol']
#         exchange_market = p.get('ExchangeMarket', 'N/A')
#         exchange_code = 'N/A'
#         ref_price = p.get('OpenPrice', 0)
#         rec_date = p.get('OpenDate', '0000-00-00T00:00:00')
#
#         if len(rec_date) > 10:
#             rec_date = rec_date[:10]
#
#         try:
#             ref_price = float(ref_price)
#         except:
#             ref_price = 0
#
#         exchange = self._mp_accessor.get_exchange(
#             Vendors.SBT_PORTOLIO.value,
#             exchange_market)
#
#         if exchange:
#             exchange_code = exchange['code']
#         elif exchange_market:
#             exchange_code = exchange_market
#
#         if exchange_code == 'HKEX':
#             exchange_code = 'N/A'
#
#         if not exchange and symbol.endswith('.HK'):
#             exchange_code = 'SEHK'
#             symbol = symbol.replace('.HK', '')
#
#         if not exchange and len(symbol) == 6 \
#                 and symbol.endswith('.T'):
#             exchange_code = 'TSE'
#             symbol = symbol.replace('.T', '')
#
#         if not exchange and symbol.endswith('.PA'):
#             exchange_code = 'ENXTPA'
#             symbol = symbol.replace('.PA', '')
#
#         if not exchange and symbol.endswith('.ST'):
#             exchange_code = 'OM'
#             symbol = symbol.replace('.ST', '')
#             symbol = symbol.replace('-', ' ')
#
#         name = p.get('Name', p.get('SymbolName', 'N/A'))
#
#         return {'portfolio_id': portfolio_id,
#                 'portfolio_name': portfolio_name,
#                 'portfolio_symbol': symbol,
#                 'portfolio_exchange': exchange_code,
#                 'pub_code': pub_code,
#                 'pub_title': pub_title,
#                 'recommendation_date': rec_date,
#                 'reference_price': ref_price,
#                 'entity_id': p['Id'],
#                 'entity_name': name}
#
#     def _populate_manual_portfolios(self,
#                                     manual_portfolio,
#                                     portfolio_mappings):
#
#         for p in manual_portfolio:
#             if 'exchange' not in p:
#                 continue
#
#             key = p['symbol'] + '~' + p['exchange']
#
#             p_t_data = {'portfolio_id': p['portfolio_id'],
#                         'portfolio_name': p['portfolio_name'],
#                         'portfolio_symbol': p['symbol'],
#                         'portfolio_exchange': p.get('exchange', 'N/A'),
#                         'pub_code': p['pub_code'],
#                         'pub_title': p['pub_title'],
#                         'recommendation_date': p.get('recommendation_date',
#                                                      '0000-00-00'),
#                         'reference_price': p.get('reference_price', 0.00),
#                         'entity_id': p['entity_id'],
#                         'entity_name': p['entity_name']}
#
#             if key in portfolio_mappings:
#                 portfolio_mappings[key].append(p_t_data)
#             else:
#                 portfolio_mappings[key] = [p_t_data]
#
#         return
#
#     def _portfolio_exists_in_sem(self,
#                                  symbol_exchange_mapping,
#                                  data):
#         p_exists = False
#         if 'sb_portfolio_mapping' not in symbol_exchange_mapping.keys():
#             return p_exists
#
#         for p in symbol_exchange_mapping['sb_portfolio_mapping']:
#             if p['portfolio_id'] == data['portfolio_id'] and \
#                     p['entity_id'] == data['entity_id']:
#                 p_exists = True
#                 break
#
#         return p_exists
#
#     def _get_new_company(self, symbol, name):
#         company = self._get_company_data_from_vendor(symbol)
#         if self._sbtcommon.collectionsutil.is_empty(company):
#             company = {
#                 "name": name,
#                 "ticker": symbol
#             }
#
#         return company
#
#     def _get_company_data_from_vendor(self, symbol):
#         company = {}
#
#         try:
#             company = self._intrinio_api.get_company(symbol)
#         except Exception as exc:
#             self._logger.error(
#                 "Unable to find company " + symbol + ":" + str(exc))
#             company = {}
#
#         return company
#
#     def _create_portfolio_lists(self):
#         """
#           Creates portfolio lists
#         """
#         current_date = self._sbtcommon.dateutil.get_current_date_string()
#         timestamp = self._get_epoch_timestamp(current_date)
#
#         top_five_day_movers = []
#         top_thirty_day_movers = []
#
#         filtered_portfolio_list = self._get_filtered_portfolio_list()
#
#         for p in filtered_portfolio_list:
#             results = self._get_stock_prices(p, '3M')
#
#             if self._sbtcommon.collectionsutil.is_empty(results):
#                 continue
#
#             sorted_results = sorted(results,
#                                     key=lambda k: k['timestamp'],
#                                     reverse=True)
#
#             current_price_date = sorted_results[0].get('date', '0000-00-00')
#             current_price = sorted_results[0]['values']['adj_close']
#
#             if current_price == 0:
#                 continue
#
#             if len(sorted_results) >= 5 and \
#                     sorted_results[4]['values']['adj_close'] > 0:
#                 five_day = sorted_results[4]['values']['adj_close']
#                 five_day_date = sorted_results[4].get('date', '0000-00-00')
#                 value = \
#                     (current_price - five_day) / five_day
#                 top_five_day_movers.append({
#                     "guid": p.get('sbt_company_id', p['guid']),
#                     "name": p["entity_name"],
#                     "symbol": p["symbol"],
#                     "exchange": p["exchange"],
#                     "exchange_currency": p["exchange_currency"],
#                     "timestamp": timestamp,
#                     "publications": self._get_formatted_publications(p),
#                     "current_price_date": current_price_date,
#                     "current_price": current_price,
#                     "previous_price_date": five_day_date,
#                     "previous_price": five_day,
#                     "change_value": value,
#                     "change_percentage": (value * 100)
#                 })
#
#             if len(sorted_results) >= 30 and \
#                     sorted_results[29]['values']['adj_close'] > 0:
#                 thirty_day = sorted_results[29]['values']['adj_close']
#                 thirty_day_date = sorted_results[29].get('date', '0000-00-00')
#                 value = \
#                     (current_price - thirty_day) / thirty_day
#                 top_thirty_day_movers.append({
#                     "guid": p.get('sbt_company_id', p['guid']),
#                     "name": p["entity_name"],
#                     "symbol": p["symbol"],
#                     "exchange": p["exchange"],
#                     "exchange_currency": p["exchange_currency"],
#                     "timestamp": timestamp,
#                     "current_price_date": current_price_date,
#                     "current_price": current_price,
#                     "publications": self._get_formatted_publications(p),
#                     "previous_price_date": thirty_day_date,
#                     "previous_day_price": thirty_day,
#                     "change_value": value,
#                     "change_percentage": (value * 100)
#                 })
#
#         sorted_top_five_day_movers = \
#             sorted(top_five_day_movers,
#                    key=lambda k: k['change_value'],
#                    reverse=True)
#
#         counter = 1
#         for five in sorted_top_five_day_movers:
#             five['rank'] = counter
#             counter = counter + 1
#
#         sorted_top_thirty_day_movers = \
#             sorted(top_thirty_day_movers,
#                    key=lambda k: k['change_value'],
#                    reverse=True)
#
#         counter = 1
#         for thirty in sorted_top_thirty_day_movers:
#             thirty['rank'] = counter
#             counter = counter + 1
#
#         cur_list = self._query_table(self._table_sbt_portfolio_list,
#                                      'list_name',
#                                      'FIVE_DAY_MOVERS',
#                                      range_name='date',
#                                      range_value=current_date)
#
#         if self._sbtcommon.collectionsutil.is_not_empty(cur_list):
#             self._logger.info('Lists are already loaded for : ' +
#                               current_date + ' deleting current lists')
#             self._delete(self._table_sbt_portfolio_list, 'list_name',
#                          'FIVE_DAY_MOVERS',
#                          range_name='date',
#                          range_value=current_date)
#             self._delete(self._table_sbt_portfolio_list, 'list_name',
#                          'THIRTY_DAY_MOVERS',
#                          range_name='date',
#                          range_value=current_date)
#
#         self._save(self._table_sbt_portfolio_list,
#                    {'list_name': 'FIVE_DAY_MOVERS',
#                     'date': current_date,
#                     'timestamp': timestamp,
#                     'values': sorted_top_five_day_movers})
#
#         self._save(self._table_sbt_portfolio_list,
#                    {'list_name': 'THIRTY_DAY_MOVERS',
#                     'date': current_date,
#                     'timestamp': timestamp,
#                     'values': sorted_top_thirty_day_movers})
#
#     def _load_portfolio_list_stock_previous_day(self):
#         list_names = ['NEWEST_RECOMMENDATIONS', 'CONVICTION_BUYS']
#
#         filters = list()
#         filters.append(
#             self._create_filter_expression('symbols', "exists", None))
#         filters.append(self._create_filter_expression('defaultCategory', "ne",
#                                                       'external_article'))
#         filter_exp = self._build_filter_expression(filters)
#         articles = self._scan_table('articles', filter_exp)
#
#         for list_name in list_names:
#
#             current_date = self._sbtcommon.dateutil.get_current_date_string()
#
#             recommendations = {}
#             for article in articles:
#                 if len(article['symbols']) == 0:
#                     continue
#
#                 # ST-2275: Skip if Newswire or Ten Stock Trader
#                 if list_name == 'NEWEST_RECOMMENDATIONS' \
#                         and (ArticleHelper.is_newswire(article)
#                              or ArticleHelper.has_publication_code(article,
#                                                                    'ttt')):
#                     continue
#
#                 art_timestamp = article.get('createdAt',
#                                             article.get('modifiedAt'))
#                 art_timestamp = self._convert_milli_timestamp_to_epoch(
#                     art_timestamp)
#
#                 self._populate_previous_day_list(
#                     article.get('wordpressId', None),
#                     article.get('publications', []),
#                     art_timestamp,
#                     self._get_previous_day_stock_price_filtered_list(list_name,
#                                                                      article),
#                     recommendations)
#
#             if len(recommendations) == 0:
#                 return
#
#             sorted_recommendations = sorted(list(recommendations.values()),
#                                             key=lambda k: k['timestamp'],
#                                             reverse=True)
#
#             sorted_recommendations = self._get_limited_sorted_recommendations(
#                 list_name, sorted_recommendations)
#
#             timestamp = 0
#             pattern = '%Y-%m-%d %H:%M:%S'
#             time_value = time.strptime(current_date + ' 00:00:00', pattern)
#             try:
#                 timestamp = int(time.mktime(time_value))
#             except:
#                 ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
#                                        tzinfo=datetime.timezone.utc)
#                 timestamp = (datetime.datetime(*time_value[:6],
#                                                tzinfo=datetime.timezone.utc) - ep).total_seconds()
#
#             record = {'list_name': list_name,
#                       'date': current_date, 'timestamp': timestamp,
#                       'values': sorted_recommendations}
#             self._save(self._table_sbt_portfolio_list, record)
#
#     def _convert_milli_timestamp_to_epoch(self, ts):
#         new_timestamp = ts
#         try:
#             new_timestamp = int(new_timestamp / 1000)
#         except Exception:
#             pass
#
#         return new_timestamp
#
#     def _get_formatted_publications(self,
#                                     symbol_exchange_mapping):
#         pubs = []
#
#         dups = set()
#         for port in symbol_exchange_mapping.get('sb_portfolio_mapping', []):
#             dup_string = port['pub_code'] + ':' + str(port['portfolio_id'])
#             if dup_string not in dups:
#                 dups.add(dup_string)
#                 pubs.append({'portfolio_id': port['portfolio_id'],
#                              'portfolio_name': port['portfolio_name'],
#                              'pub_code': port['pub_code'],
#                              'pub_title': port['pub_title'],
#                              'recommendation_date': port.get(
#                                  'recommendation_date',
#                                  '0000-00-00'),
#                              'reference_price': port.get('reference_price',
#                                                          0.00)})
#
#         return sorted(pubs, key=lambda k: k['portfolio_name'],
#                       reverse=False)
#
#     def _get_previous_day_formatted_publications(self,
#                                                  publications,
#                                                  symbol_mapping):
#         if not publications:
#             publications = []
#
#         pub_list = []
#         for p in publications:
#             p_code = p.get('publicationCode', 'N/A').upper()
#             if p_code in self._publication_lookup:
#                 pub_list.append(self._publication_lookup[p_code])
#
#         if not pub_list:
#             pub_list = self._get_formatted_publications(symbol_mapping)
#         else:
#             pub_list = sorted(pub_list, key=lambda k: k['portfolio_name'],
#                               reverse=False)
#
#         return pub_list
#
#     def _get_limited_sorted_recommendations(self, list_name,
#                                             sorted_recommendations):
#         limited = list(sorted_recommendations)
#
#         if list_name == 'CONVICTION_BUYS':
#             self._populate_previous_day_stock_price(sorted_recommendations)
#             sorted_recommendations = self._get_sorted_conviction_values(
#                 sorted_recommendations)
#             if len(sorted_recommendations) > 5:
#                 limited = sorted_recommendations[0:5]
#         elif len(sorted_recommendations) > 15:
#             limited = sorted_recommendations[0:15]
#             self._populate_previous_day_stock_price(limited)
#
#         return limited
#
#     def _get_stock_prices(self, symbols_exchange_mapping, timeframe):
#         results = []
#         table_mapping = \
#             self._mp_accessor.get_table_mapping(
#                 TableMappingGuid.US_COMPANY_STOCK_PRICE.value)
#
#         if 'snp_id' in symbols_exchange_mapping:
#             results = self._financial_accessor.query_stock_price(
#                 symbols_exchange_mapping['symbol'],
#                 timeframe,
#                 standardized_format=True,
#                 exchange=symbols_exchange_mapping['exchange'])
#         else:
#             results = self._mp_accessor.query_table_by_mapping(table_mapping,
#                                                                symbols_exchange_mapping[
#                                                                    'guid'],
#                                                                exchange=
#                                                                symbols_exchange_mapping[
#                                                                    'exchange'],
#                                                                range_name='timeframe',
#                                                                range_value=timeframe,
#                                                                vendor='intrinio')
#
#         return results
#
#     def _get_filtered_portfolio_list(self):
#         portfolios = \
#             self._mp_accessor.scan_symbol_exchange_mapping_for_sb_portfolios(
#                 True)
#
#         filtered_portfolios = {}
#         for p in portfolios:
#             guid = p.get('sbt_company_id', p['guid'])
#             if guid in filtered_portfolios:
#                 p_data = filtered_portfolios[guid]
#                 if p_data.get('exchange_country', '') != 'USA' and \
#                         p.get('exchange_country', '') == 'USA':
#                     filtered_portfolios[guid] = p
#             else:
#                 filtered_portfolios[guid] = p
#
#         return list(filtered_portfolios.values())
#
#     def _get_sorted_conviction_values(self, sorted_recommendations):
#         symbols = []
#         for c_value in sorted_recommendations:
#             symbols.append(c_value['symbol'])
#         changes = self._get_conviction_buys_percentage_change(symbols)
#
#         for c_value in sorted_recommendations:
#             if c_value['symbol'] in changes:
#                 c_value['change_value'] = changes[c_value['symbol']][
#                     'change_value']
#                 c_value['change_percentage'] = changes[c_value['symbol']][
#                     'change_percentage']
#             else:
#                 c_value['change_value'] = 0
#                 c_value['change_percentage'] = 0
#
#         final_sorted = sorted(sorted_recommendations,
#                               key=lambda k: k['stock_price'],
#                               reverse=True)
#
#         counter = 1
#         for fs in final_sorted:
#             fs['rank'] = counter
#             counter = counter + 1
#
#         return final_sorted
#
#     def _get_previous_day_stock_price_filtered_list(self, list_name, article):
#         filtered_list = []
#
#         filtered_results = None
#         if list_name == 'NEWEST_RECOMMENDATIONS':
#             filtered_results = filter(
#                 lambda x: x['analysis'] == 'recommended' and \
#                           x.get('closed', False) == False and \
#                           x.get('initiated', True) == True,
#                 article['symbols'])
#         elif list_name == 'CONVICTION_BUYS':
#             filtered_results = filter(lambda x: x['best_buy'],
#                                       article['symbols'])
#
#         if filtered_results is not None:
#             filtered_list = list(filtered_results)
#
#         return filtered_list
#
#     def _populate_previous_day_stock_price(self, stock_price_list):
#         if self._sbtcommon.collectionsutil.is_empty(stock_price_list):
#             return
#
#         counter = 1
#         for s_recom in stock_price_list:
#             s_recom['rank'] = counter
#             stock_price = 0.00
#
#             results = self._get_stock_prices(s_recom,
#                                              '1d')
#
#             if self._sbtcommon.collectionsutil.is_empty(results):
#                 continue
#
#             s_recom.pop('snp_id', None)
#
#             sorted_results = sorted(results, key=lambda k: k['timestamp'],
#                                     reverse=True)
#             temp_stock = sorted_results[0]
#             if 'values' in temp_stock and 'adj_close' in temp_stock['values']:
#                 stock_price = temp_stock['values']['adj_close']
#
#             s_recom['stock_price'] = stock_price
#             counter = counter + 1
#
#     def _populate_previous_day_list(self, word_press_id,
#                                     publications,
#                                     timestamp, filtered_results,
#                                     previous_day_list):
#         if self._sbtcommon.collectionsutil.is_empty(filtered_results):
#             return
#
#         for r in filtered_results:
#             symbol = r['symbol']
#             if symbol not in previous_day_list:
#                 rec_symbol = {}
#                 symbol_mapping = \
#                     self._mp_accessor.unique_stock_symbol_exchange_mapping(
#                         symbol)
#                 if symbol_mapping:
#                     rec_symbol['guid'] = symbol_mapping.get('sbt_company_id',
#                                                             symbol_mapping[
#                                                                 'guid'])
#                     rec_symbol['symbol'] = symbol_mapping['symbol']
#                     rec_symbol['exchange'] = symbol_mapping['exchange']
#                     rec_symbol['exchange_currency'] = symbol_mapping[
#                         'exchange_currency']
#                     rec_symbol['name'] = symbol_mapping['entity_name']
#                     rec_symbol['snp_id'] = symbol_mapping.get('snp_id', '')
#                     if word_press_id:
#                         rec_symbol['word_press_id'] = word_press_id
#                     rec_symbol['publications'] = \
#                         self._get_previous_day_formatted_publications(
#                             publications,
#                             symbol_mapping)
#                     rec_symbol['timestamp'] = timestamp
#                     previous_day_list[symbol] = rec_symbol
#             elif timestamp > previous_day_list[symbol]['timestamp']:
#                 previous_day_list[symbol]['timestamp'] = timestamp
#
#     def _load_top_performers(self):
#         current_date = self._sbtcommon.dateutil.get_current_date_string()
#
#         timestamp = 0
#         pattern = '%Y-%m-%d %H:%M:%S'
#         time_value = time.strptime(current_date + ' 00:00:00', pattern)
#         try:
#             timestamp = int(time.mktime(time_value))
#         except:
#             ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
#                                    tzinfo=datetime.timezone.utc)
#             timestamp = (datetime.datetime(*time_value[:6],
#                                            tzinfo=datetime.timezone.utc) - ep).total_seconds()
#
#         base_url = "https://publishers.tradesmith.com/webservices/TradeService.asmx/GetInnerTop10GainsByPortfolioIds"
#         guid = "Ex1mSRW2EkelrMyFZaSx1g"
#         ids = "3423,3101,3093,3098,3099,3100,3415,3095,3102,3090,3096"
#         url = base_url + "?guid=" + guid + "&portfolioIds=" + ids
#
#         try:
#             rval = None
#             req = self._sbtcommon._get_request(url, "GET", None, None, None)
#             if req.ok:
#                 rval = req.content.decode()
#
#             if rval is None:
#                 return
#
#             e = xml.etree.ElementTree.fromstring(rval)
#
#             data = e.findall(
#                 './/{http://tempuri.org/}Data//{http://tempuri.org/}ListDTO//{http://tempuri.org/}List//{http://tempuri.org/}InnerSpecialTradeView')
#             top_recommendations = {}
#
#             for child in data:
#                 symbol = child.find('{http://tempuri.org/}Symbol').text
#                 p_change = child.find('{http://tempuri.org/}PercentGain').text
#
#                 symbol_mapping = \
#                     self._mp_accessor.unique_stock_symbol_exchange_mapping(
#                         symbol)
#                 if symbol_mapping:
#                     v = float(p_change)
#                     if symbol in top_recommendations:
#                         if top_recommendations[symbol][
#                             'change_percentage'] < v:
#                             top_recommendations[symbol][
#                                 'change_percentage'] = v
#                             top_recommendations[symbol][
#                                 'change_value'] = round(v / 100, 4)
#                     else:
#                         top_recommendations[symbol] = {
#                             "guid": symbol_mapping.get("sbt_company_id",
#                                                        symbol_mapping["guid"]),
#                             "name": symbol_mapping["entity_name"],
#                             "symbol": symbol,
#                             "exchange": symbol_mapping["exchange"],
#                             "exchange_currency": symbol_mapping[
#                                 "exchange_currency"],
#                             "publications": self._get_formatted_publications(
#                                 symbol_mapping),
#                             "change_value": round(v / 100, 4),
#                             "change_percentage": v,
#                             "timestamp": timestamp
#                         }
#
#             sorted_recs = sorted(list(top_recommendations.values()),
#                                  key=lambda k: k['change_percentage'],
#                                  reverse=True)
#
#             record = {'list_name': "TOP_RECOMMENDATIONS",
#                       'date': current_date, 'timestamp': timestamp,
#                       'values': sorted_recs}
#             self._save(self._table_sbt_portfolio_list, record)
#         except Exception as e:
#             self._logger.error("Failed to load top performers : " + str(e))
#
#     def _get_conviction_buys_percentage_change(self, conviction_buys):
#         conviction_buys_results = []
#
#         data = self._get_portfolio_list_ids()
#
#         for list_id in data:
#             position_data = self._portfolio_api.get_position_local(list_id)
#             if position_data is None or not position_data.get('success',
#                                                               False) or \
#                     'position' not in position_data or \
#                     'data' not in position_data['position'] or \
#                     'positions' not in position_data['position']['data']:
#                 continue
#
#             for positions in position_data['position']['data']['positions']:
#                 self._append_to_conviction_buys_results(positions,
#                                                         conviction_buys,
#                                                         conviction_buys_results)
#
#         sorted_cv = sorted(conviction_buys_results,
#                            key=lambda k: k['change_value'], reverse=True)
#
#         final_list = {}
#         for v in sorted_cv:
#             if v['symbol'] not in final_list:
#                 final_list[v['symbol']] = v
#
#         return final_list
#
#     def _get_portfolio_list_ids(self):
#         ids = []
#
#         data = self._portfolio_api.get_all_portfolio_info()
#         if data and data.get('success', False):
#             for tab in data.get('tabinfo', []):
#                 if 'Id' in tab:
#                     ids.append(tab['Id'])
#
#         return ids
#
#     def _append_to_conviction_buys_results(self, positions,
#                                            conviction_buys,
#                                            conviction_buys_results):
#
#         for groups in positions.get('groupPositions', []):
#             symbol, change, change_percentage = \
#                 self._get_group_data(groups)
#
#             if symbol and symbol in conviction_buys:
#                 existing = \
#                     list(filter(lambda x: x['symbol'] == symbol,
#                                 conviction_buys_results))
#
#                 if existing:
#                     e_data = existing[0]
#                     if change > e_data['change_value']:
#                         e_data['change_value'] = change
#                         e_data['change_percentage'] = change_percentage
#                 else:
#                     conviction_buys_results.append(
#                         {"symbol": symbol,
#                          "change_value": change,
#                          "change_percentage": change_percentage})
#
#     def _get_group_data(self, groups):
#         symbol = None
#         change_percentage = 0
#         change = 0
#
#         columns = groups.get('columns', {})
#
#         if not columns:
#             return
#
#         datasets = []
#         option = 1
#         if 'symbolCusipCompany' in columns:
#             datasets = columns['symbolCusipCompany'].get('dataSets', [])
#             option = 2
#         elif 'tickerPositionDesc' in columns:
#             datasets = columns['tickerPositionDesc'].get('dataSets', [])
#
#         for desc in datasets:
#             if "Symbol" in desc:
#                 symbol = desc['Symbol']
#                 break
#
#         if option == 1 and \
#                 columns.get('return', {}).get('result', 0) != 0:
#             change_percentage = columns['return']['result']
#             change = change_percentage / 100
#         elif columns.get('gain', {}).get('result', 0) != 0:
#             change_percentage = columns['gain']['result']
#             change = change_percentage / 100
#
#         return symbol, change, change_percentage
#
#     def _populate_rank_and_dividends(self, portfolios):
#         if not portfolios:
#             return
#
#         counter = 1
#         for p in portfolios:
#             p['rank'] = counter
#             counter = counter + 1
#
#             data = self._financial_accessor.query_history_data(
#                 p['symbol'], 'cashdividendspershare',
#                 'q', 'desc', exchange=p['exchange'])
#
#             if data and data['data']:
#                 p['dividend'] = data['data'][0].get('value', 0)
#
#     def _get_epoch_timestamp(self, string_date_value):
#         timestamp = 0
#         pattern = '%Y-%m-%d %H:%M:%S'
#         time_value = time.strptime(string_date_value + ' 00:00:00', pattern)
#         try:
#             timestamp = int(time.mktime(time_value))
#         except:
#             ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
#                                    tzinfo=datetime.timezone.utc)
#             timestamp = (datetime.datetime(*time_value[:6],
#                                            tzinfo=datetime.timezone.utc) - ep).total_seconds()
#
#         return timestamp


class TimeseriesLoader(DynamoAccessor):
    """
      Used to load timeseries data in the data store.
    """

    def __init__(self, table_mapping,
                 symbol_mappings,
                 override_vendor_mapping=None,
                 vendor=None):
        """
          Constructor

          Args :
            table_mapping(TableMapping) : Table Mapping Object
            symbol_mappings(dict) : Symbol Exchange Mapping
            override_vendor_mapping(dict) : Overrides vendor mapping
            vendor(str) : Vendor key
        """

        super().__init__(aws_profile_name=None,
                         aws_region_name=None,
                         aws_end_point_url=None)

        if symbol_mappings is None:
            raise Exception('Symbol Mappings cannot be null.')

        if table_mapping is None:
            raise Exception('Table Mapping cannot be null.')

        if table_mapping.get_key_attribute() is None:
            raise Exception('Key Attribute is required.')

        if table_mapping.get_range_attribute() is None:
            raise Exception('Range Attribute is required.')

        if self._sbtcommon.collectionsutil.is_empty(
                table_mapping.get_value_attributes()):
            raise Exception('Value attributes cannot be empty.')

        self._table_mapping = table_mapping

        if self._sbtcommon.stringutil.is_empty(vendor):
            self._vendor = self._table_mapping.get_default_vendor()
        else:
            self._vendor = vendor

        self._vendor_mappings = None
        if self._vendor in table_mapping.get_vendor_mappings().keys():
            self._vendor_mappings = table_mapping.get_vendor_mappings()[
                self._vendor]

        if self._sbtcommon.collectionsutil.is_empty(self._vendor_mappings):
            raise Exception('Vendor Mappings cannot be empty.')

        if self._sbtcommon.collectionsutil.is_not_empty(
                override_vendor_mapping):
            self._vendor_mappings = override_vendor_mapping

        self._reload = False
        if 'reload' in self._vendor_mappings['load'].keys():
            self._reload = self._vendor_mappings['load']['reload']

        self._extraction_type = self._vendor_mappings['extraction']['type']
        self._load_type = self._vendor_mappings['load']['type']

        self._symbol_mappings = symbol_mappings
        self._standard_load = True
        self._standard_extraction = True
        self._extract_method = None
        self._extract_parameters = None
        self._extraction_class_instance = None
        if self._extraction_type.lower() != 'standard':
            self._standard_extraction = False
            extraction_module = self._vendor_mappings['extraction'][
                self._extraction_type]['module']
            extraction_class = self._vendor_mappings['extraction'][
                self._extraction_type]['class']
            self._extraction_method = self._vendor_mappings['extraction'][
                self._extraction_type]['method']
            self._extraction_parameters = self._vendor_mappings['extraction'][
                self._extraction_type]['parameters']
            module = importlib.import_module(extraction_module)
            my_class = getattr(module, extraction_class)
            self._extraction_class_instance = my_class()

    def load_data(self):
        """
          This method loads time series data for a specified vendor.
        """
        guids = []

        for s_mapping in self._symbol_mappings:
            extracted_data = None
            success = {}
            success['guid'] = s_mapping['guid']
            try:
                if self._standard_extraction:
                    extracted_data = self._standard_extraction(s_mapping)
                else:
                    extracted_data = self._non_standard_extraction(s_mapping)

                converted_data = self._get_converted_extract_data(s_mapping,
                                                                  extracted_data)

                if self._sbtcommon.collectionsutil.is_not_empty(
                        converted_data):
                    if self._standard_load:
                        self._standard_data_load(s_mapping, converted_data)
                    else:
                        self._non_standard_data_load(s_mapping, converted_data)

                success['success'] = True
            except Exception as e:
                success['success'] = False
                success['error'] = str(e)

            guids.append(success)

        return guids

    def _standard_data_load(self, s_mapping, data):
        """
          This method is called if the standard load process
          is used for a vendor.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping
            data(list) : Data to be loaded

        """
        load_data = []

        table_name = self._table_mapping.get_table_name()
        key_id = self._table_mapping.get_key_attribute().get_id()
        key_value = self._get_key_value(s_mapping)
        range_id = self._table_mapping.get_range_attribute().get_id()

        sorted_data = []
        if self._sbtcommon.collectionsutil.is_not_empty(data):
            sorted_data = sorted(data, key=lambda k: k[range_id], reverse=True)

        last_date = '0000-00-00'
        check_data = []

        if not self._reload:
            check_data = self._query_table(table_name,
                                           key_id,
                                           key_value)
        else:
            self._logger.info('Reloading data for guid : ' + key_id)

        if self._sbtcommon.collectionsutil.is_not_empty(check_data):
            sorted_check_data = sorted(check_data, key=lambda k: k[range_id],
                                       reverse=True)
            last_date = sorted_check_data[0][range_id]

        for d in sorted_data:
            if d[range_id] > last_date:
                load_data.append(d)
            else:
                break

        self._batch_save(self._table_mapping.get_table_name(), load_data)

    def _non_standard_data_load(self, data):
        """
          This method is called if code has been
          developed to load a vendors data.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping
        """
        self._logger.info('_non_standard_data_load data ' +
                          str(data))

        self._logger.error('Method is not implemented for Time Series data.')

    def _standard_extraction(self, s_mapping):
        """
          This method is called if the standard extraction process
          is used for a vendor.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            list : List of dictionaries derived from JSON
        """

        self._logger.info('_standard_extraction symbol exchange mapping ' +
                          str(s_mapping))

        self._logger.error('Method is not implemented for Time Series data.')
        return []

    def _non_standard_extraction(self, s_mapping):
        """
          This method is called if code has been
          developed to extract vendor data.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            list : List of dictionaries derived from JSON
        """
        return_data = []

        available_param = s_mapping.copy()

        method_params = self._create_parameters_dictionary(available_param,
                                                           self._extraction_parameters)
        self._logger.info(method_params)
        response = getattr(self._extraction_class_instance,
                           self._extraction_method)(**method_params)
        if self._sbtcommon.collectionsutil.is_not_empty(response):
            return_data = response

        return return_data

    def _get_converted_extract_data(self, s_mapping, extracted_data):
        """
          Converts all extracted values for a symbol exhange mapping into
          the time series format.

          Args :
            extracted_data(list) : Data extracted from a vendor
            s_mapping(dict) : Symbol exchange mapping

          Returns :
            (list) : Time Series Data
        """
        converted_data = []

        if self._sbtcommon.collectionsutil.is_not_empty(extracted_data):
            for e_data in extracted_data:
                ts_record = self._create_timeseries_record(s_mapping, e_data)
                if self._sbtcommon.collectionsutil.is_not_empty(ts_record):
                    converted_data.append(ts_record)

        return converted_data

    def _create_parameters_dictionary(self, parameter_values, parameter_def):
        """
          Creates a dictionary of the parameters to be past to a method

          Args :
            parameter_values(dict) : Dictionary of parameters that can be used
            parameter_def(list) : List of parameter definitions associated with
                                  method
        """
        params = OrderedDict()
        parameter_values_keys = parameter_values.keys()
        if self._sbtcommon.collectionsutil.is_not_empty(parameter_def):
            for param in parameter_def:
                action = param['action'].lower()
                value = param['value']
                if action == 'replace' and value in parameter_values_keys:
                    params[param['input']] = parameter_values[value]
                elif action == 'calculate':
                    params[param['input']] = \
                        self._get_parameter_calculated_value(param['input'],
                                                             param['type'],
                                                             param['value'])
                elif action == 'static':
                    params[param['input']] = value
                else:
                    raise Exception('Cannot map parameters')

        return params

    def _get_parameter_calculated_value(self, param, typ, value):
        """
          Performs a calculation on a parameter

          Args :
            param(str) : Parameter Name
            typ(str) : Parameter data type
            value : Value used in calculation

          Returns :
            (any) : Calculated Value
        """
        ret_value = None

        if param.endswith('_date') and \
                typ.lower() == 'string' and \
                (value.startswith('-') or value.startswith('+')):
            ret_value = self._sbtcommon.dateutil.get_relative_date(
                months=0, date_format='%Y%m%d', **{'days': int(value)})

        return ret_value

    def _create_timeseries_record(self, symbol_mapping, row_value):
        """
          Create a Time Series dictionary

          Args :
            symbol_mapping(dict) : Symbol Exchange Mapping
            row_value(dict) : Dictionary of values to be converted.

          Returns :
            (dict) : Time Series Dictionary
        """
        row = {}
        key_value = self._get_key_value(symbol_mapping)
        range_value = self._get_range_value(row_value)

        if self._sbtcommon.stringutil.is_empty(key_value) or \
                self._sbtcommon.stringutil.is_empty(range_value):
            return row

        row[self._table_mapping.get_key_attribute().get_id()] = key_value
        row[self._table_mapping.get_range_attribute().get_id()] = range_value

        computed_field = \
            self._table_mapping.get_range_attribute().get_computed_field()
        if self._sbtcommon.stringutil.is_not_empty(computed_field):
            row[computed_field] = \
                self._get_computed_value(computed_field,
                                         self._table_mapping.get_range_attribute(),
                                         range_value)

        values = {}

        for attr in self._table_mapping.get_value_attributes():
            values[attr.get_id()] = \
                self._get_value(attr.get_vendor_attribute_id(self._vendor),
                                attr.get_vendor_data_type(self._vendor),
                                row_value)

        row['values'] = values

        return row

    def _get_computed_value(self, computed_field, attr, value):
        """
          Generates a computed value for the field name.

          Args :
            computed_field(str) : Computed value id
            attr_type(str) : Data Type of the computed value
            value : Source value to compute the value

          Returns :
            (any) Computed Value
        """
        self._logger.debug('Attribute Name : ' + str(attr))
        computed_value = 'N/A'

        if computed_field == 'timestamp':
            pattern = '%Y-%m-%d %H:%M:%S'
            time_value = time.strptime(value + ' 00:00:00', pattern)
            try:
                computed_value = int(time.mktime(time_value))
            except:
                ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
                                       tzinfo=datetime.timezone.utc)
                computed_value = (datetime.datetime(*time_value[:6],
                                                    tzinfo=datetime.timezone.utc) - ep).total_seconds()

        return computed_value

    def _get_range_value(self, resp_dict):
        """
          Retrieves the range value from the response dictionary associated
          with the range key.

          Args :
            resp_dict(dict) : Dictionary containing value to be pulled

          Returns :
            (any) : Value
        """
        range_attr = self._table_mapping.get_range_attribute()
        return self._get_value(
            range_attr.get_vendor_attribute_id(
                self._vendor),
            range_attr.get_vendor_data_type(
                self._vendor),
            resp_dict)

    def _get_key_value(self, symbol_mapping):
        """
          Retrieves the key value from the response dictionary associated
          with the key.

          Args :
            resp_dict(dict) : Dictionary containing value to be pulled

          Returns :
            (any) : Value
        """
        key_attr = self._table_mapping.get_key_attribute()
        return symbol_mapping[key_attr.get_id().lower()]

    def _get_value(self, id_key, attr_type, resp_dict):
        """
          Retrieves the value from the response dictionary associated
          with the key.

          Args :
            id_key(str) : Identifies value to be pulled from Dictionary
            attr_type(str) : Data Type of the attribute
            resp_dict(dict) : Dictionary containing value to be pulled

          Returns :
            (any) : Value
        """
        value = None

        is_bigdec = self._is_attr_type_bigdecimal(attr_type)
        is_str = self._is_attr_type_string(attr_type)

        # Set default value for attribute type
        if is_bigdec:
            value = 0
        elif is_str:
            value = 'N/A'

        if self._sbtcommon.collectionsutil.is_not_empty(resp_dict) and \
                id_key in resp_dict.keys():
            value = resp_dict[id_key]

        return value

    def _is_attr_type_bigdecimal(self, attr_type):
        """
          Determines whether an attribute type is a big decimal

          Args :
            attr_type(str) : Attribute Type

          Returns :
            (bool) : True if the attribute type is a big decimal, otherwise false
        """
        return self._sbtcommon.stringutil.is_not_empty(attr_type) and \
               attr_type.upper() == 'BIGDECIMAL'

    def _is_attr_type_string(self, attr_type):
        """
          Determines whether an attribute type is a string

          Args :
            attr_type(str) : Attribute Type

          Returns :
            (bool) : True if the attribute type is a string, otherwise false
        """
        return self._sbtcommon.stringutil.is_not_empty(attr_type) and \
               attr_type.upper() == 'STRING'


class DataLoader:
    """
      Used to load data into the data store.
    """

    def __init__(self):
        """
          Constructor
        """
        self._mp_accessor = MappingAccessor()
        self._sbtcommon = SbtCommon()
        self._logger = self._sbtcommon.get_global_logger()
        self._calculate_sentiment = CalculateSentiment()

    def load_data(self):
        """
          Loads all mapping data into the appropriate datastore.
        """
        try:
            symbol_mappings_dict = {}
            symbol_mappings = self._mp_accessor.scan_symbol_exchange_mapping()

            for sm in symbol_mappings:
                if sm['guid'] not in symbol_mappings_dict.keys() and \
                        sm.get('primary', False):
                    symbol_mappings_dict[sm['guid']] = sm

            table_mappings = self._mp_accessor.get_table_mappings_requiring_data_laod()
            for table_mapping in table_mappings:
                data_load = self._get_table_mapping_data_load(table_mapping,
                                                              symbol_mappings_dict)

                if self._sbtcommon.collectionsutil.is_empty(data_load):
                    continue

                self._mp_accessor._batch_save(
                    self._mp_accessor.table_sbt_metadata_table_data_load,
                    data_load)

                for vdr in table_mapping.get_vendor_mappings().keys():
                    vendor_symbol_mappings = self._get_vendor_symbol_mappings(
                        data_load,
                        symbol_mappings_dict,
                        vdr)

                    if self._sbtcommon.collectionsutil.is_empty(
                            vendor_symbol_mappings):
                        continue

                    if table_mapping.is_timeseries_data_type():
                        tl = TimeseriesLoader(table_mapping,
                                              vendor_symbol_mappings,
                                              vendor=vdr)
                        processed_guids = tl.load_data()
                        self._set_vendor_timestamp(data_load, processed_guids,
                                                   vdr)

                self._set_data_load_process(data_load)
                self._mp_accessor._batch_save(
                    self._mp_accessor.table_sbt_metadata_table_data_load,
                    data_load)
            self._post_processing()

        except Exception as exc:
            self._logger.error('Failed to execute company load method ' +
                               'Exception: ' + str(exc) +
                               'Trace: ' + traceback.format_exc())

    def _post_processing(self):
        """
          Runs post processing tasks
        """
        self._calculate_sentiment.updates()

    def _set_data_load_process(self, data_load):
        """
          Sets the data load dictionary to indicate that it needs
          to be loaded into the system.

          Args :
            data_load(list) : List of data load dictionaries
        """
        for dl in data_load:
            process = False

            status_code = 0

            if 'vendor_mapping' in dl.keys():
                for v in dl['vendor_mapping']:
                    if dl['vendor_mapping'][v]['load_timestamp'] == \
                            '00-00-0000 00:00:00 GMT':
                        process = True
                        status_code = 1
                    elif dl['vendor_mapping'][v]['failed_to_load']:
                        status_code = 2

            dl['status_code'] = status_code

            if dl['process'] != process:
                dl['process'] = process

    def _set_vendor_timestamp(self, data_load, symbol_mapping_guids, vendor):
        """
          Sets the vendor timestamp after the load process is complete.
          Also, set the record in an error state if an error occurred.

          Args :
            data_load(list) : List of data load dictionaries
            symbol_mapping_guids(list) : List of dictionaries for processed symbols
            vendor(str) : Vendor Identifier
        """
        timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(
            datetime.datetime.utcnow())
        success_guids = [d['guid'] for d in list(filter(lambda x:
                                                        x['success'] == True,
                                                        symbol_mapping_guids))]

        failed_filter = list(filter(lambda x: x['success'] == False,
                                    symbol_mapping_guids))

        for dl in data_load:
            if 'vendor_mapping' not in dl.keys() or \
                    vendor not in dl['vendor_mapping'].keys() or \
                    dl['vendor_mapping'][vendor]['load_timestamp'] != \
                    '00-00-0000 00:00:00 GMT':
                continue

            failed = False
            failed_guid = []

            if dl['symbol_mapping_guid'] not in success_guids and \
                    len(failed_filter) > 0:
                failed_guid = list(
                    filter(lambda x: x['guid'] == dl['symbol_mapping_guid'],
                           failed_filter))

                failed = len(failed_guid) > 0

            if failed or dl['symbol_mapping_guid'] in success_guids:
                dl['vendor_mapping'][vendor]['load_timestamp'] = timestamp
                dl['vendor_mapping'][vendor]['failed_to_load'] = failed
                if failed:
                    dl['vendor_mapping'][vendor]['error_message'] = \
                        failed_guid[0]['error']

    def _get_vendor_symbol_mappings(self, data_load,
                                    symbol_mappings_dict,
                                    vendor):
        """
          Returns a list of symbols mappings based on the
          data load objects

          Args :
            data_load(list) : List of data load dictionaries
            symbol_mappings_dict(dict) : Dictionary of available symbol exch maps
            vendor(str) : Vendor ID

          Returns :
            (list) Symbol Exchange Mappings

        """
        symbol_mappings = []
        for dl in data_load:
            if 'vendor_mapping' in dl.keys() and \
                    vendor in dl['vendor_mapping'].keys() and \
                    dl['vendor_mapping'][vendor]['load_timestamp'] == \
                    '00-00-0000 00:00:00 GMT' and \
                    dl['symbol_mapping_guid'] in symbol_mappings_dict.keys():
                symbol_mappings.append(
                    symbol_mappings_dict[dl['symbol_mapping_guid']])

        return symbol_mappings

    def _get_table_mapping_data_load(self, table_mapping,
                                     symbol_mappings_dict):
        """
          Returns data load dictionaries associated with the table and symbol
          mappings

          Args :
            table_mapping(TableMapping) : Table Mapping Object
            symbol_mappings_dict(dict) : Dictionary of symbol exchange mappings

          Returns :
            (list) : List of Data Load Dictionaries
        """
        pull_date = self._sbtcommon.dateutil.get_current_date_string()
        vendors = table_mapping.get_vendor_mappings().keys()

        existing_data_load = self._mp_accessor._query_table(
            MappingAccessor.table_sbt_metadata_table_data_load,
            'table_mapping_guid', table_mapping.get_guid())

        ret_data = []
        existing_data_load_dict = {}
        for dl in existing_data_load:
            if dl['process']:
                ret_data.append(dl)
            existing_data_load_dict[dl['symbol_mapping_guid']] = dl

        if self._sbtcommon.collectionsutil.is_not_empty(ret_data):
            return ret_data

        processed_guids = []
        for symbol_mapping in list(symbol_mappings_dict.values()):
            if symbol_mapping['guid'] in processed_guids or \
                    'table_mapping' not in symbol_mapping.keys() or \
                    table_mapping.get_guid() not in symbol_mapping[
                'table_mapping']:
                continue

            data_load = \
                self._get_data_load(table_mapping, symbol_mapping,
                                    existing_data_load_dict, vendors,
                                    pull_date)

            if self._sbtcommon.collectionsutil.is_not_empty(data_load):
                ret_data.append(data_load)

            processed_guids.append(symbol_mapping['guid'])

        return ret_data

    def _get_data_load(self, table_mapping, symbol_mapping,
                       existing_data_load_dict,
                       vendors, pull_date):
        """
          Returns a populated data load object.

          Args :
            table_mapping(TableMapping) : Table Mapping Object
            symbol_mapping(dict) : Symbol Exchange Mapping
            existing_data_load_dict(dict) : Existing dataload objects
            vendors(list) : Vendor ID's
            pull_date(str) : Date indicating when the data was retrieved

          Returns :
            (dict)
        """
        load = None
        data_load = None
        if symbol_mapping['guid'] in existing_data_load_dict.keys():
            data_load = existing_data_load_dict[symbol_mapping['guid']]

        temp_load = None
        if self._sbtcommon.collectionsutil.is_not_empty(data_load):
            temp_load = data_load
        else:
            temp_load = {}
            temp_load['table_mapping_guid'] = table_mapping.get_guid()
            temp_load['symbol_mapping_guid'] = symbol_mapping['guid']

        temp_load['symbol'] = symbol_mapping['symbol']
        temp_load['table_name'] = table_mapping.get_name()

        if 'vendor_mapping' not in temp_load.keys():
            temp_load['vendor_mapping'] = {}

        process = False
        for v in vendors:
            if self._skip_processing(table_mapping, symbol_mapping, v):
                continue

            process = True
            if v not in temp_load['vendor_mapping'].keys():
                vendor_load = {}
                temp_load['vendor_mapping'][v] = vendor_load

            if 'error_message' in temp_load['vendor_mapping'][v].keys():
                temp_load['vendor_mapping'][v].pop('error_message')

            if 'failed_to_load' in temp_load['vendor_mapping'][v].keys():
                temp_load['vendor_mapping'][v].pop('failed_to_load')

            temp_load['vendor_mapping'][v]['table_name'] = \
                table_mapping.get_table_name(vendor=v)
            temp_load['vendor_mapping'][v]['load_timestamp'] = \
                '00-00-0000 00:00:00 GMT'
            temp_load['vendor_mapping'][v]['pull_date'] = pull_date

        if process:
            temp_load['process'] = process
            temp_load['status_code'] = 1
            load = temp_load

        return load

    def _skip_processing(self, table_mapping, symbol_mapping,
                         vend):
        """
          Checks to see if the symbol exchange mapping should be processed.

          Args :
            s_mapping(dict) : Symbol Exchange Mapping

          Returns :
            boolean : True to skip processing
        """
        skip_processing = False
        load_only_if_values_exists = False
        vendor_mappings = None

        if vend in table_mapping.get_vendor_mappings().keys():
            vendor_mappings = table_mapping.get_vendor_mappings()[vend]

        if self._sbtcommon.collectionsutil.is_empty(vendor_mappings) or \
                vendor_mappings.get('load', {}).get('type',
                                                    'thirdparty') == 'thirdparty':
            skip_processing = True
        elif 'only_if_values_exists' in vendor_mappings['load'].keys():
            load_only_if_values_exists = vendor_mappings['load'][
                'only_if_values_exists']

        # If guid is not valid for the symbol exchange mapping
        if not skip_processing and \
                ('table_mapping' not in symbol_mapping.keys() or \
                 table_mapping.get_guid() not in symbol_mapping[
                     'table_mapping']):
            skip_processing = True

        # If the _load_only_if_values_exists attribute is true load only if data
        # is already available for the mapping
        if not skip_processing and load_only_if_values_exists:
            check = self._mp_accessor._query_table(
                table_mapping.get_table_name(vendor=vend),
                table_mapping.get_key_attribute().get_id(),
                symbol_mapping['guid'])
            if self._sbtcommon.collectionsutil.is_empty(check):
                self._logger.info(symbol_mapping['symbol'] +
                                  ' has not been loaded into the table')
                skip_processing = True

        return skip_processing

    def _populate_symbol_exchange_mapping_table(self):
        snp_warehouse_accessor = SNPWarehouseAccessor()

        # only select
        primary_flag = 1

        # generate the query
        sql = """SELECT DISTINCT 
                    c.*, 
                    s.securityname, 
                    e.exchangesymbol, 
                    e.exchangename, 
                    t.tickersymbol,
                    tid.identifiervalue,
                    t.tradingitemid
                FROM
                    public.ciqcompany c
                    INNER JOIN public.ciqsecurity s 
                        ON s.companyid = c.companyid
                    INNER JOIN public.ciqsecuritysubtype sst 
                        ON sst.securitysubtypeid = s.securitysubtypeid 
                    INNER JOIN public.ciqsecuritytype ssts 
                        ON ssts.securitytypeid = sst.securitytypeid
                    INNER JOIN public.ciqtradingitem t 
                        ON s.securityid = t.securityid
                    INNER JOIN public.ciqexchange e 
                        ON e.exchangeid = t.exchangeid
                    INNER JOIN public.ciqtradingitemidentifier tid 
                        ON t.tradingitemid = tid.tradingitemid 
                WHERE c.companystatustypeid < {} 
                    AND c.companytypeid in ({}) 
                    AND t.tradingitemstatusid in ({}) 
                    AND ssts.securitygroupid in ({}) 
                    AND t.primaryflag = {}
                    AND s.securityenddate is null 
                    AND s.primaryflag = {} 
                    AND t.tickersymbol is not null
                    AND e.exchangeid in ({})""".format(
            snp_warehouse_accessor._filter_company_status_id,
            snp_warehouse_accessor._filter_company_type_id,
            snp_warehouse_accessor._filter_trading_item_status_id,
            snp_warehouse_accessor._filter_security_group_id,
            primary_flag,
            primary_flag,
            snp_warehouse_accessor._filter_exchange_id
        )
        # get data from S&P warehouse
        res = snp_warehouse_accessor._execute_query(sql, None)

        print("Done.")


class CBONDSImport:
    def import_incremental_data(self, days=7):
        CBondsDataLoad().load_incremental_data(days)


# if __name__ == "__main__":
#     dl = DataLoader()
#
#     dl._populate_symbol_exchange_mapping_table()
#
#     cl = CompanyLoader()
#     cl.load_data()

