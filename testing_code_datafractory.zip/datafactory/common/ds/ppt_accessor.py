import logging

from sbt_common import SbtGlobalCommon
from pg_accessor import PostgresAccessor


class PPTAccessor(PostgresAccessor):

  def __init__(self):
    """
    :param cfg:
    """
    self._sbtcommon = SbtGlobalCommon
    self.pgconfig   = self._sbtcommon.get_sbt_config()['postgres']['ppt']
    self._logger    = self._sbtcommon.get_logger(logging.DEBUG, __name__)
    super().__init__(self.pgconfig)

  def get_ppt_portfolio_email(self, pf_guid):
    try:
      ppt_email = ""

      if pf_guid:
        sql = "SELECT alert_emails as email" \
              "  FROM portfolio" \
              " WHERE guid = '" + pf_guid + "'"

        ppt_portfolio = self._execute_query(sql, 0)

        if ppt_portfolio:
          ppt_email = ppt_portfolio[0]['email']

      return ppt_email
    except Exception as e:
      self._logger.error('Error fetching ppt portfolio data:', e)
