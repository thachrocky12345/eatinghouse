import logging
from operator import itemgetter
from boto3.dynamodb.conditions import Key

import simplejson as json

from redis_manager import RedisManager
from dd_accessor import DynamoAccessor
from sbt_common import SbtGlobalCommon

redis_manager = RedisManager()
logger = SbtGlobalCommon.get_logger(logging.INFO, __name__)

class MarketNotesAccessor(DynamoAccessor):
  _table_name = "SBT_MARKET_NOTES"
  _secondary_index_name = "SBT_MARKET_NOTES_LATEST"

  def scan_and_update(self):
    market_notes = self._scan_table(self._table_name, None)

    if len(market_notes) == 0:
      return {}

    market_notes_sorted = sorted(market_notes, key=itemgetter('timestamp'), reverse=True)
    last_market_notes = market_notes_sorted[0]

    last_market_notes["isLatest"] = 1
    self._save(self._table_name, last_market_notes)

    return last_market_notes

  def clear_latest(self):
    table = self._dynamodb.Table(self._table_name)
    result = table.query(
      IndexName=self._secondary_index_name,
      KeyConditionExpression=Key("isLatest").eq(1),
    )

    for item in result["Items"]:
      del item["isLatest"]
      self._save(self._table_name, item)

  def save_market_notes(self, item):
    """
    Saves a market notes item to the DynamoDB table
    :param item: a market_note
    :return: the dict returned after insertion
    """

    self.clear_latest()

    item["isLatest"] = 1
    return self._save(self._table_name, item)

  def get_market_notes(self):
    """
    Retrieves Market Notes from Cache or DynamoDB table
    :return: the latest market note item
    """

    # Not found in cache find in main datastore
    table = self._dynamodb.Table(self._table_name)
    result = table.query(
      IndexName=self._secondary_index_name,
      KeyConditionExpression=Key("isLatest").eq(1),
      ScanIndexForward=False,
      Limit=1,
    )

    # If found save to cache then return
    if result["Count"] > 0:
        return result["Items"][0]
    else:
        return self.scan_and_update()


