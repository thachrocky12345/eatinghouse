from decimal import Decimal

from boto3.session import Session
from boto3.dynamodb.conditions import Attr, Key
from botocore.exceptions import ClientError
from operator import or_, and_
from functools import reduce
from sbt_common import SbtCommon

import re
import simplejson
import logging

class DynamoAccessor:
  """
    Super class that should be implemented by all objects accessing
    the Dynamo database.
  """

  def __init__(self, aws_profile_name=None, aws_region_name=None,
               aws_end_point_url=None):
    """
      Constructor
    """

    self._sbtcommon = SbtCommon()
    self._logger    = self._sbtcommon.get_logger(logging.CRITICAL, __name__)
    self._env = self._sbtcommon.get_sbt_config_env()

    ### Configure logging for boto3/botocore
    #logconf         = self._sbtcommon.get_cfg_env_var('logging')
    #logdir          = logconf['logdir']
    #self._logstream = open(logdir + '/boto3.log', 'a')
    #self._sbtcommon.get_logger(logging.INFO, 'boto3', self._logstream)
    #self._sbtcommon.get_logger(logging.DEBUG, 'botocore', self._logstream)
    #boto3.set_stream_logger(name='boto3', level=logging.INFO) # Turn on high-level logging:
    #boto3.set_stream_logger(name='botocore')                 # Turn on low-level and wire logging:

    self._aws_profile_name = aws_profile_name
    self._aws_region_name  = aws_region_name
    self._sbt_config       = self._sbtcommon.get_sbt_config()

    if self._sbtcommon.stringutil.is_empty(aws_region_name) and \
            'aws' in self._sbt_config and 'region' in self._sbt_config['aws']:
      self._aws_region_name = self._sbt_config['aws']['region']

    if self._sbtcommon.stringutil.is_empty(aws_profile_name) and \
            'aws' in self._sbt_config and 'profile' in self._sbt_config['aws']:
      self._aws_profile_name = self._sbt_config['aws']['profile']

    self._aws_end_point_url = aws_end_point_url
    self._init_dynamo_db()
    self._load_table_dictionary()

  def __exit__(self, exception_type, exception_value, traceback):
    """
    Just for closing the boto log file

    :param exception_type:
    :param exception_value:
    :param traceback:
    :return:
    """
    print("DynamoAccessor exiting...close log file")
    #self._logstream.close()

  def _init_dynamo_db(self):
    """
      Initialize DynamoDB connection
    """
    self._dynamodb = None

    if self._sbtcommon.stringutil.is_not_empty(self._aws_profile_name):
      self._logger.debug('Using AWS profile' + self._aws_profile_name)
      self._session = Session(profile_name=self._aws_profile_name)
    else:
      self._logger.debug('Using default AWS profile')
      self._session = Session()

    db_endpoint_url = ''
    if self._sbtcommon.stringutil.is_not_empty(self._aws_end_point_url):
      self._dynamodb = self._session.resource('dynamodb',
                                              region_name=self._aws_region_name,
                                              endpoint_url=db_endpoint_url)
    else:
      self._dynamodb = self._session.resource('dynamodb',
                                              region_name=self._aws_region_name)

  def _load_table_dictionary(self):
    self._table_dict = {}
    self._tables = list(self._dynamodb.tables.all())
    for table in self._tables:
      self._table_dict[table.table_name] = table

  def _table_exists(self, tablename):
    self._logger.debug("Check for existence of table : " + tablename)
    return tablename in self._table_dict.keys()

  def _make_table(self, table_name, hashk, rangek=None, **kwargs):
    if self._sbtcommon.collectionsutil.key_exists(table_name, self._table_dict):
      self._logger.debug('Table ' + table_name + ' already exists.')
      return

    hashk_type = 'S'
    rangek_type = 'S'
    table_read = 5
    table_write = 10
    index_name = 'GUIdx'
    index_read = 1
    index_write = 1

    if 'hashk_type' in kwargs.keys():
      hashk_type = kwargs['hashk_type']
    if 'rangek_type' in kwargs.keys():
      rangek_type = kwargs['rangek_type']
    if 'table_read' in kwargs.keys():
      table_read = kwargs['table_read']
    if 'table_write' in kwargs.keys():
      table_write = kwargs['table_write']
    if 'index_name' in kwargs.keys():
      index_name = kwargs['index_name']
    if 'index_read' in kwargs.keys():
      index_read = kwargs['index_read']
    if 'index_write' in kwargs.keys():
      index_write = kwargs['index_write']

    if hashk is None or len(hashk) == 0:
      raise Exception('hashk can not be empty')

    if rangek is None or len(rangek) == 0:
      keys = [
        {
          'AttributeName': hashk,
          'KeyType': 'HASH'
        }
      ]
      atts = [
        {'AttributeName': hashk, 'AttributeType': hashk_type}
      ]
      gidx = [
        {'IndexName': index_name,
         'KeySchema': [
           {
             'AttributeName': hashk,
             'KeyType': 'HASH'
           }
         ],
         'Projection': {'ProjectionType': 'KEYS_ONLY'},
         'ProvisionedThroughput': {
           'ReadCapacityUnits': index_read,
           'WriteCapacityUnits': index_write
         }
         }
      ]
    else:
      keys = [
        {
          'AttributeName': hashk,
          'KeyType': 'HASH'
        },
        {
          'AttributeName': rangek,
          'KeyType': 'RANGE'
        }
      ]
      atts = [
        {'AttributeName': hashk, 'AttributeType': hashk_type},
        {'AttributeName': rangek, 'AttributeType': rangek_type}
      ]
      gidx = [
        {'IndexName': index_name,
         'KeySchema': [
           {
             'AttributeName': hashk,
             'KeyType': 'HASH'
           }
         ],
         'Projection': {'ProjectionType': 'KEYS_ONLY'},
         'ProvisionedThroughput': {
           'ReadCapacityUnits': index_read,
           'WriteCapacityUnits': index_write
         }
         }
      ]

    try:
      # Check that table name meets dynamo's 3 char minimum.
      # Append the last char if not. Then create the table.
      table = self._dynamodb.create_table(
              TableName=table_name,
              KeySchema=keys,
              AttributeDefinitions=atts,
              GlobalSecondaryIndexes=gidx,
              ProvisionedThroughput={
                'ReadCapacityUnits': table_read,
                'WriteCapacityUnits': table_write
              }
      )
      table.wait_until_exists()
      self._load_table_dictionary()
      self._logger.debug('Table created ' + table.name)
    except ClientError as e:
      self._logger.debug("Unexpected error: %s" % e)
      raise Exception('Failed to create new table.')

  def _get_environment_table_name (self, table_name, env=None):
    """
      Returns Dynamo table name adjusted for environment.

      Args :
        table_name(str)  : Name of the table in Dynamo
        env(str) : Environment Name

      Returns :
        str : Dynamo table name based on environment
    """

    env = self._env if not env else env
    env = 'dev' if env == 'local' else env

    final_name = table_name

    if self._table_exists(env.upper() + '_' + table_name):
      final_name = env.upper() + '_' + table_name

    return final_name

  def _get_table(self, table_name):
    """
      Returns the Dynamo Boto3 table object associated with the string
      name

      Args :
        table_name(str)  : Name of the table in Dynamo

      Returns :
        table : Dynamo table object from Boto3
    """
    table = None

    if self._sbtcommon.stringutil.is_not_empty(table_name) \
            and table_name in self._table_dict.keys():
      table = self._table_dict[table_name]

    return table

  def _copy_data (self, from_table, to_table,
                  rows_at_time=0, limit=0):
    """
      Copies all data from one table to another table.
    """
    from_values = self._scan_table(from_table, None)

    rows = []
    counter = 1
    if rows_at_time > 0 :
      for from_value in from_values :
        rows.append(from_value)
        if len(rows) >= rows_at_time :
          self._batch_save(to_table, rows)
          rows.clear()

        if limit > 0 and limit >= counter :
          break

        counter = counter + 1
    else :
      rows = from_values

    self._batch_save(to_table, rows)

  def _unique_item (self, table_name, key_name, key_value,
                    range_name = None, range_value=None,
                    index_name=None):
    """
      Returns the list of data associated with the feed id and
      symbol

      Args :
        table_name (str)     : Database table name
        key_name (str)       : Key Name on Table
        key_value (*)        : Key value to query on
        range_name (str)     : Range Name on Table
        range_value (*)      : Range value to query on
        index_name (str)     : Name on index to use

      Returns :
        dict : returns a unique item from Dynamo or None if none exists
    """
    ret_value = self._query_table(table_name, key_name, key_value, range_name,
                                  range_value, index_name)

    if len(ret_value) ==  1 :
      return ret_value[0]
    else :
      return None

  def _query_table(self, table_name, key_name, key_value, range_name=None,
                   range_value=None, index_name=None):
    """
      Returns the list of data associated with the feed id and
      symbol

      Args :
        table_name (str)     : Database table name
        key_name (str)       : Key Name on Table
        key_value (*)        : Key value to query on
        range_name (str)     : Range Name on Table
        range_value (*)      : Range value to query on
        index_name (str)     : Name on index to use

      Returns :
        list : List of dictionaries representing the data in the table
    """
    response = []

    kargs = {}

    if self._sbtcommon.stringutil.is_not_empty(index_name) :
      kargs['index_name'] = index_name

    response_dict = self._query_table_response(table_name, key_name,
                                               key_value, range_name,
                                               range_value, **kargs)

    if response_dict is not None and 'Items' in response_dict.keys():
      response = response_dict['Items']

    lek = None
    if response_dict is not None and \
    'LastEvaluatedKey' in response_dict.keys():
      lek = response_dict['LastEvaluatedKey']

    while lek is not None:
      kargs['lek'] = lek
      response_dict = self._query_table_response(table_name, key_name,
                                           key_value, range_name,
                                           range_value, **kargs)

      if response_dict is not None and 'Items' in response_dict.keys():
        response.extend(response_dict['Items'])

      if response_dict is not None and \
      'LastEvaluatedKey' in response_dict.keys():
        lek = response_dict['LastEvaluatedKey']
      else :
        lek = None

    return response

  def _scrolling_scan_table (self, table_name, filter_exp,
                             last_evaluated_key=None):
    """
      Returns the list of data associated with the filter expression and
      the last evaluation key.

      Args :
        table_name (str)         : Database table name
        filter_exp (condition)   : Dynamo Boto3 Filter Expression
        last_evaluated_key (str) : Last key evaulated by scan

      Returns :
        dict : Dictionary contain the results of scan and the last
               evaluation key
    """
    return_data = {}
    items = []
    lek = None

    table = self._get_table(table_name)

    if table is not None:
      response = self._get_scan_response(table, filter_exp, last_evaluated_key)

      if 'Items' in response.keys():
        items = response['Items']

      if 'LastEvaluatedKey' in response.keys():
        lek = response['LastEvaluatedKey']

    return_data['items'] = items
    return_data['last_evaluated_key'] = lek

    return return_data

  def _create_filter_expression (self, field_name, operator,
                                 value, condition='and'):
    """
      Creates a filter expression to be used by the build_filter_expression
      method

      Args :
        field_name(str)  : Table Attribute Name
        operator(str)    : Operators (eq, ne, gt, lt, lte, gte, exists)
        value(str)       : Field Value
        condition(str)   : Condition 'and' or 'or'
    """
    filt_exp = {}
    filt_exp ['field_name'] = field_name
    filt_exp ['operator'] = operator
    filt_exp ['condition'] = condition
    filt_exp ['value'] = value

    return filt_exp

  def _build_filter_expression (self, filter_expressions):
    """
      Build a DynamoDB filter condition based on the list of conditions
      that are passed in.

      Args :
        filter_expressions(list) : List of dictionaries used to build filter

      Returns
        filter_expression : DynamoDB filter expression
    """
    filter_exp = None

    if not filter_expressions :
      return filter_exp

    for f in filter_expressions :
      operator = f ['operator']
      condition = f ['condition']
      if operator == 'eq' or  operator == '==':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).eq(f['value']),
                                         condition)
      elif operator == 'gte' or  operator == '>=' or  operator == '=>':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).gte(f['value']),
                                         condition)
      elif operator == 'lte' or  operator == '<=' or  operator == '=<':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).lte(f['value']),
                                         condition)
      elif operator == 'gt' or  operator == '>':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).gt(f['value']),
                                         condition)
      elif operator == 'lt' or  operator == '<':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).lt(f['value']),
                                         condition)
      elif operator == 'ne' or  operator == '<>' or  operator == '!=':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).ne(f['value']),
                                         condition)
      elif operator == 'begins_with' or  operator == 'starts_with':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).begins_with(f['value']),
                                         condition)
      elif operator == 'contains' or operator == 'in' :
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).contains(f['value']),
                                         condition)
      elif operator == 'exists':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).exists(),
                                         condition)
      elif operator == 'notexists':
        filter_exp = self._append_filter(filter_exp,
                                         Attr(f['field_name']).not_exists(),
                                         condition)

    return filter_exp

  def _append_filter (self, filter_expression, filter_attr, condition):
    """
      Append filter attribute to the filter expression that is passed in to
      cerate a new filter expression.

      Args :
        filter_expression(filter_expression) : Existing filter condition
        filter_attr(Attr)                    : Attribute to be appended
        condition                            : Condition 'and' or 'or'

      Returns
        filter_expression : DynamoDB filter expression
    """
    new_filter_expression = None
    if filter_expression is not None :
      if condition.upper() == 'AND' or condition.upper() == '&' \
              or condition.upper() == '&&' :
        new_filter_expression = filter_expression & filter_attr
      else :
        new_filter_expression = filter_expression | filter_attr
    else :
      new_filter_expression = filter_attr

    return new_filter_expression

  """
      Returns the list of data associated with the filter expression

      Args :
        table_name (str)         : Database table name
        filter_list (list)       : List of filter expression create by
        _create_filter_expression

      Returns :
        list : List of dictionaries representing the data in the table
    """
  def _scan_table_with_filter_list(self, table_name, filter_list):

    filter_exp = self._build_filter_expression(filter_list)
    return self._scan_table(table_name, filter_exp)

  def _scan_table_with_filter_str(self, table_name, filter_str, coerce=False):
    """
    Returns the list of data associated with the filter string.
    It creates the filter expression and run the scan;
    An alternative to _scan_table_with_filter_list.
    This works with all defined Dynamo's Attr listed below:
        eq, lt, lte, gt, gte, ne,
        is_in, exists, not_exists,
        begins_with, contains

    :param table_name (str): The DynamoDB table to be scanned.
    :param filter_string (str): A literal string with the fields, values and
    conditions to be used in the scan.
      For example:
        filter_str = 'mic contains XNYS OR composite_figi_ticker'
    :return (list of dicts): A list of dicts representing the data.
    """
    # split the filter string into filters
    filter_list0 = re.split('(OR)|(AND)', filter_str)
    # remove None items and leading/trailing spaces around each filter string
    filter_list0 = [x.strip() for x in filter_list0 if x is not None]
    # remove conditional operator
    filter_list = [x for x in filter_list0 if (x != 'OR') and (x != 'AND')]
    # get the fields for each filter
    field_list = [re.split(' |\.', x)[0] for x in filter_list]
    # get the conditions for each filter
    cond_list = [re.split(' |\.', x)[1] for x in filter_list]
    # get the values for each filter
    try:
      value_list = [re.split(' |\.', x)[2] for x in filter_list]
      value_list = [Decimal(x) for x in value_list] if coerce else value_list
      two = False
    except IndexError:
      two = True

    # get the conditional operator for the filters
    if not set([x for x in filter_list0 if x == 'OR' or x == 'AND']):
      op = ''
    else:
      op = set([x for x in filter_list0 if x == 'OR' or x == 'AND']).pop()
    # create the Dynamo filter attributes
    attr_list = [getattr(Attr, operator.lower()) for operator in cond_list]
    # create filter expression for each filter
    if not two:
      filter_expression = [attr(Attr(field), value) for
                           attr, field, value in
                           zip(attr_list, field_list, value_list)]
    else:
      filter_expression = [attr(Attr(field)) for
                           attr, field in
                           zip(attr_list, field_list)]
    # create a Dynamo filter expression object
    fe = reduce(or_, filter_expression) if op == 'OR' else \
      reduce(and_, filter_expression)
    # call method to scan table
    scan_results = self._scan_table(table_name, fe)
    return scan_results

  def _scan_table(self, table_name, filter_exp, index_name=None):
    """
      Returns the list of data associated with the filter expression

      Args :
        table_name (str)         : Database table name
        filter_exp (condition)   : Dynamo Boto3 Filter Expression
        index_name (str)     : Name on index to use

      Returns :
        list : List of dictionaries representing the data in the table
    """
    return_data = []
    lek = None

    table = self._get_table(table_name)

    if table is not None:
      response = self._get_scan_response(table, filter_exp, None, index_name)

      if 'Items' in response.keys():
        return_data.extend(response['Items'])

      if 'LastEvaluatedKey' in response.keys():
        lek = response['LastEvaluatedKey']

      while lek is not None:
        response = self._get_scan_response(table, filter_exp, lek, index_name)

        if 'Items' in response.keys():
          return_data.extend(response['Items'])

        if 'LastEvaluatedKey' in response.keys():
          lek = response['LastEvaluatedKey']
        else:
          lek = None

    return return_data

  def _delete(self, table_name, key_name, key_value, range_name=None,
              range_value=None, **kwargs):
    """
      Removed data from specified DynamoDB table.

      Args :
        table_name (str)   : Dynamo table name
        key_name (str)     : Key name
        key_value (*)      : Key value
        range_name (str)   : Range name
        range_value (*)    : Range value
    """
    response_dict = {}
    table = self._dynamodb.Table(table_name)
    if self._sbtcommon.stringutil.is_not_empty(key_name) and \
            key_value is not None and table is not None:
      if self._sbtcommon.stringutil.is_not_empty(key_value) and \
              range_name is not None:
        key_dict = {key_name: key_value, range_name: range_value}
      else:
        key_dict = {key_name: key_value}

      if key_dict is not None:
        response_dict = table.delete_item(Key=key_dict, **kwargs)

    return response_dict

  def _batch_save(self, table_name, data, overwrite_keys=None):
    """
      Saves a list of data into the specified DynamoDB table.

      Args :
        table_name (str)     :  Dynamo table name
        data (list)          :  List of data to be placed in the table
        overwrite_keys(list) :  List containing the partition key and sort key.

    """
    # If parameters do not support transaction exit method.
    if self._sbtcommon.stringutil.is_empty(table_name) or \
    data is None or len(data) == 0:
      return

    table = self._dynamodb.Table(table_name)
    if overwrite_keys is not None and len(overwrite_keys) > 0:
      with table.batch_writer(overwrite_by_pkeys=overwrite_keys) as batch:
        self._process_batch(batch, data)
    else:
      with table.batch_writer() as batch:
        self._process_batch(batch, data)

  def _save(self, table_name, data, **kwargs):
    """
      Saves a list of data into the specified DynamoDB table.

      Args :
        table_name (str) : Dynamo table name
        data (dict)      : Data to be placed in the specified table

    """
    rval = None
    table = self._dynamodb.Table(table_name)
    item = simplejson.dumps(data)

    # Size of item in KB
    ilen = len(item.encode('utf-8')) / 1000

    self._logger.debug("Save Item ...")
    self._logger.debug(item)

    # Max size of a single dynamo record 400KB
    if ilen > 400:
      self._logger.error('Cannot insert item size ' + str(ilen) + 'KB > 400KB: ')
    else:
      rval = table.put_item(Item=simplejson.loads(item, use_decimal=True), **kwargs)

    return rval

  def _update(self, table_name, attributes_to_update, attribute_values, key, expression_attribute_names):
    """
      Updates a list of corresponding attributes and values into the specified DynamoDB table.

      Args :
        table_name (str)            : Dynamo table name
        attributes_to_update (list) : Attributes to be placed in the specified table; max of 26 at a time
        attribute_values (list)     : Values to be updated (should coincide with indexes of their respective attributes)
        key                         : the item to be updated
        expression_attribute_names(dict): {'#service_name': service_name} define the attribute names with correct syntax

    """

    table = self._dynamodb.Table(table_name)
    self._logger.info("Update Item ...")
    self._logger.info(key)
    update_expression = 'set '
    attr_vals = {}
    count = 0

    if len(attributes_to_update) > 1:
      for k in expression_attribute_names.keys():
        update_expression += k + ' = :' + chr(count + 97) + ', '
        attr_vals[':' + chr(count + 97)] = attribute_values[count]
        count += 1
    else:
      update_expression += next(iter(expression_attribute_names)) + ' = :a'
      attr_vals[':a'] = attribute_values[0]
    update_expression = update_expression.strip(', ')
    return table.update_item(Key=key, UpdateExpression=update_expression,
                             ExpressionAttributeNames=expression_attribute_names, ExpressionAttributeValues=attr_vals)


  def _query_table_response (self,
                   table_name, key_name, key_value,
                   range_name=None, range_value=None,
                   **kargs):
    """
      Returns the list of data associated with the feed id and
      symbol

      Args :
        table_name (str)     : Database table name
        key_name (str)       : Key Name on Table
        key_value (*)        : Key value to query on
        range_name (str)     : Range Name on Table
        range_value (*)      : Range value to query on
        index_name (str)     : Name on index to use
        lek (dict)           : Last Evaluated Key

      Returns :
        list : List of dictionaries representing the data in the table
    """
    index_name = None
    if 'index_name' in kargs :
      index_name = kargs['index_name']

    sort_desc = False
    if 'sort_desc' in kargs and kargs['sort_desc'] :
      sort_desc = True

    lek = None
    if 'lek' in kargs :
      lek = kargs['lek']

    response_dict = None
    table = self._get_table(table_name)

    self._logger.debug("Querying Dynamo Table: " + table_name + ". With Key: " +
                      key_name + " and key_value: " + str(key_value))

    if self._sbtcommon.stringutil.is_empty(key_name) or \
    key_value is None or table is None :
      return response_dict

    kargs={}

    if self._sbtcommon.stringutil.is_not_empty(key_value) and \
            range_name is not None:
      self._logger.debug("Querying with range key: " + range_name +
                        " and range_value: " + range_value)
      kargs['KeyConditionExpression'] = Key(key_name).eq(key_value) & \
                                          Key(range_name).eq(range_value)
    else:
      kargs['KeyConditionExpression'] = Key(key_name).eq(key_value)

    if self._sbtcommon.stringutil.is_not_empty(index_name) :
      kargs['IndexName'] = index_name
    else :
      kargs['ConsistentRead'] = True

    if self._sbtcommon.collectionsutil.is_not_empty(lek) :
      kargs['ExclusiveStartKey'] = lek

    if sort_desc :
      kargs['ScanIndexForward'] = False

    response_dict = table.query(**kargs)

    return response_dict

  def _get_scan_response(self, table, filter_exp, lek, index_name=None):
    kargs = {}
    if filter_exp is not None :
      kargs['FilterExpression'] = filter_exp

    if lek is not None :
      kargs['ExclusiveStartKey'] = lek

    if self._sbtcommon.stringutil.is_not_empty(index_name) :
      kargs['IndexName'] = index_name

    return table.scan(**kargs)


  def _get_query_response_with_limit(self, table_name, key_exp,filter_exp, limit=10, index_name=None):
    kargs = {}
    table = self._get_table(table_name)

    kargs['ScanIndexForward'] = False

    if key_exp is not None :
      kargs['KeyConditionExpression'] = key_exp

    if filter_exp is not None :
      kargs['FilterExpression'] = filter_exp

    if limit is not None :
      kargs['Limit'] = limit

    if self._sbtcommon.stringutil.is_not_empty(index_name) :
      kargs['IndexName'] = index_name

    return table.query(**kargs)

  def _process_batch (self, batch, data):
    """
      Process a batch save

      Args :
        batch(batch) : Batch Object
        data (collection) : Data to be saved.
    """
    conv_data = data
    if isinstance(data, dict):
      conv_data = list(data.values())
    number_of_items = len(conv_data)
    count = 0
    for row in conv_data:
      item = simplejson.dumps(row)
      self._logger.debug("Save Batch Item ...")
      self._logger.debug(item)
      batch.put_item(Item=simplejson.loads(item, use_decimal=True))
      count += 1
      if count % 100 == 0:
        self._logger.debug("Processed {0} of {1} items".format
                          (count, number_of_items))

  def articles_json(self, dynamodb_json):
      article_json = []
      for data in dynamodb_json:
          article = {
              'source': data['source'],
              'id': data['uuid'],
              'createdAt': data['created_at'],
              'modifiedAt': data['updated_at'],
              'external_id': data['external_id'],
              'publishedAt': data['published_at']
          }

          if 'title' in data.keys():
              article['title'] = data['title']

          if 'description' in data.keys():
              article['excerpt'] = data['description']

          if 'ticker' in data.keys():
              article['ticker'] = data['ticker']

          if 'author' in data.keys():
              article['author'] = data['author']

          if 'content' in data.keys():
              article['content'] = data['content']

          if 'article_url' in data.keys():
              article['url'] = data['article_url']

          if 'authors' in data.keys():
              article['authors'] = data['authors']

          if 'tickers' in data.keys():
              article['tickers'] = data['tickers']

          if 'channels' in data.keys():
              article['channels'] = data['channels']

          article_json.append(article)
      return article_json
