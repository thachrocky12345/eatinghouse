import time

import pymongo
import urllib
import logging
from sbt_common import SbtCommon


class MongoAccessor:

    def __init__(self, collection_name):
        """
        Constructor
        """

        self._sbtcommon = SbtCommon()
        self._logger = self._sbtcommon.get_logger(logging.CRITICAL, __name__)
        self._env = self._sbtcommon.get_sbt_config_env()
        self._sbt_config = self._sbtcommon.get_sbt_config()
        self._collection_name = collection_name

        if 'mongodb' in self._sbt_config and 'host' in self._sbt_config['mongodb'] and \
                'username' in self._sbt_config['mongodb'] and \
                'password' in self._sbt_config['mongodb']:

            mongo_user = urllib.parse.quote_plus(self._sbt_config['mongodb']['username'])
            mongo_password = urllib.parse.quote_plus(self._sbt_config['mongodb']['password'])

            self._connection_url = self._sbt_config['mongodb']['host'].format(username=mongo_user, password=mongo_password)

        if 'database' in self._sbt_config['mongodb']:
            self._database = self._sbt_config['mongodb']['database']

        self._client = pymongo.MongoClient(self._connection_url)
        self._selected_database = self._client[self._database]
        self._selected_collection = self._selected_database[self._collection_name]

    def _insert_data(self, data, many=False):
        if many:
            return self._selected_collection.insert_many(data)
        else:
            return self._selected_collection.insert_one(data)

    def find(self, condition, **kwargs):
        return self._selected_collection.find(condition, **kwargs)

    def find_one(self, condition, **kwargs):
        return self._selected_collection.find_one(condition, **kwargs)
        
    def delete_many(self, condition):
      return self._selected_collection.delete_many(condition)

    def find_one_sort(self, condition, sort_fields, **kwargs):
        return self._selected_collection.find(condition).sort(sort_fields).limit(1)

    def _replace_data(self, replace_to, replace_with, upsert=False):
        return self._selected_collection.replace_one(replace_to, replace_with, upsert)

    def watch_collection(self, on_change_lambda):
        with self._selected_collection.watch() as stream:
            while stream.alive:
                change = stream.try_next()
                # Note that the ChangeStream's resume token may be updated
                # even when no changes are returned.
                # print("Current resume token: %r" % (stream.resume_token,))
                if change is not None:
                    print("Change document: %r" % (change,))
                    on_change_lambda(change)
                    continue
                # We end up here when there are no recent changes.
                # Sleep for a while before trying again to avoid flooding
                # the server with getMore requests when no changes are
                # available.
                time.sleep(1)



class MongoObject:
    @classmethod
    def _collection_name(cls):
        return ".".join([cls.__module__, cls.__name__])

    @classmethod
    def accessor(cls):
        if not hasattr(cls, "_accessor"):
            cls._accessor = MongoAccessor(cls._collection_name())

        return cls._accessor

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def generate_id(self):
        raise NotImplementedError

    def save(self):
        data = {k: v for k, v in self.__dict__.items()}
        if "id" not in data:
            data["id"] = self.generate_id()
            setattr(self, "id", data["id"])

        self.accessor()._replace_data({"id": data["id"]}, data, upsert=True)

    @classmethod
    def _obj_from_dict(cls, data):
        obj = cls()
        for k, v in data.items():
            if k != "_id":
                setattr(obj, k, v)

        return obj

    @classmethod
    def get(cls, id):
        obj = cls()
        condition = {"id": id}

        data = cls.accessor().find_one(condition)
        if data:
            return cls._obj_from_dict(data)

    @classmethod
    def find(cls, *args, **kwargs):
        return cls.accessor().find(*args, **kwargs)

    @classmethod
    def filter(cls, *args, **kwargs):
        for row in cls.find(*args, **kwargs):
            yield cls._obj_from_dict(row)
