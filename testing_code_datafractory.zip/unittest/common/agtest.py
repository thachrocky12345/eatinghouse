import sys


from sbt_common import SbtGlobalCommon

logger = SbtGlobalCommon.get_global_logger()

def main():
  """
  Main configures the user profile manager and starts running a server

  :return:
  """
  print("INFO: main starting up...")
  common = SbtGlobalCommon
  print("env: " + common.get_sbt_config_env())
  print("res: " + str(common.get_api_resources()))
  print('urt: ' + str(common.get_api_routes('user')))

  logger.info("INFO: main exiting")
  sys.exit(0)

if __name__ == '__main__':
  main()
