from common.sbt_redis.redis_manager import RedisManager
import unittest


class TestRedisManagerConnection(unittest.TestCase):

  _manager = None

  @classmethod
  def setUpClass(cls):
    cls._manager = RedisManager(host='34.192.203.126', port=6379)

  @classmethod
  def tearDownClass(cls):
    cls._manager.disconnect()

  def test_ping_connection_is_ative(self):
    self.assertEqual(self._manager.ping(), True)


if __name__ == '__main__':
  unittest.main()
