from common.sbt_redis.redis_manager import RedisManager
import unittest
import time


class TestRedisManagerPubSub(unittest.TestCase):

  _manager = None
  _pubsub = None

  @classmethod
  def setUpClass(cls):
    cls._manager = RedisManager(host='34.192.203.126', port=6379)
    cls._pubsub = cls._manager.pubsub()
    cls._pubsub.subscribe('test')

  @classmethod
  def tearDownClass(cls):
    cls._manager.disconnect()

  def test_pubsub_publish(self):
    test_message = 'TEST'
    self._manager.publish(channel='test', message=test_message)
    while True:
      message = self._pubsub.get_message()

      if message:
        self.assertEqual(message['data'].decode(), test_message)
        return

      time.sleep(1)
