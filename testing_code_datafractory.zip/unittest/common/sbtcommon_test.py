import unittest
import logging
from sbt_common import SbtCommon

"""
  Unit tests for SbtCommon 
"""
class SbtCommonTest (unittest.TestCase):
    logger = SbtCommon().get_logger(logging.INFO, 'SbtCommonTest')

    """
      Called on class setup.
      
      Args :
          cls (class) : Current class
    """
    @classmethod
    def setUpClass(cls):
      SbtCommonTest.logger.info('Unit Testing the SbtCommon Class')
    
    """
      Test the is_empty method in the StringUtil inner class
    """  
    def test_string_util_is_empty(self):
      sbtcommon = SbtCommon()
      self.logger.info('SbtCommon.StringUtil.is_empty unit tests') 
      su = sbtcommon.stringutil
      self.assertTrue(su.is_empty(''), 
                      'An empty string should evaluate to True')
      self.assertTrue(su.is_empty(None), 'None should evaluate to True')

    """
      Test the is_not_empty method in the StringUtil inner class
    """ 
    def test_string_util_is_not_empty(self):
      sbtcommon = SbtCommon()
      self.logger.info('SbtCommon.StringUtil.is_not_empty unit tests') 
      su = sbtcommon.stringutil
      self.assertFalse(su.is_not_empty(''), 
                       'An empty string should evaluate to False')
      self.assertFalse(su.is_not_empty(None), 'None should evaluate to False')

if __name__ == '__main__':
    unittest.main()
