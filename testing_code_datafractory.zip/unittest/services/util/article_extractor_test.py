import unittest
from article_utils import ArticleExtractor, ArticleHelper


def mock_article(article_type='newsletter'):
    article = {'wordpressId': 400000,
               'type': 'post',
               'title': 'test title',
               'slug': 'Test slug',
               'base_type': 'newsletter',
               'sub_types': ['newsletter'],
               'excerpt': 'fdsfds',
               'status': 'publish',
               'content': 'content',
               'canonicalUrl': 'https://stansberryresearch.com/articles/wednesday-morning-market-preview-113',
               'contentText': 'content',
               'categories': ['newsletters_monthly'],
               'defaultCategory': 'newsletters_monthly',
               'analysts': ['porter-stansberry'],
               'defaultAnalyst': 'porter-stansberry',
               'symbols': [{'symbol': 'AAPL',
                            'analysis': 'recommended',
                            'top_recommended': False,
                            'best_buy': False,
                            'initiated': False,
                            'closed': False}],
               'publications': [{'publicationCode': 'psi'}],
               'defaultPublication': {'publicationCode': 'psi'},
               'tickers': ['AAPL'],
               'tickersText': 'AAPL',
               'createdAt': 1530800991000,
               'modifiedAt': 1530800991000}
    if article_type == 'newswire':
        article['base_type'] = 'newswire'
        article['sub_types'] = ['newswire']
        article['categories'] = ['newswire']
        article['defaultCategory'] = 'newswire'
        article['analysts'] = ['scott-garliss']
        article['defaultAnalyst'] = 'scott-garliss'
        article['publications'] = [{'publicationCode': 'new', 'level': 100}]
        article['defaultPublication'] = {'publicationCode': 'new', 'level': 100}

    return article


def get_mock_publication():
    return {'publicationCode': '',
            'level': 100}


class ArticleExtractorTest(unittest.TestCase):

    def setUp(self):
        self.article = mock_article()

    # should_save
    def test_should_save(self):
        self.article = mock_article('newsletter')
        a = ArticleExtractor.extract_daily_market_notes(self.article)
        print(a)
        # self.assertEqualFalse, False)

    def test_should_save_with_trash(self):
        self.article = mock_article('newsletter')
        self.article['status'] = 'trash'
        self.assertEqual(ArticleHelper.should_save(self.article), False)

    def test_should_save_with_draft(self):
        self.article = mock_article('newsletter')
        self.article['status'] = 'draft'
        self.assertEqual(ArticleHelper.should_save(self.article), False)
