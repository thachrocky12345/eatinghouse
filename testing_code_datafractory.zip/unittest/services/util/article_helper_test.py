import unittest
import time
from article_utils import ArticleHelper


def invalid_article_stream_date(format='ms'):
    article_date = int(round(time.time()))
    if format == 'ms':
        article_date = article_date * 1000 - 359200000
    return article_date - 359200


def mock_article(article_type='newsletter'):
    article = {'wordpressId': 400000,
               'type': 'post',
               'title': 'test title',
               'slug': 'Test slug',
               'base_type': 'newsletter',
               'sub_types': ['newsletter'],
               'excerpt': 'fdsfds',
               'status': 'publish',
               'content': 'content',
               'canonicalUrl': 'https://stansberryresearch.com/articles/wednesday-morning-market-preview-113',
               'contentText': 'content',
               'categories': ['newsletters_monthly'],
               'defaultCategory': 'newsletters_monthly',
               'analysts': ['porter-stansberry'],
               'defaultAnalyst': 'porter-stansberry',
               'symbols': [{'symbol': 'AAPL',
                            'analysis': 'recommended',
                            'top_recommended': False,
                            'best_buy': False,
                            'initiated': False,
                            'closed': False}],
               'publications': [{'publicationCode': 'psi'}],
               'defaultPublication': {'publicationCode': 'psi'},
               'tickers': ['AAPL'],
               'tickersText': 'AAPL',
               'createdAt': int(round(time.time())),
               'modifiedAt': int(round(time.time()))}
    if article_type == 'newswire':
        article['base_type'] = 'newswire'
        article['sub_types'] = ['newswire']
        article['categories'] = ['newswire']
        article['defaultCategory'] = 'newswire'
        article['analysts'] = ['scott-garliss']
        article['defaultAnalyst'] = 'scott-garliss'
        article['publications'] = [{'publicationCode': 'new', 'level': 100}]
        article['defaultPublication'] = {'publicationCode': 'new', 'level': 100}

    return article


def get_mock_publication():
    return {'publicationCode': '',
            'level': 100}


class ArticleHelperTest(unittest.TestCase):

    def setUp(self):
        self.article = mock_article()

    # should_save
    def test_should_save(self):
        self.article = mock_article('newsletter')
        self.article['status'] = 'publish'
        self.assertEqual(ArticleHelper.should_save(self.article), True)

    def test_should_save_with_trash(self):
        self.article = mock_article('newsletter')
        self.article['status'] = 'trash'
        self.assertEqual(ArticleHelper.should_save(self.article), False)

    def test_should_save_with_draft(self):
        self.article = mock_article('newsletter')
        self.article['status'] = 'draft'
        self.assertEqual(ArticleHelper.should_save(self.article), False)

    # should_stream
    def test_should_stream_with_newswire(self):
        self.article = mock_article('newswire')
        print(self.article)
        self.assertEqual(ArticleHelper.should_stream(self.article), True)

    def test_should_stream_with_newsletter(self):
        self.article = mock_article('newsletter')
        self.assertEqual(ArticleHelper.should_stream(self.article), True)

    # should_stream with created date older than 3 days
    def test_should_not_stream_older_articles_milliseconds(self):
        self.article = mock_article('newsletter')
        self.article['createdAt'] = invalid_article_stream_date()
        self.assertEqual(ArticleHelper.should_stream(self.article), False)

    def test_should_not_stream_older_articles_seconds(self):
        self.article = mock_article('newsletter')
        self.article['createdAt'] = invalid_article_stream_date('s')
        self.assertEqual(ArticleHelper.should_stream(self.article), False)

    # should_stream_by_channel
    def test_should_stream_by_channel_newswire(self):
        self.article = mock_article('newswire')
        self.assertEqual(ArticleHelper.should_stream_by_channel(self.article, 'newswire'), True)
        self.assertEqual(ArticleHelper.should_stream_by_channel(self.article, 'newsletter'), False)

    def test_should_stream_by_channel_newsletter(self):
        self.article = mock_article('newsletter')
        self.assertEqual(ArticleHelper.should_stream_by_channel(self.article, 'newswire'), False)
        self.assertEqual(ArticleHelper.should_stream_by_channel(self.article, 'newsletter'), True)

    def test_should_stream_by_channel_newsletter_stansberry_content(self):
        self.article = mock_article('newsletter')
        self.assertEqual(ArticleHelper.should_stream_by_channel(self.article, 'stansberry-content'), True)

    def test_should_stream_by_channel_newswire_stansberry_content(self):
        self.article = mock_article('newswire')
        self.assertEqual(ArticleHelper.should_stream_by_channel(self.article, 'stansberry-content'), True)

    # get_base_type
    def test_get_base_type_newsletter(self):
        self.article = mock_article('newsletter')
        self.assertEqual(ArticleHelper.get_base_type(self.article), 'newsletter')

    def test_get_base_type_newswire(self):
        self.article = mock_article('newswire')
        self.assertEqual(ArticleHelper.get_base_type(self.article), 'newswire')

    def test_get_base_type_with_invalid_category(self):
        self.article['categories'] = ['invalid']
        self.assertEqual(ArticleHelper.get_base_type(self.article), 'unknown')

    # TODO: Steve: Write tests for get_sub_types
    # get_sub_types
    # def get_sub_types(self):
    #   pass

    # is_article
    def test_is_article_post(self):
        self.article = mock_article('newsletter')
        self.article['type'] = 'post'
        self.assertEqual(ArticleHelper.is_article(self.article), True)

    def test_is_article_page(self):
        self.article = mock_article('newsletter')
        self.article['type'] = 'daily_page'
        self.assertEqual(ArticleHelper.is_article(self.article), False)

    def test_is_article_daily_wealth(self):
        self.article = mock_article('newsletter')
        self.article['type'] = 'daily_wealth'
        self.assertEqual(ArticleHelper.is_article(self.article), True)

    # is_newswire
    def test_is_newswire(self):
        self.article = mock_article('newswire')
        self.assertEqual(ArticleHelper.is_newswire(self.article), True)

    def test_is_newswire_missing_category(self):
        self.article = mock_article('newswire')
        self.article['categories'] = ['updates']
        self.assertEqual(ArticleHelper.is_newswire(self.article), False)
  
    def test_is_newswire_missing_pubcode(self):
        publication = get_mock_publication()
        publication['publicationCode'] = 'psi'
        self.article['publications'] = [publication]
        self.article['categories'] = ['newswire']
        self.assertEqual(ArticleHelper.is_newswire(self.article), False)

    # is_newsletter
    def test_is_newsletter(self):
        publication = get_mock_publication()
        publication['publicationCode'] = 'psi'
        self.article['publications'] = [publication]
        self.article['categories'] = ['newsletters_daily']
        self.assertEqual(ArticleHelper.is_newsletter(self.article), True)

    def test_is_newsletter_missing_valid_category(self):
        self.article = mock_article('newsletter')
        self.article['categories'] = ['newswire']
        self.assertEqual(ArticleHelper.is_newsletter(self.article), False)

    # has_publication_code
    def test_has_publication_code(self):
        self.article = mock_article('newsletter')
        publication = get_mock_publication()
        publication['publicationCode'] = 'ttt'
        self.article['publications'] = [publication]
        self.assertEqual(ArticleHelper.has_publication_code(self.article, 'ttt'), True)
        self.assertEqual(ArticleHelper.has_publication_code(self.article, 'new'), False)

    def test_has_publication_code_invalid(self):
        self.article = mock_article('newsletter')
        self.assertEqual(ArticleHelper.has_publication_code(self.article, 'psia'), False)

    # article_categories
    def test_article_categories_returns_tuple(self):
        self.assertTrue(isinstance(ArticleHelper.article_categories(), tuple))

    # newswire_categories
    def test_newswire_categories_returns_tuple(self):
        self.assertTrue(isinstance(ArticleHelper.newswire_categories(), tuple))

    # newsletter_categories
    def test_newsletter_categories_returns_tuple(self):
        self.assertTrue(isinstance(ArticleHelper.newsletter_categories(), tuple))
