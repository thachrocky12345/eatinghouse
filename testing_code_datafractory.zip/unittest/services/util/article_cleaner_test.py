import unittest
from article_utils import ArticleCleaner


def mock_article(article_type='newsletter'):
    article = {'wordpressId': 400000,
               'type': 'post',
               'title': 'test title',
               'slug': 'Test slug',
               'base_type': 'newsletter',
               'sub_types': ['newsletter'],
               'excerpt': 'fdsfds',
               'canonicalUrl': 'http://stansberryresearch.com',
               'status': 'publish',
               'content': 'content',
               'contentText': 'content',
               'categories': ['newsletters_monthly'],
               'defaultCategory': 'newsletters_monthly',
               'analysts': ['porter-stansberry'],
               'defaultAnalyst': 'porter-stansberry',
               'symbols': [{'symbol': 'AAPL',
                            'analysis': 'recommended',
                            'top_recommended': False,
                            'best_buy': False,
                            'initiated': False,
                            'closed': False}],
               'publications': [{'publicationCode': 'psi'}],
               'defaultPublication': {'publicationCode': 'psi'},
               'tickers': ['AAPL'],
               'tickersText': 'AAPL',
               'createdAt': 1530800991000,
               'modifiedAt': 1530800991000}
    if article_type == 'newswire':
        article['base_type'] = 'newswire'
        article['sub_types'] = ['newswire']
        article['categories'] = ['newswire']
        article['defaultCategory'] = 'newswire'
        article['analysts'] = ['scott-garliss']
        article['defaultAnalyst'] = 'scott-garliss'
        article['publications'] = [{'publicationCode': 'new', 'level': 100}]
        article['defaultPublication'] = {'publicationCode': 'new',
                                         'level': 100}

    return article


def get_mock_publication():
    return {'publicationCode': '',
            'level': 100}


def clean_helper(article):
    new_article = ArticleCleaner(article)
    new_article.clean()
    return new_article


def modify_and_clean(article, field, value):
    article[field] = value
    return clean_helper(article)


def get_mock_symbol():
    return {'symbol': 'AAPL',
            'analysis': 'recommended',
            'top_recommended': False,
            'best_buy': False}


class ArticleCleanerTest(unittest.TestCase):

    def setUp(self):
        self.article = mock_article()

    # Given a valid article, ArticleCleaner
    # Should give a valid response with no logged errors
    def test_basic_valid_article(self):
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)
        self.assertEqual(len(new_article.errors), 0)

    def test_basic_invalid_article(self):
        self.article['title'] = None
        new_article = ArticleCleaner(self.article)
        new_article.clean()
        self.assertEqual(new_article.valid, False)

    # Given an article missing a require field, ArticleCleaner
    # Should return an invalid response
    def test_missing_title_field(self):
        self.article.pop('title', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)

    def test_missing_type_field(self):
        self.article.pop('type', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)

    def test_missing_status_field(self):
        self.article.pop('status', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)

    def test_missing_content_field(self):
        self.article.pop('content', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)

    def test_missing_content_text_field(self):
        self.article.pop('contentText', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)

    def test_bad_canonical_url_field(self):
        self.article['canonicalUrl'] = 1
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)

    # Given an article missing a non-required field, ArticleCleaner
    # Should try to add a default value
    def test_missing_slug_field(self):
        self.article.pop('slug', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)

    def test_missing_excerpt_field(self):
        self.article.pop('excerpt', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)

    def test_missing_publication_code_field(self):
        self.article['defaultPublication'].pop('level', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)

    def test_missing_tickers_field(self):
        self.article.pop('tickers', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)

    def test_missing_tickers_text_field(self):
        self.article.pop('tickersText', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)

    # Given an empty list that is required, ArticleCleaner
    # Should fail the validation and log the error
    def test_empty_categories_list(self):
        new_article = modify_and_clean(self.article, 'categories', [])
        self.assertEqual(new_article.valid, True)
        self.assertEqual(len(new_article.errors), 0)

    def test_empty_analysts_list(self):
        new_article = modify_and_clean(self.article, 'analysts', [])
        self.assertEqual(new_article.valid, True)
        self.assertEqual(len(new_article.errors), 0)

    def test_empty_publications_list(self):
        new_article = modify_and_clean(self.article, 'publications', [])
        self.assertEqual(new_article.valid, False)
        self.assertEqual(len(new_article.errors), 1)

    # Given an invalid symbols item thathas no default, ArticleCleaner
    # Should fail the validation and log the error
    def test_invalid_analysis_in_symbol(self):
        self.article['symbols'] = [get_mock_symbol()]
        self.article['symbols'][0].pop('analysis', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)
        self.assertEqual(len(new_article.errors), 1)

    def test_invalid_symbol_in_symbol(self):
        self.article['symbols'] = [get_mock_symbol()]
        self.article['symbols'][0].pop('symbol', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, False)
        self.assertEqual(len(new_article.errors), 1)

    # Given an invalid symbols list item, ArticleCleaner
    # Should try to save the boolean value
    def test_invalid_symbol_in_symbol_one(self):
        self.article['symbols'] = [get_mock_symbol()]
        self.article['symbols'][0].pop('top_recommended', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)
        self.assertEqual(len(new_article.errors), 0)

    def test_invalid_symbol_in_symbol_two(self):
        self.article['symbols'] = [get_mock_symbol()]
        self.article['symbols'][0].pop('best_buy', None)
        new_article = clean_helper(self.article)
        self.assertEqual(new_article.valid, True)
        self.assertEqual(len(new_article.errors), 0)

    # Regression for Web team sending tests
    # Given a list is mistakenly sent as a boolean, ArticleCleaner
    # Should convert the value to an empty list and log a warning
    def test_missing_categories_list(self):
        new_article = modify_and_clean(self.article, 'categories', False)
        self.assertEqual(new_article.valid, True)
        self.assertEqual(len(new_article.errors), 0)
        self.assertEqual(len(new_article.warnings), 1)

    def test_missing_analysts_list(self):
        new_article = modify_and_clean(self.article, 'analysts', False)
        self.assertEqual(new_article.valid, True)
        self.assertEqual(len(new_article.errors), 0)
        self.assertEqual(len(new_article.warnings), 1)

    def test_missing_publications_list(self):
        new_article = modify_and_clean(self.article, 'publications', False)
        self.assertEqual(new_article.valid, False)
        self.assertEqual(len(new_article.errors), 1)
        self.assertEqual(len(new_article.warnings), 1)


if __name__ == '__main__':
    unittest.main()
