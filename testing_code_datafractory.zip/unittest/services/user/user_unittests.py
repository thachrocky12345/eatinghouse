import unittest
import sys
import collections

from sbt_common import SbtGlobalCommon

routes = {}
ROUTE  = 0
METHOD = 1
res    = 'user'  # api gateway resource
env    = None
email  = 'test@stansberryresearch.com'
apikey = None

screener_test_name = "Test 1" #TODO: Handle screener names with ws

profile = \
  {
    "name": "Jonh Wick",
    "email": email,
    "passwd": "d2VsY29tZQ==",
    "snaid": "SAC000578279737",
    "sungard_login": "test",
    "sungard_group": "STANSBERRY",
    "sungard_pwd": "welcome",
    "tradestop_user": "apitest3@tradestops.com",
    "tradestop_pwd": "FJaMLT9NBw",
    "modified": "1511316310",
    "symsel": "VMW",
    "pagesel": "dashboard",
    "chat_id": "test@stansberryresearch.com",
    "guid": "",
    "dashboard": [
      {
        "type": "generic-media",
        "label": "Media",
        "height": 14,
        "width": 4,
        "min_height": 1,
        "min_width": 4,
        "xpos": 0,
        "ypos": 0,
        "data": {
          "defaultSymbol": "GOOG"
        },
        "wlist": []
      },
      {
        "type": "stock-chart",
        "label": "Stock Chart",
        "height": 9,
        "width": 8,
        "min_height": 1,
        "min_width": 4,
        "xpos": 4,
        "ypos": 5,
        "data": {
          "identifier": "GOOG",
          "period": 2,
          "scale": 4
        },
        "wlist": []
      },
      {
        "type": "market-watch",
        "label": "Market Watch",
        "height": 5,
        "width": 8,
        "min_height": 1,
        "min_width": 4,
        "xpos": 4,
        "ypos": 0,
        "data": {
          "default-list": ""
        },
        "wlist": [
          {
            "name": "Default List",
            "symbols": "AAPL,CVS,GOOG,VMW"
          },
          {
            "name": "Test",
            "symbols": "IBM,FB"
          }
        ]
      },
      {
        "type": "market-overview",
        "label": "overview",
        "data": {
          "expanded": False,
          "selections": [
            "S&P",
            "NASDAQ",
            "GOLD",
            "OIL"
          ]
        }
      },
      {
        "label": "Time Series",
        "data": {
          "defaultSymbol": "HYOAS"
        },
        "xpos": 4,
        "ypos": 26,
        "height": 10,
        "width": 8,
        "min_height": 1,
        "min_width": 4,
        "type": "time-series-chart"
      }
    ],
    "crypto": {
      "navsel": "btc",
      "data": {
        "cursel": {
          "btc": "eur",
          "dash": "usd",
          "eth": "gbp",
          "zec": "cad",
          "bch": "gbp"
        }
      }
    },
    "summary": {
      "navsel": "insider metrics",
      "fundsel": "income",
      "period": "annual"
    },
    "model": {
      "navsel": "efficiency model",
      "period": "quarterly",
      "data": {
        "screeners": [
        {
          "email": email,
          "name": "ScreenerA",
          "filters": [
            {
              "field": "pricetoearnings",
              "operator": "gte",
              "value": "10"
            },
            {
              "field": "dividendyield",
              "operator": "gte",
              "value": "0.01"
            }
          ]
        },
        {
          "email": email,
          "name": "ScreenerB",
          "filters": [
            {
              "field": "pricetoearnings",
              "operator": "gte",
              "value": "100"
            },
            {
              "field": "dividendyield",
              "operator": "gte",
              "value": "0.01"
            }
          ]
        }]
      },
      "valsel": "assumptions"
    },
    "portfolio": {
      "navsel": "",
      "tradestops": {},
      "sbrportfolios": {},
      "sbrrecommends": {}
    },
    "research": {
      "navsel": "sbrportfolios",
      "tradestops": {},
      "sbrportfolios": {
        "selection": "Capital Portfolio"
      },
      "sbrrecommends": {
        "selection": "Stansberry Gold & Silver Investor"
      }
    }
  }

auth = {
  "email": email,
  "passwd": "d2VsY29tZQ=="
}

uauth = {
  "email": email,
  "cpwd": "d2VsY29tZQ==",
  "npwd": "aGVsbG93b3JsZA=="
}

logout = {"email": email}

xapikey = SbtGlobalCommon.get_api_token_value()

headers = {
  'Content-type': 'application/json',
  'Accept': 'text/plain',
  'X-Api-Key': xapikey
}

uprofile = None

class UserUnitTests(unittest.TestCase):
  """

  """
  rlist = SbtGlobalCommon.get_api_routes(res)
  orderedtest = collections.OrderedDict()
  root = '/' + res

  test_order_list = [
    'all',
    'create',
    'delete',
    'create',
    'login',
    'screener_create',
    'screener_get',
    'screener_update',
    'screener_delete',
    'profile',
    'update',
    'update',
    'entitlements',
    'list',
    'active',
    'dashboard',
    'stat',
    'tscontext',
    'logout',
    'login',
    'logout',
    'bad_credentials',
    'login',
    'bad_update',
    'profile',
    'delete',
  ]

  for r in rlist: # set routes
    n = len(r[ROUTE])
    i = r[ROUTE].rindex(root) + len(root)
    k = r[ROUTE][i + 1:n]
    routes[k] = r[ROUTE], r[METHOD]
    print('ROUTE: ' + k + ' PATH: ' + r[ROUTE] + ' METHOD: ' + r[METHOD])

  @staticmethod
  def _get_route(r):
    """

    :param r:
    :return:
    """
    rval = None

    if r in routes:
      rval = routes[r][ROUTE]

    return rval

  @staticmethod
  def _get_method(r):
    """

    :param r:
    :return:
    """
    rval = None

    if r in routes:
      rval = routes[r][METHOD]

    return rval

  @staticmethod
  def _update_headers():
    h = headers.copy()
    global apikey
    if apikey:
      h['ApiKey'] = apikey
    return h

  def all(self):
    print("Retrieving all users...")
    route = self._get_route('all')
    method = self._get_method('all')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def create(self):
    print("Adding user...")
    route = self._get_route('create')
    method = self._get_method('create')
    resp = SbtGlobalCommon.makerequest(route, method, profile, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def delete(self):
    print("Deleting user...")
    route = self._get_route('delete')
    method = self._get_method('delete')
    resp = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def login(self):
    print("Logging in...")
    route = self._get_route('login')
    method = self._get_method('login')
    resp = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
    print('Response\n' + str(resp))
    global apikey
    if resp['success']:
      apikey = resp['apikey']
    else:
      apikey = None
    self.assertTrue(resp['success'])

  def logout(self):
    print("Logging out...")
    route = self._get_route('logout')
    method = self._get_method('logout')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def update(self, ip=None):
    """
    """
    if ip:
      print('**Updating with response from get profile(uprofile)**')
      p = ip
    else:
      p = profile

    p['name'] = p['name'] + ' Mod'
    route = self._get_route('update')
    method = self._get_method('update')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, p, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def bad_update(self):
    p = profile.copy()
    p["passwd"] = '﻿e83d438db4e8a7a060f65942da269ed8'
    route = self._get_route('update')
    method = self._get_method('update')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, p, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def dashboard(self):
    route = self._get_route('dashboard')
    method = self._get_method('dashboard')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def profile(self, get_profile=False):
    global uprofile
    route = self._get_route('profile')
    method = self._get_method('profile')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    uprofile = resp['profile'] if 'profile' in resp else None
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])
    return resp['success'] if ('success' in resp) and get_profile else None

  def list(self):
    route = self._get_route('list')
    method = self._get_method('list')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def entitlements(self):
    route = self._get_route('entitlements')
    method = self._get_method('entitlements')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def active(self):
    route = self._get_route('active')
    method = self._get_method('active')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def stat(self):
    route = self._get_route('stat')
    method = self._get_method('stat')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def tscontext(self):
    route = self._get_route('tscontext')
    method = self._get_method('tscontext')
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def basic_login(self):
    pass

  def updatepwd(self):
    pass

  def bad_credentials(self):
    route = self._get_route('login')
    method = self._get_method('login')
    badauth = auth.copy()
    badauth["passwd"] = "incorrect_passwd"
    resp = SbtGlobalCommon.makerequest(route, method, badauth, None, headers)
    print('Response\n' + str(resp))
    self.assertFalse(resp['success'])

  def screener_create(self):
    route = self._get_route('screener/create')
    method = self._get_method('screener/create')
    payload = {
      "email": email,
      "name": screener_test_name,
      "filters": [
        {
          "field": "pricetoearnings",
          "operator": "gte",
          "value": "10"
        },
        {
          "field": "dividendyield",
          "operator": "gte",
          "value": "15"
        }
      ]
    }
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(
            route, method, payload, None, headers
    )
    self.assertTrue(resp['success'])

  def screener_get(self):
    route  = self._get_route('screener/get')
    method = self._get_method('screener/get')
    headers = self._update_headers()
    resp   = SbtGlobalCommon.makerequest(
            route, method, None, None, headers, email
    )
    self.assertTrue(resp['success'])

  def screener_update(self):
    route = self._get_route('screener/update')
    method = self._get_method('screener/update')
    payload = {
      "email": email,
      "name": screener_test_name,
      "filters": [
        {
          "field": "pricetoearnings",
          "operator": "gte",
          "value": "1"
        },
        {
          "field": "dividendyield",
          "operator": "gte",
          "value": "100"
        }
      ]
    }
    headers = self._update_headers()
    resp = SbtGlobalCommon.makerequest(
            route, method, payload, None, headers
    )
    self.assertTrue(resp['success'])

  def screener_delete(self):
    route  = self._get_route('screener/delete')
    method = self._get_method('screener/delete')
    headers = self._update_headers()
    resp   = SbtGlobalCommon.makerequest(
               route, method, None, None, headers, email, screener_test_name)
    self.assertTrue(resp['success'])

  def _clean_up_after_exception(self):
    try:
      self.profile(get_profile=True)
      self.delete()
    except Exception as e:
      print("An exception ocurred while cleaning up ({})".format(e))

  def _gen_test_dict(self):
    # TODO read order list from config and populate this

    self.tlist = []
    self.tmap = dict()

    for i in range(0, len(self.test_order_list)):
      self.tlist.append(self.__getattribute__(self.test_order_list[i]))
      self.tmap[self.test_order_list[i]] = self.tlist[i]

  def test_in_order(self):
    """
    Execute test scenarios in sequence
    """
    tname = ''
    try:
      print('Testing UPManager in order')
      self._gen_test_dict()
      for i in range(0, len(self.test_order_list)):
        tname = self.test_order_list[i]
        print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        print("++ Executing test: " + tname)
        print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        self.tlist[i]()
        print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        print("++ Completed test: " + tname)
        print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    except Exception as e:
      print("---------------------------------------------------------------")
      print("-- Cleaning up...")
      self._clean_up_after_exception()
      print("-- Encountered exception while executing " + tname)
      print("---------------------------------------------------------------")
      self.fail("Exception: " + str(e))

def main(argc):
  """
  argv[1] test conf file
  opt argv[2] env
  """
  global env

  if argc == 1:
    env = SbtGlobalCommon.get_sbt_config_env()
  elif argc == 2:
    env = sys.argv[1]
  else:
    print('Usage: python <program> or python <program> <environment>\n' +
          '   Ex: python unittest.py\n' +
          '  Alt: python <program>\n'
         )
    sys.exit(1)

  print('Testing ' + env + ' deployment environment')

  unittest.main()

if __name__ == '__main__':
  argc = len(sys.argv)
  main(argc)

"""
Expected Output: Exception for the list of loggedin users at anytime as long as
test user appears
"""
