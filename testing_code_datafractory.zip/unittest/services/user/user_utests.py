import unittest
import os
import sys
import datetime

from time import sleep

sys.path.append(
        os.path.join(
                os.path.dirname(__file__), '..', '..', '..', '..','common','sbt'
        )
)

from sbt_common import SbtGlobalCommon

routes = {}
ROUTE  = 0
METHOD = 1

res     = 'user'  # api gateway resource
email   = 'paltest'
xapikey = SbtGlobalCommon.get_api_token_value()

global apikey

screener_test_name = "Test 1" #TODO: Handle screener names with ws

profile = \
  {
    "name":           "Jonh Wick",
    "email":          email,
    "passwd":         "YWxsaWFuY2UxMjM=",
    "snaid":          "SAC000578279737",
    "sungard_login":  "",
    "sungard_pwd":    "welcome",
    "sungard_group":  "STANSBERRY",
    "tradestop_user": "",
    "tradestop_pwd":  "",
    "chat_id":        email,
    "symsel":         "AAPL",
    "pagesel":        "dashboard",
    "accept_terms":   False,
    "dark_popout":    True,
    "dashboard":      [{
      "type":  "market-overview",
      "label": "overview",
      "data":  {
        "expanded":   False,
        "selections": []
      }
    },
      {
        "type":       "market-watch",
        "label":      "Market Watch",
        "height":     6,
        "width":      8,
        "min_height": 1,
        "min_width":  4,
        "xpos":       4,
        "ypos":       0,
        "data":       {
          "default-list":        "Default List",
          "display-column-list": [
            "identifier",
            "lastSale",
            "change",
            "lastVolume",
            "high",
            "low",
            "bid",
            "offer",
            "name"
          ],
          "ticker-portfolio":    "Total Portfolio"
        },
        "wlist":      [{
          "name":    "Total Portfolio",
          "symbols": "GRUB,MIC,TAST,RL,MSFT,AXS,DIS,RRC,FB,INTC,DIS,BXMT,NLY,MKTX,FRFHF,WRB,AXP,NVDA,GIS,HSY,IBKR,TSLA,FNV,SPG,TRV,SRCL,NVR,CTRP,NPSNY,TGT,FCX,AAU"
        },
          {
            "name":    "Default List",
            "symbols": "AAPL,CAT,CSCO,DIS,GM,GRUB,HSY,IBM,INTC,JPM,MMM,MSFT,NFLX,PM,SEAS,TSLA"
          }
        ]
      },
      {
        "type":       "news-feed-media",
        "label":      "News Feed",
        "height":     6,
        "width":      4,
        "min_height": 1,
        "min_width":  4,
        "xpos":       0,
        "ypos":       12,
        "data":       {}
      },
      {
        "type":       "paragraph-media",
        "label":      "Research",
        "height":     6,
        "width":      4,
        "min_height": 1,
        "min_width":  4,
        "xpos":       0,
        "ypos":       6,
        "data":       {
          "compact": True
        }
      },
      {
        "type":       "time-series-chart",
        "label":      "Chart",
        "height":     9,
        "width":      8,
        "min_height": 1,
        "min_width":  4,
        "xpos":       4,
        "ypos":       6,
        "data":       {
          "defaultSymbol":       "AAPL",
          "primary":             True,
          "period":              2,
          "scale":               4,
          "navigator":           True,
          "volume":              True,
          "chartType":           "ohlc",
          "scaleType":           "linear",
          "compareType":         "relative",
          "news-flag":           True,
          "indicators":          [{
            "type":         "sma",
            "period":       "25",
            "sortPeriod":   0,
            "longPeriod":   0,
            "signalPeriod": 0,
            "algorithm":    ""
          }],
          "defaultSymbolObject": {
            "symbol": "AAPL"
          }
        }
      },
      {
        "type":       "sbcontent-media",
        "label":      "NewsWire",
        "height":     6,
        "width":      4,
        "min_height": 1,
        "min_width":  4,
        "xpos":       0,
        "ypos":       0,
        "data":       {
          "compact": True
        }
      },
      {
        "type":       "time-series-chart",
        "label":      "Macro Chart",
        "height":     10,
        "width":      8,
        "min_height": 1,
        "min_width":  4,
        "xpos":       4,
        "ypos":       15,
        "data":       {
          "period":              4,
          "scale":               4,
          "defaultSymbolObject": {
            "period":    2,
            "searchKey": {
              "text":               "Commitment of Traders - GOLD (CMX) - Sentiment Indicator - Legacy Format",
              "id":                 "8bdbcf06-2ef4-4cab-b72f-9cec625b4ff1",
              "symbol":             "088691_FO_L_ALL_SENTIMENT",
              "category_guid":      "ef7b8d79-e412-48f1-aac3-5efd6bf853c4",
              "exchange":           "CFTC",
              "tags":               [
                "display_sentiment"
              ],
              "entity_description": ""
            },
            "text":      "Commitment of Traders - GOLD (CMX) - Sentiment Indicator - Legacy Format"
          },
          "navigator":           True,
          "volume":              False,
          "chartType":           "line",
          "scaleType":           "linear",
          "compareType":         "absolutePrice",
          "news-flag":           False,
          "primary":             False
        }
      }
    ],
    "crypto":         {
      "data":   {
        "cursel": {
          "BTC":  "USD",
          "DASH": "USD",
          "ETH":  "USD",
          "BCH":  "USD",
          "XRP":  "USD"
        },
        "chart":  {
          "userId":    "",
          "data":      {},
          "x":         -1,
          "y":         -1,
          "height":    5,
          "width":     6,
          "minHeight": 1,
          "minWidth":  4,
          "type":      "crypto-chart"
        }
      },
      "navsel": "BTC"
    },
    "summary":        {
      "navsel":  "Fundamentals",
      "fundsel": "CHART",
      "period":  "a",
      "data":    {
        "chart":    {
          "userId":    "",
          "data":      {},
          "x":         -1,
          "y":         -1,
          "height":    5,
          "width":     6,
          "minHeight": 1,
          "minWidth":  4,
          "type":      "summary-chart"
        },
        "yearSort": False
      }
    },
    "model":          {
      "navsel": "efficiencyModel",
      "period": "a",
      "data":   {
        "screeners": []
      },
      "valsel": ""
    },
    "research":       {
      "navsel":        "screener",
      "sbrportfolios": {
        "selection": "Total Portfolio"
      },
      "sbrrecommends": {
        "selection": "Stansberry Venture Technology"
      },
      "data":          {
        "chart": {
          "userId":    "",
          "data":      {},
          "x":         -1,
          "y":         -1,
          "height":    5,
          "width":     6,
          "minHeight": 1,
          "minWidth":  4,
          "type":      "research-chart"
        }
      }
    }
  }

auth = {
  "email": email,
  "passwd": "YWxsaWFuY2UxMjM="
}

uauth = {
  "email": email,
  "cpwd": "d2VsY29tZQ==",
  "npwd": "aGVsbG93b3JsZA=="
}

logout = {"email": email}

headers = {
  'Content-type': 'application/json',
  'Accept': 'text/plain',
  'X-Api-Key': xapikey
}

uprofile = None

class UserUnitTests(unittest.TestCase):

  def __init__(self, env):
    cfg = SbtGlobalCommon.raw_sbt_config
    # if an environment is provided, use it;
    # otherwise use what's in sbt_conf.json
    env = env if env is not None else cfg['environment']
    api = cfg['apigateway']
    uri = api['env'][env]

    self.pids = []

    # list of (ROUTE, METHOD) for the env defined in sbt_conf.json
    rlist = SbtGlobalCommon.get_api_routes(res)
    sbt_config_uri = rlist[0][0].split('/' + res)[0]

    root = '/' + res

    # set routes
    for r in rlist:
      if sbt_config_uri != uri:
        r_list = list(r)
        new_rlist = [r_list[ROUTE].replace(sbt_config_uri, uri), r_list[METHOD]]
        r = tuple(new_rlist)
      n = len(r[ROUTE])
      i = r[ROUTE].rindex(root) + len(root)
      k = r[ROUTE][i + 1:n]
      routes[k] = r[ROUTE], r[METHOD]
      print('ROUTE: ' + k + ' PATH: ' + r[ROUTE] + ' METHOD: ' + r[METHOD])
    super().__init__()

  @staticmethod
  def _get_route(r):
    """
    Retrieves the route for the specified resource
    :param r:
    :return:
    """
    rval = None

    if r in routes:
      rval = routes[r][ROUTE]

    return rval

  @staticmethod
  def _get_method(r):
    """
    Retrieves the method for the specified resource
    :param r:
    :return:
    """
    rval = None

    if r in routes:
      rval = routes[r][METHOD]

    return rval

  def all(self):
    print("Retrieving all users...")
    route = self._get_route('all')
    method = self._get_method('all')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def create(self):
    print("Adding user...")
    route = self._get_route('create')
    method = self._get_method('create')
    resp = SbtGlobalCommon.makerequest(route, method, profile, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def delete(self):
    print("Deleting user...")
    route = self._get_route('delete')
    method = self._get_method('delete')
    resp = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def login(self):
    global apikey
    print("Logging in...")
    route  = self._get_route('login')
    method = self._get_method('login')
    resp   = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])
    if resp['success'] and 'apikey' in resp: apikey = resp['apikey']

  def logout(self):
    print("Logging out...")
    route = self._get_route('logout')
    method = self._get_method('logout')
    headers['apikey'] = apikey
    resp = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def update(self, ip=None):
    """
    """
    if ip:
      print('**Updating with response from get profile(uprofile)**')
      p = ip
    else:
      p = profile

    p['name'] = p['name'] + ' Mod'
    route = self._get_route('update')
    method = self._get_method('update')
    resp = SbtGlobalCommon.makerequest(route, method, p, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def bad_update(self):
    p = profile.copy()
    p["passwd"] = '﻿e83d438db4e8a7a060f65942da269ed8'
    route = self._get_route('update')
    method = self._get_method('update')
    resp = SbtGlobalCommon.makerequest(route, method, p, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def dashboard(self):
    route = self._get_route('dashboard')
    method = self._get_method('dashboard')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def profile(self, get_profile=False):
    global uprofile
    route = self._get_route('profile')
    method = self._get_method('profile')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    uprofile = resp['profile'] if 'profile' in resp else None
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])
    return resp['success'] if ('success' in resp) and get_profile else None

  def list(self):
    route = self._get_route('list')
    method = self._get_method('list')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def entitlements(self):
    route = self._get_route('entitlements')
    method = self._get_method('entitlements')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def active(self):
    route = self._get_route('active')
    method = self._get_method('active')
    headers['apikey'] = apikey + '1'
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def _active(self):
    route = self._get_route('active')
    method = self._get_method('active')
    headers['apikey'] = apikey + '1'
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertFalse(resp['success'])

  def spam_active(self, procs=5, reqs=2000):
    print('Begin active spamming')
    self.pids = []

    for i in range(0, procs):
      print('start: '+ str(datetime.datetime.now()))
      cid = os.fork()
      self.pids.append(cid)
      if cid == 0:
        for i in range(0, reqs):
          self._active()
        os._exit(0)
      else:
        sleep(0.1)

    for pid in self.pids:
      os.waitpid(pid, 0)

    print('stop: ' + str(datetime.datetime.now()))
    print('Spamming complete')

  def stat(self):
    route = self._get_route('stat')
    method = self._get_method('stat')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def tscontext(self):
    route = self._get_route('tscontext')
    method = self._get_method('tscontext')
    resp = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
    print('Response\n' + str(resp))
    self.assertTrue(resp['success'])

  def basic_login(self):
    pass

  def updatepwd(self):
    pass

  def bad_credentials(self):
    route = self._get_route('login')
    method = self._get_method('login')
    badauth = auth.copy()
    badauth["passwd"] = "incorrect_passwd"
    resp = SbtGlobalCommon.makerequest(route, method, badauth, None, headers)
    print('Response\n' + str(resp))
    self.assertFalse(resp['success'])

  def screener_create(self):
    route = self._get_route('screener/create')
    method = self._get_method('screener/create')
    payload = {
      "email": email,
      "name": screener_test_name,
      "filters": [
        {
          "field": "pricetoearnings",
          "operator": "gte",
          "value": "10"
        },
        {
          "field": "dividendyield",
          "operator": "gte",
          "value": "15"
        }
      ]
    }
    resp = SbtGlobalCommon.makerequest(
            route, method, payload, None, headers
    )
    self.assertTrue(resp['success'])

  def screener_get(self):
    route = self._get_route('screener/get')
    method = self._get_method('screener/get')
    resp = SbtGlobalCommon.makerequest(
            route, method, None, None, headers, email
    )
    self.assertTrue(resp['success'])

  def screener_update(self):
    route = self._get_route('screener/update')
    method = self._get_method('screener/update')
    payload = {
      "email": email,
      "name": screener_test_name,
      "filters": [
        {
          "field": "pricetoearnings",
          "operator": "gte",
          "value": "1"
        },
        {
          "field": "dividendyield",
          "operator": "gte",
          "value": "100"
        }
      ]
    }
    resp = SbtGlobalCommon.makerequest(
            route, method, payload, None, headers
    )
    self.assertTrue(resp['success'])

  def screener_delete(self):
    route  = self._get_route('screener/delete')
    method = self._get_method('screener/delete')
    resp   = SbtGlobalCommon.makerequest(
               route, method, None, None, headers, email, screener_test_name)
    self.assertTrue(resp['success'])

  def _clean_up_after_exception(self):
    try:
      self.profile(get_profile=True)
      self.delete()
    except Exception as e:
      print("An exception ocurred while cleaning up ({})".format(e))
