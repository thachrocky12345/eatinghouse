import sys
import unittest
from user_utests import UserUnitTests

class RunUserUnitTests(unittest.TestCase):

  # _env = None -> run tests for dev
  _env = None

  def setUp(self):
    print("SETTING ENV TO {}".format(self._env))
    self.tests = UserUnitTests(self._env)

  def _gen_steps(self):
    #self.tests.delete()
    test_order_list = [
      'create',
      'login',
      'spam_active',
      'logout',
      'delete',
    ]
    for item in test_order_list:
      # returns method name and method
      yield item, self.tests.__getattribute__(item)

  def test_in_order(self):
    """
    Execute test scenarios in sequence
    """
    for test_name, test in self._gen_steps():
      try:
        print("======")
        print("=== Executing test {}".format(test_name))
        test()
        print("======")
        print("")
      except Exception as e:
        print("===>>> Cleaning up...")
        self.tests._clean_up_after_exception()
        self.fail(" ===>>> {} failed. Exception: {}".format(test_name, e))


if __name__ == '__main__':

  if len(sys.argv) > 1:
    RunUserUnitTests._env = sys.argv.pop()

  unittest.main()
