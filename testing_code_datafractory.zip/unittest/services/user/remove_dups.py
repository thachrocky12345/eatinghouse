import sys

from sbt_common import SbtGlobalCommon

routes  = {}
ROUTE   = 0
METHOD  = 1

emails = {
  "jp@netesenz.com" : "JP Vinjamoori",
  "mlang@stansberryresearch.com" : "Michael Lang",
  "ahand@stansberryresearch.com" : "Alexandra Hand",
  "jhires@stansberryresearch.com" : "James Hires",
  "mteodoro@stansberryresearch.com" : "mteodoro",
  "ymaalo@stansberryresearch.com" : "Yonathan Maalo",
  "subhabrata@netesenz.com" : "Subha Banerjee",
  "siju@netesenz.com" : "Siju S",
  "lingaraja@netesenz.com" : "Linga Vijayan",
  "sanooj@netesenz.com": "Sanooj Surendranath",
  "rfoster@stansberryresearch.com": "Robert Foster"
}

def responseok(res):
  """

  :param res:
  :return:
  """
  return res and 'success' in res and res['success']

def getroute(r):
  """

  :param r:
  :return:
  """
  rval = None

  if r in routes:
    rval = routes[r][ROUTE]

  return rval

def getmethod(r):
  """

  :param r:
  :return:
  """
  rval = None

  if r in routes:
    rval = routes[r][METHOD]

  return rval

def genrequest(reqmeth, data=None, params=None, *args): #TODO proper overload
  """

  :param reqmeth:
  :param data:
  :param params:
  :param args:
  :return:
  """
  url    = reqmeth[ROUTE]
  method = reqmeth[METHOD]
  return SbtGlobalCommon.makerequest(url, method, data, params, args)

def configroutes(res):
  """

  :param res:
  :return:
  """
  rlist = SbtGlobalCommon.get_api_routes(res)

  global routes

  root = '/' + res

  for r in rlist:
    l = len(r[ROUTE])
    i = r[ROUTE].rindex(root) + len(root)
    k = r[ROUTE][i+1:l]
    routes[k] = r[ROUTE], r[METHOD]
    print('ROUTE: ' + k + ' PATH: ' + r[ROUTE] + ' METHOD: ' + r[METHOD])

def get_unique_mw(mw):
  rval = []

  if mw and 'wlist' in mw:
    wlist = mw['wlist']
    nlist = []
    for w in wlist:
      if (w['name'], w['luid']) not in nlist:
        rval.append(w)
        nlist.append((w['name'], w['luid']))

  return rval

def remove_dups():
  """
  """
  users = emails

  print('users\n' + str(users))

  ukeys = users.keys()

  for user in ukeys:
    route  = getroute('profile') # Get profile
    method = getmethod('profile')
    resp   = SbtGlobalCommon.makerequest(route, method, None, None, None, user)
    print('Response\n' + str(resp))
    if not responseok(resp):
      print('Get Profile ' + user + ' Failed')
    else:
      p = resp['profile']
      d = p['dashboard']
      u = []
      for w in d:
        if len(u) == 0:
          u.append(w)
        else:
          ok = True
          for v in u:
            results = SbtGlobalCommon.CollectionsUtil.get_matching_dict_entries(w, v)
            if len(results) == len(w.items()):
              ok = False
              print ('Found duplicates\n' + str(w) + '\n' + str(v))
              break
          if ok:
            u.append(w)
          else:
            print('Skipping duplicate\n' + str(w))

      for v in u:
        if v['type'] == 'market-watch':
          v['wlist'] = get_unique_mw(v)
          break

      p['dashboard'] = u

      route  = getroute('update')
      method = getmethod('update')
      resp   = SbtGlobalCommon.makerequest(route, method, p)
      print('Response\n' + str(resp))
      if not responseok(resp):
        print('Update ' + str(u) + ' Failed')
      else:
        print('Profile without duplicates\n' + str(p))

def main(argc):
  """
  argv[1] test conf file
  opt argv[2] env
  """
  global env

  if argc == 1:
    env = SbtGlobalCommon.get_sbt_config_env()
  elif argc == 2:
    env = sys.argv[1]
    if not SbtGlobalCommon.set_sbt_config_env(env):
      print('ERROR: Failed to set sbt env: ' + env)
      sys.exit(2)
  else:
    print('Usage: python <program>\n' +
          '   Ex: python unittest.py\n' +
          '  Alt: python <program>\n'
         )

    sys.exit(1)

  res = 'user' # api gateway resource

  configroutes(res)
  print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
  print("Removing duplicates for env: " + env)
  print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
  remove_dups()
  print("--------------------------------------------------------------------")
  print("Complete remove duplicates for env: " + env)
  print("--------------------------------------------------------------------")

if __name__ == '__main__':
  argc = len(sys.argv)
  main(argc)
