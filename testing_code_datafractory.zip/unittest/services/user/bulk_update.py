import sys
import simplejson as json

from sbt_common import SbtGlobalCommon

routes  = {}
ROUTE   = 0
METHOD  = 1
ucfg    = None

headers = {
            'Content-type': 'application/json',
            'Accept':       'text/plain',
            'X-Api-Key': 'Loq7jBw1fi6hQdZN0slB59eNYyNxowKN9jjLkdWa'
          }

default = \
  {
    "name": "Alexandra Hand",
    "email": "",
    "passwd": "d2VsY29tZQ==",
    "snaid": "SAC0018827999",
    "sungard_login": "",
    "sungard_pwd": "welcome",
    "sungard_group": "STANSBERRY",
    "modified": "2018-03-22 17:38:43.109488",
    "tradestop_user": "",
    "tradestop_pwd": "",
    "chat_id": "ahand@stansberryresearch.com",
    "symsel": "AAPL",
    "pagesel": "dashboard",
    "dashboard": [
      {
        "type": "market-overview",
        "label": "overview",
        "data": {
          "expanded": False,
          "selections": []
        },
      },
      {
        "type": "generic-chart",
        "label": "Chart",
        "height": 7,
        "width": 8,
        "min_height": 1,
        "min_width": 4,
        "xpos": 4,
        "ypos": 8,
        "data": {
          "defaultSymbol": "AAPL",
          "primary": True,
          "period": 3,
          "scale": 4,
          "navigator": True,
          "volume": True,
          "chartType": "ohlc",
          "scaleType": "linear",
          "compareType": "relative"
        },
      },
      {
        "type": "sbcontent-media",
        "label": "NewsWire",
        "height": 7,
        "width": 4,
        "min_height": 1,
        "min_width": 4,
        "xpos": 0,
        "ypos": 0,
        "data": {},
      },
      {
        "type": "time-series-chart",
        "label": "Time Series",
        "height": 6,
        "width": 8,
        "min_height": 1,
        "min_width": 4,
        "xpos": 4,
        "ypos": 15,
        "data": {},
      },
      {
        "type": "market-watch",
        "label": "Market Watch",
        "height": 8,
        "width": 8,
        "min_height": 1,
        "min_width": 4,
        "xpos": 4,
        "ypos": 0,
        "data": {
          "default-list": ""
        },
        "userid": "3476e6a7-424d-46f1-a664-c1bceb434a35",
        "wlist": [
          {
            "name": "Total Portfolio",
            "symbols": "GRUB,IBKR,INTC,AXS,RRC,TSLA,DIS,WRB,FRFHF,MIC,NLY,MKTX,SPG,BXMT,AXP,MSFT,NVDA,RL,FB,TRV,TAST,NVR,FNV,CTRP,KBA,TGT,AMCX,NPSNY,FCX,AAU,SRCL"
          },
          {
            "name": "Default List",
            "symbols": "GRUB,IBKR,INTC,AXS,RRC,TSLA"
          }
        ]
      },
      {
        "type": "paragraph-media",
        "label": "Research",
        "height": 7,
        "width": 4,
        "min_height": 1,
        "min_width": 4,
        "xpos": 0,
        "ypos": 7,
        "data": {},
      },
      {
        "type": "generic-media",
        "label": "Media",
        "height": 7,
        "width": 4,
        "min_height": 1,
        "min_width": 4,
        "xpos": 0,
        "ypos": 14,
        "data": {
          "dowjones": True,
          "newsletter": True,
          "newswire": True,
          "twitter": False,
          "newsfeed": True
        },
      }
    ],
    "crypto": {
      "data": {
        "cursel": {
          "BTC": "USD",
          "DASH": "USD",
          "ETH": "USD",
          "BCH": "USD",
          "XRP": "USD"
        },
        "chart": {
          "scale": "1d",
          "period": "1m"
        }
      },
      "navsel": "BTC"
    },
    "summary": {
      "navsel": "Fundamentals",
      "fundsel": "CHART",
      "period": "a",
      "data": {}
    },
    "model": {
      "navsel": "efficiencyModel",
      "period": "a",
      "data": {
        "screeners": [
          {
            "name": "gg",
            "filters": [
              {
                "field": "mcap",
                "operator": "eq",
                "value": "large"
              },
              {
                "field": "mcap",
                "operator": "eq",
                "value": "mid"
              },
              {
                "field": "mcap",
                "operator": "eq",
                "value": "small"
              },
              {
                "field": "sector",
                "operator": "eq",
                "value": "consumer-goods"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "2020"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "2090"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "5400"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "2030"
              }
            ]
          },
          {
            "name": "aerhaerh",
            "timestamp": "2018-04-16 20:25:15.389170+00:00",
            "filters": [
              {
                "field": "mcap",
                "operator": "eq",
                "value": "small"
              },
              {
                "field": "sector",
                "operator": "eq",
                "value": "services"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "5311"
              }
            ]
          },
          {
            "name": "jjjohugh",
            "timestamp": "2018-04-16 20:23:34.529372+00:00",
            "filters": [
              {
                "field": "mcap",
                "operator": "eq",
                "value": "mega"
              },
              {
                "field": "mcap",
                "operator": "eq",
                "value": "mid"
              },
              {
                "field": "mcap",
                "operator": "eq",
                "value": "large"
              },
              {
                "field": "mcap",
                "operator": "eq",
                "value": "small"
              },
              {
                "field": "sector",
                "operator": "eq",
                "value": "financial"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "6199"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "6172"
              }
            ]
          },
          {
            "name": "dfghjkytr",
            "timestamp": "2018-04-16 20:48:32.050399+00:00",
            "filters": [
              {
                "field": "mcap",
                "operator": "eq",
                "value": "large"
              },
              {
                "field": "sector",
                "operator": "eq",
                "value": "conglomerates"
              },
              {
                "field": "sector",
                "operator": "eq",
                "value": "healthcare"
              },
              {
                "field": "indu",
                "operator": "eq",
                "value": "8090"
              }
            ]
          }
        ]
      },
      "valsel": ""
    },
    "portfolio": {
      "navsel": "",
      "tradestops": {},
      "sbrportfolios": {},
      "sbrrecommends": {}
    },
    "research": {
      "navsel": "Stansberry Portfolio Solutions",
      "tradestops": {},
      "sbrportfolios": {
        "selection": "Total Portfolio"
      },
      "sbrrecommends": {
        "selection": "Extreme Value"
      }
    }
  }

def responseok(res):
  """

  :param res:
  :return:
  """
  return res and 'success' in res and res['success']

def getroute(r):
  """

  :param r:
  :return:
  """
  rval = None

  if r in routes:
    rval = routes[r][ROUTE]

  return rval

def getmethod(r):
  """

  :param r:
  :return:
  """
  rval = None

  if r in routes:
    rval = routes[r][METHOD]

  return rval

def bulkupdate():
  """
  """
  users = ucfg['emails']
  creds = ucfg['credentials']

  print('users\n' + str(users))
  print('credentials\n' + str(creds))

  ukeys = users.keys()

  for u in ukeys:
    route  = getroute('profile')
    method = getmethod('profile')
    resp   = SbtGlobalCommon.makerequest(route, method, None, None, None, u)
    print('Response\n' + str(resp))
    if not responseok(resp):
      print('Get Profile ' + u + ' Failed')
    else:
      p   = resp['profile']
      tsu = next(iter(creds))

      p['tradestop_user'] = tsu
      p['tradestop_pwd']  = creds[tsu]
      p['passwd']         = "d2VsY29tZQ=="

      del creds[tsu]

      route  = getroute('update')
      method = getmethod('update')
      resp   = SbtGlobalCommon.makerequest(route, method, p)
      print('Response\n' + str(resp))
      if not responseok(resp):
        print('Update ' + u + ' Failed')
      else:
        route  = getroute('tscontext')
        method = getmethod('tscontext')
        resp   = SbtGlobalCommon.makerequest(route, method, None, None, None, u)
        print('Response\n' + str(resp))
        if not responseok(resp):
          print('Get TS Context ' + u + ' Failed')

def bulkcreate():

  i     = 0
  snaid = 'SAC00034827005'

  for k in ucfg['emails']:
    default['email']         = k
    default['name']          = ucfg['emails'][k]
    sl = k.split('@')
    sl = sl[0]
    default['sungard_login'] = sl
    default['snaid']         = snaid + str(i)
    default['chat_id']       = k

    if i % 2 == 0:
      default['tradestop_user'] = 'apitest1@tradestops.com'
      default['tradestop_pwd']  = 'xgEeWKw3uk'
    else:
      default['tradestop_user'] = 'apitest2@tradestops.com'
      default['tradestop_pwd']  = 'tmrp5Uv4Hu'

    route  = getroute('create')
    method = getmethod('create')

    resp = SbtGlobalCommon.makerequest(route, method, default, None, headers)
    print('Response\n' + str(resp))

    if not responseok(resp):
      print('Create user ' + k + ' Failed')
    else:
      print('Create user ' + k + ' ok')
      auth = {
        "email" : k,
        "passwd": "d2VsY29tZQ=="
      }

      route  = getroute('login')
      method = getmethod('login')
      resp   = SbtGlobalCommon.makerequest(route, method, auth)
      print('Response\n' + str(resp))

      if not responseok(resp):
        print('Login ' + k + ' Failed')
      else:
        print('User ' + k + ' login ok')
        route  = getroute('logout')
        method = getmethod('logout')
        data   = { "email" : k }
        resp   = SbtGlobalCommon.makerequest(route, method, data)
        print('Response\n' + str(resp))

        if not responseok(resp):
          print('Logout ' + k + ' Failed')
        else:
          print('User ' + k + ' logout ok')

    i = i + 1

def configusers(c):
  """
  """
  global ucfg
  ucfg = json.loads(c)
  print(json.dumps(ucfg))

def configroutes(res):
  """

  :param res:
  :return:
  """
  rlist = SbtGlobalCommon.get_api_routes(res)

  global routes

  root = '/' + res

  for r in rlist:
    l = len(r[ROUTE])
    i = r[ROUTE].rindex(root) + len(root)
    k = r[ROUTE][i+1:l]
    routes[k] = r[ROUTE], r[METHOD]
    print('ROUTE: ' + k + ' PATH: ' + r[ROUTE] + ' METHOD: ' + r[METHOD])

def main(argc):
  """
  argv[1] test conf file
  opt argv[2] env
  """
  if argc == 2:
    env = sys.argv[1]
    f   = open(sys.argv[1], 'r')
    u   = f.read()
    f.close()
  else:
    print('Usage: python <program>\n' +
          '   Ex: python bulk_update.py users.json\n' +
          '  Alt: python <program>\n'
         )

    sys.exit(1)

  res = 'user'  # api gateway resource

  configroutes(res)
  configusers(u)
  print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
  print("Add/Modify users for" + env + " ApiGateway")
  print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
  bulkcreate()
  #bulkupdate()
  print("--------------------------------------------------------------------")
  print("Add/Modify " + env + " Complete")
  print("--------------------------------------------------------------------")

if __name__ == '__main__':
  argc = len(sys.argv)
  main(argc)