import sys

from sbt_common import SbtGlobalCommon

routes  = {}
ROUTE   = 0
METHOD  = 1

#TODO Schema -> Class

email   = 'test@stansberryresearch.com'

profile = \
{
  "name":           "Jonh Wick",
  "email":          email,
  "passwd":         "d2VsY29tZQ==",
  "snaid":          "SAC000578279737",
  "sungard_login":  "test",
  "sungard_group":  "STANSBERRY",
  "sungard_pwd":    "welcome",
  "tradestop_user": "apitest3@tradestops.com",
  "tradestop_pwd":  "FJaMLT9NBw",
  "modified":       "1511316310",
  "symsel": "VMW",
  "pagesel": "dashboard",
  "chat_id" : "test@stansberryresearch.com",
  "guid" : "",
  "dashboard": [
    {
      "type":       "generic-media",
      "label":      "Media",
      "height":     14,
      "width":      4,
      "min_height": 1,
      "min_width":  4,
      "xpos":       0,
      "ypos":       0,
      "data": {
        "defaultSymbol": "GOOG"
      },
      "wlist":      []
    },
    {
      "type":       "stock-chart",
      "label":      "Stock Chart",
      "height":     9,
      "width":      8,
      "min_height": 1,
      "min_width":  4,
      "xpos":       4,
      "ypos":       5,
      "data":       {
        "identifier": "GOOG",
        "period":     2,
        "scale":      4
      },
      "wlist":      []
    },
    {
      "type":       "market-watch",
      "label":      "Market Watch",
      "height":     5,
      "width":      8,
      "min_height": 1,
      "min_width":  4,
      "xpos":       4,
      "ypos":       0,
      "data":       {
        "default-list": ""
      },
      "wlist": [
        {
          "name":    "Default List",
          "symbols": "AAPL,CVS,GOOG,VMW"
        },
        {
          "name":    "Test",
          "symbols": "IBM,FB"
        }
      ]
    },
    {
      "type": "market-overview",
      "label": "overview",
      "data": {
        "expanded": False,
        "selections": [
          "S&P",
          "NASDAQ",
          "GOLD",
          "OIL"
        ]
      }
    }
  ],
  "crypto":    {
    "navsel": "btc",
    "data":   {
      "cursel": {
        "btc":  "eur",
        "dash": "usd",
        "eth":  "gbp",
        "zec":  "cad",
        "bch":  "gbp"
      }
    }
  },
  "summary":   {
    "navsel":  "insider metrics",
    "fundsel": "income",
    "period":  "annual"
  },
  "model":     {
    "navsel": "efficiency model",
    "period": "quarterly",
    "data":   {
      "screeners": ["Frist", "Second"]
    },
    "valsel": "assumptions"
  },
  "portfolio": {
    "navsel":        "",
    "tradestops":    {
      "tabsel":       "portfolio position research",
      "portfoliotab": {
        "statsel": "open closed all"
      },
      "positiontab":  {
        "portfoliosel":  "popular",
        "viewsel":       "default fundamentals",
        "possel":        "positions closed positions",
        "expandsummary": True
      },
      "researchtab":  {
        "symbol": "",
        "eprice": "",
        "tsp":    65
      },
      "portfolios":   [{
        "name":      "popstocks",
        "currency":  "",
        "cash":      "",
        "brokerage": "",
        "notes":     "",
        "positions": [{
          "symbol":      "AAPL",
          "entry_date":  "01/01/2017",
          "entry_price": "",
          "shares":      "",
          "trade_type":  "long short"
        }]
      }]
    },
    "sbrportfolios": {
      "selection": "Income Portfolio"
    },
    "sbrrecommends": {
      "selection": "Stansberry Gold & Silver Investor"
    }
  }
}

auth = {
          "email"  : email,
          "passwd" : "d2VsY29tZQ=="
       }

uauth = {
          "email": email,
          "cpwd" : "d2VsY29tZQ==",
          "npwd" : "aGVsbG93b3JsZA=="
        }

logout = { "email" : email }

headers = {
            'Content-type': 'application/json',
            'Accept':       'text/plain',
            'X-Api-Key': 'Loq7jBw1fi6hQdZN0slB59eNYyNxowKN9jjLkdWa'
          }
uprofile = None

def responseok(res):
  """

  :param res:
  :return:
  """
  return res and 'success' in res and res['success']

def getroute(r):
  """

  :param r:
  :return:
  """
  rval = None

  if r in routes:
    rval = routes[r][ROUTE]

  return rval

def getmethod(r):
  """

  :param r:
  :return:
  """
  rval = None

  if r in routes:
    rval = routes[r][METHOD]

  return rval

def genrequest(reqmeth, data=None, params=None, *args): #TODO proper overload
  """

  :param reqmeth:
  :param data:
  :param params:
  :param args:
  :return:
  """
  url    = reqmeth[ROUTE]
  method = reqmeth[METHOD]
  return SbtGlobalCommon.makerequest(url, method, data, params, args)

def testcreate():
  route  = getroute('create')
  method = getmethod('create')
  resp   = SbtGlobalCommon.makerequest(route, method, profile)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Create User ' + email + ' Failed')
    return False

  return True

def testdelete():
  route = getroute('delete')
  method = getmethod('delete')
  resp = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Delete User ' + email + ' Failed')
    return False

  return True

def testlogin():
  route  = getroute('login')
  method = getmethod('login')
  resp   = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Login ' + email + ' Failed')
    return False

  return True

def testlogout():
  route = getroute('logout')
  method = getmethod('logout')
  resp = SbtGlobalCommon.makerequest(route, method, auth, None, headers)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Logout ' + email + ' Failed')
    return False

  return True

def testupdate(ip=None):
  global profile

  if ip:
    print('**Updating with response from get profile(uprofile)**')
    p = ip
  else:
    p = profile

  p['name'] = p['name'] + ' Mod'
  route = getroute('update')
  method = getmethod('update')
  resp = SbtGlobalCommon.makerequest(route, method, p, None, headers)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Update ' + email + ' Failed')
    return False

  return True

def testbadupdate():
  p = profile.copy()
  p["passwd"] = '﻿e83d438db4e8a7a060f65942da269ed8'
  route = getroute('update')
  method = getmethod('update')
  resp = SbtGlobalCommon.makerequest(route, method, p, None, headers)
  print('Response\n' + str(resp))
  if responseok(resp):
    print('Update ' + email + ' did not fail')
    return False

  return True

def testdashboard():
  route  = getroute('dashboard')
  method = getmethod('dashboard')
  resp   = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Get dashboard ' + email + ' Failed')
    return False

  return True

def testprofile():
  global uprofile
  route  = getroute('profile')
  method = getmethod('profile')
  resp   = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Get Profile ' + email + ' Failed')
    return False
  else:
    uprofile = resp['profile']

  return True

def testlist():
  route  = getroute('list')
  method = getmethod('list')
  resp   = SbtGlobalCommon.makerequest(route, method, None, None, headers)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Get list ' + email + ' Failed')
    return False

  return True

def testentitlements():
  route  = getroute('entitlements')
  method = getmethod('entitlements')
  resp   = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Get Entitlements ' + email + ' Failed')
    return False

  return True

def testactive():
  route  = getroute('active')
  method = getmethod('active')
  resp   = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Get active ' + email + ' Failed')
    return False

  return True

def teststat():
  route  = getroute('stat')
  method = getmethod('stat')
  resp   = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Get Stat ' + email + ' Failed')
    return False

  return True

def testtscontext():
  route  = getroute('tscontext')
  method = getmethod('tscontext')
  resp   = SbtGlobalCommon.makerequest(route, method, None, None, headers, email)
  print('Response\n' + str(resp))
  if not responseok(resp):
    print('Get TS Context ' + email + ' Failed')
    return False

  return True

def testbasiclogin():
  pass

def testupdatepwd():
  return True

def testbadcredentials():
  route = getroute('login')
  method = getmethod('login')
  badauth = auth.copy()
  badauth["passwd"] = "incorrect_passwd"
  resp = SbtGlobalCommon.makerequest(route, method, badauth, None, headers)
  print('Response\n' + str(resp))
  if responseok(resp):
    print('Invalid Login ' + email + ' Failed')
    return False

  return True

def test():
  """
  Execute test scenarios in sequence
  """
  #create
  if not testcreate():
    print('ERROR: testcreate()')

  #delete
  if not testdelete():
    print('ERROR: ')
  #create
  if not testcreate():
    print('ERROR: ')
  #login
  if not testlogin():
    print('ERROR: ')
  #profile
  if not testprofile():
    print('ERROR: ')
  #update
  if not testupdate():
    print('ERROR: ')
  #with response from get profile (resuse guids)
  if not testupdate(uprofile):
    print('ERROR: ')
  #entitlements
  if not testentitlements():
    print('ERROR: ')
  #list logged in users
  if not testlist():
    print('ERROR: ')
  #activie
  if not testactive():
    print('ERROR: ')
  #layout
  if not testdashboard():
    print('ERROR: ')
  #stat
  if not teststat():
    print('ERROR: ')
  #tscontext
  if not testtscontext():
    print('ERROR: ')
  #logout
  if not testlogout():
    print('ERROR: ')
  #login
  if not testlogin():
    print('ERROR: ')

  #TODO this method is not exposed
  #basiclogin
  #if not testbasiclogin():
  #  print('ERROR: ')

  #test invalid credentials
  print('Invalid login tests...')
  if not testlogout():
    print('ERROR: ')
  if not testbadcredentials():
    print('ERROR: ')
  if not testlogin():
    print('ERROR: ')

  #test update should not delete on failure
  if not testbadupdate():
    print('ERROR: ')
  if not testprofile():
    print('ERROR: ')

  #test update pwd
  #if not testupdatepwd():
  #  print('ERROR: ')

  #delete
  if not testdelete():
    print('ERROR: delete failed')

def configroutes(res):
  """

  :param res:
  :return:
  """
  rlist = SbtGlobalCommon.get_api_routes(res)

  global routes

  root = '/' + res

  for r in rlist:
    l = len(r[ROUTE])
    i = r[ROUTE].rindex(root) + len(root)
    k = r[ROUTE][i+1:l]
    routes[k] = r[ROUTE], r[METHOD]
    print('ROUTE: ' + k + ' PATH: ' + r[ROUTE] + ' METHOD: ' + r[METHOD])

def main(argc):
  """
  argv[1] test conf file
  opt argv[2] env
  """
  env = ''
  if argc == 1:
    env = SbtGlobalCommon.get_sbt_config_env()
  elif argc == 2:
    env = sys.argv[2]
  else:
    print('Usage: python <program>\n' +
          '   Ex: python unittest.py\n' +
          '  Alt: python <program>\n'
         )

    sys.exit(1)

  res = 'user'  # api gateway resource

  configroutes(res)
  print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
  print("Testing " + env + " ApiGateway")
  print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
  test()
  print("--------------------------------------------------------------------")
  print("Testing " + env + " Complete")
  print("--------------------------------------------------------------------")

if __name__ == '__main__':
  argc = len(sys.argv)
  main(argc)

"""
Expected Output: Exception for the list of loggedin users at anytime as long as
test user appears

ROUTE: login PATH: https://api.stansberryterminal.com/v0/dev/user/login METHOD: POST
ROUTE: profile PATH: https://api.stansberryterminal.com/v0/dev/user/profile METHOD: GET
ROUTE: dashboard PATH: https://api.stansberryterminal.com/v0/dev/user/dashboard METHOD: GET
ROUTE: active PATH: https://api.stansberryterminal.com/v0/dev/user/active METHOD: GET
ROUTE: create PATH: https://api.stansberryterminal.com/v0/dev/user/create METHOD: POST
ROUTE: update PATH: https://api.stansberryterminal.com/v0/dev/user/update METHOD: PUT
ROUTE: delete PATH: https://api.stansberryterminal.com/v0/dev/user/delete METHOD: DELETE
ROUTE: entitlements PATH: https://api.stansberryterminal.com/v0/dev/user/entitlements METHOD: GET
ROUTE: logout PATH: https://api.stansberryterminal.com/v0/dev/user/logout METHOD: POST
ROUTE: list PATH: https://api.stansberryterminal.com/v0/dev/user/list METHOD: GET
ROUTE: stat PATH: https://api.stansberryterminal.com/v0/dev/user/stat METHOD: GET
ROUTE: tscontext PATH: https://api.stansberryterminal.com/v0/dev/user/tscontext METHOD: GET
ROUTE: pwd/update PATH: https://api.stansberryterminal.com/v0/dev/user/pwd/update METHOD: PUT
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Testing dev ApiGateway
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
URL:
https://api.stansberryterminal.com/v0/dev/user/create
DATA:
{"name": "Jonh Wick", "email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ==", "snaid": "SAC000578279737", "sungard_login": "test", "sungard_group": "STANSBERRY", "sungard_pwd": "welcome", "tradestop_user": "apitest3@tradestops.com", "tradestop_pwd": "FJaMLT9NBw", "modified": "1511316310", "symsel": "VMW", "pagesel": "dashboard", "chat_id": "test@stansberryresearch.com", "guid": "", "dashboard": [{"type": "generic-media", "label": "Media", "height": 14, "width": 4, "min_height": 1, "min_width": 4, "xpos": 0, "ypos": 0, "data": {"defaultSymbol": "GOOG"}, "wlist": []}, {"type": "stock-chart", "label": "Stock Chart", "height": 9, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 5, "data": {"identifier": "GOOG", "period": 2, "scale": 4}, "wlist": []}, {"type": "market-watch", "label": "Market Watch", "height": 5, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 0, "data": {"default-list": ""}, "wlist": [{"name": "Default List", "symbols": "AAPL,CVS,GOOG,VMW"}, {"name": "Test", "symbols": "IBM,FB"}]}, {"type": "market-overview", "label": "overview", "data": {"expanded": false, "selections": ["S&P", "NASDAQ", "GOLD", "OIL"]}}], "crypto": {"navsel": "btc", "data": {"cursel": {"btc": "eur", "dash": "usd", "eth": "gbp", "zec": "cad", "bch": "gbp"}}}, "summary": {"navsel": "insider metrics", "fundsel": "income", "period": "annual"}, "model": {"navsel": "efficiency model", "period": "quarterly", "data": {"screeners": ["Frist", "Second"]}, "valsel": "assumptions"}, "portfolio": {"navsel": "", "tradestops": {"tabsel": "portfolio position research", "portfoliotab": {"statsel": "open closed all"}, "positiontab": {"portfoliosel": "popular", "viewsel": "default fundamentals", "possel": "positions closed positions", "expandsummary": true}, "researchtab": {"symbol": "", "eprice": "", "tsp": 65}, "portfolios": [{"name": "popstocks", "currency": "", "cash": "", "brokerage": "", "notes": "", "positions": [{"symbol": "AAPL", "entry_date": "01/01/2017", "entry_price": "", "shares": "", "trade_type": "long short"}]}]}, "sbrportfolios": {"selection": "Income Portfolio"}, "sbrrecommends": {"selection": "Stansberry Gold & Silver Investor"}}}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'created': 'User test@stansberryresearch.com constructed', 'profile': {'name': 'Jonh Wick', 'email': 'test@stansberryresearch.com', 'snaid': 'SAC000578279737', 'sungard_login': 'test', 'sungard_group': 'STANSBERRY', 'sungard_pwd': 'welcome', 'modified': '1518081332', 'tradestop_user': 'apitest3@tradestops.com', 'tradestop_pwd': 'FJaMLT9NBw', 'chat_id': 'test@stansberryresearch.com', 'symsel': 'VMW', 'pagesel': 'dashboard', 'guid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'dashboard': [{'type': 'generic-media', 'label': 'Media', 'height': 14, 'width': 4, 'min_height': 1, 'min_width': 4, 'xpos': 0, 'ypos': 0, 'data': {'defaultSymbol': 'GOOG'}, 'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'guid': 'e92705fc-9028-4b41-84c3-c76f60caa118'}, {'type': 'stock-chart', 'label': 'Stock Chart', 'height': 9, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 5, 'data': {'identifier': 'GOOG', 'period': 2, 'scale': 4}, 'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'guid': 'ec3f055e-1f08-4736-9b12-9830f8448a24'}, {'type': 'market-watch', 'label': 'Market Watch', 'height': 5, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 0, 'data': {'default-list': ''}, 'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'guid': '37f06d52-f7eb-471b-bcbf-42562bf257db', 'wlist': [{'luid': '37f06d52-f7eb-471b-bcbf-42562bf257db', 'name': 'Default List', 'symbols': 'AAPL,CVS,GOOG,VMW', 'guid': '32c06cf0-b53a-4f5e-89a7-96ceb09fc786'}, {'luid': '37f06d52-f7eb-471b-bcbf-42562bf257db', 'name': 'Test', 'symbols': 'IBM,FB', 'guid': '8fa6c2d4-06d5-482c-b01a-b5e54fc966ab'}]}, {'type': 'market-overview', 'label': 'overview', 'height': -1, 'width': -1, 'min_height': -1, 'min_width': -1, 'xpos': -1, 'ypos': -1, 'data': {'expanded': False, 'selections': ['S&P', 'NASDAQ', 'GOLD', 'OIL']}, 'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'guid': '6ec74736-8f76-45e3-bd55-d0d72fca6bca'}], 'crypto': {'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'navsel': 'btc', 'data': {'cursel': {'btc': 'eur', 'dash': 'usd', 'eth': 'gbp', 'zec': 'cad', 'bch': 'gbp'}}}, 'summary': {'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'navsel': 'insider metrics', 'fundsel': 'income', 'period': 'annual'}, 'model': {'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'navsel': 'efficiency model', 'period': 'quarterly', 'data': {'screeners': ['Frist', 'Second']}}, 'portfolio': {'userid': 'f9b61708-9305-47f2-bb77-97c013cbe94e', 'navsel': '', 'tradestops': {'tabsel': 'portfolio position research', 'portfoliotab': {'statsel': 'open closed all'}, 'positiontab': {'portfoliosel': 'popular', 'viewsel': 'default fundamentals', 'possel': 'positions closed positions', 'expandsummary': True}, 'researchtab': {'symbol': '', 'eprice': '', 'tsp': 65}, 'portfolios': [{'name': 'popstocks', 'currency': '', 'cash': '', 'brokerage': '', 'notes': '', 'positions': [{'symbol': 'AAPL', 'entry_date': '01/01/2017', 'entry_price': '', 'shares': '', 'trade_type': 'long short'}]}]}, 'sbrportfolios': {'selection': 'Income Portfolio'}, 'sbrrecommends': {'selection': 'Stansberry Gold & Silver Investor'}}}}
URL:
https://api.stansberryterminal.com/v0/dev/user/delete
DATA:
{"email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ=="}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'user': 'test@stansberryresearch.com'}
URL:
https://api.stansberryterminal.com/v0/dev/user/create
DATA:
{"name": "Jonh Wick", "email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ==", "snaid": "SAC000578279737", "sungard_login": "test", "sungard_group": "STANSBERRY", "sungard_pwd": "welcome", "tradestop_user": "apitest3@tradestops.com", "tradestop_pwd": "FJaMLT9NBw", "modified": "1511316310", "symsel": "VMW", "pagesel": "dashboard", "chat_id": "test@stansberryresearch.com", "guid": "", "dashboard": [{"type": "generic-media", "label": "Media", "height": 14, "width": 4, "min_height": 1, "min_width": 4, "xpos": 0, "ypos": 0, "data": {"defaultSymbol": "GOOG"}, "wlist": []}, {"type": "stock-chart", "label": "Stock Chart", "height": 9, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 5, "data": {"identifier": "GOOG", "period": 2, "scale": 4}, "wlist": []}, {"type": "market-watch", "label": "Market Watch", "height": 5, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 0, "data": {"default-list": ""}, "wlist": [{"name": "Default List", "symbols": "AAPL,CVS,GOOG,VMW"}, {"name": "Test", "symbols": "IBM,FB"}]}, {"type": "market-overview", "label": "overview", "data": {"expanded": false, "selections": ["S&P", "NASDAQ", "GOLD", "OIL"]}}], "crypto": {"navsel": "btc", "data": {"cursel": {"btc": "eur", "dash": "usd", "eth": "gbp", "zec": "cad", "bch": "gbp"}}}, "summary": {"navsel": "insider metrics", "fundsel": "income", "period": "annual"}, "model": {"navsel": "efficiency model", "period": "quarterly", "data": {"screeners": ["Frist", "Second"]}, "valsel": "assumptions"}, "portfolio": {"navsel": "", "tradestops": {"tabsel": "portfolio position research", "portfoliotab": {"statsel": "open closed all"}, "positiontab": {"portfoliosel": "popular", "viewsel": "default fundamentals", "possel": "positions closed positions", "expandsummary": true}, "researchtab": {"symbol": "", "eprice": "", "tsp": 65}, "portfolios": [{"name": "popstocks", "currency": "", "cash": "", "brokerage": "", "notes": "", "positions": [{"symbol": "AAPL", "entry_date": "01/01/2017", "entry_price": "", "shares": "", "trade_type": "long short"}]}]}, "sbrportfolios": {"selection": "Income Portfolio"}, "sbrrecommends": {"selection": "Stansberry Gold & Silver Investor"}}}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'created': 'User test@stansberryresearch.com constructed', 'profile': {'name': 'Jonh Wick', 'email': 'test@stansberryresearch.com', 'snaid': 'SAC000578279737', 'sungard_login': 'test', 'sungard_group': 'STANSBERRY', 'sungard_pwd': 'welcome', 'modified': '1518081334', 'tradestop_user': 'apitest3@tradestops.com', 'tradestop_pwd': 'FJaMLT9NBw', 'chat_id': 'test@stansberryresearch.com', 'symsel': 'VMW', 'pagesel': 'dashboard', 'guid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'dashboard': [{'type': 'generic-media', 'label': 'Media', 'height': 14, 'width': 4, 'min_height': 1, 'min_width': 4, 'xpos': 0, 'ypos': 0, 'data': {'defaultSymbol': 'GOOG'}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '953d16f1-04b8-4270-a278-2b26f1bfcf60'}, {'type': 'stock-chart', 'label': 'Stock Chart', 'height': 9, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 5, 'data': {'identifier': 'GOOG', 'period': 2, 'scale': 4}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': 'c4660ea6-d8f2-4ffa-9be8-8baa72c8e30a'}, {'type': 'market-watch', 'label': 'Market Watch', 'height': 5, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 0, 'data': {'default-list': ''}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'wlist': [{'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Default List', 'symbols': 'AAPL,CVS,GOOG,VMW', 'guid': 'cbebc6e0-1fa9-4fa7-b909-7bf469cb6b1d'}, {'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Test', 'symbols': 'IBM,FB', 'guid': 'c2cad740-07ab-4769-a0af-ed2dddc3729b'}]}, {'type': 'market-overview', 'label': 'overview', 'height': -1, 'width': -1, 'min_height': -1, 'min_width': -1, 'xpos': -1, 'ypos': -1, 'data': {'expanded': False, 'selections': ['S&P', 'NASDAQ', 'GOLD', 'OIL']}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '7d4a5c0b-7f8b-433d-afae-2e897619fc7e'}], 'crypto': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'btc', 'data': {'cursel': {'btc': 'eur', 'dash': 'usd', 'eth': 'gbp', 'zec': 'cad', 'bch': 'gbp'}}}, 'summary': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'insider metrics', 'fundsel': 'income', 'period': 'annual'}, 'model': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'efficiency model', 'period': 'quarterly', 'data': {'screeners': ['Frist', 'Second']}}, 'portfolio': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': '', 'tradestops': {'tabsel': 'portfolio position research', 'portfoliotab': {'statsel': 'open closed all'}, 'positiontab': {'portfoliosel': 'popular', 'viewsel': 'default fundamentals', 'possel': 'positions closed positions', 'expandsummary': True}, 'researchtab': {'symbol': '', 'eprice': '', 'tsp': 65}, 'portfolios': [{'name': 'popstocks', 'currency': '', 'cash': '', 'brokerage': '', 'notes': '', 'positions': [{'symbol': 'AAPL', 'entry_date': '01/01/2017', 'entry_price': '', 'shares': '', 'trade_type': 'long short'}]}]}, 'sbrportfolios': {'selection': 'Income Portfolio'}, 'sbrrecommends': {'selection': 'Stansberry Gold & Silver Investor'}}}}
URL:
https://api.stansberryterminal.com/v0/dev/user/login
DATA:
{"email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ=="}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'user': 'Authenticated user test@stansberryresearch.com', 'apikey': "b'W9MPTN1scG8VPOvYnwJ2BQ=='"}
URL:
https://api.stansberryterminal.com/v0/dev/user/profile
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
Arg 0 : test@stansberryresearch.com
URL:
https://api.stansberryterminal.com/v0/dev/user/profile/test@stansberryresearch.com
status_code:200
Response
{'success': True, 'profile': {'name': 'Jonh Wick', 'email': 'test@stansberryresearch.com', 'snaid': 'SAC000578279737', 'sungard_login': 'test', 'sungard_group': 'STANSBERRY', 'sungard_pwd': 'welcome', 'modified': '1518081334', 'tradestop_user': 'apitest3@tradestops.com', 'tradestop_pwd': 'FJaMLT9NBw', 'chat_id': 'test@stansberryresearch.com', 'symsel': 'VMW', 'pagesel': 'dashboard', 'guid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'dashboard': [{'type': 'generic-media', 'label': 'Media', 'height': 14, 'width': 4, 'min_height': 1, 'min_width': 4, 'xpos': 0, 'ypos': 0, 'data': {'defaultSymbol': 'GOOG'}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '953d16f1-04b8-4270-a278-2b26f1bfcf60'}, {'type': 'stock-chart', 'label': 'Stock Chart', 'height': 9, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 5, 'data': {'identifier': 'GOOG', 'period': 2, 'scale': 4}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': 'c4660ea6-d8f2-4ffa-9be8-8baa72c8e30a'}, {'type': 'market-watch', 'label': 'Market Watch', 'height': 5, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 0, 'data': {'default-list': ''}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'wlist': [{'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Default List', 'symbols': 'AAPL,CVS,GOOG,VMW', 'guid': 'cbebc6e0-1fa9-4fa7-b909-7bf469cb6b1d'}, {'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Test', 'symbols': 'IBM,FB', 'guid': 'c2cad740-07ab-4769-a0af-ed2dddc3729b'}]}, {'type': 'market-overview', 'label': 'overview', 'height': -1, 'width': -1, 'min_height': -1, 'min_width': -1, 'xpos': -1, 'ypos': -1, 'data': {'expanded': False, 'selections': ['S&P', 'NASDAQ', 'GOLD', 'OIL']}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '7d4a5c0b-7f8b-433d-afae-2e897619fc7e'}], 'crypto': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'btc', 'data': {'cursel': {'btc': 'eur', 'dash': 'usd', 'eth': 'gbp', 'zec': 'cad', 'bch': 'gbp'}}}, 'summary': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'insider metrics', 'fundsel': 'income', 'period': 'annual'}, 'model': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'efficiency model', 'period': 'quarterly', 'data': {'screeners': ['Frist', 'Second']}}, 'portfolio': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': '', 'tradestops': {'tabsel': 'portfolio position research', 'portfoliotab': {'statsel': 'open closed all'}, 'positiontab': {'portfoliosel': 'popular', 'viewsel': 'default fundamentals', 'possel': 'positions closed positions', 'expandsummary': True}, 'researchtab': {'symbol': '', 'eprice': '', 'tsp': 65}, 'portfolios': [{'name': 'popstocks', 'currency': '', 'cash': '', 'brokerage': '', 'notes': '', 'positions': [{'symbol': 'AAPL', 'entry_date': '01/01/2017', 'entry_price': '', 'shares': '', 'trade_type': 'long short'}]}]}, 'sbrportfolios': {'selection': 'Income Portfolio'}, 'sbrrecommends': {'selection': 'Stansberry Gold & Silver Investor'}}}}
URL:
https://api.stansberryterminal.com/v0/dev/user/update
DATA:
{"name": "Jonh Wick Mod", "email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ==", "snaid": "SAC000578279737", "sungard_login": "test", "sungard_group": "STANSBERRY", "sungard_pwd": "welcome", "tradestop_user": "apitest3@tradestops.com", "tradestop_pwd": "FJaMLT9NBw", "modified": "1511316310", "symsel": "VMW", "pagesel": "dashboard", "chat_id": "test@stansberryresearch.com", "guid": "", "dashboard": [{"type": "generic-media", "label": "Media", "height": 14, "width": 4, "min_height": 1, "min_width": 4, "xpos": 0, "ypos": 0, "data": {"defaultSymbol": "GOOG"}, "wlist": []}, {"type": "stock-chart", "label": "Stock Chart", "height": 9, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 5, "data": {"identifier": "GOOG", "period": 2, "scale": 4}, "wlist": []}, {"type": "market-watch", "label": "Market Watch", "height": 5, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 0, "data": {"default-list": ""}, "wlist": [{"name": "Default List", "symbols": "AAPL,CVS,GOOG,VMW"}, {"name": "Test", "symbols": "IBM,FB"}]}, {"type": "market-overview", "label": "overview", "data": {"expanded": false, "selections": ["S&P", "NASDAQ", "GOLD", "OIL"]}}], "crypto": {"navsel": "btc", "data": {"cursel": {"btc": "eur", "dash": "usd", "eth": "gbp", "zec": "cad", "bch": "gbp"}}}, "summary": {"navsel": "insider metrics", "fundsel": "income", "period": "annual"}, "model": {"navsel": "efficiency model", "period": "quarterly", "data": {"screeners": ["Frist", "Second"]}, "valsel": "assumptions"}, "portfolio": {"navsel": "", "tradestops": {"tabsel": "portfolio position research", "portfoliotab": {"statsel": "open closed all"}, "positiontab": {"portfoliosel": "popular", "viewsel": "default fundamentals", "possel": "positions closed positions", "expandsummary": true}, "researchtab": {"symbol": "", "eprice": "", "tsp": 65}, "portfolios": [{"name": "popstocks", "currency": "", "cash": "", "brokerage": "", "notes": "", "positions": [{"symbol": "AAPL", "entry_date": "01/01/2017", "entry_price": "", "shares": "", "trade_type": "long short"}]}]}, "sbrportfolios": {"selection": "Income Portfolio"}, "sbrrecommends": {"selection": "Stansberry Gold & Silver Investor"}}}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True}
**Updating with response from get profile(uprofile)**
URL:
https://api.stansberryterminal.com/v0/dev/user/update
DATA:
{"name": "Jonh Wick Mod", "email": "test@stansberryresearch.com", "snaid": "SAC000578279737", "sungard_login": "test", "sungard_group": "STANSBERRY", "sungard_pwd": "welcome", "modified": "1518081334", "tradestop_user": "apitest3@tradestops.com", "tradestop_pwd": "FJaMLT9NBw", "chat_id": "test@stansberryresearch.com", "symsel": "VMW", "pagesel": "dashboard", "guid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "dashboard": [{"type": "generic-media", "label": "Media", "height": 14, "width": 4, "min_height": 1, "min_width": 4, "xpos": 0, "ypos": 0, "data": {"defaultSymbol": "GOOG"}, "userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "guid": "953d16f1-04b8-4270-a278-2b26f1bfcf60"}, {"type": "stock-chart", "label": "Stock Chart", "height": 9, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 5, "data": {"identifier": "GOOG", "period": 2, "scale": 4}, "userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "guid": "c4660ea6-d8f2-4ffa-9be8-8baa72c8e30a"}, {"type": "market-watch", "label": "Market Watch", "height": 5, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 0, "data": {"default-list": ""}, "userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "guid": "452dd6c8-190a-4ed8-b882-cda65f35e478", "wlist": [{"luid": "452dd6c8-190a-4ed8-b882-cda65f35e478", "name": "Default List", "symbols": "AAPL,CVS,GOOG,VMW", "guid": "cbebc6e0-1fa9-4fa7-b909-7bf469cb6b1d"}, {"luid": "452dd6c8-190a-4ed8-b882-cda65f35e478", "name": "Test", "symbols": "IBM,FB", "guid": "c2cad740-07ab-4769-a0af-ed2dddc3729b"}]}, {"type": "market-overview", "label": "overview", "height": -1, "width": -1, "min_height": -1, "min_width": -1, "xpos": -1, "ypos": -1, "data": {"expanded": false, "selections": ["S&P", "NASDAQ", "GOLD", "OIL"]}, "userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "guid": "7d4a5c0b-7f8b-433d-afae-2e897619fc7e"}], "crypto": {"userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "navsel": "btc", "data": {"cursel": {"btc": "eur", "dash": "usd", "eth": "gbp", "zec": "cad", "bch": "gbp"}}}, "summary": {"userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "navsel": "insider metrics", "fundsel": "income", "period": "annual"}, "model": {"userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "navsel": "efficiency model", "period": "quarterly", "data": {"screeners": ["Frist", "Second"]}}, "portfolio": {"userid": "f09b208d-5724-41bc-aa76-4dab51858fd2", "navsel": "", "tradestops": {"tabsel": "portfolio position research", "portfoliotab": {"statsel": "open closed all"}, "positiontab": {"portfoliosel": "popular", "viewsel": "default fundamentals", "possel": "positions closed positions", "expandsummary": true}, "researchtab": {"symbol": "", "eprice": "", "tsp": 65}, "portfolios": [{"name": "popstocks", "currency": "", "cash": "", "brokerage": "", "notes": "", "positions": [{"symbol": "AAPL", "entry_date": "01/01/2017", "entry_price": "", "shares": "", "trade_type": "long short"}]}]}, "sbrportfolios": {"selection": "Income Portfolio"}, "sbrrecommends": {"selection": "Stansberry Gold & Silver Investor"}}}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True}
URL:
https://api.stansberryterminal.com/v0/dev/user/entitlements
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
Arg 0 : test@stansberryresearch.com
URL:
https://api.stansberryterminal.com/v0/dev/user/entitlements/test@stansberryresearch.com
status_code:400
Response
None
Get Entitlements test@stansberryresearch.com Failed
URL:
https://api.stansberryterminal.com/v0/dev/user/list
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'users': ['test@stansberryresearch.com']}
URL:
https://api.stansberryterminal.com/v0/dev/user/active
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
Arg 0 : test@stansberryresearch.com
URL:
https://api.stansberryterminal.com/v0/dev/user/active/test@stansberryresearch.com
status_code:200
Response
{'success': True, 'activity': '2018-02-07 23:15:39.689325'}
URL:
https://api.stansberryterminal.com/v0/dev/user/dashboard
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
Arg 0 : test@stansberryresearch.com
URL:
https://api.stansberryterminal.com/v0/dev/user/dashboard/test@stansberryresearch.com
status_code:200
Response
{'success': True, 'dashboard': [{'type': 'generic-media', 'label': 'Media', 'height': 14, 'width': 4, 'min_height': 1, 'min_width': 4, 'xpos': 0, 'ypos': 0, 'data': {'defaultSymbol': 'GOOG'}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '953d16f1-04b8-4270-a278-2b26f1bfcf60'}, {'type': 'stock-chart', 'label': 'Stock Chart', 'height': 9, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 5, 'data': {'identifier': 'GOOG', 'period': 2, 'scale': 4}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': 'c4660ea6-d8f2-4ffa-9be8-8baa72c8e30a'}, {'type': 'market-watch', 'label': 'Market Watch', 'height': 5, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 0, 'data': {'default-list': ''}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'wlist': [{'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Default List', 'symbols': 'AAPL,CVS,GOOG,VMW', 'guid': 'cbebc6e0-1fa9-4fa7-b909-7bf469cb6b1d'}, {'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Test', 'symbols': 'IBM,FB', 'guid': 'c2cad740-07ab-4769-a0af-ed2dddc3729b'}]}, {'type': 'market-overview', 'label': 'overview', 'height': -1, 'width': -1, 'min_height': -1, 'min_width': -1, 'xpos': -1, 'ypos': -1, 'data': {'expanded': False, 'selections': ['S&P', 'NASDAQ', 'GOLD', 'OIL']}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '7d4a5c0b-7f8b-433d-afae-2e897619fc7e'}]}
URL:
https://api.stansberryterminal.com/v0/dev/user/stat
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
Arg 0 : test@stansberryresearch.com
URL:
https://api.stansberryterminal.com/v0/dev/user/stat/test@stansberryresearch.com
status_code:200
Response
{'success': True, 'stats': {'timestamp': '2018-02-07 23:15:42.087058', 'entitlements': [], 'profile': {'name': 'Jonh Wick Mod', 'email': 'test@stansberryresearch.com', 'snaid': 'SAC000578279737', 'sungard_login': 'test', 'sungard_group': 'STANSBERRY', 'sungard_pwd': 'welcome', 'modified': '1518081339', 'tradestop_user': 'apitest3@tradestops.com', 'tradestop_pwd': 'FJaMLT9NBw', 'chat_id': 'test@stansberryresearch.com', 'symsel': 'VMW', 'pagesel': 'dashboard', 'guid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'dashboard': [{'type': 'generic-media', 'label': 'Media', 'height': 14, 'width': 4, 'min_height': 1, 'min_width': 4, 'xpos': 0, 'ypos': 0, 'data': {'defaultSymbol': 'GOOG'}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '953d16f1-04b8-4270-a278-2b26f1bfcf60'}, {'type': 'stock-chart', 'label': 'Stock Chart', 'height': 9, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 5, 'data': {'identifier': 'GOOG', 'period': 2, 'scale': 4}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': 'c4660ea6-d8f2-4ffa-9be8-8baa72c8e30a'}, {'type': 'market-watch', 'label': 'Market Watch', 'height': 5, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 0, 'data': {'default-list': ''}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'wlist': [{'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Default List', 'symbols': 'AAPL,CVS,GOOG,VMW', 'guid': 'cbebc6e0-1fa9-4fa7-b909-7bf469cb6b1d'}, {'luid': '452dd6c8-190a-4ed8-b882-cda65f35e478', 'name': 'Test', 'symbols': 'IBM,FB', 'guid': 'c2cad740-07ab-4769-a0af-ed2dddc3729b'}]}, {'type': 'market-overview', 'label': 'overview', 'height': -1, 'width': -1, 'min_height': -1, 'min_width': -1, 'xpos': -1, 'ypos': -1, 'data': {'expanded': False, 'selections': ['S&P', 'NASDAQ', 'GOLD', 'OIL']}, 'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'guid': '7d4a5c0b-7f8b-433d-afae-2e897619fc7e'}], 'crypto': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'btc', 'data': {'cursel': {'btc': 'eur', 'dash': 'usd', 'eth': 'gbp', 'zec': 'cad', 'bch': 'gbp'}}}, 'summary': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'insider metrics', 'fundsel': 'income', 'period': 'annual'}, 'model': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': 'efficiency model', 'period': 'quarterly', 'data': {'screeners': ['Frist', 'Second']}}, 'portfolio': {'userid': 'f09b208d-5724-41bc-aa76-4dab51858fd2', 'navsel': '', 'tradestops': {'tabsel': 'portfolio position research', 'portfoliotab': {'statsel': 'open closed all'}, 'positiontab': {'portfoliosel': 'popular', 'viewsel': 'default fundamentals', 'possel': 'positions closed positions', 'expandsummary': True}, 'researchtab': {'symbol': '', 'eprice': '', 'tsp': 65}, 'portfolios': [{'name': 'popstocks', 'currency': '', 'cash': '', 'brokerage': '', 'notes': '', 'positions': [{'symbol': 'AAPL', 'entry_date': '01/01/2017', 'entry_price': '', 'shares': '', 'trade_type': 'long short'}]}]}, 'sbrportfolios': {'selection': 'Income Portfolio'}, 'sbrrecommends': {'selection': 'Stansberry Gold & Silver Investor'}}}, 'apikey': "b'byRVYg7BIk1bNQ4/0re8eA=='", 'screeners': []}}
URL:
https://api.stansberryterminal.com/v0/dev/user/tscontext
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
Arg 0 : test@stansberryresearch.com
URL:
https://api.stansberryterminal.com/v0/dev/user/tscontext/test@stansberryresearch.com
status_code:200
Response
{'success': True, 'ContextKey': 'dbcf87d8-6fd4-43ae-8def-9728890f1328'}
URL:
https://api.stansberryterminal.com/v0/dev/user/logout
DATA:
{"email": "test@stansberryresearch.com"}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'user': 'Logged out user test@stansberryresearch.com'}
URL:
https://api.stansberryterminal.com/v0/dev/user/login
DATA:
{"email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ=="}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'user': 'Authenticated user test@stansberryresearch.com', 'apikey': "b'/+ZO3xXaZlftjxQI8GvDzQ=='"}
URL:
https://api.stansberryterminal.com/v0/dev/user/logout
DATA:
{"email": "test@stansberryresearch.com"}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'user': 'Logged out user test@stansberryresearch.com'}
URL:
https://api.stansberryterminal.com/v0/dev/user/login
DATA:
{"email": "test@stansberryresearch.com", "passwd": "incorrect_passwd"}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': False, 'error': 'Unable to authenticate user test@stansberryresearch.com'}
URL:
https://api.stansberryterminal.com/v0/dev/user/login
DATA:
{"email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ=="}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'user': 'Authenticated user test@stansberryresearch.com', 'apikey': "b'tijeKRFlrE49HkyiqbEJww=='"}
URL:
https://api.stansberryterminal.com/v0/dev/user/update
DATA:
{"name": "Jonh Wick Mod", "email": "test@stansberryresearch.com", "passwd": "\ufeffe83d438db4e8a7a060f65942da269ed8", "snaid": "SAC000578279737", "sungard_login": "test", "sungard_group": "STANSBERRY", "sungard_pwd": "welcome", "tradestop_user": "apitest3@tradestops.com", "tradestop_pwd": "FJaMLT9NBw", "modified": "1511316310", "symsel": "VMW", "pagesel": "dashboard", "chat_id": "test@stansberryresearch.com", "guid": "", "dashboard": [{"type": "generic-media", "label": "Media", "height": 14, "width": 4, "min_height": 1, "min_width": 4, "xpos": 0, "ypos": 0, "data": {"defaultSymbol": "GOOG"}, "wlist": []}, {"type": "stock-chart", "label": "Stock Chart", "height": 9, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 5, "data": {"identifier": "GOOG", "period": 2, "scale": 4}, "wlist": []}, {"type": "market-watch", "label": "Market Watch", "height": 5, "width": 8, "min_height": 1, "min_width": 4, "xpos": 4, "ypos": 0, "data": {"default-list": ""}, "wlist": [{"name": "Default List", "symbols": "AAPL,CVS,GOOG,VMW"}, {"name": "Test", "symbols": "IBM,FB"}]}, {"type": "market-overview", "label": "overview", "data": {"expanded": false, "selections": ["S&P", "NASDAQ", "GOLD", "OIL"]}}], "crypto": {"navsel": "btc", "data": {"cursel": {"btc": "eur", "dash": "usd", "eth": "gbp", "zec": "cad", "bch": "gbp"}}}, "summary": {"navsel": "insider metrics", "fundsel": "income", "period": "annual"}, "model": {"navsel": "efficiency model", "period": "quarterly", "data": {"screeners": ["Frist", "Second"]}, "valsel": "assumptions"}, "portfolio": {"navsel": "", "tradestops": {"tabsel": "portfolio position research", "portfoliotab": {"statsel": "open closed all"}, "positiontab": {"portfoliosel": "popular", "viewsel": "default fundamentals", "possel": "positions closed positions", "expandsummary": true}, "researchtab": {"symbol": "", "eprice": "", "tsp": 65}, "portfolios": [{"name": "popstocks", "currency": "", "cash": "", "brokerage": "", "notes": "", "positions": [{"symbol": "AAPL", "entry_date": "01/01/2017", "entry_price": "", "shares": "", "trade_type": "long short"}]}]}, "sbrportfolios": {"selection": "Income Portfolio"}, "sbrrecommends": {"selection": "Stansberry Gold & Silver Investor"}}}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True}
Update test@stansberryresearch.com did not fail
URL:
https://api.stansberryterminal.com/v0/dev/user/profile
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
Arg 0 : test@stansberryresearch.com
URL:
https://api.stansberryterminal.com/v0/dev/user/profile/test@stansberryresearch.com
status_code:200
Response
{'success': True, 'profile': {'name': 'Jonh Wick Mod', 'email': 'test@stansberryresearch.com', 'snaid': 'SAC000578279737', 'sungard_login': 'test', 'sungard_group': 'STANSBERRY', 'sungard_pwd': 'welcome', 'modified': '1518081356', 'tradestop_user': 'apitest3@tradestops.com', 'tradestop_pwd': 'FJaMLT9NBw', 'chat_id': 'test@stansberryresearch.com', 'symsel': 'VMW', 'pagesel': 'dashboard', 'guid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'dashboard': [{'type': 'generic-media', 'label': 'Media', 'height': 14, 'width': 4, 'min_height': 1, 'min_width': 4, 'xpos': 0, 'ypos': 0, 'data': {'defaultSymbol': 'GOOG'}, 'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'guid': '9bd7c57c-f1f4-4de2-b68b-125ef076282d'}, {'type': 'stock-chart', 'label': 'Stock Chart', 'height': 9, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 5, 'data': {'identifier': 'GOOG', 'period': 2, 'scale': 4}, 'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'guid': '0cd48aff-ea89-4915-a729-1a3680cf7e0e'}, {'type': 'market-watch', 'label': 'Market Watch', 'height': 5, 'width': 8, 'min_height': 1, 'min_width': 4, 'xpos': 4, 'ypos': 0, 'data': {'default-list': ''}, 'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'guid': '94b89d42-4e0c-460b-b0ab-3eff25970f76', 'wlist': [{'luid': '94b89d42-4e0c-460b-b0ab-3eff25970f76', 'name': 'Default List', 'symbols': 'AAPL,CVS,GOOG,VMW', 'guid': 'f1548669-15a4-4e35-9fbe-975468534baa'}, {'luid': '94b89d42-4e0c-460b-b0ab-3eff25970f76', 'name': 'Test', 'symbols': 'IBM,FB', 'guid': '9b368fe5-a286-4456-8f93-736845cc81cc'}]}, {'type': 'market-overview', 'label': 'overview', 'height': -1, 'width': -1, 'min_height': -1, 'min_width': -1, 'xpos': -1, 'ypos': -1, 'data': {'expanded': False, 'selections': ['S&P', 'NASDAQ', 'GOLD', 'OIL']}, 'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'guid': '4c58276f-e3e1-4b6e-8d3b-da1f7c5fac70'}], 'crypto': {'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'navsel': 'btc', 'data': {'cursel': {'btc': 'eur', 'dash': 'usd', 'eth': 'gbp', 'zec': 'cad', 'bch': 'gbp'}}}, 'summary': {'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'navsel': 'insider metrics', 'fundsel': 'income', 'period': 'annual'}, 'model': {'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'navsel': 'efficiency model', 'period': 'quarterly', 'data': {'screeners': ['Frist', 'Second']}}, 'portfolio': {'userid': '6b44e13e-6beb-4536-a11d-81fbcfeb5948', 'navsel': '', 'tradestops': {'tabsel': 'portfolio position research', 'portfoliotab': {'statsel': 'open closed all'}, 'positiontab': {'portfoliosel': 'popular', 'viewsel': 'default fundamentals', 'possel': 'positions closed positions', 'expandsummary': True}, 'researchtab': {'symbol': '', 'eprice': '', 'tsp': 65}, 'portfolios': [{'name': 'popstocks', 'currency': '', 'cash': '', 'brokerage': '', 'notes': '', 'positions': [{'symbol': 'AAPL', 'entry_date': '01/01/2017', 'entry_price': '', 'shares': '', 'trade_type': 'long short'}]}]}, 'sbrportfolios': {'selection': 'Income Portfolio'}, 'sbrrecommends': {'selection': 'Stansberry Gold & Silver Investor'}}}}
URL:
https://api.stansberryterminal.com/v0/dev/user/delete
DATA:
{"email": "test@stansberryresearch.com", "passwd": "d2VsY29tZQ=="}
HEADERS:
{'Content-type': 'application/json', 'Accept': 'text/plain'}
status_code:200
Response
{'success': True, 'user': 'test@stansberryresearch.com'}
--------------------------------------------------------------------
Testing dev Complete
--------------------------------------------------------------------

Process finished with exit code 0
"""
