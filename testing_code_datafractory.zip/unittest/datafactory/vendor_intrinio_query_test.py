import unittest
import logging
from intrinio_query import IntrinioQuery
from sbt_common import SbtCommon

"""
  Unit tests for SbtCommon 
"""
class IntrinioQueryTest (unittest.TestCase):
    logger = SbtCommon().get_logger(logging.INFO, 'IntrinioQueryTest')

    """
      Called on class setup.
      
      Args :
          cls (class) : Current class
    """
    @classmethod
    def setUpClass(cls):
      IntrinioQueryTest.logger.info('Unit Testing the IntrinioQuery Class')
    
    """
      Test the is_empty method in the StringUtil inner class
    """  
    def test_query_dynamodb(self):
      sbtcommon = SbtCommon()
      self.logger.info('IntrinioQuery.query_dynamodb unit tests') 
      iquery = IntrinioQuery()
      self.assertTrue(len(iquery.query_dynamodb('AAPL', 2015)) > 0, 
                          'AAPL was not found in database.')


if __name__ == '__main__':
    unittest.main()
