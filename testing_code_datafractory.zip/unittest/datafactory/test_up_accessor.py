import sys

from up_accessor import UserProfileAccessor
from sbt_common import SbtGlobalCommon

def main(argc):
  """
  :param argc: Is the argument count or len for sys.argv
  :return: 0 on succes 1 otherwise
  """
  if argc == 3:
    try:
      f = open(sys.argv[2], 'r')
      p = json.loads(f.read())
      f.close()

      sbtcommon = SbtGlobalCommon
      cfg = sbtcommon.get_config(sys.argv[1])
      db = UserProfileAccessor(cfg)
      logger = SbtGlobalCommon.get_global_logger()

      c = db.get_tscontext('')
      logger.debug('TSContext: ' + c)

      e = db.getentitlements('ruthko@aol.com')
      logger.debug('Entitlements...' +  '\n' + str(e))

      if not db.addprofile(p):
        logger.debug('Error: unable to add user')

      ul = db.getusers()
      logger.debug('User list: ' + str(ul))

      p = db.getprofile('test@stansberryresearch.com')
      logger.debug('Profile output\n' + str(p))

      f = open('./updateprofile.json', 'r')
      up = json.loads(f.read())
      f.close()

      u = db.update_profile(up)
      if not u:
        logger.debug('Error updating profile')

      d = db.deleteprofile(up['email'])
      if not d:
        logger.debug('Error deleting profile')

      logger.debug('Profile...\n' + json.dumps(p))
    except Exception as e:
      print('Error: Encountered exception ' + str(e))
      exit(1)
  else:
    print('\nUsage: python args...\n' +
                 '  argv[0]: program\n' +
                 '  argv[1]: config file\n' +
                 '  argv[2]: qualified path user profile file name (.json)\n' +
                 '  Ex: python profileacessor.py userprofile.cfg exprofile.json\n'
                )
    exit(1)

  exit(0)

if __name__ == '__main__':
  argc = len(sys.argv)
  main(argc)
