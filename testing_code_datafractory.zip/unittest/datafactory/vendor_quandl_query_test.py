import unittest
import logging
from quandl_query import QuandlDbQuery
from sbt_common import SbtCommon

"""
  Unit tests for SbtCommon 
"""
class IntrinioQueryTest (unittest.TestCase):
    logger = SbtCommon().get_logger(logging.INFO, 'QuandlQueryTest')

    """
      Called on class setup.
      
      Args :
          cls (class) : Current class
    """
    @classmethod
    def setUpClass(cls):
      IntrinioQueryTest.logger.info('Unit Testing the QuandlQuery Class')
    
    """
      Test the is_empty method in the StringUtil inner class
    """  
    def test_query_dynamodb(self):
      sbtcommon = SbtCommon()
      self.logger.info('IntrinioQuery.query_dynamodb unit tests') 
      qquery = QuandlDbQuery()
      temp = qquery.query_dynamodb('AAPL', '2015')
      self.assertTrue(len(temp) > 0, 
                          'AAPL was not found in database.')


if __name__ == '__main__':
    unittest.main()
