import itertools
import os
import sys
from io import StringIO

import simplejson as json
import pandas as pd
import requests
import sqlalchemy
from bs4 import BeautifulSoup
import re
import decimal
from decimal import Decimal
import time
import datetime
from pymongo import MongoClient
import logging

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']

mongo_client = MongoClient(
    "mongodb+srv://{username}:{password}@terminal-default-kguz9.mongodb.net/test?retryWrites=true".format(
        username="terminal-mongo-user",
        password="6Zjb07JNwJQz5VIJ",
        database="stansberry_terminal_dev"
    )
)


class FredApi(object):
    def __init__(self):
        self._URL = "https://fred.stlouisfed.org/graph/fredgraph.csv?id="

        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

    def get_data(self, symbol):
        # get the data from the URL
        df = pd.read_csv(self._URL + symbol,
                         names=('date', 'value'),
                         header=None)
        # remove "header"
        df.drop([0], inplace=True)
        # reset index after dropping "header"
        df.reset_index(drop=True)
        # convert non-numeric items into NaN
        df['value'] = pd.to_numeric(df['value'], errors='coerce')
        # drop any index that has at least one NaN
        df.dropna(axis=0, how='any', inplace=True)

        # normalize the data to the US dollar
        if (symbol.startswith("DEX")) or (symbol.startswith("EX")):
            new_symbol = symbol.replace("DEX", "")
            if len(new_symbol) == 4:
                from_curr = new_symbol[:2]
            if from_curr == 'US':
                df['value'] = 1. / df['value']

        # convert df to JSON
        res = json.loads(df.to_json(orient='records'), use_decimal=True)

        return res

    @staticmethod
    def pull_data(symbol):
        url = "https://fred.stlouisfed.org/data/" + symbol + ".txt"
        hdr = {'User-Agent': 'we dont want to wait for more requests /u/m&j'}
        response = requests.get(url, stream=True, headers=hdr)
        soup = BeautifulSoup(response.text, "html.parser")
        split_txt = soup.text.splitlines()
        meta = True
        meta_dict = {}
        meta_dict['notes'] = ''
        data_dict = {}
        for el in split_txt:
            try:
                if meta:
                    if '' == el:
                        pass
                    elif ' ' == el[0]:
                        meta_dict['notes'] += el.replace(
                            '                     ', ' ')
                    elif 'DATE' in el:
                        meta = False
                    elif 'Series' in el[:10] or 'Seasonal' in el[
                                                              :10] or 'Date Range' in el[
                                                                                      :10] or 'Last' in el[
                                                                                                        :10]:
                        tab_split = el.split(None, 2)
                        tab_split = [tab_split[0] + '_' + tab_split[1],
                                     tab_split[2]]
                        meta_dict[tab_split[0].lower().replace(':', '')] = \
                        tab_split[1]
                    else:
                        tab_split = el.split(None, 1)
                        if len(tab_split) == 1:
                            meta_dict[
                                tab_split[0].lower().replace(':', '')] = ''
                        else:
                            meta_dict[tab_split[0].lower().replace(':', '')] = \
                            tab_split[1]
                else:
                    tab_split = el.split(None, 1)
                    data_dict[tab_split[0].lower().replace(':', '')] = \
                    tab_split[1]
            except IndexError as e:
                pass

        format_data = []
        for k, v in data_dict.items():
            if v == '.':
                pass
            # format_data.append({'date': k, 'value': decimal.Decimal('NaN')})
            else:
                format_data.append({'date': k, 'value': decimal.Decimal(v)})
        return format_data, meta_dict

    # Returns time series data for a given FRED symbol
    def get_data_updated(self, symbol):
        return self.pull_data(symbol)[0]

    # Returns metadata for a given FRED symbol
    def get_meta_data(self, symbol):
        return self.pull_data(symbol)[1]

    @staticmethod
    # This method retrieves tags for a given symbol from FRED
    def get_tags(symbol):
        url = "https://fred.stlouisfed.org/series/" + symbol
        hdr = {'User-Agent': 'we dont want to wait for more requests /u/m&j'}
        response = requests.get(url, stream=True, headers=hdr)
        soup = BeautifulSoup(response.text, "html.parser")

        # finding all the anchor attributes that contain information about the CIK
        results = soup.find_all("a", href=re.compile(
            r'/tags/series?'))

        tags = []
        for x in results:
            x = str(x)
            x = re.sub('\n', '', x)
            x = re.sub('</a>', '', x)
            x = re.sub('            ', '', x)
            x = re.sub('        ', '', x)
            tags.append(str(x).split('target="_blank">', 1)[1])
        return tags


class FredAccessor(object):
    def __init__(self):
        self._fred = FredApi()

        self.ts_table_name = "timeseries_external_data"

        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # read the entire config file
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        ### PG
        # get the config for data factory DB
        self._pg_df = config['dev']['postgres']['datafactory']
        self._pg_df_engine = self._create_pg_engine(self._pg_df)

        self._pg_df_qa = config['qa']['postgres']['datafactory']
        self._pg_df_qa_engine = self._create_pg_engine(self._pg_df_qa)

        self._pg_df_prod = config['prod']['postgres']['datafactory']
        self._pg_df_prod_engine = self._create_pg_engine(self._pg_df_prod)

        self.fred_data = {}
        self.transformed_data_df = None

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_df_engine,
                             'QA': self._pg_df_qa_engine,
                             'PROD': self._pg_df_prod_engine}

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def to_pg(self, df, table_name, col_order=None, drop_previous_table=False):
        data = StringIO()
        # write to CSV format
        if col_order is not None:
            df.to_csv(data, columns=col_order, header=False, index=False)
        else:
            df.to_csv(data, header=False, index=False)
        # save to all envs
        for env in ENVS_TO_UPDATE:
            # get engine
            con = self.db_to_update.get(env.upper())
            # set pointer to the beginning of file
            data.seek(0)
            # get raw connection
            raw = con.raw_connection()
            # get cursor
            curs = raw.cursor()
            if drop_previous_table:
                # drop previous table
                try:
                    curs.execute("DROP TABLE IF EXISTS {}".format(table_name))
                except:
                    self._logger.info("COULDN'T DROP TABLE {}".format(table_name))

                empty_table = pd.io.sql.get_schema(df, table_name, con=con)
                # remove undesired characters
                empty_table = empty_table.replace('"', '')
                empty_table = empty_table.replace('\t', '')

                curs.execute(empty_table)
            # copy from CSV format to table
            curs.copy_expert(
                """COPY {} FROM STDIN WITH (FORMAT CSV)""".format(table_name),
                data)
            # commit transactions
            curs.connection.commit()

    def transform_data(self):
        # normalizing schema for timeseries
        transformed_data = [[
            {
                "id": "{}:{}".format(k, v1.get("timestamp")),
                "composite_pk_id": "{}:FRED".format(k),
                "timestamp": datetime.datetime.fromtimestamp(v1.get("timestamp")),
                "value": v1.get("values").get("value"),
                "updated_at": datetime.datetime.now()
            } for v1 in v] for k, v in self.fred_data.items()]

        # create df from flattened list of lists
        self.transformed_data_df = pd.DataFrame(
            list(itertools.chain(*transformed_data))
        )

    def load_data(self):
        # get the db
        db = mongo_client.stansberry_terminal_dev
        # get the collections
        static_dataset_collection = db.static_sbt_symbol_exchange_mapping
        # parse Collection into list of dict
        fred_items = \
            [x for x in static_dataset_collection.find({'source': 'FRED'})
             if not x.get("symbol").count("_SENTIMENT")]
        # remove _id attribute
        for i, x in enumerate(fred_items):
            fred_items[i].pop('_id')

        for i, item in enumerate(fred_items):
            try:
                data = self._fred.pull_data(item['symbol'])[0]
                self.fred_data[item['symbol']] = [
                    {
                        'guid': item['guid'],
                        'date': x['date'],
                        'values': {'value': float(x['value'])},
                        'timestamp':
                            int(datetime.datetime.strptime(x['date'], "%Y-%m-%d").timestamp())
                    } for x in data
                ]
                self._logger.info(' ({:4d}) SYMBOL {} IS DONE.'.format(i+1, item['symbol']))
            except Exception as e:
                self._logger.info('Error retrieving data from FRED')

        self._logger.info("STOP.")

    def run(self):
        self.load_data()
        self.transform_data()
        self.to_pg(df=self.transformed_data_df,
                   table_name=self.ts_table_name,
                   drop_previous_table=True)


if __name__ == '__main__':
    # fred = FredApi()
    # fred.pull_data('M1SL')
    fred_load = FredAccessor()
    """
    Available exchange rates:
      US / Euro Foreign Exchange Rate (DEXUSEU)
      China / US Foreign Exchange Rate (DEXCHUS)
      Japan / US Foreign Exchange Rate (DEXJPUS)
      US / UK Foreign Exchange Rate (DEXUSUK)
      Canada / US Foreign Exchange Rate (DEXCAUS)
      South Korea / US Foreign Exchange Rate (DEXKOUS)
      Brazil / US Foreign Exchange Rate (DEXBZUS)
      US / Australia Foreign Exchange Rate (DEXUSAL)
      India / US Foreign Exchange Rate (DEXINUS)
      Switzerland / US Foreign Exchange Rate (DEXSZUS)
      Sweden / US Foreign Exchange Rate (DEXSDUS)
      Hong Kong / US Foreign Exchange Rate (DEXHKUS)
      Denmark / US Foreign Exchange Rate (DEXDNUS)
      Mexico / US Foreign Exchange Rate (DEXMXUS)
      National Currency to US Exchange Rate: Average of Daily Rates for Germany (CCUSMA02DEM618N)
      South Africa / US Foreign Exchange Rate (DEXSFUS)
      Venezuela / US Foreign Exchange Rate (DEXVZUS)
      Norway / US Exchange Rate (EXNOUS)
      US / New Zealand Foreign Exchange Rate (DEXUSNZ)
      Sri Lanka / US Foreign Exchange Rate (DEXSLUS)
    """
    # res = fred.get_data('DEXUSUK')
    # res = fred.get_data_updated('DEXUSUK')
    # res = fred.get_meta_data('86565C_FO_L_ALL')
    #  res = fred.get_data('USREC')
    fred_load.run()
    # print(res['units'])
