import os
import re
import sys
from io import StringIO
import datetime
import itertools

import sqlalchemy
from pymongo import MongoClient
import pandas as pd
import simplejson as json
import logging

from sqlalchemy import text

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']

mongo_client = MongoClient("mongodb://default-read:A3afhKZe3FVybkRk@secure-shard-00-00-hbyld.mongodb.net:27017,secure-shard-00-01-hbyld.mongodb.net:27017,secure-shard-00-02-hbyld.mongodb.net:27017/secure?ssl=true&replicaSet=secure-shard-0&authSource=admin&retryWrites=true&w=majority")


class Screener(object):
    """
    Class to initialize the Postgres Screener table from scratch.
    """

    def __init__(self):

        # table to be created to contain all available items for selection
        self.FINANCIAL_PARAMETERS = 'new_screener_financial_parameters'
        # table to contain all the staging data
        self.SCREENER_STAGING = 'new_screener_staging'
        # table to contain all the companies info
        self.SCREENER_COMPANY = 'new_screener_company'
        # table to be used for data queries
        self.SCREENER_DATA = 'new_screener_data'
        # table with dataitem descriptions and units
        self.SCREENER_DESCRIPTION_TABLE = 'new_screener_data_description'

        # table to read the ticker symbols from
        self._SUPPORTED_SECURITIES_TABLE_NAME = 'v2mv_sbt_company'

        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # read the entire config file
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        # PG DB
        # get the config for XPF DB
        self._pg_snp = config['dev']['postgres']['snpsource']
        self._pg_snp_engine = self._create_pg_engine(self._pg_snp)

        # get the config for sbtcompanyfin DB
        self._pg_snpfin = config['dev']['postgres']['snpcompanyfinancials']
        self._pg_snpfin_engine = self._create_pg_engine(self._pg_snpfin)

        # get the config for datafactory DB
        self._pg_df = config['dev']['postgres']['datafactory']
        self._pg_df_engine = self._create_pg_engine(self._pg_df)

        self._pg_df_qa = config['qa']['postgres']['datafactory']
        self._pg_df_qa_engine = self._create_pg_engine(self._pg_df_qa)

        self._pg_df_prod = config['prod']['postgres']['datafactory']
        self._pg_df_prod_engine = self._create_pg_engine(self._pg_df_prod)

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_df_engine,
                             'QA': self._pg_df_qa_engine,
                             'PROD': self._pg_df_prod_engine}

        # exchange_symbol mapping (from ES loader)
        self.EXCHANGE_MAPPING = {
            'Nasdaq': 'NSDQ',
            'NASDAQ': 'NSDQ',
            'NasdaqGS': 'NSDQ',
            'NasdaqGM': 'NSDQ',
            'NasdaqCM': 'NSDQCM',
            'ARCA': 'NYSEARCA',
        }
        self.SB_EXCHANGE_MAPPING = {
            'TSX': 'TO',
            'LSE': 'L',
            'AIM': 'L',
            'SEHK': 'HK',
            'TSXV': 'V',
            'PAR': 'PA',
            'STO': 'ST',
            'BSE': 'BR',
            'JPX': 'T',
            'CSE': 'CO',
            'FWB': 'DE',
            'SIX': 'SW',
            'MCX': 'ME',
            'MCE': 'MC',
            'ATH': 'AT',
            'MIL': 'MI',
        }

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def get_exchange_mapping(self, exchange_symbol, sb_map=False):
        if exchange_symbol is not None:
            if exchange_symbol.startswith('OTC'):
                exchange_mapping = 'OTC'
            else:
                exchange_mapping = \
                    self.EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol) \
                        if not sb_map else \
                    self.SB_EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol)
        else:
            self._logger.error(" EXCHANGE IS NONE.")
            exchange_mapping = exchange_symbol

        return exchange_mapping

    def to_pg(self, df, table_name, col_order=None, drop_previous_table=False):
        data = StringIO()
        # write to CSV format
        if col_order is not None:
            df.to_csv(data, columns=col_order, header=False, index=False)
        else:
            df.to_csv(data, header=False, index=False)
        # save to all envs
        for env in ENVS_TO_UPDATE:
            # get engine
            con = self.db_to_update.get(env.upper())
            # set pointer to the beginning of file
            data.seek(0)
            # get raw connection
            raw = con.raw_connection()
            # get cursor
            curs = raw.cursor()
            if drop_previous_table:
                # drop previous table
                try:
                    curs.execute("DROP TABLE IF EXISTS {}".format(table_name))
                except:
                    self._logger.info("COULDN'T DROP TABLE {}".format(table_name))

                empty_table = pd.io.sql.get_schema(df, table_name, con=con)
                # remove undesired characters
                empty_table = empty_table.replace('"', '')
                empty_table = empty_table.replace('\t', '')

                curs.execute(empty_table)
            # copy from CSV format to table
            curs.copy_expert(
                """COPY {} FROM STDIN WITH (FORMAT CSV)""".format(table_name),
                data)
            # commit transactions
            curs.connection.commit()

    # def _create_financial_parameters_table_for_screener(self):
    #     """
    #     This method reads all the financial parameters used in the Terminal
    #     from the *snp_data_item* table and creates a separate table for the
    #     Screener.
    #     :return: None
    #     """
    #     sql_query = "SELECT * " \
    #                 "FROM dev_snp_data_item " \
    #                 "WHERE sbt_data_item_id != 'unknown'"
    #
    #     df = pd.read_sql_query(sql_query, self._pg_snpfin_engine)
    #
    #     # DATATYPE CHANGE
    #     df.snp_data_item_id = df.snp_data_item_id.astype(str)
    #
    #     self.to_pg(df,
    #                 self.FINANCIAL_PARAMETERS,
    #                 drop_previous_table=True)
    #
    #     print("DONE READING snp_data_item TABLE.")

    def _get_financial_parameters(self):
        """
        This method reads the content of the financial parameters to be used in
        the Screener and returns its S&P's data item ID.
        :return: List of S&P's data item ID.
        """
        sql_query = "SELECT snp_data_item_id " \
                    "FROM {}".format(self.FINANCIAL_PARAMETERS)

        df = pd.read_sql_query(sql_query, self._pg_df_engine)

        rval = list(df.snp_data_item_id)

        return rval

    def _get_supported_securities(self):
        """
        This method reads the full content of the sbt_symbol_exchange_mapping
        table and returns a list of the composite_pk_id (unique identifiers).
        :return: Dictionary of all supported ticker:exchange.
        """
        sql_query = "SELECT companyid, tradingitemid FROM {};".format(
            self._SUPPORTED_SECURITIES_TABLE_NAME
        )

        df = pd.read_sql_query(sql_query, self._pg_snp_engine)

        # return only unique company IDs
        rval = df.drop_duplicates().to_dict(orient='records')

        return rval

    def _get_data_by_id(self, composite_pk_id_list=None,
                        financial_parameters_list=None
                        ):

        def build_sql_query(snp_id, fin_param):
            sql_query = """
                    select distinct
                        -- info about company
                        c.companyName as company_name, 
                        c.companyId as company_companyid,
                        c.companyId as data_companyid,
                        ti.tradingItemId as company_tradingitemid,
                        ti.tradingItemId as data_tradingitemid,
                        ti.tickerSymbol as company_tickersymbol, 
                        e.exchangeSymbol as company_exchangesymbol,
                        -- info about financial period
                        pt.periodTypeName as company_periodtypename, 
                        fp.calendarQuarter as company_calendarquarter, 
                        fp.calendarYear as company_calendaryear,
                        -- info about sector, industry etc. (GICS)
                        gics.gsector as company_sectorid,
                        rgics.gicdesc as company_sectordesc,
                        gics.ggroup as company_groupid,
                        rgicsGroup.gicdesc as company_groupdesc,
                        gics.gind as company_industry,
                        rgicsInd.gicdesc as company_industry_desc,
                        gics.gsubind as company_subindustry,
                        rgicsSubind.gicdesc as company_subindustry_desc,
                        -- info about financial parameter
                        fd.dataItemId as data_itemid,
                        fd.unittypeid as data_unittypeid,
                        unit.unittypename as data_unittypename,
                        di.dataItemName as data_itemname,
                        fd.dataItemValue as data_itemvalue
                    from
                        ciqCompany c
                        join ciqSecurity s using ("companyid")
                        join ciqTradingItem ti using ("securityid")
                        join ciqExchange e using ("exchangeid")
                        join ciqLatestInstanceFinPeriod fp using ("companyid")
                        join ciqPeriodType pt using ("periodtypeid")
                        join ciqFinancialData fd using ("financialperiodid")
                        join ciqDataItem di using ("dataitemid")
                        join ciqfinunittype unit using ("unittypeid")
                        join ciqgvkeyiid gkey on c.companyid = gkey.relatedcompanyid
                        join gic_ccompany gics on gkey.gvkey = gics.gvkey
                        join r_giccd rgics on rgics.giccd = gics.gsector
                        join r_giccd rgicsGroup on rgicsGroup.giccd = gics.ggroup
                        join r_giccd rgicsInd on rgicsInd.giccd = gics.gind
                        join r_giccd rgicsSubind on rgicsSubind.giccd = gics.gsubind
                    where
                        -- S&P ID for every financial parameter supported in the Terminal
                        fd.dataItemId in ({})
                        -- LTM
                        and fp.periodTypeId = 4 
                        -- Security's primary exchange in the USA
                        and s.primaryflag = 1
                        and e.countryid in (213)
                        -- valid ticker and exchangesymbol
                        and ti.tickersymbol is not null
                        and e.exchangesymbol is not null
                        -- Trading item ID
                        and ti.tradingitemid = {}
                        --Current Period
                        and fp.latestPeriodFlag = 1
                        order by di.dataItemName
                    """.format(", ".join([str(x) for x in fin_param]),
                               snp_id)

            return sql_query

        # build all the queries
        queries = []
        [queries.append(
            build_sql_query(x.get('tradingitemid'),
                            financial_parameters_list
                            )
        ) for x in composite_pk_id_list]

        batch_size = 2000
        save_counter = 1
        time_list = []
        df = pd.DataFrame()
        # get start of processing time
        start_time = datetime.datetime.now()

        # run the queries
        for i, q in enumerate(queries):
            # self._logger.info("RUNNING QUERY #{}...".format(i+1))
            df = df.append(pd.read_sql_query(q, self._pg_snp_engine),
                           ignore_index=True
                           )
            # self._logger.info(" DONE.")
            if not ((i + 1) % batch_size):
                self._logger.info("SAVING THE LAST {} RESULTS ({}).".format(
                    batch_size, datetime.datetime.now)
                )
                # replace previous table with new results
                # if table exists and this is the first batch
                action = True if (i + 1) == batch_size else False
                t0 = datetime.datetime.now()

                # DATATYPE CHANGES
                # change data_companyid to string
                df.data_companyid = df.data_companyid.astype(str)
                df.company_companyid = df.company_companyid.astype(str)
                df.data_tradingitemid = df.data_tradingitemid.astype(str)
                df.company_tradingitemid = df.company_tradingitemid.astype(str)
                # change data_itemid to string
                df.data_itemid = df.data_itemid.astype(str)
                # change data_itemvalue data type to string
                # so that we can add the tags later on
                df.data_itemvalue = df.data_itemvalue.astype(str)
                # exchange mapping
                df.company_exchangesymbol = df.company_exchangesymbol.apply(
                    lambda x: self.get_exchange_mapping(x)
                )

                # split df into 2 parts for normalization purposes & drop dups
                # (this is done automatically based on the column name)
                df_company = df.filter(regex='company_').drop_duplicates().copy()
                df_data = df.filter(regex='data_').drop_duplicates().copy()

                # saving company's info
                self.to_pg(df_company,
                           self.SCREENER_COMPANY,
                           drop_previous_table=action)

                # saving data
                self.to_pg(df_data,
                           self.SCREENER_STAGING,
                           drop_previous_table=action)

                t1 = datetime.datetime.now()

                dt = (t1 - t0)
                save_counter += 1

                time_list.append(dt)
                # number of batches remaining
                n = (len(queries) - save_counter * batch_size) / batch_size
                # current ETA
                eta = n * dt
                # average ETA
                avg_eta = n * sum(time_list,
                                  datetime.timedelta()) / len(time_list)
                self._logger.info(" DONE.")
                self._logger.info("{} ETA: {}".format(
                    datetime.datetime.now(), eta)
                )
                self._logger.info("{} <ETA>: {}".format(
                    datetime.datetime.now(), avg_eta)
                )
                df = pd.DataFrame()

        if len(df) > 0:
            # saving the rest of the data
            # DATATYPE CHANGES
            # change data_companyid to string
            df.data_companyid = df.data_companyid.astype(str)
            df.company_companyid = df.company_companyid.astype(str)
            df.data_tradingitemid = df.data_tradingitemid.astype(str)
            df.company_tradingitemid = df.company_tradingitemid.astype(str)
            # change data_itemid to string
            df.data_itemid = df.data_itemid.astype(str)
            # change data_itemvalue data type to string
            # so that we can add the tags later on
            df.data_itemvalue = df.data_itemvalue.astype(str)
            # exchange mapping
            df.company_exchangesymbol = df.company_exchangesymbol.apply(
                lambda x: self.get_exchange_mapping(x)
            )

            # split df into 2 parts for normalization purposes & drop dups
            # (this is done automatically based on the column name)
            df_company = df.filter(regex='company_').drop_duplicates().copy()
            df_data = df.filter(regex='data_').drop_duplicates().copy()

            # saving company's info
            self.to_pg(df_company,
                       self.SCREENER_COMPANY,
                       drop_previous_table=False)

            # saving data
            self.to_pg(df_data,
                       self.SCREENER_STAGING,
                       drop_previous_table=False)

        # get end of processing time
        end_time = datetime.datetime.now()
        self._logger.info(" TABLE CREATED IN {}.".format(
            end_time - start_time
        ))

    def _create_description_table(self):
        sql_query = """
            select data_itemid, data_unittypename, data_itemname 
            from {} 
            group by data_itemid, data_unittypename, data_itemname
        """.format(self.SCREENER_STAGING)

        df = pd.read_sql(sql_query, self._pg_df_engine)

        # DATATYPE CHANGE
        df.data_itemid = df.data_itemid.astype(str)

        # save screener data table
        self.to_pg(df,
                   self.SCREENER_DESCRIPTION_TABLE,
                   drop_previous_table=True)

    def _add_tags(self):
        def flatten(container):
            # flatten out a nested list
            # (see https://bit.ly/3baTi2A)
            for i in container:
                if isinstance(i, (list, tuple)):
                    for j in flatten(i):
                        yield j
                else:
                    yield i

        def get_id_by_symbol_exchange(symbol, exchange):
            base_sql = """
                select companyid, tradingitemid
                from {securities_table} v
                where v.tickersymbol = '{symbol}' 
                    and v.exchangesymbol {exchange_operation}
                limit 1
            """

            # TODO: account for period in the symbol: e.g. OGC.TO:TSX should be OGC:TSX
            symbol = symbol.split('.')[0] if symbol.count(".") else symbol
            symbol = symbol.replace('-', '.') if symbol.count("-") else symbol

            if exchange == 'NASDAQ':
                exchange_operation = "like 'Nasdaq%'"
            elif exchange == 'NYSEARCA':
                exchange_operation = "= 'ARCA'"
            elif exchange.startswith("OTC"):
                exchange_operation = "= OTCPK"
            else:
                exchange_operation = "= '{}'".format(exchange)

            SQL = text(
                base_sql.format(
                    securities_table=self._SUPPORTED_SECURITIES_TABLE_NAME,
                    symbol=symbol,
                    exchange_operation=exchange_operation
                )
            )

            try:
                # self._logger.info(" RUNNING QUERY FOR {} AND {}".format(symbol, exchange_operation))
                df = pd.read_sql(
                    SQL,
                    self._pg_snp_engine,
                    coerce_float=True
                )
                if len(df) == 0 and len(symbol) > 4 and exchange == 'NASDAQ':
                    symbol = symbol.replace(symbol[-1], '.'+symbol[-1])
                    SQL = text(
                        base_sql.format(
                            securities_table=self._SUPPORTED_SECURITIES_TABLE_NAME,
                            symbol=symbol,
                            exchange_operation=exchange_operation
                        )
                    )
                    df = pd.read_sql(SQL, self._pg_snp_engine,
                                     coerce_float=True)

                rval = {
                    'companyid': int(df['companyid'].values),
                    'tradingitemid': int(df['tradingitemid'].values)
                }
            except:
                # no equity found
                self._logger.info(" NOTHING FOUND FOR {} AND {}".format(symbol,
                                                                        exchange_operation))
                rval = {
                    'companyid': "{}:{}".format(symbol.upper(), exchange.upper()),
                    'tradingitemid': "{}:{}".format(symbol.upper(), exchange.upper())
                }

            return rval

        # list of keys to discard
        discard_list = ['_id', 'wordpressId', 'createdAt', 'modifiedAt',
                        'code', 'exchange']
        # get database
        db = mongo_client.secure
        # get collection
        collection = db.ArticleTags
        article_tags = [x for x in collection.find()]

        company_id_dict = {
            "{}_{}".format(x.get('code').upper(), x.get('exchange').upper()):
                get_id_by_symbol_exchange(
                    x.get('code').upper(), x.get('exchange').upper()
                ) for x in article_tags if x.get('exchange') is not None}

        print("DONE")
        data = [
            [
                {
                    "data_companyid":
                        company_id_dict.get("{}_{}".format(
                            x.get("code").upper(),
                            x.get("exchange").upper())
                        ).get('companyid'),
                    "data_tradingitemid":
                        company_id_dict.get("{}_{}".format(
                            x.get("code").upper(),
                            x.get("exchange").upper())
                        ).get('tradingitemid'),
                    "data_itemid": k,
                    "data_unittypeid": None,
                    "data_unittypename": None,
                    "data_itemname": None,
                    "data_itemvalue": v,
                    # "data_tags": v
                } for k, v in x.items() if k not in discard_list
            ] for x in article_tags if x.get('exchange') is not None
        ]

        # flatten out list and create df
        data_df = pd.DataFrame(list(flatten(data)))

        # setting the column order
        column_order = [
            'data_companyid',
            'data_tradingitemid',
            'data_itemid',
            'data_unittypeid',
            'data_unittypename',
            'data_itemname',
            'data_itemvalue'
        ]

        self.to_pg(data_df,
                   self.SCREENER_STAGING,
                   col_order=column_order,
                   drop_previous_table=False)

        print("STOP")

    def pivot_data_table(self):
        def dromedary_case_split(string):
            # split a camelCase string into its component words
            list_of_words = [word.lower() for word in re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)', string)]

            return "_".join(list_of_words)

        # get original table
        source_df = pd.read_sql("select * from {}".format(self.SCREENER_STAGING),
                                self._pg_df_engine)
        # remove tag data
        no_tags_df = source_df.query("data_itemid != 'tag'")
        # drop duplicates
        nodups_df = no_tags_df.drop_duplicates(
            subset=['data_tradingitemid', 'data_itemid', 'data_itemvalue']
        ).copy()

        new_df = nodups_df.pivot_table(
            index='data_tradingitemid',
            columns='data_itemid',
            values='data_itemvalue',
            aggfunc=lambda x: list(x) if len(x) > 1 else x
        ).copy()

        # new_df = nodups_df.set_index(
        #     [nodups_df.groupby('data_itemid').cumcount(), 'data_itemid']
        # )['data_itemvalue'].unstack()
        #
        # temp = nodups_df.set_index(
        #     [nodups_df.groupby('data_itemid').cumcount(), "data_tradingitemid", 'data_itemid']
        # )['data_itemvalue'].unstack()
        #
        # temp2 = temp.reset_index(level=1).copy()

        # # pivot dataframe
        # new_df = nodups_df.pivot(
        #     columns=["data_tradingitemid", "data_itemid"],
        #     values=["data_tradingitemid", "data_itemvalue"]
        # ).copy()
        # nodups_df.reset_index(inplace=True)
        # new_df = nodups_df.pivot(index='data_tradingitemid',
        #                          columns='data_itemid',
        #                          values='data_itemvalue')
        # rename columns to avoid having
        # column names starting with numeric type
        new_df.rename(columns=lambda id: 'data_itemid{}'.format(id),
                      inplace=True)

        # add companyid to df
        # (data_itemid_ prefix left on purpose; it's fixed later on)
        new_df['data_itemid_data_tradingitemid'] = list(new_df.index.values)

        # set correct datatype based on column name (exclude tags)
        numeric_cols = [col for col in new_df.columns
                            if col.split('data_itemid')[1].isdigit()]
        text_cols = [col for col in new_df.columns
                        if not col.split('data_itemid')[1].isdigit()]

        # numeric columns first
        new_df_final = new_df[numeric_cols].apply(pd.to_numeric)

        # add text columns back
        for col in text_cols:
            new_df_final[col] = new_df[col].copy()
            text_to_change = col.split('data_itemid')[1]
            new_col = 'data_itemid{}'.format(dromedary_case_split(text_to_change))
            new_df_final.rename(columns={col: new_col},
                                inplace=True)

        # fix column name
        new_df_final.rename(
            columns={'data_itemiddata_tradingitemid': 'data_tradingitemid'},
            inplace=True
        )

        # save screener data table
        self.to_pg(new_df_final,
                   self.SCREENER_DATA,
                   drop_previous_table=True)

    def create_tables(self):
        tic = datetime.datetime.now()
        # create table with the financial parameters that the user can select
        # self._create_financial_parameters_table_for_screener()
        # get all financial parameters
        financial_parameters_list = self._get_financial_parameters()
        # get supported securities
        composite_pk_id_list = self._get_supported_securities()
        # populate screener tables
        self._get_data_by_id(composite_pk_id_list, financial_parameters_list)

        self._logger.info("STAGING TABLE WAS CREATED. ADDING TAGS NOW...")
        try:
            self._add_tags()
            self._logger.info("TAGS ADDED.")
        except Exception as e:
            self._logger.info("AN ERROR OCCURRED WHILE ADDING TAGS: {}".format(e))

        # create table with description and units for dataitems
        self._create_description_table()

        self._logger.info("PIVOTING STAGING TABLE NOW...")
        # reshape the data and save it
        self.pivot_data_table()

        tac = datetime.datetime.now()
        self._logger.info("SCREENER TABLES UPDATED AT {} AFTER {}.".format(
            datetime.datetime.now(),
            (tac - tic)
        ))


if __name__ == '__main__':
    sc = Screener()
    sc.create_tables()
