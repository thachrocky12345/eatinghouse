import os
import pathlib
import json
import collections
import requests
import pymongo
import urllib
import logging

root_path = pathlib.Path(os.path.dirname(os.path.realpath(__file__)))
logger = logging.getLogger(__name__)
envs = ['dev', 'qa', 'prod']
symbol_data_file_path = os.path.join(os.path.join(root_path), 'symbols.json')
f = open(symbol_data_file_path, 'r')
c = f.read()
f.close()

symbols_json = json.loads(c, object_pairs_hook=collections.OrderedDict)
symbols_list = symbols_json["symbols"]

def load_config():
  config_dir = os.path.join(root_path)
  config_file = os.path.join(config_dir, 'sbt_conf.json')
  logger.info("loading config file: " + config_file)

  f = open(config_file, 'r')
  c = f.read()
  f.close()

  return json.loads(c, object_pairs_hook=collections.OrderedDict)


get_config = load_config()
defaultenv = get_config['environment']
config = get_config[defaultenv]
cc_config = config["api_feeds"]["iex"]
base_url = cc_config["url"]
api_key = cc_config["token"]


def do_request(urlpart, method="GET", data=None, params={}):
  logger.info(urlpart)
  params['token'] = api_key
  url = urllib.parse.urljoin(base_url, urlpart)
  req = requests.request(method, url, json=data, params=params, headers={"Content-Type": 'application/json'})
  req.raise_for_status()

  response = req.json()
  if "Data" in response:
      return response["Data"]

  return response

def upsert_mongo(mongo_data, mongo_accessor):
    condition = {'id': mongo_data['id']}
    existing_data = mongo_accessor.find(condition)

    if existing_data.count() > 0:
        mongo_accessor._replace_data(condition, mongo_data)
    else:
        mongo_accessor._insert_data(mongo_data)

def load_symbol_options():
  options_dict = do_request('ref-data/options/symbols')
  approved_symbol_list = set(options_dict.keys()) & set(symbols_list)

  for key in approved_symbol_list:
    mongo_data = {}
    mongo_data['id'] = key
    mongo_data['expirations'] = options_dict[key]

    for env in envs:
      try:
        upsert_mongo(mongo_data, MongoAccessor('symbol_options', get_config[env]))
      except Exception as e:
        logger.error("Unable to load data in" + env)

def load_symbol_expirations():
  for env in envs:
    econfig = get_config[env]
    options_dict = MongoAccessor('symbol_options', econfig).find({})

    for options in options_dict:
      for option in options['expirations']:
        url = 'stock/{symbol}/options/{expiration}'.format(symbol=options['id'], expiration=option)
        try:
          option_data = do_request(url)
          mongo_data = {}
          mongo_data['id'] = options['id'] + option
          mongo_data['data'] = option_data
          upsert_mongo(mongo_data, MongoAccessor('symbol_expiration_details', econfig))
        except Exception as e:
          logger.error("Unable to load data from iex" + url)


class MongoAccessor:
  def __init__(self, collection_name, sconfig):
    """
    Constructor
    """
    self._sbt_config = sconfig
    self._collection_name = collection_name

    if 'mongodb' in self._sbt_config and 'host' in self._sbt_config['mongodb'] and \
            'username' in self._sbt_config['mongodb'] and \
            'password' in self._sbt_config['mongodb']:

        mongo_user = urllib.parse.quote_plus(self._sbt_config['mongodb']['username'])
        mongo_password = urllib.parse.quote_plus(self._sbt_config['mongodb']['password'])

        self._connection_url = self._sbt_config['mongodb']['host'].format(username=mongo_user, password=mongo_password)

    if 'database' in self._sbt_config['mongodb']:
        self._database = self._sbt_config['mongodb']['database']

    self._client = pymongo.MongoClient(self._connection_url)
    self._selected_database = self._client[self._database]
    self._selected_collection = self._selected_database[self._collection_name]

  def _insert_data(self, data, many=False):
    if many:
        return self._selected_collection.insert_many(data)
    else:
        return self._selected_collection.insert_one(data)

  def find(self, condition, **kwargs):
    return self._selected_collection.find(condition, **kwargs)

  def find_one(self, condition, **kwargs):
    return self._selected_collection.find_one(condition, **kwargs)

  def _replace_data(self, replace_to, replace_with, upsert=False):
    return self._selected_collection.replace_one(replace_to, replace_with, upsert)

if __name__ == "__main__":
  load_symbol_options()
  load_symbol_expirations()
