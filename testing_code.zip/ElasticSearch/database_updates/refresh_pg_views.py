#!/usr/bin/env python

import datetime
import os
import sys
import simplejson as json
import logging

import sqlalchemy
from environs import Env

# read global vars from .env file
GLOBAL_VAR = Env()
GLOBAL_VAR.read_env()


class RefreshPGMViews(object):
    def __init__(self):
        # configure logger
        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        ### PG
        # get the config for XPF DB (from DEV env)
        self._pg_snp_engine = self._create_pg_engine()

        # renames the current table to
        self.MVIEWS_LIST = [
            'mv_sbt_company',
            'mv_exchange_rate',
            'mv_dividend_timeseries',
            'mv_last_year_dividends'
        ]

        self.MVIEWS_SNAPSHOT_LIST = [
            'mv_snapshot_latest_financials',
            'mv_snapshot_latest_financials_period',
            'mv_snapshot_latest_paid_dividends',
            'mv_snapshot_beta',
            'mv_snapshot_market_cap',
            'mv_snapshot_market_cap_usd',
            'mv_snapshot_price_lowest',
            'mv_snapshot_price_highest',
            'mv_snapshot_price_last_close',
            'mv_snapshot_volatility_timeframe',
            'mv_snapshot',
            'mv_prices'
        ]

    @staticmethod
    def _create_pg_engine():
        host = GLOBAL_VAR('SNP_DB_HOST')
        credentials = GLOBAL_VAR('SNP_DB_CREDENTIALS')
        user = GLOBAL_VAR('SNP_DB_USER')
        dbname = GLOBAL_VAR('SNP_DB_DATABASE')
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def _refresh_mviews(self, reason=None):
        SIMPLE_REFRESH = """REFRESH MATERIALIZED VIEW {mview};"""

        self._logger.critical(" ")
        self._logger.critical(" STARTED MVIEWS REFRESH AT {}.".format(datetime.datetime.now()))
        self._logger.critical(" ")
        # select the list of mviews to refresh based on the
        # script that's calling this module
        mview_list = self.MVIEWS_LIST if reason == "for_pm_staging_loader" \
            else self.MVIEWS_SNAPSHOT_LIST
        self._logger.critical(" ")
        self._logger.critical(" LIST OF MVIEWS TO BE REFRESHED: ")
        [self._logger.critical("  -> {}".format(mview)) for mview in mview_list]
        self._logger.critical(" ")
        with self._pg_snp_engine.connect() as con:
            for mview in mview_list:
                self._logger.critical(" REFRESHING MVIEW {}...".format(mview))
                tic = datetime.datetime.now()
                con.execute(SIMPLE_REFRESH.format(mview=mview))
                tac = datetime.datetime.now()
                dt = tac - tic
                self._logger.critical("  -> Dt({}): {}".format(mview, dt))

        self._logger.critical(" ")
        self._logger.critical(" FINISHED MVIEWS REFRESH AT {}.".format(datetime.datetime.now()))
        self._logger.critical(" ")

    def run_loader(self, reason=None):

        try:
            # refresh mviews
            self._refresh_mviews(reason)

            self._logger.critical(
                " ALL MATERIALIZED VIEWS HAVE BEEN REFRESHED."
            )

        except Exception as e:
            self._logger.error(
                " AN ERROR OCCURRED WHEN REFRESHING THE MATERIALIZED VIEWS: {}.".format(e)
            )


if __name__ == "__main__":
    rmv = RefreshPGMViews()
    # sys.argv[0] is always the executed file's name
    # sys.argv[1:n] are arguments passed when executing the command line
    if len(sys.argv) > 1:
        # an argument was passed in when running the command line
        rmv.run_loader(sys.argv[1])
    else:
        # nothing was provided
        rmv.run_loader()
