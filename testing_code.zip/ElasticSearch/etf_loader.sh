#!/usr/bin/env bash

aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_intrinio_etf/intrinio_etf_loader.py /home/ec2-user/etf_loader.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_intrinio_etf/.env /home/ec2-user/.env

echo "Running ETF loader..."
python /home/ec2-user/etf_loader.py