#!/usr/bin/env python

import datetime
import os
import sys
from io import StringIO

import pandas as pd
import requests
import simplejson as json
import logging
# import boto3

import sqlalchemy
from sqlalchemy import VARCHAR, FLOAT, TIMESTAMP, JSON, INTEGER

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']


class PortfolioStagingTableLoader(object):
    def __init__(self):
        # ### Dynamo
        # self.ddb = boto3.resource('dynamodb')
        # self.client = boto3.client('dynamodb')
        # # get a list of all available tables
        # self.dynamo_table_list = self.client.list_tables()['TableNames']

        # table to read the ticker symbols from
        self._SUPPORTED_SECURITIES_TABLE_NAME = 'v2mv_sbt_company'
        self._PORTFOLIO_MANAGER_STAGING_TABLE_NAME = 'current_pm_trading_data'
        self._LONGSHORT_URL = "https://7lwyh5hvh6.execute-api.us-east-1.amazonaws.com/dev/portfolios/lists/porters-list/"

        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # read the entire config file
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        ### PG
        # get the config for total portfolio DB
        self._pg_pf = config['dev']['postgres']['portfolio']
        self._pg_pf_engine = self._create_pg_engine(self._pg_pf)

        self._pg_pf_qa = config['qa']['postgres']['portfolio']
        self._pg_pf_qa_engine = self._create_pg_engine(self._pg_pf_qa)

        self._pg_pf_prod = config['prod']['postgres']['portfolio']
        self._pg_pf_prod_engine = self._create_pg_engine(self._pg_pf_prod)

        # get the config for XPF DB (from DEV env)
        self._pg_snp = config['dev']['postgres']['snpsource']
        self._pg_snp_engine = self._create_pg_engine(self._pg_snp)

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_pf_engine,
                             'QA': self._pg_pf_qa_engine,
                             'PROD': self._pg_pf_prod_engine}

        # list of results from Dynamo
        self._dynamo_results = []
        # dictionary of last close price dates (trading item id is the key)
        self._pg_dates = {}
        # list of pandas df with the results from PG
        self._pg_data_list = []
        # dict with the transformed results to be saved into the main table in PG
        self._final_data = []
        # list of long/short recommendations
        self._longshort_recommendations = {}
        # list of supported securities
        self.supported_securities_list = None

        # if a PG table exists when loading data, tell pandas to take this action
        self.action_to_take_if_table_exists = 'replace'

        # exchangesymbol mapping
        self.EXCHANGE_MAPPING = {
            'NasdaqGS': 'NSDQ',
            'NasdaqGM': 'NSDQ',
            'NasdaqCM': 'NSDQ',
            'ARCA': 'NYSEARCA'
        }

    def to_pg(self, df, table_name, col_order=None, drop_previous_table=False):
        data = StringIO()
        # write to CSV format
        if col_order is not None:
            df.to_csv(data, columns=col_order, header=False, index=False)
        else:
            df.to_csv(data, header=False, index=False)
        # save to all envs
        for env in ENVS_TO_UPDATE:
            # get engine
            con = self.db_to_update.get(env.upper())
            # set pointer to the beginning of file
            data.seek(0)
            # get raw connection
            raw = con.raw_connection()
            # get cursor
            curs = raw.cursor()
            if drop_previous_table:
                # drop previous table
                try:
                    curs.execute("DROP TABLE IF EXISTS {}".format(table_name))
                except:
                    self._logger.info("COULDN'T DROP TABLE {}".format(table_name))

                empty_table = pd.io.sql.get_schema(df, table_name, con=con)
                # remove undesired characters
                empty_table = empty_table.replace('"', '')
                empty_table = empty_table.replace('\t', '')

                curs.execute(empty_table)
            # copy from CSV format to table
            curs.copy_expert(
                """COPY {} FROM STDIN WITH (FORMAT CSV)""".format(table_name),
                data)
            # commit transactions
            curs.connection.commit()

    def get_exchange_mapping(self, exchange_symbol):
        if exchange_symbol is not None:
            if exchange_symbol.startswith('OTC'):
                exchange_mapping = 'OTC'
            else:
                exchange_mapping = \
                    self.EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol)
        else:
            self._logger.error(" EXCHANGE IS NONE.")
            exchange_mapping = exchange_symbol

        return exchange_mapping

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def _get_longshort_recommendations(self):
        res = requests.get(self._LONGSHORT_URL)
        if str(res.status_code).startswith('20'):
            res_json = res.json()
            # populate the long/short recommendations dict
            self._longshort_recommendations = {
                "{}:{}".format(x['symbol'], x['exchange']):
                    [{
                        'name': y['portfolio_name'],
                        'code': y['pub_code'],
                        'id': y['portfolio_id'],
                        'recommendation': y['type']
                    } for y in x['publications']]
                for x in res_json['data']['values']['values']
            }
        else:
            self._logger.critical(
                " LONG/SHORT ENDPOINT RETURNED CODE STATUS: {}".format(
                    res.status_code
                )
            )

    def _get_supported_securities(self, primary_only=False):
        self._logger.critical(' EXTRACTING DATA -- GETTING LIST OF SUPPORTED SECURITIES...')
        sql_query = """
            select 
                t.identifiervalue, 
                t.tickersymbol, 
                t.exchangesymbol, 
                t.tradingitemid, 
                t.companyid, 
                t.companyname 
                from {} t""".format(
                self._SUPPORTED_SECURITIES_TABLE_NAME
            )
        if primary_only:
            sql_query = sql_query + " where t.is_primary_exchange is true"
        self.supported_securities_list = pd.read_sql(
            sql_query,
            self._pg_snp_engine
        )

    def _get_data_from_pg(self):
        self._logger.critical(' EXTRACTING DATA -- GETTING DATA FROM PG...')

        # base PG queries
        query_last_close_price = """
            ---last close price
            SELECT plc.priceclose, plc.pricingdate, plc.isocode
                FROM v_snapshot_price_last_close plc
                WHERE plc.tradingItemId = '{trading_item_id}';
        """

        query_52_week_low = """
        ---52 week low
            SELECT pl.pricelow
                FROM v_snapshot_price_lowest pl
                WHERE pl.tradingItemId = '{trading_item_id}';
        """

        query_52_week_high = """
            ---52 week high
            SELECT ph.pricehigh
                FROM v_snapshot_price_highest ph
                WHERE ph.tradingItemId = '{trading_item_id}';
        """

        query_volatility = """
            ---this is the same query used in the snapshot
            select
                ( SELECT (t1.res * 0.5 + t2.res * 0.3 + t3.res * 0.2)::double precision * sqrt(252::double precision) * 2::double precision / 3::double precision AS volatility
                   FROM ( SELECT 1 AS id,
                            x.std AS res
                           FROM ( SELECT t.pricingdate,
                                    stddev_samp(t.adj_return) OVER (ORDER BY t.pricingdate ROWS BETWEEN 756 PRECEDING AND CURRENT ROW) AS std
                                   FROM ( SELECT v.pricingdate,
                                            (v.adj_price_close - lag(v.adj_price_close, '-1'::integer) OVER (ORDER BY v.pricingdate DESC)) / lag(v.adj_price_close, '-1'::integer) OVER (ORDER BY v.pricingdate DESC) AS adj_return
                                           FROM v_snapshot_volatility v
                                          WHERE v.tradingitemid = psc.tradingitemid) t) x
                          ORDER BY x.pricingdate DESC
                         LIMIT 1) t1
                     JOIN ( SELECT 1 AS id,
                            x.std_252 AS res
                           FROM ( SELECT t.pricingdate,
                                    stddev_samp(t.adj_return) OVER (ORDER BY t.pricingdate ROWS BETWEEN 756 PRECEDING AND CURRENT ROW) AS std_252
                                   FROM ( SELECT v.pricingdate,
                                            (v.adj_price_close - lag(v.adj_price_close, '-1'::integer) OVER (ORDER BY v.pricingdate DESC)) / lag(v.adj_price_close, '-1'::integer) OVER (ORDER BY v.pricingdate DESC) AS adj_return
                                           FROM v_snapshot_volatility v
                                          WHERE v.tradingitemid = psc.tradingitemid) t) x
                          ORDER BY x.pricingdate
                         OFFSET 252
                         LIMIT 1) t2 ON t2.id = t1.id
                     JOIN ( SELECT 1 AS id,
                            x.std_504 AS res
                           FROM ( SELECT t.pricingdate,
                                    stddev_samp(t.adj_return) OVER (ORDER BY t.pricingdate ROWS BETWEEN 756 PRECEDING AND CURRENT ROW) AS std_504
                                   FROM ( SELECT v.pricingdate,
                                            (v.adj_price_close - lag(v.adj_price_close, '-1'::integer) OVER (ORDER BY v.pricingdate DESC)) / lag(v.adj_price_close, '-1'::integer) OVER (ORDER BY v.pricingdate DESC) AS adj_return
                                           FROM v_snapshot_volatility v
                                          WHERE v.tradingitemid = psc.tradingitemid) t) x
                          ORDER BY x.pricingdate
                         OFFSET 504
                         LIMIT 1) t3 ON t3.id = t1.id)
                from v2mv_sbt_company psc
                where psc.tradingitemid = '{trading_item_id}';
        """

        query_dividend = """
            --get data about dividend dates and split adjusted dividends
            SELECT d.splitadjdivamount, d.exdate, d.paydate, d.recorddate
                FROM v2mv_last_year_dividends d
                WHERE d.tradingItemId = '{trading_item_id}'
                LIMIT 1;
        """

        query_annualized_dividend = """
            --get data about amount and annualized dividend
            SELECT vd.annualized_dividend, vd.dividend_yield_percentage, vd.dividend_currency
                FROM v_latest_paid_dividends vd
                WHERE vd.tradingitemid = '{trading_item_id}'
                LIMIT 1;
        """

        # run queries for data
        supported_securities_list = \
            self.supported_securities_list.to_dict(orient='records')
        for i, x in enumerate(supported_securities_list):
            tic0 = datetime.datetime.now()
            if 'tradingitemid' in x:
                # get current date/time
                now = datetime.datetime.now()

                # last close price, date, & isocode
                last_close_price = pd.read_sql(
                    query_last_close_price.format(
                        trading_item_id=x['tradingitemid']
                    ),
                    self._pg_snp_engine
                )

                # low 52-week price, date, & isocode
                low_52week_price = pd.read_sql(
                    query_52_week_low.format(
                        trading_item_id=x['tradingitemid']
                    ),
                    self._pg_snp_engine
                )

                # high 52-week price, date, & isocode
                high_52week_price = pd.read_sql(
                    query_52_week_high.format(
                        trading_item_id=x['tradingitemid']
                    ),
                    self._pg_snp_engine
                )

                # get volatility from the dev_snp_company table
                # (only companies that trade on their US-based primary exchange)
                volatility = pd.read_sql(
                    query_volatility.format(
                        trading_item_id=x['tradingitemid']
                    ),
                    self._pg_snp_engine
                ).volatility

                # get long/short recommendations
                longshort_recommendations = \
                    self._longshort_recommendations.get(
                        "{}:{}".format(
                            x['tickersymbol'],
                            self.get_exchange_mapping(x['exchangesymbol']))
                    )

                # get last paid dividend
                dividend = pd.read_sql(
                    query_dividend.format(
                        trading_item_id=x['tradingitemid']
                    ),
                    self._pg_snp_engine
                )

                # get annualized dividend
                annualized_dividend = pd.read_sql(
                    query_annualized_dividend.format(
                        trading_item_id=x['tradingitemid']
                    ),
                    self._pg_snp_engine
                )

                # wrapping up
                data = (x, now, last_close_price,
                        low_52week_price, high_52week_price,
                        volatility,
                        longshort_recommendations,
                        dividend,
                        annualized_dividend
                        )

                self._transform_data(data)

            # log Dt / trading item
            self._logger.critical(
                ' Dt({:06d}) = {}'.format(i+1, datetime.datetime.now() - tic0)
            )

    def _extract_data(self):
        self._logger.critical(' EXTRACTING DATA...')
        self._get_longshort_recommendations()
        self._get_supported_securities()
        self._get_data_from_pg()
        self._logger.critical(' DATA EXTRACTION DONE.')

    def _transform_data(self, data):
        try:
            # transform results into final format
            x, now, last_close_price, \
                low_52week_price, high_52week_price, \
                volatility, \
                longshort_recommendations,\
                dividend,\
                annualized_dividend = data

            res = {
                "company_name": x['companyname'],
                "company_id": x['companyid'],
                "globalid": x['identifiervalue'] if x['identifiervalue'] else None,
                "composite_pk_id": '{}:{}'.format(
                    x['tickersymbol'],
                    self.get_exchange_mapping(x['exchangesymbol'])
                ),
                "trading_item_id": x['tradingitemid'],
                "symbol": x['tickersymbol'],
                "exchange": self.get_exchange_mapping(x['exchangesymbol']),
                "prices_isocode": last_close_price.isocode.values[0] if len(last_close_price) else None,
                "last_close_price": last_close_price.priceclose.values[0] if len(last_close_price) else None,
                "last_close_price_date": last_close_price.pricingdate.values[0] if len(last_close_price) else None,
                "low_52week_price": low_52week_price.pricelow.values[0] if len(low_52week_price) else None,
                "high_52week_price": high_52week_price.pricehigh.values[0] if len(high_52week_price) else None,
                "volatility": volatility.values[0] if len(volatility) else None,
                "dividend_amount": dividend.to_dict(orient='records')[0].get('splitadjdivamount') if len(dividend) else None,
                "dividend_exdate": dividend.to_dict(orient='records')[0].get('dividenddate') if len(dividend) else None,
                "dividend_paydate": dividend.to_dict(orient='records')[0].get('paydate') if len(dividend) else None,
                "dividend_recorddate": dividend.to_dict(orient='records')[0].get('recorddate') if len(dividend) else None,
                "annualized_dividend": annualized_dividend.to_dict(orient='records')[0].get('annualized_dividend') if len(annualized_dividend) else None,
                "dividend_yield_percentage": annualized_dividend.to_dict(orient='records')[0].get('dividend_yield_percentage') if len(annualized_dividend) else None,
                "dividend_currency": annualized_dividend.to_dict(orient='records')[0].get('dividend_currency') if len(annualized_dividend) else None,
                "longshort_recommendations": longshort_recommendations if longshort_recommendations else None,
                "updated_at": now
            }

            self._logger.critical(
                ' DATA TRANSFORM: '
                'TICKERSYMBOL {} (EXCHANGESYMBOL: {}) '.format(
                    x['tickersymbol'],
                    x['exchangesymbol']
                )
            )

            # append result to final data
            if len(self._final_data) >= 1000:
                self._load_data()
            else:
                self._final_data.append(res)

        except Exception as e:

            self._logger.critical(
                ' DATA TRANSFORM WARNING: '
                'SKIPPING TICKERSYMBOL {} (EXCHANGESYMBOL: {}) '
                'BECAUSE OF THE FOLLOWING ERROR: {}'.format(
                    x['tickersymbol'],
                    x['exchangesymbol'],
                    e
                )
            )

    def _load_data(self):
        self._logger.critical(' LOADING DATA...')
        # set schema & data types
        dtypes = {
            "company_name": VARCHAR,
            "company_id": INTEGER,
            "globalid": VARCHAR,
            "composite_pk_id": VARCHAR,
            "trading_item_id": INTEGER,
            "symbol": VARCHAR,
            "exchange": VARCHAR,
            "prices_isocode": VARCHAR,
            "last_close_price": FLOAT,
            "last_close_price_date": TIMESTAMP,
            "low_52week_price": FLOAT,
            "high_52week_price": FLOAT,
            "volatility": FLOAT,
            "dividend_amount": FLOAT,
            "dividend_exdate": TIMESTAMP,
            "dividend_paydate": TIMESTAMP,
            "dividend_recorddate": TIMESTAMP,
            "annualized_dividend": FLOAT,
            "annualized_dividend_pricingdate": TIMESTAMP,
            "dividend_yield_percentage": FLOAT,
            "longshort_recommendations": JSON,
            "updated_at": TIMESTAMP}

        # create df with specified data type
        df = pd.DataFrame([
            {k: x[k] for k in dtypes.keys() if k in x}
            for x in self._final_data
        ])
        # save to PG
        for env in ENVS_TO_UPDATE:
            self._logger.critical(' SAVING DATA TO {} ENV...'.format(env.upper()))
            df.to_sql(self._PORTFOLIO_MANAGER_STAGING_TABLE_NAME,
                      self.db_to_update.get(env.upper()),
                      if_exists=self.action_to_take_if_table_exists,
                      index=False,
                      dtype=dtypes)

        # reset final data variable for the dividend data
        self._final_data = []
        self.action_to_take_if_table_exists = 'append'

        self._logger.critical(' DATA LOADING DONE.')

    def _create_index(self):
        create_index = """
            CREATE UNIQUE INDEX pm_trading_data_trading_item_id_idx
                ON public.pm_trading_data
                USING btree (
                    trading_item_id
                );
        """

        get_index_name = """
            select
                t.relname as table_name,
                i.relname as index_name
            from
                pg_class t,
                pg_class i,
                pg_index ix,
                pg_attribute a
            where
                t.oid = ix.indrelid
                and i.oid = ix.indexrelid
                and a.attrelid = t.oid
                and a.attnum = ANY(ix.indkey)
                and t.relkind = 'r'
                and i.relname like 'pm_trading_data%'
            order by
                t.relname,
                i.relname
        """

        check_if_index_exists = """
            select exists ({query});
        """.format(query=get_index_name)

        delete_index = """DROP INDEX public.pm_trading_data_trading_item_id_idx;"""

        # save to PG
        for env in ENVS_TO_UPDATE:
            with self.db_to_update.get(env).connect() as con:
                response = con.execute(
                    sqlalchemy.text(check_if_index_exists)).fetchone()
                if response[0]:
                    con.execute(sqlalchemy.text(delete_index))
                con.execute(create_index)

        self._logger.critical(" INDEX CREATION DONE.")

    def _backup_tables(self):
        # renames the current table to
        source_name = 'pm_trading_data'
        target_name = 'pm_trading_data_bkp'

        rename = """
            ALTER TABLE IF EXISTS {source} RENAME TO {target};
        """.format(source=source_name, target=target_name)

        # we need to check if there's a previous backup table in place
        chek_if_bkp_exists = """
            SELECT EXISTS (
               SELECT FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
               WHERE n.nspname = 'public'
               AND c.relname = '{}'
               AND c.relkind = 'r' -- only tables
            );
        """.format(target_name)
        # delete backup table if needed
        delete_table = """DROP TABLE {}""".format(target_name)

        for env in ENVS_TO_UPDATE:
            with self.db_to_update.get(env.upper()).connect() as con:
                if con.execute(chek_if_bkp_exists):
                    # delete previous backup table
                    con.execute(delete_table)
                # create backup table
                con.execute(rename)

        self._logger.critical(" BACKUP CREATED.")

    def _migrate_tables(self):
        # rename table created by the loader to the one used by the PM
        source_name = self._PORTFOLIO_MANAGER_STAGING_TABLE_NAME
        target_name = 'pm_trading_data'

        rename = """
            ALTER TABLE IF EXISTS {source} RENAME TO {target};
        """.format(source=source_name, target=target_name)

        for env in ENVS_TO_UPDATE:
            with self.db_to_update.get(env.upper()).connect() as con:
                con.execute(rename)

        self._logger.critical(" DATA MIGRATION DONE.")

    def _create_financial_table(self):
        if self.supported_securities_list is None:
            self._get_supported_securities(primary_only=True)
        # run queries for data
        supported_securities_list = \
            self.supported_securities_list.to_dict(orient='records')

        query_get_financial_parameters = """
            --query to get all the pre-defined financial parameters
            SELECT companyid, dataitemid, dataitemvalue, filingdate 
            FROM v_get_selected_financial_parameters
            WHERE companyid = '{company_id}'
        """

        df_list = []

        try:
            [df_list.append(pd.read_sql(
                query_get_financial_parameters.format(
                    company_id=x['companyid']),
                self._pg_snp_engine
            )) for x in supported_securities_list]
        except Exception as e:
            self._logger.error(" AN ERROR OCCURRED: {}".e)

        # remove empty dataframes
        df_list_non_zero = [df for df in df_list if len(df) > 0]
        # concatenate all non-zero dataframes
        df_final = pd.concat(df_list_non_zero)
        # rename colum for consistency
        df_final.rename(
            {'companyid': 'company_id'}, axis='columns', inplace=True
        )

        # create df of filing date and set the index to company_id
        df_filing_date = pd.DataFrame(
            [{
                "company_id": x[0],
                "filing_date": x[1][0].strftime("%Y-%m-%d"),
                "updated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            } for x in df_final.groupby("company_id")["filingdate"]]
        ).set_index("company_id")

        # pivot results
        df_final_pivoted = df_final.pivot(
            index='company_id', columns='dataitemid', values='dataitemvalue'
        )

        # rename columns for consistency
        df_final_pivoted.rename(
            {x: "dataitemid_{}".format(x) for x in df_final_pivoted.keys()},
            axis="columns", inplace=True)

        # merge filing dates into pivoted df
        df_result = df_final_pivoted.merge(df_filing_date,
                                           how="left", on="company_id")
        # create index column with company_id
        df_result.reset_index(inplace=True)

        # save df
        self.to_pg(df_result,
                   'pm_financial_parameters',
                   drop_previous_table=True)

        print("DONE.")

    def run_loader(self):

        try:

            # get data
            self._extract_data()
            # save results
            self._load_data()
            # rename current table to backup
            self._backup_tables()
            # rename loader table to current table
            self._migrate_tables()
            # create index
            self._create_index()

            self._logger.critical(" PORTFOLIO STAGING TABLE CREATED.")

            # # create staging table for a selected set of financial parameters
            # self._create_financial_table()

        except Exception as e:
            self._logger.error(" AN ERROR OCCURRED: {}.".format(e))


if __name__ == "__main__":
    pl = PortfolioStagingTableLoader()
    pl.run_loader()
