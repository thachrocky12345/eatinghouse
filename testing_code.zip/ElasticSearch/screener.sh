#!/usr/bin/env bash

aws s3 cp s3://sbt-datapipeline-assets/loaders/screener/screener_data_loader.py /home/ec2-user/screener_data_loader.py

aws s3 cp s3://sbt-datapipeline-assets/loaders/config_file/sbt_conf.json /home/ec2-user/sbt_conf.json

echo "Running Screener loader..."
python /home/ec2-user/screener_data_loader.py
