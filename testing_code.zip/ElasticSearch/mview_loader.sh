#!/usr/bin/env bash

aws s3 cp s3://sbt-datapipeline-assets/loaders/database_updates/refresh_pg_views.py /home/ec2-user/refresh_pg_views.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/database_updates/.env /home/ec2-user/.env

echo "Refreshing MViews..."
python /home/ec2-user/refresh_pg_views.py
