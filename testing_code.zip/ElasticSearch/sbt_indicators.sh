#!/usr/bin/env bash

aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_indicators/capeff_loader.py /home/ec2-user/capeff.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_indicators/composite_loader.py /home/ec2-user/composite.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_indicators/merton_loader.py /home/ec2-user/merton.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_indicators/dcf_loader.py /home/ec2-user/dcf.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_indicators/dividend_loader.py /home/ec2-user/dividend.py

aws s3 cp s3://sbt-datapipeline-assets/loaders/config_file/sbt_conf.json /home/ec2-user/sbt_conf.json

echo "Running Capital Efficiency indicator..."
python /home/ec2-user/capeff.py
echo "Running Merton indicator..."
python /home/ec2-user/merton.py
echo "Running DCF indicator..."
python /home/ec2-user/dcf.py
echo "Running Dividend indicator..."
python /home/ec2-user/dividend.py
echo "Running Composite indicator..."
python /home/ec2-user/composite.py
