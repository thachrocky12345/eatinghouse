#!/usr/bin/env bash

aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_options/iex_options.py /home/ec2-user/iex_options.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_options/symbols.json /home/ec2-user/symbols.json

aws s3 cp s3://sbt-datapipeline-assets/loaders/config_file/sbt_conf.json /home/ec2-user/sbt_conf.json

echo "Running IEX loader..."
python /home/ec2-user/iex_options.py
