#!/usr/bin/env python

import logging
import sqlalchemy
from environs import Env
import requests
import json
import pandas as pd

# read global vars from .env file
GLOBAL_VAR = Env()
GLOBAL_VAR.read_env()

table_name = "sbt_etfs"
pg_schema = 'etf'

EXCHANGE_MIC_MAPPING = {
    "NSDQ": "XNAS",
    "NYSE": "ARCX",
    "NYSEARCA": "ARCX",
    "AMEX": "ARCX",
    "BATS-CHIXE": "BATS",
}


class IntrinioEtfLoader(object):
    def __init__(self):
        # configure logger
        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # intrinio config
        self._protocol = GLOBAL_VAR("intrinio_protocol")
        self._domain_name = GLOBAL_VAR("intrinio_domain_name")
        self._port = GLOBAL_VAR("intrinio_port")
        self._user_name = GLOBAL_VAR("intrinio_user_name")
        self._credentials = GLOBAL_VAR("intrinio_credentials")
        self._api_key = GLOBAL_VAR("intrinio_api_key")

        ##PG Connection
        self._pg_snp_engine = self._create_pg_engine()

    @staticmethod
    def _create_pg_engine():
        host = GLOBAL_VAR('SNP_DB_HOST')
        credentials = GLOBAL_VAR('SNP_DB_CREDENTIALS')
        user = GLOBAL_VAR('SNP_DB_USER')
        dbname = GLOBAL_VAR('SNP_DB_DATABASE')
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def _get_basic_auth(self):
        basic_auth = None
        if self._user_name and self._credentials:
            basic_auth = requests.auth.HTTPBasicAuth(self._user_name, self._credentials)

        return basic_auth

    def _get_formatted_domain(self):
        if self._port == 80 or self._port == 443:
            return self._protocol + '://' + self._domain_name
        else:
            return self._protocol + '://' + self._domain_name + ":" + str(self._port)

    def _query_url(self, url, method='GET'):
        data = {}
        response = None

        try:
            self._logger.debug(url)
            basic_auth = self._get_basic_auth()

            if method.upper() == 'GET':
                response = requests.get(url, auth=basic_auth)
            elif method.upper() == 'POST':
                response = requests.post(url, auth=basic_auth)

            data = json.loads(response.text)

        except Exception as exc:
            self._logger.info(exc)
            if response is not None and isinstance(response.text, str) \
                    and len(response.text.strip()) > 0:
                self._logger.info("Response Error : " + str(response.text))

        return data

    def _get_intrinio_page_data(self, base_url):
        current_page = 1
        page_size = 100
        page_data = []

        url = base_url + \
              '&page_size=' + str(page_size) + \
              '&page_number=' + str(current_page)

        data = self._query_url(url)

        if 'errors' in data.keys():
            raise Exception(data['errors'][0]['human'])
        else:
            page_data.extend(data['data'])
            total_pages = int(data['total_pages'])

        if total_pages > current_page:
            while current_page < total_pages:
                url = base_url + \
                      '&page_size=' + str(page_size) + \
                      '&page_number=' + str(current_page + 1)
                self._logger.info('Calling url : ' + url)
                data = self._query_url(url)

                if 'errors' in data.keys():
                    raise Exception(data['errors'][0]['human'])
                else:
                    page_data.extend(data['data'])
                    current_page = int(data['current_page'])

        return page_data

    def get_etf(self, symbol):
        if not symbol.endswith(':US'):
            symbol = symbol + ':US'

        url = self._get_formatted_domain() + '/etfs?api_key=' + \
              self._api_key + '&identifier=' + symbol

        data = self._query_url(url)

        if 'errors' in data.keys():
            raise Exception(data['errors'][0]['human'])
        else:
            return data

    def get_all_etfs(self):
        url = self._get_formatted_domain() + '/etfs?api_key=' + \
              self._api_key

        return self._get_intrinio_page_data(url)

    def update_etf_list(self):
        self._logger.info("Update ETF List - Started")
        all_etfs = self.get_all_etfs()
        loaded = set()

        rows_list = []

        for etf in all_etfs:
            if etf["ticker"] in loaded:
                continue

            loaded.add(etf["ticker"])

            row = self.get_etf(etf["ticker"])
            row["symbol"] = row["ticker"]
            del row["ticker"]

            if row["symbol"] and row["exchange_mic"]:
                row["composite_pk_id"] = row["symbol"].upper() + ":" + row["exchange_mic"].upper()
                rows_list.append(row)

        df = pd.DataFrame(rows_list)

        df.to_sql(table_name,
                  self._pg_snp_engine, schema=pg_schema, if_exists='replace')

        self._logger.info("Update ETF List - Completed")


if __name__ == '__main__':
    etf_loader = IntrinioEtfLoader()
    etf_loader.update_etf_list()
