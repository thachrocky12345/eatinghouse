#!/usr/bin/env bash

aws s3 cp s3://sbt-datapipeline-assets/loaders/elasticsearch/elasticsearch_data_loader.py /home/ec2-user/elasticsearch_data_loader.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/elasticsearch/category_map.json /home/ec2-user/category_map.json
aws s3 cp s3://sbt-datapipeline-assets/loaders/elasticsearch/suggestions.json /home/ec2-user/suggestions.json
aws s3 cp s3://sbt-datapipeline-assets/loaders/elasticsearch/.env /home/ec2-user/.env

echo "Running Elasticsearch Loader..."
python /home/ec2-user/elasticsearch_data_loader.py
