import sys
import traceback
import pandas as pd
import sqlalchemy
import json
import requests
from datetime import datetime, timedelta
from ratelimit import limits, sleep_and_retry
from environs import Env

GLOBAL_VAR = Env()
GLOBAL_VAR.read_env()
_create_engine = sqlalchemy.create_engine(
  'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
          user=GLOBAL_VAR("SNP_DB_USER"), password=GLOBAL_VAR("SNP_DB_CREDENTIALS"),
          host=GLOBAL_VAR("SNP_DB_HOST"), db=GLOBAL_VAR("SNP_DB_DATABASE")
  )
)

_sbt_cbonds_engine = _create_engine.engine

class HttpUrlAccessor :
  """
      The UrlQuery class is the super class for all URL query objects.
  """
  _max_tries  = 4
  _sleep_time = 15

  def __init__(self, protocol, domain_name, port=80, user_name = None, 
               credentials = None, useport = False) :
    """
       Constructor method used to initialize the class
    """
    self._useport = useport
    self._protocol = protocol
    self._domain_name = domain_name
    self._port = port
    self._user_name = user_name
    self._credentials = credentials

  def _get_formatted_domain (self):
    """
      Returns the formatted URL domain
      
      Returns:
          str: Formatted domain URL with port     
    """
    if self._useport == False:
      #TODO: This class needs to provide generic access to urls without ports
      pass
    elif self._port == 80 or self._port == 443 :
      return self._protocol + '://' + self._domain_name
    else :
      return self._protocol + '://' + self._domain_name + ":" + str(self._port)
      
  def _makerequest(self, url, data):
    headers = {
                'Content-type': 'application/json',
                'Accept': 'text/plain'
              }
              
    response = requests.post(url, data=json.dumps(data), headers=headers)
    return response.json()

class CBondsAccessor ():
  table_flow = 'cbonds_flow'
  table_offert = 'cbonds_offert'
  table_issue = 'cbonds_issue'
  table_prospectus = 'cbonds_prospectus'
  table_us_trading = 'cbonds_us_bond_trading'
  table_cbonds_trading = 'cbonds_us_trading'

  table_cbonds_emissions = 'cbonds_emissions'
  table_cbonds_emitents = 'cbonds_emitents'
  table_cbonds_flow = table_flow
  table_cbonds_offert = table_offert
  table_cbonds_emission_default = 'cbonds_emission_default'
  table_cbonds_emission_tap_issues = 'cbonds_emission_tap_issues'
  table_cbonds_countries = 'cbonds_countries'
  table_cbonds_branches = 'cbonds_branches'
  table_cbonds_emission_status = 'cbonds_emission_status'
  table_cbonds_coupon_types = 'cbonds_coupon_types'

  def __init__ (self):
    self.cbondsApi = CBondsApi()
      
  def bulk_upsert_pg(self, table_name, items):
    df = pd.DataFrame(items)
    df.to_sql(table_name,
              _sbt_cbonds_engine, schema='cbonds',
              if_exists='replace')
    
class CBondsApi (HttpUrlAccessor):
  def __init__(self):  
    api_config = {
      
    }
    self._json_service = "services/json"    
    super().__init__("https", 
                     GLOBAL_VAR("DOMAIN_NAME"), 
                     443,
                     None,
                     None,
                     True)  
    
    self._user_name = GLOBAL_VAR("USERNAME")
    self._credentials = GLOBAL_VAR("CREDENTIALS")

    self._req = {
      "auth": self._get_authentication(),
      "filters": [],
      "quantity": {},
      "sorting": [{"field": "id", "order": "asc"}]
    }

  def get_url(self, path, lang="eng", cache_all_revalidate=0, nocache_all=0):
    return self._get_formatted_domain() + '/' + self._json_service + '/' + path + \
           '?lang=' + lang + '&cache_all_revalidate' + str(cache_all_revalidate) + '&nocache_all=' + str(nocache_all)


  def cbond_detail(self, url_path, filter_field=None, filter_value=None, page=1, limit=25, filter_operator='eq'):
    req = self._req
    if filter_field:
      req['filters'] = [{
        "field": filter_field,
        "operator": filter_operator,
        "value": filter_value
      }]

    req['quantity'] = {"limit": limit, "offset": (int(page) - 1) * int(limit)}

    url = self.get_url(url_path)
              
    resp = self._makerequest(url, req)
    return resp

  def _get_authentication (self):
    return {"login":      self._user_name,
            "password":   self._credentials}
            
class CBondsDataLoad():
  ONE_MINUTE = int(GLOBAL_VAR("ONE_MINUTE")) # Seconds
  CALL_COUNT = int(GLOBAL_VAR("CALL_COUNT")) # Call count per minute
  limit = int(GLOBAL_VAR("LIMIT")) # Maximum record per request

  def __init__(self):
    self._cbonds_accessor = CBondsAccessor()
    self.cbondsApi = CBondsApi()

  # By Default Load incremental data for last 7 days
  def load_incremental_data(self, days=7):
    data_from = (datetime.now() + timedelta(days=-days)).strftime("%x")
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_emissions, 'get_emissions', 'emission', 'update_time', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_emitents, 'get_emitents', 'emitent', 'updating_date', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_flow, 'get_flow', 'flow', 'updating_date', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_offert, 'get_offert', 'offert', 'updating_date', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_emission_default, 'get_emission_default', 'emission_default', 'updating_date', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_emission_tap_issues, 'get_emission_tap_issues', 'emission_tap_issues', 'updating_date', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_countries, 'get_countries', 'countries', 'update_time', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_branches, 'get_branches', 'branches', 'branch_update_time', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_coupon_types, 'get_coupon_types', 'coupon_types', 'statuses_update_time', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_emission_status, 'get_emission_statuses', 'emission_status', 'statuses_update_time', data_from)
    self.load_incremental_cbond_data(self._cbonds_accessor.table_cbonds_trading, 'get_tradings', 'trading', 'date', data_from)

  def load_incremental_cbond_data(self, table_name, url, type, filter_field, filter_value, filter_operation='gt'):
    try:
      page = 1
      page_available = True

      print(type + " incremental import starts")
      while page_available:
        res = self.get_incremental_cbond_data(url, filter_field, filter_value, page, self.limit, filter_operation)

        if res["count"] > 0:
          items = res['items']
          self._cbonds_accessor.bulk_upsert_pg(table_name, items)

        if res["count"] > 0 and res["total"] > (page * self.limit):
          page += 1
          print(type + ' incrementing page to ' + str(page))
        else:
          print(type + ' no more page available')
          page_available = False

      print(type + ' incremental import completed')
    except Exception as e:
      print(type + ' page-requested:' + str(page) + ' ~ exception-time: ' + str(datetime.now()))
      print('Type: ' + type +
                         'Exception: ' + str(e) +
                         'Trace: ' + traceback.format_exc())

  def log_message(self, type, message):
    d = datetime.now()
    print(str(d) + ' ~ ' + type + ' ~ ' + d.strftime('%s') + ' ~ ' + message)

  @sleep_and_retry
  @limits(calls=CALL_COUNT, period=ONE_MINUTE)
  def get_incremental_cbond_data(self, url, filter_field, filter_value, page, limit, filter_operation):
    return self.cbondsApi.cbond_detail(url, filter_field, filter_value, page, limit, filter_operation)

if __name__ == "__main__":
  CBondsDataLoad().load_incremental_data(7)