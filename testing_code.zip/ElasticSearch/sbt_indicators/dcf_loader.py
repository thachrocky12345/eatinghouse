import logging
import numpy as np
import datetime
import pandas as pd
import os
import sys
import json
import sqlalchemy
from dateutil.relativedelta import relativedelta
from scipy import stats
from sqlalchemy import JSON, FLOAT, VARCHAR, text

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']


class DCFModel:
    def __init__(self):
        # configure logging
        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        self.end_date = datetime.datetime.now()
        self.start_date = self.end_date - relativedelta(years=5)

        # read the entire config file
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        # self.ENV = 'dev'
        self._snp_pg = config['dev']['postgres']['snpsource']
        self._snp_engine = self._create_pg_engine(self._snp_pg)

        self._pg_df = config['dev']['postgres']['datafactory']
        self._pg_df_engine = self._create_pg_engine(self._pg_df)

        self._pg_df_qa = config['qa']['postgres']['datafactory']
        self._pg_df_qa_engine = self._create_pg_engine(self._pg_df_qa)

        self._pg_df_prod = config['prod']['postgres']['datafactory']
        self._pg_df_prod_engine = self._create_pg_engine(self._pg_df_prod)

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_df_engine,
                             'QA': self._pg_df_qa_engine,
                             'PROD': self._pg_df_prod_engine}

        self.EXCHANGE_MAPPING = {
            'NasdaqGS': 'NSDQ',
            'NasdaqGM': 'NSDQ',
            'NasdaqCM': 'NSDQ',
            'ARCA': 'NYSEARCA'
        }
        self.SB_EXCHANGE_MAPPING = {
            'TSX': 'TO',
            'LSE': 'L',
            'AIM': 'L',
            'SEHK': 'HK',
            'TSXV': 'V',
            'PAR': 'PA',
            'STO': 'ST',
            'BSE': 'BR',
            'JPX': 'T',
            'CSE': 'CO',
            'FWB': 'DE',
            'SIX': 'SW',
            'MCX': 'ME',
            'MCE': 'MC',
            'ATH': 'AT',
            'MIL': 'MI',
        }
        self.rf_rate = pd.read_sql("SELECT * FROM timeseries_external_data WHERE composite_pk_id = 'DGS5:FRED'",
                                   self._pg_df_engine).sort_values('timestamp').iloc[-1]['value']/100
        self.fcf_data = pd.read_sql('SELECT * FROM v_indicators_dcf_fcf_metrics', self._snp_engine)
        self.data = pd.read_sql('SELECT * FROM v_indicators_dcf_current_metrics', self._snp_engine)
        aggregation_functions = {'fcf_curr1': 'sum',
                                 'fcf_curr2': 'sum', 'fcf_curr3': 'sum', 'fcf_curr4': 'sum', 'fcf_minus1_1': 'sum',
                                 'fcf_minus1_2': 'sum', 'fcf_minus1_3': 'sum', 'fcf_minus1_4': 'sum',
                                 'fcf_minus2_1': 'sum', 'fcf_minus2_2': 'sum', 'fcf_minus2_3': 'sum',
                                 'fcf_minus2_4': 'sum', 'fcf_minus3_1': 'sum', 'fcf_minus3_2': 'sum',
                                 'fcf_minus3_3': 'sum', 'fcf_minus3_4': 'sum', 'fcf_minus4_1': 'sum',
                                 'fcf_minus4_2': 'sum', 'fcf_minus4_3': 'sum', 'fcf_minus4_4': 'sum',
                                 'fcf_minus5_1': 'sum', 'fcf_minus5_2': 'sum', 'fcf_minus5_3': 'sum',
                                 'fcf_minus5_4': 'sum', 'companyid': 'first'}
        self.agg_fcf_data = self.fcf_data.groupby(self.fcf_data['companyid']).aggregate(aggregation_functions)
        self.data['interestexpense'] = self.data['interestexpense'] * -1
        self.data['efftaxrate'] = self.data['efftaxrate'] / 100
        self.data['sharesoutstanding'] = self.data['sharesoutstanding']/1000000
        self.agg_fcf_data.reset_index(inplace=True, drop=True)
        self.mergeddata = pd.merge(left=self.data, right=self.agg_fcf_data, left_on='companyid', right_on='companyid')
        self.results = pd.DataFrame(columns=['tickersymbol', 'exchangesymbol', 'tradingitemid', 'dcf_val', 'curr_price',
                                             'upside_percent', 'adj_growth_rate', 'wacc'])

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )


    # def load_values(self):
    #     print("Risk Free Rate: {}".format(self.rf_rate))
    #
    #     beta_mktrtn = calculateBeta_and_mktReturn('AAPL')
    #     print("Beta: {}".format(beta_mktrtn[0]))
    #     print("Market Return: {}".format(beta_mktrtn[1]))
    #
    #     equity = float(query[0]['totalequity'])
    #     print("Total Equity: {}".format(equity))
    #     debt = float(query[0]['debt'])
    #     print("Total Debt: {}".format(debt))
    #     interest = float(query[0]['cashinterestpaid'])
    #     print("Total Interest: {}".format(interest))
    #     tax_rate = float(query[0]['efftaxrate'])
    #     print("Tax Rate: {}".format(tax_rate))
    #     fcf = float(query[0]['freecashflow'])
    #     print("Free Cash Flow: {}".format(fcf))
    #     shrs_outstanding = float(query[0]['weightedavebasicsharesos'])
    #     print("Shares Outstanding: {}".format(shrs_outstanding))
    #     fcf_growth = float(query[0]['fcffgrowth'])
    #     print("Free Cash Flow Growth: {}".format(fcf_growth))
    #     ebitda = float(query[0]['ebitda'])
    #     print("EBITDA: {}".format(ebitda))
    #     ev = float(query[0]['enterprisevalue'])
    #     print("Enterprise Value: {}".format(ev))
    #
    #     ke = calculate_capm(risk_free, beta_mktrtn[0], beta_mktrtn[1])
    #     print("Cost of Equity: {}".format(ke))
    #     kd = calculate_kd(interest, debt)
    #     print("Cost of Debt: {}".format(kd))
    #     wacc = calculate_wacc(equity, debt, ke, kd, tax_rate)
    #     print("WACC: {}".format(wacc))
    #     dcf = calculateDCF(fcf, fcf_growth, wacc, shrs_outstanding, ebitda, ev)
    #     print("DCF Analysis Predicted Stock Price: '${:,.2f}'".format(dcf))
    #
    #     return dcf

    # aka cost of equity
    def calculate_capm(self, risk_free_rate, beta, market_return):
        return risk_free_rate + (beta * (market_return - risk_free_rate))

    def calculate_kd(self, tot_int, tot_debt):
        try:
            return tot_int/tot_debt
        except ZeroDivisionError:
            return 0

    def calculate_wacc(self, equity, debt, cost_of_equity, cost_of_debt, corporate_tax_rate):
        v = equity + debt
        return ((equity/v) * cost_of_equity) + ((debt/v) * cost_of_debt * (1 - corporate_tax_rate))

    def calculateDCF(self, current_fcf, growth_rate, WACC, shares_outstanding, ebitda, ev, debt, cashandequiv):
        fcf_lst = []
        for x in range(0, 5):
            if current_fcf < 0:
                current_fcf = current_fcf * (1 - growth_rate)
            elif current_fcf == 0:
                if len(fcf_lst) > 1:
                    current_fcf = abs(fcf_lst[-2]) * (1 + growth_rate)
                else:
                    current_fcf = 1 * (1 + growth_rate)
            else:
                current_fcf = current_fcf * (1 + growth_rate)
            fcf_lst.append(current_fcf)
            # print(current_fcf)
        # print(fcf_list)
        # print("NPV:", np.npv(WACC, fcf_list))
        if WACC > 0:
            pre_terminal_value = np.npv(WACC, fcf_lst)
        else:
            print(WACC)
            print('negative wacc')
            pre_terminal_value = np.npv(WACC, fcf_lst)
        # if pre_terminal_value <= 0:
        #     return 0
        terminal_value = (current_fcf * (1+0.025)) / (WACC - 0.025)
        dcf = (pre_terminal_value + terminal_value)
        # Not sure about using this one
        if terminal_value/dcf > 0.9:
            return (pre_terminal_value + cashandequiv - debt)/shares_outstanding
        else:
            return (dcf + cashandequiv - debt)/shares_outstanding

    def get_prices(self, tradingitemid):
        sql_start = """SELECT * FROM v_price_timeseries WHERE pricingdate >= '{}' AND tradingitemid = '{}';"""
        return pd.read_sql(sql_start.format(self.start_date, tradingitemid),
                           self._snp_engine).sort_values('pricingdate')

    def calculate_beta_mktReturn(self, tradingitemid, spy_prices, mkt_rtn):
            stock_prices = self.get_prices(tradingitemid)
            stock_prices['rets'] = stock_prices['divadjprice'].pct_change()

            # stock_lst = []
            # mkt_lst = []
            # for x in range(len(stock_prices)):
            #     stock_lst.append(float(stock_prices['divadjprice'].iloc[x]))
            #     mkt_lst.append(float(spy_prices['divadjprice'].iloc[x]))
            #
            # stock_return_list = []
            # market_return_list = []
            # for y in range(1, len(stock_prices)):
            #     stock_return_list.append((stock_lst[y]-stock_lst[y-1])/stock_lst[y-1])
            #     market_return_list.append((mkt_lst[y] - mkt_lst[y - 1]) / mkt_lst[y - 1])
            merged_pricing = pd.merge(left=stock_prices, right=spy_prices, left_on='pricingdate', right_on='pricingdate')
            merged_pricing.at[0, 'rets_y'] = np.nan


            # print(stock_return_list)
            # print(market_return_list)
            # print(lst)
            # stock_rtn = (stock_lst[-1] - stock_lst[0]) / (stock_lst[0])
            # print(stock_rtn)
            #
            # mkt_rtn = (mkt_lst[-1] - mkt_lst[0]) / (mkt_lst[0])

            # print(mkt_rtn)
            ret_x = merged_pricing['rets_x'].dropna()
            ret_y = merged_pricing['rets_y'].dropna()
            while len(ret_x) < len(ret_y):
                ret_y = ret_y[1:]
            try:
                covariance = np.cov(ret_x, ret_y, bias=True)[0][1]
            except ZeroDivisionError:
                print('error calculating beta')
                try:
                    return 1, mkt_rtn, stock_prices['divadjprice'].iloc[-1]
                except IndexError:
                    print('error retrieving last stock price')
                    return 1, mkt_rtn, np.nan
            # print(Covariance)
            variance_mkt = np.var(ret_y)
            # print(variance_mkt)
            beta = (covariance / variance_mkt)

            return beta, mkt_rtn, stock_prices['divadjprice'].iloc[-1]

    def calculate_growth_rate(self, fcf_lst):
        growth_rates = []
        for i in range(1, len(fcf_lst)):
            try:
                growth_rates.append((fcf_lst[i] - fcf_lst[i-1]) / abs(fcf_lst[i-1]))
            except ZeroDivisionError:
                if fcf_lst[i] > 0:
                    growth_rates.append(1)
                elif fcf_lst[i] < 0:
                    growth_rates.append(-1)
                else:
                    growth_rates.append(0)
        # print(growth_rates)
        growth_rate = np.median(growth_rates)

        slope, intercept, r_value, p_value, std_err = stats.linregress(range(0, 5), fcf_lst)
        if r_value**2 > .7:
            new_fcf = (intercept + (slope * 5))
            adjusted_growth_rate = (new_fcf - fcf_lst[-1])/abs(fcf_lst[-1])
        else:
            # adjusted_growth_rate, variance = self.calculate_adjusted_growth_rate(growth_rates, growth_rate)
            adjusted_growth_rate = 0.1*growth_rates[0] + 0.2*growth_rates[1] + 0.3*growth_rates[2] + 0.4*growth_rates[3]
            if abs(adjusted_growth_rate) > 1:
                adjusted_growth_rate = growth_rate
            if adjusted_growth_rate < 0:
                adjusted_growth_rate = adjusted_growth_rate * (1 + 1 - r_value**2)
            else:
                adjusted_growth_rate = adjusted_growth_rate * r_value**2
            # print("Growth Rate:", growth_rate, "Adj", adjusted_growth_rate)
        return growth_rate, adjusted_growth_rate

    def run(self):
        self.mergeddata['interestexpense'][np.isnan(self.mergeddata['interestexpense'])] = 0
        self.mergeddata['ltliabilities'][np.isnan(self.mergeddata['ltliabilities'])] = 0
        self.mergeddata['cashandequiv'][np.isnan(self.mergeddata['cashandequiv'])] = 0
        self.mergeddata['efftaxrate'][np.isnan(self.mergeddata['efftaxrate'])] = .21
        print(len(self.mergeddata['tickersymbol']))
        self.mergeddata = self.mergeddata[self.mergeddata['gicsgroup'] != 'Banks']
        print(len(self.mergeddata['tickersymbol']))

        spy_tradingitemid = 6179710
        spy_prices = self.get_prices(spy_tradingitemid)
        spy_prices['rets'] = spy_prices['divadjprice'].pct_change()
        mkt_rtn = (spy_prices['divadjprice'].iloc[-1] / spy_prices['divadjprice'].iloc[0]) ** (1 / 5) - 1

        for stock in self.mergeddata.iterrows():
            count = stock[0]
            stock = stock[1]
            # print()
            print(stock['tickersymbol'])
            fcf_lst_curr = [stock['fcf_curr1'], stock['fcf_curr2'], stock['fcf_curr3'], stock['fcf_curr4']]
            fcf_lst_1 = [stock['fcf_minus1_1'], stock['fcf_minus1_2'], stock['fcf_minus1_3'], stock['fcf_minus1_4']]
            fcf_lst_2 = [stock['fcf_minus2_1'], stock['fcf_minus2_2'], stock['fcf_minus2_3'], stock['fcf_minus2_4']]
            fcf_lst_3 = [stock['fcf_minus3_1'], stock['fcf_minus3_2'], stock['fcf_minus3_3'], stock['fcf_minus3_4']]
            fcf_lst_4 = [stock['fcf_minus4_1'], stock['fcf_minus4_2'], stock['fcf_minus4_3'], stock['fcf_minus4_4']]
            fcf_lst_5 = [stock['fcf_minus5_1'], stock['fcf_minus5_2'], stock['fcf_minus5_3'], stock['fcf_minus5_4']]
            fcf_total_lst = fcf_lst_5 + fcf_lst_4 + fcf_lst_3 + fcf_lst_2 + fcf_lst_1 + fcf_lst_curr
            fcf_total_lst = np.trim_zeros(fcf_total_lst)

            fcf_yr_lst = [sum(fcf_total_lst[-20:-16]), sum(fcf_total_lst[-16:-12]), sum(fcf_total_lst[-12:-8]),
                          sum(fcf_total_lst[-8:-4]), sum(fcf_total_lst[-4:len(fcf_total_lst)])]
            # print(fcf_yr_lst)

            growth_rate, adjusted_growth_rate = self.calculate_growth_rate(fcf_yr_lst)
            # print(adjusted_growth_rate, variance)

            beta, mkt_rtn, last_price = self.calculate_beta_mktReturn(stock['tradingitemid'], spy_prices, mkt_rtn)
            ke = self.calculate_capm(self.rf_rate, beta, mkt_rtn)
            # print("Cost of Equity: {}".format(ke))
            kd = self.calculate_kd(stock['interestexpense'], stock['ltliabilities'])
            if kd < 0:
                kd = 0
            wacc = self.calculate_wacc(stock['marketcap'], stock['ltliabilities'], ke, kd, stock['efftaxrate'])
            # print("Cost of Debt: {}".format(kd))
            # print("WACC: {}".format(wacc))

            curr_fcf = sum(fcf_total_lst[-4:len(fcf_total_lst)])
            if curr_fcf < 0:
                if fcf_yr_lst[-2] > curr_fcf:
                    curr_fcf = fcf_yr_lst[-2]
            dcf_val = self.calculateDCF(curr_fcf, adjusted_growth_rate, wacc,
                                        stock['sharesoutstanding'], stock['ebitda'], stock['tev'], stock['ltliabilities'], stock['cashandequiv'])
            # print("DCF Analysis Predicted Stock Price: '${:,.2f}'".format(dcf), 'UPSIDE: ', (dcf-last_price)/last_price)
            # print(stock['tickersymbol'], adjusted_growth_rate, dcf_val, last_price, (dcf_val - last_price) /
            # last_price)
            self.results.loc[count] = {'tickersymbol': stock['tickersymbol'], 'exchangesymbol': stock['exchangesymbol'],
                                       'tradingitemid': stock['tradingitemid'], 'dcf_val': dcf_val,
                                       'curr_price': last_price, 'upside_percent': (dcf_val - last_price) / last_price,
                                       'adj_growth_rate': adjusted_growth_rate, 'wacc': wacc}

    def create_model_stats_table(self, data=None):
        print(
            'DCF: CREATING STATS TABLE IN PG...')
        tic = datetime.datetime.now()
        # # # rating stats table
        TABLE_NAME = "sbt_indicator_dcf_rating_stats"
        # get the min/max for the model's rank (:= total number of points),
        # which is the most important result for CE
        df_stats = data.groupby(by='rating') \
            .agg({"score": [min, max, "count"]})
        # rename columns
        df_stats.columns = ['minRank', 'maxRank', 'total']
        # save rating stats
        for env in ENVS_TO_UPDATE:
            df_stats.to_sql(TABLE_NAME,
                            self.db_to_update.get(env.upper()),
                            if_exists='replace',
                            index_label='rating'
                            )
        # # rank stats table
        TABLE_NAME = "sbt_indicator_dcf_score_stats"
        model_stat_df = data.agg({'score': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minscore', 'maxscore', 'total']
        # stats per model (total within each rank bin)
        data.loc[(self.results['upside_percent'] >= 0.1), 'score'] = 100
        data.loc[(self.results['upside_percent'] <= -0.1), 'score'] = 0
        data.loc[(self.results['upside_percent'] <= 0.1) & ((self.results['upside_percent'] >= -0.1)), 'score'] = 50
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['score'], [-1000, -999, 20, 40, 60, 80, 100])
        )['score'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        for env in ENVS_TO_UPDATE:
            model_score_stat_df.to_sql(TABLE_NAME,
                                       self.db_to_update.get(env.upper()),
                                       if_exists='replace'
                                       )
        print(
            'DCF: DCF TABLE CREATED IN Dt = {}'.format(
                datetime.datetime.now() - tic)
        )

    def get_exchange_mapping(self, exchange_symbol, sb_map=False):
        if exchange_symbol is not None:
            if exchange_symbol.startswith('OTC'):
                exchange_mapping = 'OTC'
            else:
                exchange_mapping = \
                    self.EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol) \
                        if not sb_map else \
                    self.SB_EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol)
        else:
            self._logger.error(" EXCHANGE IS NONE.")
            exchange_mapping = exchange_symbol

        return exchange_mapping

    def data_load(self):
        print("Running")
        self.run()
        self.results = self.results.loc[~np.isnan(self.results['upside_percent'])]
        self.results.loc[(self.results['upside_percent'] >= 0.1), 'rating'] = 'Under Valued'
        self.results.loc[(self.results['upside_percent'] <= -0.1), 'rating'] = 'Over Valued'
        self.results.loc[(self.results['upside_percent'] <= 0.1) & ((self.results['upside_percent'] >= -0.1)),
                         'rating'] = 'Fairly Valued'
        # self.results.loc[self.results['exchangesymbol'].isin(['NasdaqGS', 'NasdaqGM']), 'exchangesymbol'] = 'NSDQ'
        # self.results.loc[self.results['exchangesymbol'] == 'NasdaqCM', 'exchangesymbol'] = 'NSDQCM'
        # self.results.loc[self.results['exchangesymbol'] == 'ARCA', 'exchangesymbol'] = 'NYSEARCA'
        # self.results['composite_pk_id'] = self.results['tickersymbol'] + ':' + self.results['exchangesymbol']
        self.results['score'] = self.results['upside_percent']
        self.results['composite_pk_id'] = ["{}:{}".format(sym, self.get_exchange_mapping(exc)) for sym, exc in zip(self.results['tickersymbol'], self.results['exchangesymbol'])]
        self.results = self.results.sort_values('upside_percent')
        self.results.reset_index(inplace=True, drop=True)
        self.results['rank'] = self.results.index/(len(self.results.index)-1)
        self.results['model'] = ""
        # count = 0
        for row in self.results.iterrows():
            count = row[0]
            row = row[1]
            self.results.at[count, 'model'] = {
                'model': {
                    "composite_pk_id": row["composite_pk_id"],
                    'date_calculated': datetime.datetime.now().strftime('%Y-%m-%d'),
                    "guid": str(row["tradingitemid"]),
                    'score': row['upside_percent'],
                    'value': row['upside_percent'],
                    'rank': row['rank'],
                    'rating': row['rating'],
                    'raw_data': {},
                    'calculated_data': {"wacc": {"calculation": row['wacc']*100, "value": row['wacc']*100, "date_calculated": datetime.datetime.now().strftime('%Y-%m-%d'), "description": "WACC", "display_value_as": "percentage"},
                                        "growth_rate": {"calculation": row['adj_growth_rate']*100, "value": row['adj_growth_rate']*100, "date_calculated": datetime.datetime.now().strftime('%Y-%m-%d'), "description": "FCF Growth Rate", "display_value_as": "percentage"},
                                        "fair_value": {"calculation": row['dcf_val'], "value": row['dcf_val'], "date_calculated": datetime.datetime.now().strftime('%Y-%m-%d'), "description": "Fair Value", "display_value_as": "currency"},
                                        "upside_percent": {"calculation": row['upside_percent']*100, "value": row['upside_percent']*100, "date_calculated": datetime.datetime.now().strftime('%Y-%m-%d'), "description": "Upside", "display_value_as": "percentage"}}
                }
            }
            # count = count + 1
        to_db = self.results[['tradingitemid', 'composite_pk_id', 'model', 'rank', 'rating', 'score']]
        # renaming column in place
        to_db.rename(columns={"tradingitemid": "trading_item_id"}, inplace=True)
        to_db = to_db.sort_values('rank', ascending=False)
        self._logger.info(" DONE.")

        tic = datetime.datetime.now()
        for env in ENVS_TO_UPDATE:
            to_db.to_sql(
                'sbt_indicator_dcf',
                self.db_to_update.get(env.upper()),
                if_exists='replace',
                index=False,
                dtype={
                    'model': JSON,
                    'score': FLOAT,
                    'rank': FLOAT,
                    'rating': VARCHAR,
                    'composite_pk_id': VARCHAR
                })
            tac = datetime.datetime.now()

            self._logger.info(" {}: DATA SAVED IN Dt={}.".format(
                env.upper(), tac - tic)
            )
        self.create_model_stats_table(data=to_db)


# this test is for DHI... WACC is almost perfect based on my calculations
if __name__ == '__main__':
    import time
    start = time.time()
    print(start)
    dcf = DCFModel()
    dcf.data_load()
    end = time.time()
    print(end)
    print(start-end)
