import logging
import os
import sys

import simplejson as json
import sqlalchemy
import pandas as pd
import numpy as np
import datetime

from sqlalchemy import JSON, FLOAT, VARCHAR, text
from io import StringIO

# suppress warning SettingWithCopyWarning messages from pandas
pd.options.mode.chained_assignment = None

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']


class CapitalEfficiencyIndicator(object):

    def __init__(self):
        self._SUPPORTED_SECURITIES_TABLE_NAME = 'v2mv_sbt_company'
        self._RESULT_TABLENAME_PREFIX = 'test_new_loader_sbt_models'

        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # read the entire config file
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        ### PG
        # get the config for data factory DB
        self._pg_df = config['dev']['postgres']['datafactory']
        self._pg_df_engine = self._create_pg_engine(self._pg_df)

        self._pg_df_qa = config['qa']['postgres']['datafactory']
        self._pg_df_qa_engine = self._create_pg_engine(self._pg_df_qa)

        self._pg_df_prod = config['prod']['postgres']['datafactory']
        self._pg_df_prod_engine = self._create_pg_engine(self._pg_df_prod)

        # get the config for sbtcompanyfin DB
        self._pg_snpfin = config['dev']['postgres']['snpcompanyfinancials']
        self._pg_snpfin_engine = self._create_pg_engine(self._pg_snpfin)

        # get the config for XPF DB
        self._pg_snp = config['dev']['postgres']['snpsource']
        self._pg_snp_engine = self._create_pg_engine(self._pg_snp)

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_df_engine,
                             'QA': self._pg_df_qa_engine,
                             'PROD': self._pg_df_prod_engine}

        # dataframe to contain all the data necessary for an indicator
        self.data_df = None
        # dataframe to contain info about the company and financial period
        self.company_data_df = None
        # dict to contain all the calculations for the indicator
        self.calculations_dict = {}
        # dataframe to contain the results for the indicator
        # (calculations & ranking)
        self.indicator = None
        # dataframe to contain the final results for the indicator
        # (calculations, ranking, and company/financial info)
        self.result = None

        # read scoring system for the models
        # scoring_system = pd.read_json("./models_scoring_system.json", orient="records")
        scoring_system = {
            "ce": {
                "fcf_to_revenue": {
                    "to": [1000000, 40, 31, 22, 15, 8, 0, -8, -16, -25, -34,
                           -10000],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.35
                },
                "roa": {
                    "to": [1000000, 15, 12, 8, 6, 3, 0, -3, -5, -9, -12, -100],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.25
                },
                "revenue_growth": {
                    "to": [1000000, 54, 43, 32, 24, 16, 9, 1, -8, -19, -30,
                           -100],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.10
                },
                "sh_return": {
                    "to": [1000000, 25, 19, 12, 7, 1, -1, -7, -12, -19, -25,
                           -100],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.30
                },
                "FIVE_YEAR_FCF_REVENUE_AVERAGE": {
                    "to": [1000000, 40, 31, 22, 15, 8, 0, -8, -16, -25, -34,
                           -10000],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.35
                },
                "FIVE_YEAR_ROA": {
                    "to": [1000000, 15, 12, 8, 6, 3, 0, -3, -5, -9, -12, -100],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.25
                },
                "FIVE_YEAR_REVENUE_GROWTH": {
                    "to": [1000000, 54, 43, 32, 24, 16, 9, 1, -8, -19, -30,
                           -100],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.10
                },
                "FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE": {
                    "to": [1000000, 25, 19, 12, 7, 1, -1, -7, -12, -19, -25,
                           -100],
                    "points": [100, 95, 90, 80, 70, 60, 50, 40, 30, 20, 10,
                               -999],
                    "weight": 0.30
                },
                "rating": {
                    "to": [100, 80, 75, 70, 63, 55, 48, 40, 30, 20, 0, -99],
                    "grade": ["A", "B", "B", "C", "C", "C", "C", "D", "D", "F",
                              "F", "N/A"]
                }
            }
        }
        self.SCORING_SYSTEM = pd.DataFrame.from_dict(scoring_system['ce'])

        # points to be deducted from total points each time a criteria IS NOT met
        self.penalty_value = 5
        # list of calculated items and its description to be used in the UI
        self.calc_data_item_description = {}

        # list of items to get from company table
        self.AVAILABLE_ITEMS = {
            'tickersymbol': 'symbol',
            'exchangesymbol': 'exchange_id',
            'tradingitemid': 'trading_item_id'
        }

        # mapping between alias and S&P's dataItemId
        self.PARAMETER_MAPPING = {
            'issuanceofpreferredequity': 2181,
            'capex': 2021,
            'repurchaseofpreferredequity': 2172,
            'repurchaseofcommonequity': 2164,
            'paymentofdividends': 2022,
            'issuanceofcommonequity': 2169,
            'netcashfromoperatingactivities': 2006,
            'roa': 4178,
            'revenuegrowth': 4194,
            'totalrevenue': 28,
            'debt': 4173
        }

        # RAW PARAMETERS NEEDED (MODEL SPECIFIC)
        self.RAW_DATA_LABELS = {
            '2181': {
                'df_name': 'issuanceofpreferredequity',
                'alias': 'Issuance of preferred equity'
            },
            '2021': {
                'df_name': 'capex',
                'alias': 'Capital Expenditure'
            },
            '2172': {
                'df_name': 'repurchaseofpreferredequity',
                'alias': 'Repurchase of preferred equity'
            },
            '2164': {
                'df_name': 'repurchaseofcommonequity',
                'alias': 'Repurchase of common equity'
            },
            '2022': {
                'df_name': 'paymentofdividends',
                'alias': 'Common & Preferred Stock Dividends Paid'
            },
            '2169': {
                'df_name': 'issuanceofcommonequity',
                'alias': 'Issuance of common equity'
            },
            '2006': {
                'df_name': 'netcashfromoperatingactivities',
                'alias': 'Cash from Operations'
            },
            '4178': {
                'df_name': 'roa',
                'alias': 'Return on assets'
            },
            '4194': {
                'df_name': 'revenuegrowth',
                'alias': 'Total revenue (1-yr growth %)'
            },
            '28': {
                'df_name': 'totalrevenue',
                'alias': 'Total revenue'
            },
            '4173': {
                'df_name': 'debt',
                'alias': 'Total debt'
            },
            '4422': {
                'df_name': 'freecashflow',
                'alias': 'Levered FCF'
            }
        }
        # DESCRIPTIONS TO BE DISPLAYED IN THE UI (MODEL SPECIFIC)
        #
        # CALCULATED PARAMETERS
        self.CALCULATED_DATA_LABELS = {
            'fcf_to_revenue': {
                'label': 'FCF-to-revenue ratio',
                'display_value_as': 'percentage'
            },
            'roa': {
                'label': 'Return on asset',
                'display_value_as': 'ratio'
            },
            'revenue_growth': {
                'label': 'Revenue growth (1 yr)',
                'display_value_as': 'percentage'
            },
            'sh_return': {
                'label': 'Shareholder return',
                'display_value_as': 'percentage'
            }
        }

        # exchange_symbol mapping (from ES loader)
        self.EXCHANGE_MAPPING = {
            'Nasdaq': 'NSDQ',
            'NASDAQ': 'NSDQ',
            'NasdaqGS': 'NSDQ',
            'NasdaqGM': 'NSDQ',
            'NasdaqCM': 'NSDQCM',
            'ARCA': 'NYSEARCA',
        }
        self.SB_EXCHANGE_MAPPING = {
            'TSX': 'TO',
            'LSE': 'L',
            'AIM': 'L',
            'SEHK': 'HK',
            'TSXV': 'V',
            'PAR': 'PA',
            'STO': 'ST',
            'BSE': 'BR',
            'JPX': 'T',
            'CSE': 'CO',
            'FWB': 'DE',
            'SIX': 'SW',
            'MCX': 'ME',
            'MCE': 'MC',
            'ATH': 'AT',
            'MIL': 'MI',
        }

    def to_pg(self, df, table_name, col_order=None, drop_previous_table=False):
        data = StringIO()
        # write to CSV format
        if col_order is not None:
            df.to_csv(data, columns=col_order, header=False, index=False)
        else:
            df.to_csv(data, header=False, index=False)
        # save to all envs
        for env in ENVS_TO_UPDATE:
            # get engine
            con = self.db_to_update.get(env.upper())
            # set pointer to the beginning of file
            data.seek(0)
            # get raw connection
            raw = con.raw_connection()
            # get cursor
            curs = raw.cursor()
            if drop_previous_table:
                # drop previous table
                try:
                    curs.execute("DROP TABLE IF EXISTS {}".format(table_name))
                except:
                    self._logger.info("COULDN'T DROP TABLE {}".format(table_name))

                empty_table = pd.io.sql.get_schema(df, table_name, con=con)
                # remove undesired characters
                empty_table = empty_table.replace('"', '')
                empty_table = empty_table.replace('\t', '')

                curs.execute(empty_table)
            # copy from CSV format to table
            curs.copy_expert(
                """COPY {} FROM STDIN WITH (FORMAT CSV)""".format(table_name),
                data)
            # commit transactions
            curs.connection.commit()

    def get_exchange_mapping(self, exchange_symbol, sb_map=False):
        if exchange_symbol is not None:
            if exchange_symbol.startswith('OTC'):
                exchange_mapping = 'OTC'
            else:
                exchange_mapping = \
                    self.EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol) \
                        if not sb_map else \
                    self.SB_EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol)
        else:
            self._logger.error(" EXCHANGE IS NONE.")
            exchange_mapping = exchange_symbol

        return exchange_mapping

    def _get_points(self, criterion, value):
        score = np.array(self.SCORING_SYSTEM[criterion].to)
        point = np.array(self.SCORING_SYSTEM[criterion].points)

        rval = int(point[np.where(score > value)].min())

        return rval

    def _get_weighted_points(self, criterion, value):
        w = np.array(self.SCORING_SYSTEM[criterion].weight)
        weighted_point = w * value

        return weighted_point

    def _get_rating(self, value):
        final_point = np.array(self.SCORING_SYSTEM["rating"].to)
        grade = np.array(self.SCORING_SYSTEM["rating"].grade)

        rval = grade[np.where(final_point >= value)][-1]

        return rval

    def get_alias_mapping(self, value):
        # get alias from dataItemId
        key = [k for k, v in self.PARAMETER_MAPPING.items() if v == value][0]
        return key

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def _get_supported_securities(self):
        self._logger.critical(' EXTRACTING DATA -- GETTING LIST OF SUPPORTED SECURITIES...')
        # conditions for a supported security
        # CONDITIONS = "securityname ilike 'common%stock' " \
        #              "and exchangecountry = 'USA' " \
        #              "and exchangesymbol not ilike 'mutualfund'"
        CONDITIONS = "exchangesymbol in ('NYSE', 'AMEX', 'ARCA') " \
                     "or exchangesymbol like 'Nasdaq%' " \
                     "and is_primary_exchange is true"
        # build query
        SQL = text(
            "SELECT {items} FROM {table_name} WHERE {conditions};".format(
                items=', '.join(list(self.AVAILABLE_ITEMS.keys())),
                table_name=self._SUPPORTED_SECURITIES_TABLE_NAME,
                conditions=CONDITIONS
            ))
        # get supported securities
        self.supported_securities_df = pd.read_sql(SQL, self._pg_snp_engine)
        # remove preferred stocks (tickersymbol containing .PR*)
        self.supported_securities_df = self.supported_securities_df[
            self.supported_securities_df["tickersymbol"].str.contains(".PR") == False
            ]

    def _get_data(self):
        SQL = "SELECT * " \
              "FROM v_indicators_capitalefficiency " \
              "WHERE tradingitemid in ('{}')" \
              "".format("', '".join([str(x)
                                     for x in list(
                self.supported_securities_df.tradingitemid)]))
        # get data
        self.data_df = pd.read_sql(SQL, self._pg_snp_engine)
        # set indexes
        self.data_df.set_index(['tradingitemid', 'fiscalyear', 'periodenddate'], inplace=True)

        # data about the company and financial period
        self.company_data_df = self.data_df.drop(
            columns=['dataitemid', 'dataitemname', 'dataitemvalue']
        )
        # drop duplicates
        # self.company_data_df.drop_duplicates(inplace=True)

    def _add_item_description(self, item_description_dict):
        # add calculated item's description
        self.calc_data_item_description.update(item_description_dict)

    def save_result(self):
        # create final df containing everything for each company
        res = self.result[
            ['trading_item_id', 'composite_pk_id', 'model', 'rank', 'rating', 'score']
        ]
        # sort by score
        res = res.sort_values(by=['rank'], ascending=False).copy()
        self._logger.info(" DONE.")

        tic = datetime.datetime.now()
        # save to PG
        self.to_pg(res, "sbt_indicator_capeff", drop_previous_table=True)
        tac = datetime.datetime.now()
        self._logger.info(" DATA SAVED IN Dt={}.".format(tac - tic))

        for env in ENVS_TO_UPDATE:
            # res.to_sql(
            #     "sbt_indicator_capeff",
            #     self.db_to_update.get(env.upper()),
            #     if_exists='replace',
            #     index_label='trading_item_id',
            #     dtype={
            #         'model': JSON,
            #         'score': FLOAT,
            #         'rank': FLOAT,
            #         'rating': VARCHAR,
            #         'composite_pk_id': VARCHAR
            #     },
            #     method="multi"
            # )
            # tac = datetime.datetime.now()
            #
            # self._logger.info(" {}: DATA SAVED IN Dt={}.".format(
            #     env.upper(), tac - tic)
            # )

            # create stats table
            self._create_stats_table(res, env.upper())

    def _create_stats_table(self, data=None, env='DEV'):

        if data is None:
            data = pd.read_sql_table(
                "sbt_indicator_capeff",
                self.db_to_update.get(env)
            ).set_index('trading_item_id', drop=True, inplace=True)

        # rating stats table
        TABLE_NAME = "sbt_indicator_capeff_rating_stats"
        # get the min/max for the model's rank (:= total number of points),
        # which is the most important result for CE
        df_stats = pd.DataFrame([data['rating'], data['rank']]).T.groupby(
            by="rating").agg({"rank": [min, max, "count"]})
        # rename columns
        df_stats.columns = ['minRank', 'maxRank', 'total']
        # save rating stats
        df_stats.to_sql(TABLE_NAME,
                        self.db_to_update.get(env),
                        if_exists='replace',
                        index_label='rating')

        # rank stats table
        TABLE_NAME = "sbt_indicator_capeff_score_stats"
        model_stat_df = data.agg({'rank': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minrank', 'maxrank', 'total']
        # stats per model (total within each rank bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['rank'], [-1000, 0, 20, 40, 60, 80, 100])
        )['rank'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        model_score_stat_df.to_sql(TABLE_NAME,
                                   self.db_to_update.get(env),
                                   if_exists='replace')

    def load_data(self):
        self._get_supported_securities()
        self._get_data()

    def run_scoring_system(self):
        def get_fcf_to_revenue(res):
            data = {}

            try:
                # data necessary for calculation
                capex = [x['dataitemvalue'] for x in res if int(x['dataitemid'].iloc[0])
                         == self.PARAMETER_MAPPING.get('capex')][0]
                net_cash_from_operating_activities = [x['dataitemvalue'] for x in res if int(x['dataitemid'].iloc[0])
                                                      == self.PARAMETER_MAPPING.get('netcashfromoperatingactivities')][0]
                total_revenue = [x['dataitemvalue'] for x in res if int(x['dataitemid'].iloc[0])
                                 == self.PARAMETER_MAPPING.get('totalrevenue')][0]
                debt = [x['dataitemvalue'] for x in res if
                                 int(x['dataitemid'].iloc[0])
                                 == self.PARAMETER_MAPPING.get(
                                     'debt')][0]
                # FCF calculation
                fcf = capex + net_cash_from_operating_activities

                raw = {"freecashflow": fcf.fillna(0).copy(),
                       "capex": capex,
                       "totalrevenue": total_revenue,
                       "netcashfromoperatingactivities":
                           net_cash_from_operating_activities,
                       "debt": debt}

                data['raw'] = raw

                # aggregate by mean
                avg = {k: v['dataitemvalue'].groupby(level=0).agg('mean')
                    if 'dataitemvalue' in v.keys()
                    else v.groupby(level=0).agg('mean')
                    for k, v in data['raw'].items()}

                data['avg'] = avg

                value = data['avg']['freecashflow'] / data['avg']['totalrevenue'] * 100
                # drop NaN
                value = value[value.notna()].copy()

                data['value'] = value

                # get the total points
                data['points'] = pd.DataFrame(value).apply(lambda x: self._get_points('fcf_to_revenue', x['dataitemvalue']), axis=1)

                return data
            except Exception as e:
                self._logger.error(e)
                raise Exception

        def get_roa(res):
            data = {}

            try:
                # data necessary for calculation
                roa = [x['dataitemvalue'] for x in res if
                         int(x['dataitemid'].iloc[0])
                         == self.PARAMETER_MAPPING.get('roa')][0]

                raw = {"roa": roa}

                data['raw'] = raw

                # aggregate by mean
                avg = {k: v['dataitemvalue'].groupby(level=0).agg('mean')
                if 'dataitemvalue' in v.keys()
                else v.groupby(level=0).agg('mean')
                       for k, v in data['raw'].items()}

                data['avg'] = avg

                value = data['avg']['roa']
                # drop NaN
                value = value[value.notna()].copy()

                data['value'] = value

                # get the total points
                data['points'] = pd.DataFrame(value).apply(
                    lambda x: self._get_points('roa',
                                               x['dataitemvalue']), axis=1)

                return data
            except:
                raise Exception

        def get_revenue_growth(res):
            data = {}

            try:
                # data necessary for calculation
                revenuegrowth = [x['dataitemvalue'] for x in res if
                         int(x['dataitemid'].iloc[0])
                         == self.PARAMETER_MAPPING.get('revenuegrowth')][0]

                raw = {"revenuegrowth": revenuegrowth}

                data['raw'] = raw

                # aggregate by mean
                avg = {k: v['dataitemvalue'].groupby(level=0).agg('mean')
                if 'dataitemvalue' in v.keys()
                else v.groupby(level=0).agg('mean')
                       for k, v in data['raw'].items()}

                data['avg'] = avg

                value = data['avg']['revenuegrowth']
                # drop NaN
                value = value[value.notna()].copy()

                data['value'] = value

                # get the total points
                data['points'] = pd.DataFrame(value).apply(
                    lambda x: self._get_points('revenue_growth',
                                               x['dataitemvalue']), axis=1)

                return data
            except:
                raise Exception

        def get_sh_return(res):
            data = {}

            try:
                # data necessary for calculation
                paymentofdividends = [x['dataitemvalue'] for x in res if int(x['dataitemid'].iloc[0])
                         == self.PARAMETER_MAPPING.get('paymentofdividends')][0]
                issuanceofpreferredequity = [x['dataitemvalue'] for x in res if int(x['dataitemid'].iloc[0])
                                                      == self.PARAMETER_MAPPING.get('issuanceofpreferredequity')][0]
                issuanceofcommonequity = [x['dataitemvalue'] for x in res if
                                             int(x['dataitemid'].iloc[0])
                                             == self.PARAMETER_MAPPING.get(
                                                 'issuanceofcommonequity')][
                    0]
                repurchaseofcommonequity = [x['dataitemvalue'] for x in res if
                                      int(x['dataitemid'].iloc[0])
                                      == self.PARAMETER_MAPPING.get(
                                          'repurchaseofcommonequity')][0]
                repurchaseofpreferredequity = [x['dataitemvalue'] for x in res if
                                      int(x['dataitemid'].iloc[0])
                                      == self.PARAMETER_MAPPING.get(
                                          'repurchaseofpreferredequity')][0]
                totalrevenue = [x['dataitemvalue'] for x in res if
                                 int(x['dataitemid'].iloc[0])
                                 == self.PARAMETER_MAPPING.get(
                                     'totalrevenue')][0]
                # SH RETURN calculation
                # see equation here: https://bit.ly/2W8Z8fG
                sh_return = paymentofdividends.add(
                    repurchaseofcommonequity, fill_value=0
                ).sub(
                    issuanceofpreferredequity, fill_value=0
                ).add(
                    issuanceofcommonequity, fill_value=0
                )

                # SH RETURN as a fraction of the total revenue
                sh_return = sh_return.div(totalrevenue) * (-100)
                # SH RETURN cannot be NaN
                sh_return.fillna(0, inplace=True)

                raw = {"paymentofdividends": paymentofdividends,
                       "issuanceofpreferredequity": issuanceofpreferredequity,
                       "issuanceofcommonequity": issuanceofcommonequity,
                       "repurchaseofcommonequity": repurchaseofcommonequity,
                       "repurchaseofpreferredequity": repurchaseofpreferredequity,
                       "totalrevenue": totalrevenue,
                       "shreturn": sh_return}

                data['raw'] = raw

                # aggregate by mean
                avg = {k: v['dataitemvalue'].groupby(level=0).agg('mean')
                    if 'dataitemvalue' in v.keys()
                    else v.groupby(level=0).agg('mean')
                    for k, v in data['raw'].items()}

                data['avg'] = avg

                value = data['avg']['shreturn']

                data['value'] = value

                # get the total points
                data['points'] = pd.DataFrame(value).apply(lambda x: self._get_points('sh_return', x['dataitemvalue']), axis=1)

                return data
            except:
                raise Exception

        # group by dataitemid
        dataitemid_group = self.data_df.groupby('dataitemid')
        # get list of df by group
        df_group_list = [
            dataitemid_group.get_group(x)
            for x in dataitemid_group.groups.keys()]

        # calculate FCF-TO-REVENUE
        self.calculations_dict['fcf_to_revenue'] = get_fcf_to_revenue(df_group_list)

        # calculate ROA
        self.calculations_dict['roa'] = get_roa(df_group_list)

        # calculate REVENUE GROWTH
        self.calculations_dict['revenue_growth'] = get_revenue_growth(df_group_list)

        # calculate SHAREHOLDER RETURN
        self.calculations_dict['sh_return'] = get_sh_return(df_group_list)

    def transform_result(self):
        def format_raw_data():
            list_of_raw_data_labels = []

            # list of data labels used in the calculations
            raw_data_labels = [v2['df_name'] for k2, v2 in self.RAW_DATA_LABELS.items()]

            # get all valid series
            raw_data_series = {k1: v.get('raw').get(k1) for k1 in raw_data_labels
                               for k, v in self.calculations_dict.items()
                               if v.get('raw').get(k1) is not None}

            formatted_raw_data = {}
            for k, v in raw_data_series.items():
                # done with the help from: https://bit.ly/3cUKsr2
                formatted_raw_data[k] = \
                    pd.Series(raw_data_series[k].reset_index().apply(
                        lambda x: {
                            'fiscal_year': int(x['fiscalyear']),
                            'fiscal_id': "{}FY".format(int(x['fiscalyear'])),
                            'fiscal_period': "FY",
                            'date': str(x['periodenddate'].strftime('%Y-%m-%d')),
                            'timestamp': int(x['periodenddate'].timestamp()),
                            'value': x['dataitemvalue']
                        }, axis=1).values,
                              index=raw_data_series[k].index)

            return formatted_raw_data

        def format_avg_data():
            list_of_avg_data_labels = []

            # list of data labels used in the calculations
            avg_data_labels = [v2['df_name'] for k2, v2 in self.RAW_DATA_LABELS.items()]

            # get all valid series
            avg_data_series = {k1: v.get('avg').get(k1) for k1 in avg_data_labels
                               for k, v in self.calculations_dict.items()
                               if v.get('avg').get(k1) is not None}

            formatted_avg_data = {}
            for k, v in avg_data_series.items():
                # done with the help from: https://bit.ly/3cUKsr2
                formatted_avg_data[k] = \
                    pd.Series(avg_data_series[k].reset_index().apply(
                        lambda x: x['dataitemvalue'], axis=1).values,
                              index=avg_data_series[k].index)

            return formatted_avg_data

        def format_calculated_data():
            # list of data labels used in the calculations
            raw_data_labels = [v2['df_name'] for k2, v2 in self.RAW_DATA_LABELS.items()]
            calc_data_labels = [k for k, v in self.CALCULATED_DATA_LABELS.items()]

            # get all values and points
            calc_data_df = {k: pd.concat([v.get('value'), v.get('points')], axis=1, levels=0)
                            for k, v in self.calculations_dict.items()}

            formatted_calc_data = {}
            for k in calc_data_labels:
                formatted_calc_data[k] = pd.Series(calc_data_df[k].reset_index().apply(
                        lambda x: {
                            'date_calculated': datetime.datetime.now().strftime('%Y-%m-%d'),
                            'value': x['dataitemvalue'],
                            'calculation': x['dataitemvalue'],
                            'points': x[0],
                            'rank': x[0],
                            'description': self.CALCULATED_DATA_LABELS.get(k).get('label'),
                            'display_value_as': self.CALCULATED_DATA_LABELS.get(k).get('display_value_as')
                        }, axis=1).values, index=calc_data_df[k].index)

            return formatted_calc_data

        formatted_raw_data = format_raw_data()
        formatted_avg_data = format_avg_data()
        formatted_calc_data = format_calculated_data()

        # create df and drop NaN
        calc_data_df = pd.DataFrame.from_dict(formatted_calc_data)
        calc_data_df.dropna(inplace=True)
        # raw
        raw_data_df_list = [pd.DataFrame(formatted_raw_data[k], columns=[k])
                            for k in formatted_raw_data]
        raw_data_df = pd.concat(raw_data_df_list, axis=1)
        # avg
        avg_data_df_list = [pd.DataFrame(formatted_avg_data[k], columns=[k])
                            for k in formatted_raw_data]
        avg_data_df = pd.concat(avg_data_df_list, axis=1)

        # build final schema
        # raw & calc data to dict (replace nan's with zeros)
        raw_data = {x[0]: x[1].fillna(0).to_dict(orient='list')
                    for x in raw_data_df.groupby(level=0)}
        avg_data = {x[0]: x[1].fillna(0).to_dict(orient='list')
                    for x in avg_data_df.groupby(level=0)}
        # add raw data
        calc_data = {x[0]: x[1].to_dict(orient='list')
                     for x in calc_data_df.groupby(level=0)}
        # add raw & calc data to final schema
        self.calculations_dict = {
            k: {
                "calculated_data": v,
                "raw_data": raw_data.get(k),
                "avg_data": avg_data.get(k)
            } for k, v in calc_data.items()
        }

        print("DONE.")

    def apply_penalties(self):
        # N.B.: no penalty is applied if definition/criterion is met
        def check_1():
            pre_condition = {
                "definition": "FCF not negative in the last 5 yr.",
                "parameters_to_use": ["freecashflow"],
                "criterion": "{freecashflow} >= 0"
            }
            rval = {
                k:
                    {
                        "definition": pre_condition.get("definition"),
                        "met_criteria": bool(sum(
                        [1 if x.get('value') >= 0 else 0 for x in v.get('freecashflow') if
                         x is not 0]))
                    } for k, v in raw_data.items()
             }
            return rval

        def check_2():
            pre_condition = {
                "definition": "Revenue growth not negative in the last 5 yr.",
                "parameters_to_use": ["revenuegrowth"],
                "criterion": "{revenuegrowth} >= 0"
            }
            rval = {
                k:
                    {
                        "definition": pre_condition.get("definition"),
                        "met_criteria": bool(sum(
                        [1 if x.get('value') >= 0 else 0 for x in v.get('revenuegrowth') if
                         x is not 0]))
                    } for k, v in raw_data.items()
             }
            return rval

        def check_3():
            pre_condition = {
                "definition": "Revenue growth > -15% in the last 5 yr.",
                "parameters_to_use": ["revenuegrowth"],
                "criterion": "{revenuegrowth} > -15.0"
            }
            rval = {
                k:
                    {
                        "definition": pre_condition.get("definition"),
                        "met_criteria": bool(sum(
                            [1 if x.get('value') > -15.0 else 0 for x in
                             v.get('revenuegrowth') if
                             x is not 0]))
                    } for k, v in raw_data.items()
            }
            return rval

        def check_4():
            pre_condition = {
                "definition": "<FCF> x 10 > ST/LT Debt.",
                "parameters_to_use": ["freecashflow", "debt"],
                "criterion": "{freecashflow} * 10 > {debt}"
            }
            rval = {
                k:
                    {
                        "definition": pre_condition.get("definition"),
                        "met_criteria": bool(sum(
                            [1 if v.get('freecashflow')[0] * 10 > v.get('debt')[0] else 0 for x in
                             v.get('revenuegrowth') if
                             x is not 0]))
                    } for k, v in avg_data.items()
            }
            return rval

        self._logger.info("APPLYING PENALTIES...")

        # prepare data
        raw_data = {
            k: {k1: v1 for k1, v1 in v.get('raw_data').items()}
            for k, v in self.calculations_dict.items()
        }
        avg_data = {
            k: {k1: v1 for k1, v1 in v.get('avg_data').items()}
            for k, v in self.calculations_dict.items()
        }
        calculated_data = {
            k: {k1: v1[0] for k1, v1 in v.get('calculated_data').items()}
            for k, v in self.calculations_dict.items()
        }

        # check pre-conditions
        pc1 = check_1()
        pc2 = check_2()
        pc3 = check_3()
        pc4 = check_4()

        total_score = {
            k: sum([self._get_weighted_points(k1, v1.get('value'))
                    for k1, v1 in v.items()])
            for k, v in calculated_data.items()
        }

        total_penalty = {
            k: sum([1 if not x.get(k).get('met_criteria') else 0
                    for x in [pc1, pc2, pc3, pc4]]) * self.penalty_value
            for k, v in calculated_data.items()
        }

        total_points = {
            k: sum([self._get_weighted_points(k1, v1.get('points'))
                    for k1, v1 in v.items()])
            for k, v in calculated_data.items()
        }

        final_points = {
            k: total_points.get(k) - total_penalty.get(k)
            for k, v in calculated_data.items()
        }

        final_points_percentile_rank = {
            k: v * 100
            for k, v in zip(
                pd.DataFrame.from_dict(final_points.items())[0],
                pd.DataFrame.from_dict(final_points.items())[1].rank(pct=True).values)
        }

        rating = {
            k: self._get_rating(final_points.get(k))
            for k, v in calculated_data.items()
        }

        composite_pk_id = {
            k: {
                "{}:{}".format(sym, self.get_exchange_mapping(exc))
                for sym, exc in
                zip(self.company_data_df['tickersymbol'].loc[k],
                    self.company_data_df['exchangesymbol'].loc[k])}.pop()
            for k, v in calculated_data.items()
        }

        # final schema to be saved
        self.result = pd.DataFrame.from_dict({
            k: {
                "trading_item_id": k,
                "composite_pk_id": composite_pk_id.get(k),
                "model": {
                    "composite_pk_id": composite_pk_id.get(k),
                    "date_calculated": datetime.datetime.now().strftime(
                        "%Y-%m-%d"),
                    "score": total_points.get(k),
                    "value": total_points.get(k),
                    "total_penalty": total_penalty.get(k),
                    "final_points": final_points.get(k),
                    "rank": final_points_percentile_rank.get(k),
                    "rating": rating.get(k),
                    "pre_conditions": [x.get(k) for x in [pc1, pc2, pc3, pc4]],
                    "raw_data": raw_data.get(k),
                    "calculated_data": calculated_data.get(k),
                    "average_data": avg_data.get(k)
                },
                "rank": final_points_percentile_rank.get(k),
                "rating": rating.get(k),
                "score": total_points.get(k),
            } for k, v in calculated_data.items()
        }).T
        # replace NaN with zeros
        self.result.fillna(0, inplace=True)

        self._logger.info("DONE.")

    def run(self):
        self._logger.info(
            " CAPEFF INDICATOR STARTED AT {}".format(
                datetime.datetime.now()
            )
        )
        tic = datetime.datetime.now()
        self.load_data()
        tac = datetime.datetime.now()
        self._logger.info(
            " DATA LOAD DONE IN {}.".format(tac - tic)
        )

        self.run_scoring_system()

        # format and save the results
        self.transform_result()

        # apply penalties and create
        # the final schema to be saved
        self.apply_penalties()

        # save results
        self.save_result()

        self._logger.critical(' CAPITAL EFFICIENCY FINISHED.')


if __name__ == "__main__":
    ce = CapitalEfficiencyIndicator()
    ce.run()
