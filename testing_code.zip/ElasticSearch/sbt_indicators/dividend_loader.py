import warnings
warnings.simplefilter(action='ignore', category=Warning)
# import sqlalchemy
# import boto3
# from sbt_common import SbtGlobalCommon
# from sbt_common import SbtCommon
# from pg_accessor import PostgresAccessor
# from dd_accessor import DynamoAccessor

# from div_model import DivModel
# import statsmodels.api as sm
# import statsmodels.formula.api as smf
# from sklearn.model_selection import train_test_split
# from statistics import mean

# from sklearn.ensemble import RandomForestClassifier
# from sklearn.tree import export_graphviz
# import pydot
# from boto3.dynamodb.conditions import Key, Attr
# from sklearn.metrics import roc_curve, auc, classification_report
# from sklearn.tree import _tree
# import statistics
# import math
# import matplotlib.pyplot as plt
import pandas as pd
import os
import numpy as np
from joblib import dump, load
import datetime
from io import StringIO
import boto3
import json
import sys
import sqlalchemy
from sqlalchemy.types import JSON, VARCHAR, FLOAT
import logging

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']


class DivLoader():
    def __init__(self):
        # session = boto3.session.Session(profile_name='profilename')
        # self.ddb = session.resource('dynamodb', region_name='us-east-1')
        # self.client = session.client('dynamodb', region_name='us-east-1')
        # get a list of all available tables
        # self.dynamo_table_list = self.client.list_tables()['TableNames']
        # self.config = SbtGlobalCommon.raw_sbt_config
        # self._host = self.config[self.ENV]['postgres']['datafactory']['host']
        # self._port = self.config[self.ENV]['postgres']['datafactory']['port']
        # self._credentials = self.config[self.ENV]['postgres']['datafactory']['credentials']
        # self._user = self.config[self.ENV]['postgres']['datafactory']['user']
        # self._dbname = self.config[self.ENV]['postgres']['datafactory']['database']
        # self._connection_string = "dbname='" + self._dbname + "' user='" + \
        #                           self._user + "' host='" + self._host + \
        #                           "' password=" + self._credentials
        # # dialect+driver://username:password@host:port/database
        # self._engine = sqlalchemy.create_engine(
        #   'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
        #     user=self._user, password=self._credentials,
        #     host=self._host, db=self._dbname))
        # self.ENV = "dev"
        # self.pgconfig = {self.ENV: self.config[self.ENV]['postgres']['datafactory']}
        # self.pg = PostgresAccessor(self.pgconfig[self.ENV])
        # self.dd = DynamoAccessor()

        # read the entire config file
        # configure logging
        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        # self.ENV = 'dev'
        self._snp_pg = config['dev']['postgres']['snpsource']
        self._snp_engine = self._create_pg_engine(self._snp_pg)

        self._pg_df = config['dev']['postgres']['datafactory']
        self._pg_df_engine = self._create_pg_engine(self._pg_df)

        self._pg_df_qa = config['qa']['postgres']['datafactory']
        self._pg_df_qa_engine = self._create_pg_engine(self._pg_df_qa)

        self._pg_df_prod = config['prod']['postgres']['datafactory']
        self._pg_df_prod_engine = self._create_pg_engine(self._pg_df_prod)

        # get the config for sbtcompanyfin DB
        self._pg_snpfin = config['dev']['postgres']['snpcompanyfinancials']
        self._pg_snpfin_engine = self._create_pg_engine(self._pg_snpfin)

        # get the config for XPF DB
        self._pg_snp = config['dev']['postgres']['snpsource']
        self._pg_snp_engine = self._create_pg_engine(self._pg_snp)

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_df_engine,
                             'QA': self._pg_df_qa_engine,
                             'PROD': self._pg_df_prod_engine}

        self.EXCHANGE_MAPPING = {
            'NasdaqGS': 'NSDQ',
            'NasdaqGM': 'NSDQ',
            'NasdaqCM': 'NSDQ',
            'ARCA': 'NYSEARCA'
        }
        self.SB_EXCHANGE_MAPPING = {
            'TSX': 'TO',
            'LSE': 'L',
            'AIM': 'L',
            'SEHK': 'HK',
            'TSXV': 'V',
            'PAR': 'PA',
            'STO': 'ST',
            'BSE': 'BR',
            'JPX': 'T',
            'CSE': 'CO',
            'FWB': 'DE',
            'SIX': 'SW',
            'MCX': 'ME',
            'MCE': 'MC',
            'ATH': 'AT',
            'MIL': 'MI',
        }

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def get_exchange_mapping(self, exchange_symbol, sb_map=False):
        if exchange_symbol is not None:
            if exchange_symbol.startswith('OTC'):
                exchange_mapping = 'OTC'
            else:
                exchange_mapping = \
                    self.EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol) \
                        if not sb_map else \
                    self.SB_EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol)
        else:
            self._logger.error(" EXCHANGE IS NONE.")
            exchange_mapping = exchange_symbol

        return exchange_mapping

    def special_growth(self, new_val, old_val):
        if new_val >= old_val:
            multiplier = 1
        else:
            multiplier = -1
        if old_val == 0 and new_val == 0:
            return 0
        elif old_val == 0:
            return 1
        else:
            return multiplier * abs((new_val - old_val) / old_val)

    def dividend_growth(self, new_group, old_group):
        new_flag = ''
        new_val = 0
        old_val = 0
        if new_group['annual_flag'] == 1:
            new_flag = 'annual'
            new_val = new_group['cashdividendspershare'] / 4
        elif new_group['semiannual_flag'] == 1:
            new_flag = 'semi'
            new_val = new_group['cashdividendspershare'] / 2
        else:
            new_flag = 'quarter'

        old_flag = ''
        if old_group['annual_flag'] == 1:
            old_flag = 'annual'
            old_val = old_group['cashdividendspershare'] / 4
        elif old_group['semiannual_flag'] == 1:
            old_flag = 'semi'
            old_val = old_group['cashdividendspershare'] / 2
        else:
            old_flag = 'quarter'

        if new_flag == old_flag:
            return self.special_growth(new_group['cashdividendspershare'], old_group['cashdividendspershare'])
        else:
            return self.special_growth(new_val, old_val)

    def special_division(self, numerator, denominator):
        if denominator == 0:
            return 0
        else:
            return numerator / denominator

    def binary(self, val):
        # 1 is no change or increase, 0 is cut
        if val < 0:
            return 0
        else:
            return 1

    def load(self, companyid, symbol):
        # divmodel = DivModel()
        # sbtcommon = SbtCommon()
        # config = sbtcommon.get_sbt_config()
        # pg_snp = PostgresAccessor(config['postgres']['snpsource'])

        # companyid = 24937
        dataitemids = [3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 368, 2042]
        dataitemdict = {'3058': 'cashdividendspershare', '100003': 'pricetoearnings',
                        '2006': 'netcashfromoperatingactivities', '4424': 'fcffgrowth', '4422': 'freecashflow',
                        '100063': 'evtoebitda', '400': 'ebit', '100689': 'ebitda', '15': 'netincome',
                        '4192': 'debttoebitda', '8': 'dilutedeps', '1096': 'cashandcashequiv',
                        '368': 'totalinterestexpense', '2042': 'saleofppe'}

        sql_query = """SELECT c.companyname, mv.gicsgroup, c.reportingtemplatetypeid, lp.filingdate, lp.fiscalyear,
        pt.periodtypeid, pt.periodtypename,
                lp.fiscalquarter, lp.calendaryear, lp.calendarquarter,
                lp.periodenddate, un.unittypeid, un.unittypename, di.dataitemid,
                di.dataitemname, di.dataitemdescription, fd.dataitemvalue
            FROM public.ciqfinancialdata fd 
                INNER JOIN public.ciqlatestinstancefinperiod lp ON fd.financialperiodid = lp.financialperiodid
                INNER JOIN public.ciqcompany c ON lp.companyid = c.companyid
                INNER JOIN v2mv_sbt_company mv on lp.companyid = mv.companyid
                INNER JOIN public.ciqdataitem di ON fd.dataitemid = di.dataitemid
                INNER JOIN public.ciqfinunittype un ON un.unittypeid = fd.unittypeid
                INNER JOIN public.ciqperiodtype pt ON pt.periodtypeid = lp.periodtypeid
            WHERE lp.companyid = {}
                AND lp.periodtypeid = 1
                AND di.dataitemid in (3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 368)
                ORDER BY lp.fiscalyear desc, lp.fiscalquarter desc;
            """.format(companyid)
        df = pd.read_sql(sql_query, con=self._snp_engine, coerce_float=True)
        annual_div = df[df['dataitemid'] == 3058]

        # sql_query = """SELECT de.exdate, de.paydate, de.recorddate, de.announceddate, de.divamount,
        #                        cur.isocode, ex.exchangesymbol, defreq.divfreqtypename
        #                 FROM ciqdividend de
        #                     JOIN ciqtradingitem tii ON tii.tradingitemid = de.tradingitemid AND
        #                     tii.tradingitemstatusid in (15) AND tii.primaryflag = 1
        #                     JOIN ciqsecurity s ON s.securityid = tii.securityid AND s.primaryflag = 1
        #                     join ciqexchange ex on de.exchangeid = ex.exchangeid
        #                     join ciqcurrency cur on de.currencyid = cur.currencyid
        #                     left outer join ciqdividendfrequencytype defreq on de.divfreqtypeid = defreq.divfreqtypeid
        #                 WHERE s.companyid = {}
        #                     AND s.primaryflag = 1
        #                 ORDER BY exdate desc""".format(companyid)
        # df2 = pd.read_sql(sql_query, con=pg_snp._engine, coerce_float=True)
        # print()

        sql_query = """SELECT c.companyname, c.reportingtemplatetypeid, lp.filingdate, lp.fiscalyear, 
        pt.periodtypeid, pt.periodtypename, 
                        lp.fiscalquarter, lp.calendaryear, lp.calendarquarter, 
                        lp.periodenddate, un.unittypeid, un.unittypename, di.dataitemid, 
                        di.dataitemname, di.dataitemdescription, fd.dataitemvalue 
                    FROM public.ciqfinancialdata fd 
                        INNER JOIN public.ciqlatestinstancefinperiod lp ON fd.financialperiodid = lp.financialperiodid 
                        INNER JOIN public.ciqcompany c ON lp.companyid = c.companyid 
                        INNER JOIN public.ciqdataitem di ON fd.dataitemid = di.dataitemid 
                        INNER JOIN public.ciqfinunittype un ON un.unittypeid = fd.unittypeid 
                        INNER JOIN public.ciqperiodtype pt ON pt.periodtypeid = lp.periodtypeid 
                    WHERE lp.companyid = {}
                        AND lp.periodtypeid = 2
                        AND di.dataitemid in (3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 
                        368, 2042)
                        ORDER BY lp.fiscalyear desc, lp.fiscalquarter desc
    """.format(companyid)
        df = pd.read_sql(sql_query, con=self._snp_engine, coerce_float=True)
        df_transformed = df[df['dataitemid'] == 8]
        df_transformed.drop(columns=['dataitemid', 'dataitemdescription', 'dataitemname', 'dataitemvalue'],
                            inplace=True)
        df_transformed.set_index('periodenddate', inplace=True)
        df_transformed.sort_index(inplace=True)
        meta = {}
        for id in dataitemids:
            df1 = df[df['dataitemid'] == id]
            if len(df1) > 0:
                meta[str(id)] = {'dataitemname': df1.at[df1.index[0], 'dataitemname'],
                                 'dataitemdescription': df1.at[df1.index[0], 'dataitemdescription']}
                df1.set_index('periodenddate', inplace=True)
                df_transformed = df_transformed.loc[~df_transformed.index.duplicated(keep='first')]
                df1 = df1.loc[~df1.index.duplicated(keep='first')]
                df_transformed = pd.concat([df_transformed, df1['dataitemvalue']], axis=1)
                # df_transformed.drop(columns=['dataitemid', 'dataitemdescription', 'dataitemname'], inplace=True)
                df_transformed.rename(columns={'dataitemvalue': dataitemdict[str(id)]}, inplace=True)
            else:
                df_transformed[dataitemdict[str(id)]] = np.nan
            if id in [100003, 2006, 4422, 100063, 400, 100689, 1096, 2042]:
                df_transformed[dataitemdict[str(id)] + "_growth"] = [0] + [
                    self.special_growth(df_transformed.at[df_transformed.index[i], dataitemdict[str(id)]],
                                            df_transformed.at[df_transformed.index[i - 1], dataitemdict[str(id)]]) for i
                    in
                    range(1, len(df_transformed[dataitemdict[str(id)]]))]

                if len(df_transformed[dataitemdict[str(id)]]) > 4:
                    df_transformed[dataitemdict[str(id)] + "_1ygrowth"] = [0, 0, 0, 0] + [
                        self.special_growth(
                            df_transformed.at[df_transformed.index[i], dataitemdict[str(id)]],
                            df_transformed.at[df_transformed.index[i - 4], dataitemdict[str(id)]])
                        for i in
                        range(4, len(df_transformed[dataitemdict[str(id)]]))]

                if len(df_transformed[dataitemdict[str(id)]]) > 20:
                    df_transformed[dataitemdict[str(id)] + "_5ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                           0, 0, 0, 0,
                                                                           0] + [
                                                                              self.special_growth(
                                                                                  df_transformed.at[
                                                                                      df_transformed.index[i],
                                                                                      dataitemdict[str(id)]],
                                                                                  df_transformed.at[
                                                                                      df_transformed.index[i - 20],
                                                                                      dataitemdict[str(id)]])
                                                                              for i in
                                                                              range(20, len(df_transformed[dataitemdict[
                                                                                  str(id)]]))]

                if len(df_transformed[dataitemdict[str(id)]]) > 40:
                    df_transformed[dataitemdict[str(id)] + "_10ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                            0, 0, 0, 0,
                                                                            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                            0, 0, 0, 0,
                                                                            0, 0] + [
                                                                               self.special_growth(
                                                                                   df_transformed.at[
                                                                                       df_transformed.index[i],
                                                                                       dataitemdict[str(id)]],
                                                                                   df_transformed.at[
                                                                                       df_transformed.index[i - 40],
                                                                                       dataitemdict[str(id)]])
                                                                               for i in
                                                                               range(40, len(df_transformed[
                                                                                                 dataitemdict[
                                                                                                     str(id)]]))]

                df_transformed[dataitemdict[str(id)] + "_binary"] = [self.binary(x) for x in
                                                                     df_transformed[dataitemdict[str(id)] + "_growth"]]
            elif id == 3058:
                df_transformed['cashdividendspershare_growth'] = [0] + [
                    self.special_growth(df_transformed[dataitemdict[str(id)]][i],
                                            df_transformed[dataitemdict[str(id)]][i - 1]) for i in
                    range(1, len(df_transformed[dataitemdict[str(id)]]))]
                df_transformed['div_binary'] = [self.binary(df_transformed['cashdividendspershare_growth'][i + 1])
                                                for i in
                                                range(len(df_transformed['cashdividendspershare_growth']) - 1)] + [1]

        if len(df_transformed['cashdividendspershare'].iloc[-6:].dropna()) == 0:
            return None
        df_transformed['div_payout_ratio'] = [
            self.special_division(df_transformed.at[df_transformed.index[i], 'cashdividendspershare'],
                                      df_transformed.at[df_transformed.index[i], 'dilutedeps']) for i in
            range(len(df_transformed['dilutedeps']))]
        df_transformed["div_payout_ratio_growth"] = [0] + [
            self.special_growth(df_transformed.at[df_transformed.index[i], 'div_payout_ratio'],
                                    df_transformed.at[df_transformed.index[i - 1], 'div_payout_ratio']) for i in
            range(1, len(df_transformed['div_payout_ratio']))]
        if len(df_transformed['div_payout_ratio']) > 4:
            df_transformed['div_payout_ratio' + "_1ygrowth"] = [0, 0, 0, 0] + [
                self.special_growth(
                    df_transformed.at[df_transformed.index[i], 'div_payout_ratio'],
                    df_transformed.at[df_transformed.index[i - 4], 'div_payout_ratio'])
                for i in
                range(4, len(df_transformed['div_payout_ratio']))]

        if len(df_transformed['div_payout_ratio']) > 20:
            df_transformed['div_payout_ratio' + "_5ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                0] + [
                                                                   self.special_growth(
                                                                       df_transformed.at[
                                                                           df_transformed.index[i], 'div_payout_ratio'],
                                                                       df_transformed.at[df_transformed.index[
                                                                                             i - 20],
                                                                                         'div_payout_ratio'])
                                                                   for i in
                                                                   range(20, len(df_transformed['div_payout_ratio']))]

        if len(df_transformed['div_payout_ratio']) > 40:
            df_transformed['div_payout_ratio' + "_10ygrowth"] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                 0,
                                                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                                 0,
                                                                 0, 0] + [
                                                                    self.special_growth(
                                                                        df_transformed.at[df_transformed.index[
                                                                                              i], 'div_payout_ratio'],
                                                                        df_transformed.at[df_transformed.index[
                                                                                              i - 40],
                                                                                          'div_payout_ratio'])
                                                                    for i in
                                                                    range(40, len(df_transformed['div_payout_ratio']))]

        df_transformed['int/income'] = [
            self.special_division(abs(df_transformed.at[df_transformed.index[i], 'totalinterestexpense']),
                                      df_transformed.at[df_transformed.index[i], 'netincome']) for i in
            range(len(df_transformed))]
        df_transformed['int/cash'] = [
            self.special_division(abs(df_transformed.at[df_transformed.index[i], 'totalinterestexpense']),
                                      df_transformed.at[df_transformed.index[i], 'cashandcashequiv']) for i in
            range(len(df_transformed))]

        # formula = 'div_binary ~ pricetoearnings + netcashfromoperatingactivities + freecashflow + ebit + ebitda +
        # netincome + debttoebitda + dilutedeps + pricetoearnings_growth + netcashfromoperatingactivities_growth +
        # freecashflow_growth + ebit_growth + ebitda_growth + div_payout_ratio + div_payout_ratio_growth'
        # model = smf.glm(formula=formula,data=df_transformed, family=sm.families.Binomial()).fit()
        # print(model.summary())
        dic = {}
        df_transformed['annual_dividend'] = np.nan
        df_transformed['annual_flag'] = 0
        df_transformed['semiannual_flag'] = 0
        df_transformed['quarter_flag'] = 0
        for row in annual_div.iterrows():
            dic[row[1]['fiscalyear']] = row[1]['dataitemvalue']
        count = 0
        non_nan_count = 0
        for row2 in df_transformed.iterrows():
            try:
                df_transformed.at[df_transformed.index[count], 'annual_dividend'] = dic[row2[1]['fiscalyear']]
            except KeyError:
                df_transformed.at[df_transformed.index[count], 'annual_dividend'] = np.nan
            if not np.isnan(row2[1]['fiscalyear']):
                try:
                    if (count == 0 or non_nan_count == 0) and row2[1]['cashdividendspershare'] == dic[
                        int(row2[1]['fiscalyear'])]:
                        df_transformed.at[df_transformed.index[count], 'quarter_flag'] = 1
                    else:
                        if row2[1]['cashdividendspershare'] == dic[int(row2[1]['fiscalyear'])]:
                            df_transformed.at[df_transformed.index[count], 'annual_flag'] = 1
                        elif row2[1]['cashdividendspershare'] + df_transformed.at[
                            df_transformed.index[count - 2], 'cashdividendspershare'] == dic[
                            int(row2[1]['fiscalyear'])]:
                            df_transformed.at[df_transformed.index[count], 'semiannual_flag'] = 1
                            df_transformed.at[df_transformed.index[count - 2], 'semiannual_flag'] = 1
                            df_transformed.at[df_transformed.index[count - 2], 'quarter_flag'] = 0
                            df_transformed.at[df_transformed.index[count - 2], 'annual_flag'] = 0
                        else:
                            df_transformed.at[df_transformed.index[count], 'quarter_flag'] = 1
                except KeyError:
                    df_transformed.at[df_transformed.index[count], 'semiannual_flag'] = df_transformed.at[
                        df_transformed.index[count - 1], 'semiannual_flag']
                    df_transformed.at[df_transformed.index[count], 'annual_flag'] = df_transformed.at[
                        df_transformed.index[count - 1], 'annual_flag']
                    df_transformed.at[df_transformed.index[count], 'quarter_flag'] = df_transformed.at[
                        df_transformed.index[count - 1], 'quarter_flag']
                finally:
                    non_nan_count += 1
            else:
                df_transformed.at[df_transformed.index[count], 'semiannual_flag'] = df_transformed.at[
                    df_transformed.index[count - 1], 'semiannual_flag']
                df_transformed.at[df_transformed.index[count], 'annual_flag'] = df_transformed.at[
                    df_transformed.index[count - 1], 'annual_flag']
                df_transformed.at[df_transformed.index[count], 'quarter_flag'] = df_transformed.at[
                    df_transformed.index[count - 1], 'quarter_flag']

            count += 1

        nans = df_transformed[np.isnan(df_transformed['cashdividendspershare'])].index
        zs = df_transformed[df_transformed['cashdividendspershare'] == 0].index
        # print(len(nans))
        df_transformed.drop(nans, inplace=True)
        df_transformed.drop(zs, inplace=True)
        updated_df = pd.DataFrame()
        df_transformed['composite_pk_id'] = symbol
        for group in df_transformed.groupby(['composite_pk_id']):
            growth_lst = []
            binary_lst = []
            # print(group[0])
            group = group[1]
            group.reset_index(inplace=True)
            # print(group['cashdividendspershare'])

            growth_lst.append([0] + [self.dividend_growth(group.iloc[i],
                                                              group.iloc[i - 1]) for i in
                                     range(1, len(group['cashdividendspershare']))])
            group['cashdividendspershare_growth'] = growth_lst[0]

            binary_lst.append([self.binary(group['cashdividendspershare_growth'][i + 1])
                               for i in range(len(group['cashdividendspershare_growth']) - 1)] + [1])

            group['div_binary'] = binary_lst[0]
            updated_df = pd.concat([updated_df, group])

        ever_cut = 0
        last_5 = 0
        last_10 = 0
        last_index = 0
        quick = 0
        count = 0
        last_cut = 0
        borrowed = 0
        updated_df["ever_cut"] = 0
        updated_df["last5cut"] = 0
        updated_df["last10cut"] = 0
        updated_df['quick_recover'] = 0
        updated_df['borrowed'] = 0
        for row in updated_df.iterrows():
            if np.sign(row[1]['cashdividendspershare_growth']) < 0:
                last_cut = count
                ever_cut = 1
                last_5 = 1
                last_10 = 1
                quick = 0
            if last_index - count > 20 and last_5 == 1:
                last_5 = 0
            if last_index - count > 40 and last_10 == 1:
                last_10 = 0
            if last_5 == 1 and row[1]['cashdividendspershare'] >= updated_df.at[
                updated_df.index[last_cut], 'cashdividendspershare']:
                quick = 1

            if row[1]['dilutedeps'] <= row[1]['cashdividendspershare'] and row[1]['cashdividendspershare'] > 0 and \
                row[1]['cashandcashequiv_1ygrowth'] < 0:
                updated_df.at[row[0], "borrowed"] = 1

            updated_df.at[row[0], "quick_recover"] = quick
            updated_df.at[row[0], "ever_cut"] = ever_cut
            updated_df.at[row[0], "last5cut"] = last_5
            updated_df.at[row[0], "last10cut"] = last_10
            count += 1
        return updated_df

    def to_pg(self):
        companies = pd.read_sql("""SELECT mv.companyname,
               mv.companyid,
               mv.tickersymbol,
               pt.periodtypename,
               fp.calendarquarter,
               fp.calendaryear,
               fd.dataitemid,
               di.dataitemname,
               fd.dataitemvalue,
               fp.fiscalyear,
               fp.fiscalquarter,
               fp.periodenddate,
               fp.filingdate,
               fp.financialperiodid,
               fp.latestperiodflag,
               mv.exchangesymbol,
               mv.gicsgroup,
               mv.tradingitemid
                FROM (((((v2mv_sbt_company mv
                    JOIN ciqlatestinstancefinperiod fp ON ((fp.companyid = mv.companyid)))
                    JOIN ciqperiodtype pt ON ((pt.periodtypeid = fp.periodtypeid)))
                    JOIN ciqfinancialdata fd ON ((fd.financialperiodid = fp.financialperiodid)))
                    JOIN ciqdataitem di ON ((di.dataitemid = fd.dataitemid))))
                WHERE ((fd.dataitemid = ANY (ARRAY [3058])) AND (pt.periodtypeid = 1) AND
                       (fp.latestperiodflag = 1) AND ((mv.exchangesymbol)::text = ANY
                                                      (ARRAY ['NYSE'::text, 'AMEX'::text, 'ARCA'::text, 
                                                      'NasdaqGS'::text, 'NasdaqGM'::text, 'NasdaqCM'::text, 
                                                      'NasdaqCS'::text])) AND
                       (mv.is_primary_exchange = true));""", self._snp_engine)
        correct_symbols = companies[companies['gicsgroup'].notnull()]
        # correct_symbols = pd.read_sql("SELECT * FROM v2mv_sbt_company WHERE exchangesymbol = ANY (ARRAY "
        #                               "['NYSE', 'AMEX', 'ARCA', 'NasdaqGS', 'NasdaqGM', 'NasdaqCM', 'NasdaqCS']) "
        #                               "AND is_primary_exchange = true", self._snp_engine)
        # correct_symbols.loc[correct_symbols['exchangesymbol'].isin(['NasdaqGS', 'NasdaqGM']), 'exchangesymbol'] = 'NSDQ'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'NasdaqCM', 'exchangesymbol'] = 'NSDQCM'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'ARCA', 'exchangesymbol'] = 'NYSEARCA'
        # correct_symbols['composite_pk_id'] = correct_symbols['tickersymbol'] + ':' + correct_symbols['exchangesymbol']
        correct_symbols['composite_pk_id'] = ["{}:{}".format(sym, self.get_exchange_mapping(exc)) for sym, exc in zip(correct_symbols['tickersymbol'], correct_symbols['exchangesymbol'])]
        sql = """
        SELECT tickersymbol, companyname, companyid, calendaryear, calendarquarter, latestperiodflag, exchangesymbol, gicsgroup, tradingitemid, filingdate, cashdividendspershare, pricetoearnings, netcashfromoperatingactivities, fcffgrowth, freecashflow, evtoebitda, ebit, ebitda, netincome, debttoebitda, dilutedeps, cashandcashequiv, totalinterestexpense, saleofppe
FROM (SELECT t1.tickersymbol,
             t1.companyname,
             t1.companyid,
             t1.calendaryear,
             t1.calendarquarter,
             t1.latestperiodflag,
             t1.exchangesymbol,
             t1.gicsgroup,
             t1.tradingitemid,
             t1.filingdate,
             SUM(CASE
                         WHEN (t1.dataitemid = 3058) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS cashdividendspershare,
             SUM(CASE
                         WHEN (t1.dataitemid = 100003) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS pricetoearnings,
             SUM(CASE
                         WHEN (t1.dataitemid = 2006) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS netcashfromoperatingactivities,
             SUM(CASE
                         WHEN (t1.dataitemid = 4424) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS fcffgrowth,
             SUM(CASE
                         WHEN (t1.dataitemid = 4422) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS freecashflow,
             SUM(CASE
                         WHEN (t1.dataitemid = 100063) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS evtoebitda,
             SUM(CASE
                         WHEN (t1.dataitemid = 400) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS ebit,
             SUM(CASE
                         WHEN (t1.dataitemid = 100689) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS ebitda,
             SUM(CASE
                         WHEN (t1.dataitemid = 15) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS netincome,
             SUM(CASE
                         WHEN (t1.dataitemid = 4192) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS debttoebitda,
             SUM(CASE
                         WHEN (t1.dataitemid = 8) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS dilutedeps,
             SUM(CASE
                         WHEN (t1.dataitemid = 1096) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS cashandcashequiv,
             SUM(CASE
                         WHEN (t1.dataitemid = 368) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS totalinterestexpense,
             SUM(CASE
                         WHEN (t1.dataitemid = 2042) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS saleofppe
      FROM (SELECT mv.companyname,
       mv.companyid,
       mv.tickersymbol,
       pt.periodtypename,
       fp.calendarquarter,
       fp.calendaryear,
       fd.dataitemid,
       di.dataitemname,
       fd.dataitemvalue,
       fp.fiscalyear,
       fp.fiscalquarter,
       fp.periodenddate,
       fp.filingdate,
       fp.financialperiodid,
       fp.latestperiodflag,
       mv.exchangesymbol,
       mv.gicsgroup,
       mv.tradingitemid
        FROM (((((v2mv_sbt_company mv
            JOIN ciqlatestinstancefinperiod fp ON ((fp.companyid = mv.companyid)))
            JOIN ciqperiodtype pt ON ((pt.periodtypeid = fp.periodtypeid)))
            JOIN ciqfinancialdata fd ON ((fd.financialperiodid = fp.financialperiodid)))
            JOIN ciqdataitem di ON ((di.dataitemid = fd.dataitemid))))
        WHERE ((fd.dataitemid = ANY (ARRAY [3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 368, 2042])) AND (pt.periodtypeid = 1) AND
        ((mv.exchangesymbol)::text = ANY
                                              (ARRAY ['NYSE'::text, 'AMEX'::text, 'ARCA'::text, 'NasdaqGS'::text, 'NasdaqGM'::text, 'NasdaqCM'::text, 'NasdaqCS'::text])) AND
               (mv.is_primary_exchange = true))) t1 GROUP BY t1.tickersymbol, t1.companyname, t1.companyid, t1.calendaryear, t1.calendarquarter, t1.latestperiodflag, t1.exchangesymbol, t1.gicsgroup, t1.tradingitemid, t1.filingdate) s;
        """
        sql = """SELECT mv.companyname, lp.filingdate, lp.fiscalyear,
        pt.periodtypeid, pt.periodtypename,
                lp.fiscalquarter, lp.calendaryear, lp.calendarquarter,
                lp.periodenddate, un.unittypeid, un.unittypename, di.dataitemid,
                di.dataitemname, di.dataitemdescription, fd.dataitemvalue
            FROM public.v2mv_sbt_company mv
                JOIN public.ciqlatestinstancefinperiod lp ON mv.companyid = lp.companyid
                JOIN public.ciqfinancialdata fd ON fd.financialperiodid = lp.financialperiodid
                JOIN public.ciqdataitem di ON fd.dataitemid = di.dataitemid
                JOIN public.ciqfinunittype un ON un.unittypeid = fd.unittypeid
                JOIN public.ciqperiodtype pt ON pt.periodtypeid = lp.periodtypeid
            WHERE lp.companyid in ('{}')
                AND lp.periodtypeid = 1
                AND di.dataitemid in (3058, 100003, 2006, 4424, 4422, 100063, 400, 100689, 15, 4192, 8, 1096, 368);""".format("', '".join([str(x) for x in list(correct_symbols['companyid'])]))
        # df = pd.read_sql(sql, self._snp_engine)

        # dd = DynamoAccessor()
        s = []
        big_df = pd.DataFrame()
        for symbol in correct_symbols.iterrows():
            symbol = symbol[1]
            print(symbol['composite_pk_id'])
            # add = self.dd._query_table("QA_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NYSE")
            # if add:
            try:
                retval = self.load(symbol['companyid'], symbol['composite_pk_id'])
                if retval is not None:
                    # retval['symbol'] = symbol
                    big_df = pd.concat([big_df, retval])
                    # print()
            except Exception as e:
                print("error", e)
            # else:
            #     add = self.dd._query_table("QA_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NSDQ")
            #     retval = self.load(add[0]['snp_id'], add[0]['composite_pk_id'])
        print('writing to db')
        self.big_df_to_pg(big_df, 'dev_dividend_model', col_order=['annual_dividend', 'annual_flag', 'borrowed', 'calendarquarter', 'calendaryear', 'cashandcashequiv', 'cashandcashequiv_10ygrowth', 'cashandcashequiv_1ygrowth', 'cashandcashequiv_5ygrowth', 'cashandcashequiv_binary', 'cashandcashequiv_growth', 'cashdividendspershare', 'cashdividendspershare_growth', 'companyname', 'composite_pk_id', 'debttoebitda', 'dilutedeps', 'div_binary', 'div_payout_ratio', 'div_payout_ratio_10ygrowth', 'div_payout_ratio_1ygrowth', 'div_payout_ratio_5ygrowth', 'div_payout_ratio_growth', 'ebit', 'ebit_10ygrowth', 'ebit_1ygrowth', 'ebit_5ygrowth', 'ebit_binary', 'ebit_growth', 'ebitda', 'ebitda_10ygrowth', 'ebitda_1ygrowth', 'ebitda_5ygrowth', 'ebitda_binary', 'ebitda_growth', 'ever_cut', 'evtoebitda', 'evtoebitda_10ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_binary', 'evtoebitda_growth', 'fcffgrowth', 'filingdate', 'fiscalquarter', 'fiscalyear', 'freecashflow', 'freecashflow_10ygrowth', 'freecashflow_1ygrowth', 'freecashflow_5ygrowth', 'freecashflow_binary', 'freecashflow_growth', 'int/cash', 'int/income', 'last10cut', 'last5cut', 'netcashfromoperatingactivities', 'netcashfromoperatingactivities_10ygrowth', 'netcashfromoperatingactivities_1ygrowth', 'netcashfromoperatingactivities_5ygrowth', 'netcashfromoperatingactivities_binary', 'netcashfromoperatingactivities_growth', 'netincome', 'periodenddate', 'periodtypeid', 'periodtypename', 'pricetoearnings', 'pricetoearnings_10ygrowth', 'pricetoearnings_1ygrowth', 'pricetoearnings_5ygrowth', 'pricetoearnings_binary', 'pricetoearnings_growth', 'quarter_flag', 'quick_recover', 'reportingtemplatetypeid', 'saleofppe', 'saleofppe_10ygrowth', 'saleofppe_1ygrowth', 'saleofppe_5ygrowth', 'saleofppe_binary', 'saleofppe_growth', 'semiannual_flag', 'totalinterestexpense', 'unittypeid', 'unittypename'], drop_previous_table=True)
        # big_df.to_sql('dev_dividend_model',
        #               self.pg._engine,
        #               if_exists='replace',
        #               index=False
        #               # index_label='periodenddate'
        #               )
        self.rankings()

    def big_df_to_pg(self, df, table_name, col_order=None, drop_previous_table=False):
        data = StringIO()
        ENVS_TO_UPDATE = ['dev']
        # write to CSV format
        if col_order is not None:
            df.to_csv(data, columns=col_order, header=False, index=False)
        else:
            df.to_csv(data, header=False, index=False)
        # save to all envs
        for env in ENVS_TO_UPDATE:
            # get engine
            con = self.db_to_update.get(env.upper())
            # set pointer to the beginning of file
            data.seek(0)
            # get raw connection
            raw = con.raw_connection()
            # get cursor
            curs = raw.cursor()
            if drop_previous_table:
                # drop previous table
                try:
                    curs.execute("DELETE FROM {}".format(table_name))
                except:
                    print("COULDN'T DROP TABLE {}".format(table_name))
                    # self._logger.info("COULDN'T DROP TABLE {}".format(table_name))
                # empty_table = pd.io.sql.get_schema(df, table_name, con=con)
                # # remove undesired characters
                # empty_table = empty_table.replace('"', '')
                # empty_table = empty_table.replace('\t', '')
                # curs.execute(empty_table)
            # copy from CSV format to table
            curs.copy_expert(
                """COPY {} FROM STDIN WITH (FORMAT CSV)""".format(table_name),
                data)
            # commit transactions
            curs.connection.commit()

    def run_logit_model(self):
        select = "SELECT * FROM dev_dividend_model_banks;"
        big_df = pd.read_sql(select, self.pg._engine)
        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)
        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)
        print(len(zeros), len(newdf))
        # to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
        #              'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
        #              'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
        #              'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
        #              'ebit_10ygrowth']
        # all_columns = set(newdf.columns.tolist()) - set(to_remove)
        # for col in list(all_columns):
        #   # zeros.hist(col, bins=100, alpha=.5)
        #   print("0_" + col, statistics.median(zeros[col]))
        #   print(zeros[col].quantile([0.25, 0.5, 0.75]))
        #   # plt.title("0_" + col)
        #   # plt.show()
        #
        #   # ones.hist(col, bins=100, alpha=.5)
        #   print("1_" + col, statistics.median(ones[col]))
        #   print(ones[col].quantile([0.25, 0.5, 0.75]))
        # plt.title("1_" + col)
        #
        # plt.show()

        accuracy_lst = []
        succ0 = []
        succ1 = []
        falsepos = []
        falseneg = []
        for i in range(1):

            # from sklearn.model_selection import train_test_split

            train, test = train_test_split(newdf, test_size=0.2)
            # formula = 'div_binary ~ 0 + netcashfromoperatingactivities + freecashflow + ebitda +
            # div_payout_ratio_growth + pricetoearnings_binary + ever_cut + last5cut + last10cut +
            # cashandcashequiv_growth + cashandcashequiv_1ygrowth + cashandcashequiv_5ygrowth +
            # cashandcashequiv_10ygrowth'
            # model = smf.glm(formula=formula, data=train, family=sm.families.Binomial()).fit()
            to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend', 'saleofppe_growth', 'saleofppe_1ygrowth',
                     'saleofppe_5ygrowth', 'saleofppe_10ygrowth', 'saleofppe_binary', 'saleofppe', 'int/cash',
                         'int/income', 'pricetoearnings', 'ebitda_5ygrowth', 'netcashfromoperatingactivities_10ygrowth',
                         'ebit_binary', 'freecashflow', 'freecashflow_binary', 'freecashflow_5ygrowth',
                         'netcashfromoperatingactivities_binary', 'ebit_5ygrowth', 'pricetoearnings_growth',
                         'totalinterestexpense', 'freecashflow_10ygrowth', 'ebitda_growth', 'ebit', 'ebitda_1ygrowth',
                         'freecashflow_1ygrowth', 'debttoebitda', 'ebit_growth', 'ebitda', 'pricetoearnings_binary',
                         'last10cut', 'div_payout_ratio', 'netcashfromoperatingactivities_growth',
                         'netcashfromoperatingactivities_1ygrowth', 'cashandcashequiv_binary',
                         'pricetoearnings_10ygrowth', 'ebitda_10ygrowth', 'div_payout_ratio_1ygrowth',
                         'cashandcashequiv_growth', 'cashandcashequiv_1ygrowth', 'ebit_1ygrowth', 'cashandcashequiv_binary',
                         'netcashfromoperatingactivities_5ygrowth', 'div_payout_ratio_growth', 'fcffgrowth',
                         'netcashfromoperatingactivities', 'div_payout_ratio_10ygrowth', 'cashandcashequiv',
                         'div_payout_ratio_5ygrowth', 'dilutedeps', 'pricetoearnings_1ygrowth',
                         'pricetoearnings_5ygrowth', 'freecashflow_growth']
            all_columns = " + ".join(set(train.columns.tolist()) - set(to_remove))
            formula = 'div_binary ~  ' + all_columns
            train.fillna(0, inplace=True)
            model = smf.glm(formula=formula, data=train, family=sm.families.Binomial()).fit()
            print(model.summary())
            # print(model.pvalues)
            # for i, value in enumerate(model.pvalues):
            #   if value > 0.05:
            #     if model.pvalues.index[i] != "Intercept":
            #       to_remove.append(model.pvalues.index[i])
            # else:
            # print(model.pvalues.index[i])
            modifytest = test.copy()
            pred = model.predict(exog=modifytest.drop(columns=to_remove, inplace=True))
            threshold = 0.5

            predictions = (pd.Series(pred) >= threshold).astype('int')

            # Use the forest's predict method on the test data
            # predictions = rf.predict(modifytest)
            #test.loc[:, 'predictions'] = predictions
            print(classification_report(train['div_binary'], predictions))

            # p = model.params
            # print(p)
            # start = int(len(big_df) * (3 / 4))
        #     count_succ0 = 0
        #     count_succ1 = 0
        #     count_falsepos = 0
        #     count_falseneg = 0
        #     count = 0
        #     for row in test.iterrows():
        #         val = pred[count]
        #         # val = row[1]['netcashfromoperatingactivities_binary'] * 10 + row[1]['div_payout_ratio_growth'] *
        #         # -10 + row[1][
        #         #   'debttoebitda'] * 0 + row[1]['last5cut'] * -10 + row[1]['last10cut'] * -.5 + row[1]['ever_cut'] *
        #         #   -.5 + row[1][
        #         #         'cashandcashequiv_1ygrowth'] * 0 + row[1]['freecashflow_binary'] * 0 + row[1][
        #         #         'quick_recover'] * 5
        #         # val = math.exp(val) / (1 + math.exp(val))
        #         # print(val)
        #         if val >= .5:
        #             model_predict = 1
        #         elif val <= .5:
        #             model_predict = 0
        #         else:
        #             model_predict = -1
        #
        #         if np.isnan(row[1]['div_binary']) or np.isnan(val):
        #             pass
        #         elif model_predict == row[1]['div_binary']:
        #             if model_predict == 0:
        #                 # print("Successfully Guessed Decrease")
        #                 # print("Success")
        #                 count_succ0 += 1
        #             else:
        #                 count_succ1 += 1
        #         # elif model_predict == -1:
        #         #   print("skipping")
        #         else:
        #             # print(model_predict)
        #             # print(model_predict, row[1]['div_binary'])
        #             # print("Failure")
        #             if model_predict == 0:
        #                 count_falseneg += 1
        #             elif model_predict == 1:
        #                 count_falsepos += 1
        #         count += 1
        #     # print(count_fail, count_succ)
        #     succ1.append(count_succ1)
        #     succ0.append(count_succ0)
        #     falsepos.append(count_falsepos)
        #     falseneg.append(count_falseneg)
        #     accuracy = (count_succ1 + count_succ0) / ((count_succ1 + count_succ0) + (count_falseneg + count_falsepos))
        #     print("Accuracy:", accuracy)
        #     print("succ0: ", count_succ0)
        #     print("succ1: ", count_succ1)
        #     print("falsepos: ", count_falsepos)
        #     print("falseneg: ", count_falseneg)
        #     accuracy_lst.append(accuracy)
        # print("Mean Accuracy:", mean(accuracy_lst))
        # print("Mean succ0: ", mean(succ0))
        # print("Mean succ1: ", mean(succ1))
        # print("Mean falsepos: ", mean(falsepos))
        # print("Mean falseneg: ", mean(falseneg))
        # train = big_df.iloc[0:int(len(big_df) * (3 / 4))]
        # test = big_df.iloc[int(len(big_df) * (3 / 4)):len(big_df)]
        # formula = 'div_binary ~ pricetoearnings + netcashfromoperatingactivities + freecashflow + ebit + ebitda +
        # netincome + debttoebitda + dilutedeps + pricetoearnings_growth + netcashfromoperatingactivities_growth +
        # freecashflow_growth + ebit_growth + ebitda_growth + div_payout_ratio + div_payout_ratio_growth'
        # model = smf.glm(formula=formula,data=big_df, family=sm.families.Binomial()).fit()
        # print(model.summary())

        # p = model.params
        # pos = 2972
        # print(big_df['netcashfromoperatingactivities'].iloc[pos], big_df['freecashflow'].iloc[pos],
        # big_df['ebit'].iloc[pos],
        #       big_df['ebitda'].iloc[pos], big_df['div_payout_ratio_growth'].iloc[pos])
        # val = p['Intercept'] + p['netcashfromoperatingactivities'] * big_df['netcashfromoperatingactivities'].iloc[
        # pos] + p[
        #   'freecashflow'] * big_df['freecashflow'].iloc[pos] + p['ebit'] * big_df['ebit'].iloc[pos] + p['ebitda'] * \
        #       big_df['ebitda'].iloc[pos] + p['div_payout_ratio_growth'] * big_df['div_payout_ratio_growth'].iloc[pos]
        # print(val / (1 + val), big_df['div_binary'].iloc[pos])
        print()

    def run_rf_model(self, big_df):
        nans = big_df[np.isnan(big_df['cashdividendspershare'])].index
        zs = big_df[big_df['cashdividendspershare'] == 0].index
        # print(len(nans))
        big_df.drop(nans, inplace=True)
        big_df.drop(zs, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend']
        to_remove_plot = ["calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                          'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                          'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                          'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                          'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision trees
        rf = RandomForestClassifier(n_estimators=50, max_depth=5, max_features=1.0)
        # Train the model on training data
        rf.fit(modifytrain, train['div_binary'])

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        threshold = 0.55

        predicted_proba = rf.predict_proba(modifytest)
        predictions = (predicted_proba[:, 1] >= threshold).astype('int')

        # Use the forest's predict method on the test data
        # predictions = rf.predict(modifytest)
        test.loc[:, 'predictions'] = predictions
        test['probs'] = predicted_proba[:, 1]

        # Create a scatter matrix from the dataframe, color by y_train
        import seaborn as sns
        sns.set_style("white")

        # Import data
        # df = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/diamonds.csv')
        x1 = test.loc[test.div_binary == 0, 'probs']
        x2 = test.loc[test.div_binary == 1, 'probs']
        # x3 = test.loc[test.cut=='Good', 'probs']

        # Plot
        kwargs = dict(hist_kws={'alpha': .6}, kde_kws={'linewidth': 2})

        plt.figure(figsize=(10, 7), dpi=80)
        sns.distplot(x1, color="dodgerblue", label="0", bins=50, **kwargs)
        sns.distplot(x2, color="orange", label="1", bins=50, **kwargs)
        # sns.distplot(x3, color="deeppink", label="minivan", **kwargs)
        plt.xlim(0, 1)
        plt.legend()

        # modifyplot = train.copy()
        # modifyplot.drop(columns=to_remove_plot, inplace=True)
        # g = sns.pairplot(modifyplot, hue="div_binary")

        # Calculate the absolute errors
        errors = abs(predictions - test['div_binary'])
        # Print out the mean absolute error (mae)
        print('Mean Absolute Error:', np.mean(errors))

        print(classification_report(test['div_binary'], test['predictions']))

        feature_names = ['borrowed', 'calendarquarter', 'calendaryear', 'cashandcashequiv',
                         'cashandcashequiv_10ygrowth', 'cashandcashequiv_1ygrowth',
                         'cashandcashequiv_5ygrowth', 'cashandcashequiv_binary',
                         'cashandcashequiv_growth', 'cashdividendspershare',
                         'cashdividendspershare_growth', 'companyname', 'debttoebitda',
                         'dilutedeps', 'div_binary', 'div_payout_ratio',
                         'div_payout_ratio_10ygrowth', 'div_payout_ratio_1ygrowth',
                         'div_payout_ratio_5ygrowth', 'div_payout_ratio_growth', 'ebit',
                         'ebit_10ygrowth', 'ebit_1ygrowth', 'ebit_5ygrowth', 'ebit_binary',
                         'ebit_growth', 'ebitda', 'ebitda_10ygrowth', 'ebitda_1ygrowth',
                         'ebitda_5ygrowth', 'ebitda_binary', 'ebitda_growth', 'ever_cut',
                         'evtoebitda', 'evtoebitda_10ygrowth', 'evtoebitda_1ygrowth',
                         'evtoebitda_5ygrowth', 'evtoebitda_binary', 'evtoebitda_growth',
                         'fcffgrowth', 'filingdate', 'fiscalquarter', 'fiscalyear',
                         'freecashflow', 'freecashflow_10ygrowth', 'freecashflow_1ygrowth',
                         'freecashflow_5ygrowth', 'freecashflow_binary', 'freecashflow_growth',
                         'last10cut', 'last5cut', 'netcashfromoperatingactivities',
                         'netcashfromoperatingactivities_10ygrowth',
                         'netcashfromoperatingactivities_1ygrowth',
                         'netcashfromoperatingactivities_5ygrowth',
                         'netcashfromoperatingactivities_binary',
                         'netcashfromoperatingactivities_growth', 'netincome', 'periodtypeid',
                         'periodtypename', 'pricetoearnings', 'pricetoearnings_10ygrowth',
                         'pricetoearnings_1ygrowth', 'pricetoearnings_5ygrowth',
                         'pricetoearnings_binary', 'pricetoearnings_growth', 'quick_recover',
                         'reportingtemplatetypeid', 'unittypeid', 'unittypename']
        feature_list = list(set(feature_names) - set(to_remove))
        # print(feature_list)
        importances = list(rf.feature_importances_)
        # List of tuples with variable and importance
        feature_importances = [(feature, round(importance, 2)) for feature, importance in
                               zip(feature_list, importances)]
        # Sort the feature importances by most important first
        feature_importances = sorted(feature_importances, key=lambda x: x[1], reverse=True)
        # Print out the feature and importances
        [print('Variable: {:20} Importance: {}'.format(*pair)) for pair in feature_importances]
        dump(rf, 'div_rf_7.joblib')
        return classification_report(test['div_binary'], test['predictions'], output_dict=True)['accuracy']

        # count_succ0 = 0
        # count_succ1 = 0
        # count_falsepos = 0
        # count_falseneg = 0
        # count = 0
        # for row in test.iterrows():
        #     val = row[1]['predictions']
        #     if val > .5:
        #         model_predict = 1
        #     else:
        #         model_predict = 0
        #
        #     if np.isnan(row[1]['div_binary']) or np.isnan(val):
        #         pass
        #     elif model_predict == row[1]['div_binary']:
        #         if model_predict == 0:
        #             # print("Successfully Guessed Decrease")
        #             # print("Success")
        #             count_succ0 += 1
        #         else:
        #             count_succ1 += 1
        #     # elif model_predict == -1:
        #     #   print("skipping")
        #     else:
        #         # print(model_predict)
        #         # print(model_predict, row[1]['div_binary'])
        #         # print("Failure")
        #         if model_predict == 0:
        #             count_falseneg += 1
        #         elif model_predict == 1:
        #             count_falsepos += 1
        #     count += 1
        #
        # accuracy = (count_succ1 + count_succ0) / ((count_succ1 + count_succ0) + (count_falseneg + count_falsepos))
        # acc_0 = count_succ0 / (count_succ0 + count_falsepos)
        # acc_1 = count_succ1 / (count_succ1 + count_falseneg)
        # print("Accuracy:", accuracy)
        # print("Accuracy 0's:", acc_0)
        # print("Accuracy  1's:", acc_1)
        # print("succ0: ", count_succ0)
        # print("succ1: ", count_succ1)
        # print("falsepos: ", count_falsepos)
        # print("falseneg: ", count_falseneg)
        # print(rf.score(modifytest, test['div_binary']))

    # def load_trained_model(self):
    #     rf = load('div_rf_2.joblib')
    #
    #     select = "SELECT * FROM dev_dividend_model;"
    #     big_df = pd.read_sql(select, self.pg._engine)
    #     # print(big_df.columns)
    #     nans = big_df[np.isnan(big_df['div_binary'])].index
    #     big_df.drop(nans, inplace=True)
    #     big_df.fillna(0, inplace=True)
    #     # train, test = train_test_split(big_df, test_size=0.2)
    #     # train.fillna(0, inplace=True)
    #     # modifytrain = train.copy()
    #     to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
    #                  'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
    #                  'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
    #                  'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
    #                  'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']
    #
    #     # modifytrain.drop(columns=to_remove, inplace=True)
    #     # Import the model we are using
    #     # Instantiate model with 1000 decision trees
    #     # rf = RandomForestRegressor(n_estimators=10)
    #     # Train the model on training data
    #     # rf.fit(modifytrain, train['div_binary'])
    #
    #     # test.fillna(0, inplace=True)
    #     modifydf = big_df.copy()
    #     modifydf.drop(columns=to_remove, inplace=True)
    #
    #     # Use the forest's predict method on the test data
    #     predictions = rf.predict(modifydf)
    #     big_df['predictions'] = predictions
    #     # Calculate the absolute errors
    #     errors = abs(predictions - big_df['div_binary'])
    #     # Print out the mean absolute error (mae)
    #     print('Mean Absolute Error:', round(np.mean(errors), 2))
    #
    #
    #
    #     count_succ0 = 0
    #     count_succ1 = 0
    #     count_falsepos = 0
    #     count_falseneg = 0
    #     count = 0
    #     for row in big_df.iterrows():
    #         val = row[1]['predictions']
    #         # val = row[1]['netcashfromoperatingactivities_binary'] * 10 + row[1]['div_payout_ratio_growth'] * -10
    #         + row[1][
    #         #   'debttoebitda'] * 0 + row[1]['last5cut'] * -10 + row[1]['last10cut'] * -.5 + row[1]['ever_cut'] *
    #         -.5 + row[1][
    #         #         'cashandcashequiv_1ygrowth'] * 0 + row[1]['freecashflow_binary'] * 0 + row[1][
    #         'quick_recover'] * 5
    #         # val = math.exp(val) / (1 + math.exp(val))
    #         # print(val)
    #         if val > .5:
    #             model_predict = 1
    #         else:
    #             model_predict = 0
    #
    #         if np.isnan(row[1]['div_binary']) or np.isnan(val):
    #             pass
    #         elif model_predict == row[1]['div_binary']:
    #             if model_predict == 0:
    #                 # print("Successfully Guessed Decrease")
    #                 # print("Success")
    #                 count_succ0 += 1
    #             else:
    #                 count_succ1 += 1
    #         # elif model_predict == -1:
    #         #   print("skipping")
    #         else:
    #             # print(model_predict)
    #             # print(model_predict, row[1]['div_binary'])
    #             # print("Failure")
    #             if model_predict == 0:
    #                 count_falseneg += 1
    #             elif model_predict == 1:
    #                 count_falsepos += 1
    #         count += 1
    #
    #     accuracy = (count_succ1 + count_succ0) / ((count_succ1 + count_succ0) + (count_falseneg + count_falsepos))
    #     acc_0 = count_succ0 / (count_succ0 + count_falsepos)
    #     acc_1 = count_succ1 / (count_succ1 + count_falseneg)
    #     print("Accuracy:", accuracy)
    #     print("Accuracy 0's:", acc_0)
    #     print("Accuracy  1's:", acc_1)
    #     print("succ0: ", count_succ0)
    #     print("succ1: ", count_succ1)
    #     print("falsepos: ", count_falsepos)
    #     print("falseneg: ", count_falseneg)

    @staticmethod
    def tree_to_code():
        feature_names = ['borrowed', 'calendarquarter', 'calendaryear', 'cashandcashequiv',
                         'cashandcashequiv_10ygrowth', 'cashandcashequiv_1ygrowth',
                         'cashandcashequiv_5ygrowth', 'cashandcashequiv_binary',
                         'cashandcashequiv_growth', 'cashdividendspershare',
                         'cashdividendspershare_growth', 'companyname', 'debttoebitda',
                         'dilutedeps', 'div_binary', 'div_payout_ratio',
                         'div_payout_ratio_10ygrowth', 'div_payout_ratio_1ygrowth',
                         'div_payout_ratio_5ygrowth', 'div_payout_ratio_growth', 'ebit',
                         'ebit_10ygrowth', 'ebit_1ygrowth', 'ebit_5ygrowth', 'ebit_binary',
                         'ebit_growth', 'ebitda', 'ebitda_10ygrowth', 'ebitda_1ygrowth',
                         'ebitda_5ygrowth', 'ebitda_binary', 'ebitda_growth', 'ever_cut',
                         'evtoebitda', 'evtoebitda_10ygrowth', 'evtoebitda_1ygrowth',
                         'evtoebitda_5ygrowth', 'evtoebitda_binary', 'evtoebitda_growth',
                         'fcffgrowth', 'filingdate', 'fiscalquarter', 'fiscalyear',
                         'freecashflow', 'freecashflow_10ygrowth', 'freecashflow_1ygrowth',
                         'freecashflow_5ygrowth', 'freecashflow_binary', 'freecashflow_growth',
                         'last10cut', 'last5cut', 'netcashfromoperatingactivities',
                         'netcashfromoperatingactivities_10ygrowth',
                         'netcashfromoperatingactivities_1ygrowth',
                         'netcashfromoperatingactivities_5ygrowth',
                         'netcashfromoperatingactivities_binary',
                         'netcashfromoperatingactivities_growth', 'netincome', 'periodtypeid',
                         'periodtypename', 'pricetoearnings', 'pricetoearnings_10ygrowth',
                         'pricetoearnings_1ygrowth', 'pricetoearnings_5ygrowth',
                         'pricetoearnings_binary', 'pricetoearnings_growth', 'quick_recover',
                         'reportingtemplatetypeid', 'unittypeid', 'unittypename']
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']
        feature_list = list(set(feature_names) - set(to_remove))
        rf = load('div_rf_2.joblib')

        # Pull out one tree from the forest
        tree = rf.estimators_[5]
        # Export the image to a dot file
        export_graphviz(tree, out_file='tree2.dot', feature_names=feature_list, rounded=True, precision=1, filled=True)
        # Use dot file to create a graph
        (graph,) = pydot.graph_from_dot_file('tree2.dot')
        # Write graph to a png file
        graph.write_png('tree2.png')

        # Get numerical feature importances
        importances = list(rf.feature_importances_)
        # List of tuples with variable and importance
        feature_importances = [(feature, round(importance, 2)) for feature, importance in
                               zip(feature_list, importances)]
        # Sort the feature importances by most important first
        feature_importances = sorted(feature_importances, key=lambda x: x[1], reverse=True)
        # Print out the feature and importances
        [print('Variable: {:20} Importance: {}'.format(*pair)) for pair in feature_importances]

    def n_estimators(self):
        n_estimators = range(1, 200)
        train_results = []
        test_results = []

        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        for estimator in n_estimators:
            rf = RandomForestClassifier(n_estimators=estimator, n_jobs=-1)
            # Train the model on training data
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(n_estimators, train_results, 'b', label="Train AUC")
        line2, = plt.plot(n_estimators, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('n_estimators')
        plt.show()

    def max_depth(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        max_depths = np.linspace(1, 32, 32, endpoint=True)
        train_results = []
        test_results = []
        for max_depth in max_depths:
            rf = RandomForestClassifier(max_depth=max_depth, n_jobs=-1)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(max_depths, train_results, 'b', label="Train AUC")
        line2, = plt.plot(max_depths, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('Tree Depth')
        plt.show()

    def min_samples_split(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        min_samples_splits = np.linspace(0.1, 1.0, 10, endpoint=True)
        train_results = []
        test_results = []
        for min_samples_split in min_samples_splits:
            rf = RandomForestClassifier(min_samples_split=min_samples_split)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(min_samples_splits, train_results, 'b', label="Train AUC")
        line2, = plt.plot(min_samples_splits, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('min samples split')
        plt.show()

    def min_samples_leaf(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        min_samples_leafs = np.linspace(0.1, 0.5, 5, endpoint=True)
        train_results = []
        test_results = []
        for min_samples_leaf in min_samples_leafs:
            rf = RandomForestClassifier(min_samples_leaf=min_samples_leaf)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(min_samples_leafs, train_results, 'b', label="Train AUC")
        line2, = plt.plot(min_samples_leafs, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('min samples leaf')
        plt.show()

    def max_features(self):
        select = "SELECT * FROM dev_dividend_model;"
        big_df = pd.read_sql(select, self.pg._engine)

        nans = big_df[np.isnan(big_df['div_binary'])].index
        big_df.drop(nans, inplace=True)

        ones = big_df[big_df['div_binary'] == 1]
        zeros = big_df[big_df['div_binary'] == 0]
        # num = big_df['div_binary'].value_counts()[1] -
        num = big_df['div_binary'].value_counts()[0]
        sample = ones.sample(n=num)
        newdf = zeros.append(sample)

        train, test = train_test_split(newdf, test_size=0.2)
        train.fillna(0, inplace=True)
        modifytrain = train.copy()
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id']

        modifytrain.drop(columns=to_remove, inplace=True)
        # Import the model we are using
        # Instantiate model with 1000 decision tree

        test.fillna(0, inplace=True)
        modifytest = test.copy()
        modifytest.drop(columns=to_remove, inplace=True)

        max_features = np.linspace(0.1, 1.0, 10, endpoint=True)
        print(max_features)
        train_results = []
        test_results = []
        for max_feature in max_features:
            rf = RandomForestClassifier(max_features=max_feature)
            rf.fit(modifytrain, train['div_binary'])
            train_pred = rf.predict(modifytrain)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(train['div_binary'], train_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            train_results.append(roc_auc)
            y_pred = rf.predict(modifytest)
            false_positive_rate, true_positive_rate, thresholds = roc_curve(test['div_binary'], y_pred)
            roc_auc = auc(false_positive_rate, true_positive_rate)
            test_results.append(roc_auc)
        from matplotlib.legend_handler import HandlerLine2D
        line1, = plt.plot(max_features, train_results, 'b', label="Train AUC")
        line2, = plt.plot(max_features, test_results, 'r', label="Test AUC")
        plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
        plt.ylabel('AUC score')
        plt.xlabel('max features')
        plt.show()

    @staticmethod
    def download_resources(file):
        if not os.path.exists('dividend-model-resources'):
            print('creating directory...')
            os.makedirs('dividend-model-resources')

        # files = ['not_freq_updated_80.joblib']

        bucket = 'dividend-model-resources'

        # credentials = boto3.Session().get_credentials()

        # s3 = boto3.client('s3', aws_access_key_id=credentials.access_key,
        # aws_secret_access_key=credentials.secret_key)

        s3 = boto3.client('s3', region_name='us-east-1')

        s3.download_file(bucket, file,
                         'dividend-model-resources/{}'.format(file))

    def predict_single(self, row):
        try:
            rf = load('not_freq_updated_80.joblib')
        except Exception:
            self.download_resources('not_freq_updated_80.joblib')
            rf = load('dividend-model-resources/not_freq_updated_80.joblib')

        # select = "SELECT * FROM dev_dividend_model WHERE symbol='{}' AND periodenddate>='{}';".format(symbol, date)
        select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id='{}' AND periodenddate = (SELECT MAX(" \
                 "periodenddate) FROM dev_dividend_model WHERE composite_pk_id='{}')".format(
            row['composite_pk_id'], row['composite_pk_id'])
        big_df = pd.read_sql(select, self._pg_df_engine)
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend', 'saleofppe', 'int/cash', 'int/income',
                     'totalinterestexpense', 'saleofppe_growth', 'saleofppe_1ygrowth',
                     'saleofppe_5ygrowth', 'saleofppe_10ygrowth', 'saleofppe_binary']
        if len(big_df) > 0:
            if big_df['cashdividendspershare'].iloc[0] is None:
                return np.nan
            else:
                big_df.fillna(0, inplace=True)
                modifydf = big_df.copy()
                modifydf.drop(columns=to_remove, inplace=True)
                predicted_proba = rf.predict_proba(modifydf)
                return predicted_proba[0][1]
        else:
            return np.nan

    def rankings(self):
        # correct_symbols = ['CLNY', 'RGR', 'BHP', 'TOT', 'MAS', 'MSFT', 'ADI', 'LEN', 'AGN', 'AVB', 'FLS', 'J', 'DXC',
        #                    'ZTS', 'RAD', 'FMC', 'XYL', 'LH', 'ADS', 'MO', 'EW', 'DHI', 'FLR', 'MRK', 'IVZ', 'DTE',
        #                    'GWW', 'TFC', 'MKC', 'ATVI', 'BLL', 'KIM', 'V', 'PFE', 'RMD', 'DIS', 'MNST', 'GPC',
        #                    'LKQ', 'MET', 'CTSH', 'DGX', 'AFL', 'JPS', 'ABT', 'PFG', 'EQIX', 'AEP', 'ECL', 'COO', 'HOPE',
        #                    'CVS', 'XEL', 'VFC', 'RSG', 'UHS', 'FAST', 'TEVA', 'SEE', 'ICE', 'HRB', 'SRCL', 'ADSK',
        #                    'MDT', 'DAL', 'GPS', 'MYL', 'XRX', 'BA', 'AMG', 'AXP', 'RL', 'PNC', 'JCI', 'PPG', 'KLAC',
        #                    'MAC', 'WELL', 'C', 'URI', 'MAR', 'AMGN', 'AYI', 'KO', 'ACN', 'HOLX', 'HSY', 'AME', 'D',
        #                    'MS', 'IPGP', 'AMT', 'TMUS', 'WHR', 'VAR', 'LLY', 'CNC', 'WYNN', 'SPGI', 'M', 'MGM', 'CMA',
        #                    'IRM', 'PVH', 'JNPR', 'VMC', 'WFC', 'RE', 'TDG', 'PM', 'ETFC', 'WAT', 'F', 'K', 'BXP', 'TXT',
        #                    'VRTX', 'PSA', 'CTAS', 'AMD', 'AIZ', 'PEG', 'WU', 'MMM', 'BHF', 'NVDA', 'GD', 'TSCO', 'WM',
        #                    'REGN', 'GOLD', 'MAA', 'EMN', 'HII', 'UAA', 'FL', 'NUE', 'CSCO', 'WF', 'FRT', 'INTC', 'PH',
        #                    'NOC', 'CPB', 'BDX', 'EFX', 'O', 'NI', 'KL', 'HBI', 'MU', 'KSS', 'PRGO', 'LB', 'NDAQ', 'CMI',
        #                    'TRV', 'DUK', 'CAH', 'RJF', 'NTAP', 'MTB', 'AOS', 'CF', 'DISH', 'COST', 'PEP', 'TAP', 'SWKS',
        #                    'DRI', 'STT', 'SLG', 'ORCL', 'ALLE', 'AAL', 'BK', 'UNH', 'WMT', 'TTWO', 'NFLX', 'SO', 'EMD',
        #                    'KMX', 'UA', 'TEL', 'IBM', 'CERN', 'TXN', 'JWN', 'AMZN', 'ADP', 'BLK', 'WLTW', 'TGT', 'EXPE',
        #                    'HCA', 'DVA', 'SIVB', 'GS', 'VZ', 'BMY', 'EBAY', 'DFS', 'CHRW', 'BWA', 'APTV', 'FOX', 'AZO',
        #                    'APD', 'LEG', 'CL', 'FCX', 'ETN', 'PKG', 'BHC', 'PG', 'DOV', 'SYF', 'HSIC', 'CHTR', 'WEC',
        #                    'ESS', 'EQR', 'ROST', 'ALXN', 'KEY', 'SCHW', 'AON', 'DG', 'NKE', 'MCK', 'SPR', 'PLD', 'GLW',
        #                    'ULTA', 'LNC', 'NLSN', 'MLM', 'BP', 'ALB', 'VTR', 'T', 'IFF', 'TPR', 'HST', 'PKI', 'ANSS',
        #                    'ORLY', 'GT', 'IR', 'IDXX', 'CNP', 'TIF', 'EXR', 'NCLH', 'BBY', 'JCP', 'INTU', 'TROW', 'UNM',
        #                    'OMC', 'KR', 'STX', 'NEM', 'FE', 'GOOG', 'XLNX', 'AAP', 'DE', 'WRK', 'MTD', 'PCAR', 'PAYX',
        #                    'AIG', 'BAC', 'NUV', 'CB', 'NSC', 'EA', 'NWS', 'EMR', 'CSX', 'PPL', 'ARE', 'RF', 'BIIB',
        #                    'SHW', 'WBA', 'RCL', 'HOG', 'FLIR', 'HLT', 'FOXA', 'ALGN', 'AEE', 'CMS', 'FFIV', 'KSU',
        #                    'KMB', 'GRMN', 'AVY', 'LUV', 'CI', 'MCHP', 'INCY', 'FBHS', 'MOS', 'WY', 'PBCT', 'PNW',
        #                    'GILD', 'QCOM', 'ARNC', 'ABBV', 'BSX', 'MDLZ', 'RTN', 'HD', 'NKTR', 'EXPD', 'AMP', 'RHI',
        #                    'HBAN', 'XRAY', 'LOW', 'AWK', 'JPM', 'VNO', 'AIV', 'MTCH', 'UDR', 'MA', 'UTX', 'GE', 'SPG',
        #                    'ETR', 'DHR', 'CINF', 'ILMN', 'HRL', 'LRCX', 'NTRS', 'REG', 'ED', 'NEE', 'FIS', 'PYPL',
        #                    'MCO', 'IPG', 'CRM', 'BF.B', 'PHM', 'EXC', 'UNP', 'NAVI', 'HPE', 'NWL', 'A', 'ALL', 'CBRE',
        #                    'HUM', 'CCL', 'SYK', 'MAT', 'ITW', 'KHC', 'HON', 'TJX', 'VRSK', 'EIX', 'IQV', 'COF', 'EL',
        #                    'ROL', 'ROK', 'SBAC', 'UAL', 'ROP', 'LNT', 'IP', 'FITB', 'BAX', 'SJM', 'ES', 'SYY', 'AJG',
        #                    'CAG', 'GIS', 'ADM', 'SWK', 'MSI', 'MMC', 'STZ', 'SNA', 'BEN', 'DOW', 'ZBH', 'TRIP', 'ABC',
        #                    'YUM', 'PNR', 'CFG', 'UPS', 'WDC', 'IT', 'BRK.B', 'PRU', 'ADBE', 'DLTR', 'JBHT', 'LMT',
        #                    'HAS', 'GM', 'MCD', 'DLR', 'FTV', 'TMO', 'CAT', 'CTL', 'PGR', 'AAPL', 'SNPS', 'VIAC', 'CTXS',
        #                    'BKNG', 'INFO', 'GPN', 'HIG', 'CME', 'VRSN', 'CMG', 'AMAT', 'HPQ', 'FDX', 'SRE', 'CLX',
        #                    'ISRG', 'APH', 'JNJ', 'RECN', 'USB', 'COTY', 'NWSA', 'CDNS', 'QRVO', 'AKAM', 'ALK', 'AVGO',
        #                    'FB', 'MHK', 'SBUX', 'FISV', 'TSN', 'LYB', 'CHD', 'ZION', 'L', 'DRE', 'PWR', 'ANTM', 'CCI']
        companies = pd.read_sql("""SELECT mv.companyname,
                       mv.companyid,
                       mv.tickersymbol,
                       pt.periodtypename,
                       fp.calendarquarter,
                       fp.calendaryear,
                       fd.dataitemid,
                       di.dataitemname,
                       fd.dataitemvalue,
                       fp.fiscalyear,
                       fp.fiscalquarter,
                       fp.periodenddate,
                       fp.filingdate,
                       fp.financialperiodid,
                       fp.latestperiodflag,
                       mv.exchangesymbol,
                       mv.gicsgroup,
                       mv.gicsindustry,
                       mv.tradingitemid
                        FROM (((((v2mv_sbt_company mv
                            JOIN ciqlatestinstancefinperiod fp ON ((fp.companyid = mv.companyid)))
                            JOIN ciqperiodtype pt ON ((pt.periodtypeid = fp.periodtypeid)))
                            JOIN ciqfinancialdata fd ON ((fd.financialperiodid = fp.financialperiodid)))
                            JOIN ciqdataitem di ON ((di.dataitemid = fd.dataitemid))))
                        WHERE ((fd.dataitemid = ANY (ARRAY [3058])) AND (pt.periodtypeid = 1) AND
                               (fp.latestperiodflag = 1) AND ((mv.exchangesymbol)::text = ANY
                                                              (ARRAY ['NYSE'::text, 'AMEX'::text, 'ARCA'::text, 
                                                              'NasdaqGS'::text, 'NasdaqGM'::text, 'NasdaqCM'::text, 
                                                              'NasdaqCS'::text])) AND
                               (mv.is_primary_exchange = true));""", self._snp_engine)
        correct_symbols = companies[companies['gicsgroup'].notnull()]
        # correct_symbols.loc[correct_symbols['exchangesymbol'].isin(['NasdaqGS', 'NasdaqGM']), 'exchangesymbol'] = 'NSDQ'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'NasdaqCM', 'exchangesymbol'] = 'NSDQCM'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'ARCA', 'exchangesymbol'] = 'NYSEARCA'
        # correct_symbols['composite_pk_id'] = correct_symbols['tickersymbol'] + ':' + correct_symbols['exchangesymbol']
        correct_symbols['composite_pk_id'] = ["{}:{}".format(sym, self.get_exchange_mapping(exc)) for sym, exc in zip(correct_symbols['tickersymbol'], correct_symbols['exchangesymbol'])]
        correct_symbols['prob'] = np.nan
        # correct_symbols = correct_symbols[~correct_symbols['gicsindustry'].isin(['Energy Equipment and Services', 'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels'])]
        # correct_symbols = correct_symbols[(correct_symbols['gicsgroup'] != 'Energy') & (correct_symbols['gicsgroup'] != 'Materials')]
        correct_symbols['prob'] = correct_symbols.apply(self.predict_single, axis=1)
        # correct_symbols.loc[~correct_symbols['gicsindustry'].isin(['Energy Equipment and Services', " \
        # "'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels']), 'prob'].apply(self.predict_single(correct_symbols['composite_pk_id']))
        # df = pd.DataFrame(columns=['composite_pk_id', 'score'])
        # for symbol in correct_symbols:
        #     symbol = symbol[1]
        #     print(symbol['composite_pk_id'])
        #     # add = self.dd._query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NYSE")
        #     # if add:
        #     prob = self.predict_single(symbol['composite_pk_id'])
        #     # else:
        #     #     add = self.dd._query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", 'symbol', symbol, 'exchange', "NSDQ")
        #     #     prob = self.predict_single(add[0]['composite_pk_id'])
        #     if prob is not None:
        #         df = df.append({'composite_pk_id': symbol['composite_pk_id'], 'score': prob,
        #                         'rating': None, 'rank': None, 'model': {
        #                 'model': {'score': prob, 'composite_pk_id': symbol['composite_pk_id'],
        #                           'date_calculated': str(datetime.date.today())}}}, ignore_index=True)
        # correct_symbols = correct_symbols.append(self.energy_rankings())
        correct_symbols = correct_symbols.loc[~np.isnan(correct_symbols['prob'])]
        correct_symbols['score'] = correct_symbols['prob']
        correct_symbols['rank'] = None
        correct_symbols['rating'] = None
        correct_symbols.sort_values(by='score', ascending=False, inplace=True)
        correct_symbols.reset_index(inplace=True, drop=True)
        correct_symbols['rank'] = -(correct_symbols.index + 1 - len(correct_symbols.index)) / (len(correct_symbols.index) - 1)
        correct_symbols['model'] = None
        count = 0
        for row in correct_symbols.iterrows():
            row = row[1]
            correct_symbols.at[count, 'model'] = {
                'model': {
                    "composite_pk_id": row["composite_pk_id"],
                    'date_calculated': datetime.datetime.now().strftime('%Y-%m-%d'),
                    "guid": str(row["tradingitemid"]),
                    'score': row['score'],
                    'value': row['score'],
                    'rank': None,
                    'rating': None,
                    'raw_data': {},
                    'calculated_data': {},
                }
            }
            count = count + 1
        to_db = correct_symbols[['tradingitemid', 'composite_pk_id', 'model', 'rank', 'rating', 'score']]
        # renaming column in place
        to_db.rename(columns={"tradingitemid": "trading_item_id"}, inplace=True)
        to_db = to_db.sort_values('rank', ascending=False)
        self._logger.info(" DONE.")

        tic = datetime.datetime.now()
        for env in ENVS_TO_UPDATE:
            to_db.to_sql(
                'sbt_indicator_dividend',
                self.db_to_update.get(env.upper()),
                if_exists='replace',
                index=False,
                dtype={
                    'model': JSON,
                    'score': FLOAT,
                    'rank': FLOAT,
                    'rating': VARCHAR,
                    'composite_pk_id': VARCHAR
                })

            to_db.to_sql(
                'development_sbt_models_dividend_rankings',
                self.db_to_update.get(env.upper()),
                if_exists='replace',
                index=False,
                dtype={
                    'model': JSON,
                    'score': FLOAT,
                    'rank': FLOAT,
                    'rating': VARCHAR,
                    'composite_pk_id': VARCHAR
                })
            tac = datetime.datetime.now()

            self._logger.info(" {}: DATA SAVED IN Dt={}.".format(
                env.upper(), tac - tic)
            )

        # create stats table
        self.create_model_stats_table(data=to_db)

    def predict_single_energy(self, row):
        try:
            rf = load('energy_model_updated_79.joblib')
        except Exception:
            self.download_resources('energy_model_updated_79.joblib')
            rf = load('dividend-model-resources/energy_model_updated_79.joblib')

        # select = "SELECT * FROM dev_dividend_model WHERE symbol='{}' AND periodenddate>='{}';".format(symbol, date)
        select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id='{}' AND periodenddate = (SELECT MAX(" \
            "periodenddate) FROM dev_dividend_model WHERE composite_pk_id='{}')".format(
                                                                                    row['composite_pk_id'], row['composite_pk_id'])
        big_df = pd.read_sql(select, self._pg_df_engine)
        # to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
        #              'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
        #              'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
        #              'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
        #              'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
        #              'semiannual_flag', 'annual_dividend']
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend', 'saleofppe_growth', 'saleofppe_1ygrowth',
                     'saleofppe_5ygrowth', 'saleofppe_10ygrowth', 'saleofppe_binary', 'saleofppe']
        if len(big_df) > 0:
            if big_df['cashdividendspershare'].iloc[0] is None:
                return np.nan
            else:
                big_df.fillna(0, inplace=True)
                modifydf = big_df.copy()
                modifydf.drop(columns=to_remove, inplace=True)
                predicted_proba = rf.predict_proba(modifydf)
                return predicted_proba[0][1]
        else:
            return np.nan

    def energy_rankings(self):
        # div = DivLoader()
        # sbtcommon = SbtCommon()
        # config = sbtcommon.get_sbt_config()
        # pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
        # select0 = "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Energy Equipment and Services', " \
        # "'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels')"
        # guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
        # composites = []
        # snp_ids = []
        # valid_guids = []
        # for guid in guids:
        #     response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING",
        #                                **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})[
        #         'Items']
        #     if response:
        #         if 'NYSE' in response[0]['composite_pk_id'] or 'NSDQ' in response[0]['composite_pk_id'] or 'AMEX' in \
        #             response[0]['composite_pk_id']:
        #             composites.append(response[0]['composite_pk_id'])
        #             snp_ids.append(response[0]['snp_id'])
        #             valid_guids.append(guid)
        companies = pd.read_sql("""SELECT mv.companyname,
                                       mv.companyid,
                                       mv.tickersymbol,
                                       pt.periodtypename,
                                       fp.calendarquarter,
                                       fp.calendaryear,
                                       fd.dataitemid,
                                       di.dataitemname,
                                       fd.dataitemvalue,
                                       fp.fiscalyear,
                                       fp.fiscalquarter,
                                       fp.periodenddate,
                                       fp.filingdate,
                                       fp.financialperiodid,
                                       fp.latestperiodflag,
                                       mv.exchangesymbol,
                                       mv.gicsgroup,
                                       mv.gicsindustry,
                                       mv.tradingitemid
                                        FROM (((((v2mv_sbt_company mv
                                            JOIN ciqlatestinstancefinperiod fp ON ((fp.companyid = mv.companyid)))
                                            JOIN ciqperiodtype pt ON ((pt.periodtypeid = fp.periodtypeid)))
                                            JOIN ciqfinancialdata fd ON ((fd.financialperiodid = fp.financialperiodid)))
                                            JOIN ciqdataitem di ON ((di.dataitemid = fd.dataitemid))))
                                        WHERE ((fd.dataitemid = ANY (ARRAY [3058])) AND (pt.periodtypeid = 1) AND
                                               (fp.latestperiodflag = 1) AND ((mv.exchangesymbol)::text = ANY
                                                                              (ARRAY ['NYSE'::text, 'AMEX'::text, 
                                                                              'ARCA'::text, 
                                                                              'NasdaqGS'::text, 'NasdaqGM'::text, 
                                                                              'NasdaqCM'::text, 
                                                                              'NasdaqCS'::text])) AND
                                               (mv.is_primary_exchange = true));""", self._snp_engine)
        correct_symbols = companies[companies['gicsgroup'].notnull()]
        # correct_symbols.loc[correct_symbols['exchangesymbol'].isin(['NasdaqGS', 'NasdaqGM']), 'exchangesymbol'] = 'NSDQ'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'NasdaqCM', 'exchangesymbol'] = 'NSDQCM'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'ARCA', 'exchangesymbol'] = 'NYSEARCA'
        # correct_symbols['composite_pk_id'] = correct_symbols['tickersymbol'] + ':' + correct_symbols['exchangesymbol']
        # correct_symbols = correct_symbols[correct_symbols['gicsindustry'].isin(['Energy Equipment and Services', 'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels'])]
        correct_symbols['composite_pk_id'] = ["{}:{}".format(sym, self.get_exchange_mapping(exc)) for sym, exc in zip(correct_symbols['tickersymbol'], correct_symbols['exchangesymbol'])]
        correct_symbols = correct_symbols[correct_symbols['gicsgroup'] == 'Energy']
        correct_symbols['prob'] = correct_symbols.apply(self.predict_single_energy, axis=1)
        # df = pd.DataFrame(columns=['composite_pk_id', 'score'])
        # for (symbol, guid) in zip(composites, valid_guids):
        #     print(symbol)
        #     prob = self.predict_single_energy(symbol)
        #     if prob is not None:
        #         df = df.append({'composite_pk_id': symbol, 'guid': guid, 'score': prob,
        #                         'rating': None, 'rank': None, 'model': {
        #                 'model': {'score': prob, 'composite_pk_id': symbol,
        #                           'date_calculated': str(datetime.date.today())}}}, ignore_index=True)
        # df.sort_values(by='score', ascending=False, inplace=True)
        # df.to_sql('development_sbt_models_dividend_rankings_energy',
        #               self.pg._engine,
        #               if_exists='replace', dtype={'model': JSON,
        #            'score': FLOAT,
        #            'rank': FLOAT,
        #            'rating': VARCHAR,
        #            'composite_pk_id': VARCHAR
        #            }, index=False)
        return correct_symbols

    def predict_single_materials(self, row):
        try:
            rf = load('materials_78.joblib')
        except Exception:
            self.download_resources('materials_78.joblib')
            rf = load('dividend-model-resources/materials_78.joblib')

        # select = "SELECT * FROM dev_dividend_model WHERE symbol='{}' AND periodenddate>='{}';".format(symbol, date)
        select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id='{}' AND periodenddate = (SELECT MAX(" \
            "periodenddate) FROM dev_dividend_model WHERE composite_pk_id='{}')".format(
                                                                                    row['composite_pk_id'], row['composite_pk_id'])
        big_df = pd.read_sql(select, self._pg_df_engine)
        # to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
        #              'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
        #              'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
        #              'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
        #              'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
        #              'semiannual_flag', 'annual_dividend']
        to_remove = ["div_binary", "calendarquarter", "calendaryear", 'filingdate', 'fiscalquarter', 'fiscalyear',
                     'periodtypename', 'periodtypeid', 'reportingtemplatetypeid', 'unittypeid', 'unittypename',
                     'evtoebitda_10ygrowth', 'evtoebitda_5ygrowth', 'evtoebitda_1ygrowth', 'evtoebitda',
                     'evtoebitda_binary', 'evtoebitda_growth', 'companyname', 'cashdividendspershare',
                     'ebit_10ygrowth', 'periodenddate', 'composite_pk_id', 'annual_flag', 'quarter_flag',
                     'semiannual_flag', 'annual_dividend']
        if len(big_df) > 0:
            if big_df['cashdividendspershare'].iloc[0] is None:
                return np.nan
            else:
                big_df.fillna(0, inplace=True)
                modifydf = big_df.copy()
                modifydf.drop(columns=to_remove, inplace=True)
                predicted_proba = rf.predict_proba(modifydf)
                return predicted_proba[0][1]
        else:
            return np.nan

    def materials_rankings(self):
        # div = DivLoader()
        # sbtcommon = SbtCommon()
        # config = sbtcommon.get_sbt_config()
        # pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
        # select0 = "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Energy Equipment and Services', " \
        # "'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels')"
        # guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
        # composites = []
        # snp_ids = []
        # valid_guids = []
        # for guid in guids:
        #     response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING",
        #                                **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})[
        #         'Items']
        #     if response:
        #         if 'NYSE' in response[0]['composite_pk_id'] or 'NSDQ' in response[0]['composite_pk_id'] or 'AMEX' in \
        #             response[0]['composite_pk_id']:
        #             composites.append(response[0]['composite_pk_id'])
        #             snp_ids.append(response[0]['snp_id'])
        #             valid_guids.append(guid)
        companies = pd.read_sql("""SELECT mv.companyname,
                                       mv.companyid,
                                       mv.tickersymbol,
                                       pt.periodtypename,
                                       fp.calendarquarter,
                                       fp.calendaryear,
                                       fd.dataitemid,
                                       di.dataitemname,
                                       fd.dataitemvalue,
                                       fp.fiscalyear,
                                       fp.fiscalquarter,
                                       fp.periodenddate,
                                       fp.filingdate,
                                       fp.financialperiodid,
                                       fp.latestperiodflag,
                                       mv.exchangesymbol,
                                       mv.gicsgroup,
                                       mv.gicsindustry,
                                       mv.tradingitemid
                                        FROM (((((v2mv_sbt_company mv
                                            JOIN ciqlatestinstancefinperiod fp ON ((fp.companyid = mv.companyid)))
                                            JOIN ciqperiodtype pt ON ((pt.periodtypeid = fp.periodtypeid)))
                                            JOIN ciqfinancialdata fd ON ((fd.financialperiodid = fp.financialperiodid)))
                                            JOIN ciqdataitem di ON ((di.dataitemid = fd.dataitemid))))
                                        WHERE ((fd.dataitemid = ANY (ARRAY [3058])) AND (pt.periodtypeid = 1) AND
                                               (fp.latestperiodflag = 1) AND ((mv.exchangesymbol)::text = ANY
                                                                              (ARRAY ['NYSE'::text, 'AMEX'::text, 
                                                                              'ARCA'::text, 
                                                                              'NasdaqGS'::text, 'NasdaqGM'::text, 
                                                                              'NasdaqCM'::text, 
                                                                              'NasdaqCS'::text])) AND
                                               (mv.is_primary_exchange = true));""", self._snp_engine)
        correct_symbols = companies[companies['gicsgroup'].notnull()]
        # correct_symbols.loc[correct_symbols['exchangesymbol'].isin(['NasdaqGS', 'NasdaqGM']), 'exchangesymbol'] = 'NSDQ'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'NasdaqCM', 'exchangesymbol'] = 'NSDQCM'
        # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'ARCA', 'exchangesymbol'] = 'NYSEARCA'
        # correct_symbols['composite_pk_id'] = correct_symbols['tickersymbol'] + ':' + correct_symbols['exchangesymbol']
        # correct_symbols = correct_symbols[correct_symbols['gicsindustry'].isin(['Energy Equipment and Services', 'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels'])]
        correct_symbols['composite_pk_id'] = ["{}:{}".format(sym, self.get_exchange_mapping(exc)) for sym, exc in zip(correct_symbols['tickersymbol'], correct_symbols['exchangesymbol'])]
        correct_symbols = correct_symbols[correct_symbols['gicsgroup'] == 'Materials']
        correct_symbols['prob'] = correct_symbols.apply(self.predict_single_materials, axis=1)
        # df = pd.DataFrame(columns=['composite_pk_id', 'score'])
        # for (symbol, guid) in zip(composites, valid_guids):
        #     print(symbol)
        #     prob = self.predict_single_energy(symbol)
        #     if prob is not None:
        #         df = df.append({'composite_pk_id': symbol, 'guid': guid, 'score': prob,
        #                         'rating': None, 'rank': None, 'model': {
        #                 'model': {'score': prob, 'composite_pk_id': symbol,
        #                           'date_calculated': str(datetime.date.today())}}}, ignore_index=True)
        # df.sort_values(by='score', ascending=False, inplace=True)
        # df.to_sql('development_sbt_models_dividend_rankings_energy',
        #               self.pg._engine,
        #               if_exists='replace', dtype={'model': JSON,
        #            'score': FLOAT,
        #            'rank': FLOAT,
        #            'rating': VARCHAR,
        #            'composite_pk_id': VARCHAR
        #            }, index=False)
        return correct_symbols

    def count_div_paying_companies(self):
        # self.ENV = "dev"

        companies = pd.read_sql("""SELECT mv.companyname,
       mv.companyid,
       mv.tickersymbol,
       pt.periodtypename,
       fp.calendarquarter,
       fp.calendaryear,
       fd.dataitemid,
       di.dataitemname,
       fd.dataitemvalue,
       fp.fiscalyear,
       fp.fiscalquarter,
       fp.periodenddate,
       fp.filingdate,
       fp.financialperiodid,
       fp.latestperiodflag,
       mv.exchangesymbol,
       mv.gicsgroup,
       mv.tradingitemid
        FROM (((((v2mv_sbt_company mv
            JOIN ciqlatestinstancefinperiod fp ON ((fp.companyid = mv.companyid)))
            JOIN ciqperiodtype pt ON ((pt.periodtypeid = fp.periodtypeid)))
            JOIN ciqfinancialdata fd ON ((fd.financialperiodid = fp.financialperiodid)))
            JOIN ciqdataitem di ON ((di.dataitemid = fd.dataitemid))))
        WHERE ((fd.dataitemid = ANY (ARRAY [3058])) AND (pt.periodtypeid = 1) AND
               (fp.latestperiodflag = 1) AND ((mv.exchangesymbol)::text = ANY
                                              (ARRAY ['NYSE'::text, 'AMEX'::text, 'ARCA'::text, 'NasdaqGS'::text, 'NasdaqGM'::text, 'NasdaqCM'::text, 'NasdaqCS'::text])) AND
               (mv.is_primary_exchange = true));""", self._snp_engine)
        us_count = len(companies[companies['gicsgroup'].notnull()])
        # count = 0
        # us_count = 0
        # for company in companies.iterrows():
        #     if company[1]['cash_div_per_share_f0'] > 0 and company[1]['latest_filing_date'] > '2019-06-01':
        #         count += 1
        #     if company[1]['cash_div_per_share_f0'] > 0 and company[1]['country_code'] == 'USA' and company[1][
        #         'latest_filing_date'] > '2019-06-01':
        #         us_count += 1
        print(us_count)

    def create_model_stats_table(self, data=None):
        print(
            ' DIVIDEND: CREATING STATS TABLE IN PG...')
        tic = datetime.datetime.now()
        # # rating stats table
        # TABLE_NAME = "{}_{}_rating_stats".format(RESULT_TABLENAME_PREFIX,
        #                                          model_id
        #                                          )
        # # get the min/max for the model's rank (:= total number of points),
        # # which is the most important result for CE
        # df_stats = pd.DataFrame(
        #     (x for x in data),
        #     columns=['rating', 'score']).groupby(by='rating') \
        #     .agg({"score": [min, max, "count"]})
        # # rename columns
        # df_stats.columns = ['minRank', 'maxRank', 'total']
        # # save rating stats
        # df_stats.to_sql(TABLE_NAME,
        #                 self.pg._engine,
        #                 if_exists='replace',
        #                 index_label='rating'
        #                 )
        # # rank stats table
        TABLE_NAME = "sbt_indicator_dividend_score_stats"
        data = pd.DataFrame(data)
        model_stat_df = data.agg({'score': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minscore', 'maxscore', 'total']
        # stats per model (total within each rank bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['score'], [-1000, 0, .25, .45, .55, .75, 1])
        )['score'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        for env in ENVS_TO_UPDATE:
            model_score_stat_df.to_sql(TABLE_NAME,
                                       self.db_to_update.get(env.upper()),
                                       if_exists='replace'
                                       )
        print(
            ' DIVIDEND: DIVIDEND TABLE CREATED IN Dt = {}'.format(
                datetime.datetime.now() - tic)
        )

    def query_table(self, table_name, **kwargs):
        # get table
        table = self.ddb.Table(table_name)
        # get query response
        response = table.query(
            IndexName=kwargs.get('index_name', ''),
            KeyConditionExpression=Key(kwargs.get('key'))
                .__getattribute__(kwargs.get('operator'))(kwargs.get('value'))
        )
        return response

    def load_energy(self):
        div = DivLoader()
        sbtcommon = SbtCommon()
        config = sbtcommon.get_sbt_config()
        pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
        select0 = "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Energy Equipment and Services', " \
        "'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels')"
        guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
        composites = []
        snp_ids = []
        for guid in guids:
            response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING",
                                       **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})[
                'Items']
            if response:
                if 'NYSE' in response[0]['composite_pk_id'] or 'NSDQ' in response[0]['composite_pk_id'] or 'AMEX' in \
                    response[0]['composite_pk_id']:
                    composites.append(response[0]['composite_pk_id'])
                    snp_ids.append(response[0]['snp_id'])
        big_df = pd.DataFrame()
        print(len(composites))
        for composite, snp_id in zip(composites, snp_ids):
            print(composite)
            try:
                retval = self.load(snp_id, composite)
            except Exception as e:
                print(e, composite)
            if retval is not None:
                # retval['symbol'] = symbol
                big_df = pd.concat([big_df, retval])

        big_df.to_sql('dev_dividend_model_energy',
                      self.pg._engine,
                      if_exists='replace',
                      index=False
                      # index_label='periodenddate'
                      )
        return self.energy_rankings()

    def load_banks(self):
        div = DivLoader()
        sbtcommon = SbtCommon()
        config = sbtcommon.get_sbt_config()
        pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
        select0 = "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Banks')"
        guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
        composites = []
        snp_ids = []
        for guid in guids:
            response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING",
                                       **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})[
                'Items']
            if response:
                if 'NYSE' in response[0]['composite_pk_id'] or 'NSDQ' in response[0]['composite_pk_id'] or 'AMEX' in \
                    response[0]['composite_pk_id']:
                    composites.append(response[0]['composite_pk_id'])
                    snp_ids.append(response[0]['snp_id'])
        big_df = pd.DataFrame()
        print(len(composites))
        for composite, snp_id in zip(composites, snp_ids):
            print(composite)
            try:
                retval = self.load(snp_id, composite)
            except Exception as e:
                print(e, composite)
            if retval is not None:
                # retval['symbol'] = symbol
                big_df = pd.concat([big_df, retval])

        big_df.to_sql('dev_dividend_model_banks',
                      self.pg._engine,
                      if_exists='replace',
                      index=False
                      # index_label='periodenddate'
                      )
        return self.energy_rankings()


if __name__ == '__main__':
    # div = DivLoader()
    # companies = pd.read_sql("""SELECT mv.companyname,
    #                                        mv.companyid,
    #                                        mv.tickersymbol,
    #                                        pt.periodtypename,
    #                                        fp.calendarquarter,
    #                                        fp.calendaryear,
    #                                        fd.dataitemid,
    #                                        di.dataitemname,
    #                                        fd.dataitemvalue,
    #                                        fp.fiscalyear,
    #                                        fp.fiscalquarter,
    #                                        fp.periodenddate,
    #                                        fp.filingdate,
    #                                        fp.financialperiodid,
    #                                        fp.latestperiodflag,
    #                                        mv.exchangesymbol,
    #                                        mv.gicsgroup,
    #                                        mv.gicsindustry,
    #                                        mv.gicssector,
    #                                        mv.tradingitemid
    #                                         FROM (((((v2mv_sbt_company mv
    #                                             JOIN ciqlatestinstancefinperiod fp ON ((fp.companyid = mv.companyid)))
    #                                             JOIN ciqperiodtype pt ON ((pt.periodtypeid = fp.periodtypeid)))
    #                                             JOIN ciqfinancialdata fd ON ((fd.financialperiodid =
    #                                             fp.financialperiodid)))
    #                                             JOIN ciqdataitem di ON ((di.dataitemid = fd.dataitemid))))
    #                                         WHERE ((fd.dataitemid = ANY (ARRAY [3058])) AND (pt.periodtypeid = 1) AND
    #                                                (fp.latestperiodflag = 1) AND ((mv.exchangesymbol)::text = ANY
    #                                                                               (ARRAY ['NYSE'::text, 'AMEX'::text,
    #                                                                               'ARCA'::text,
    #                                                                               'NasdaqGS'::text, 'NasdaqGM'::text,
    #                                                                               'NasdaqCM'::text,
    #                                                                               'NasdaqCS'::text])) AND
    #                                                (mv.is_primary_exchange = true));""", div._snp_engine)
    # correct_symbols = companies[companies['gicsgroup'].notnull()]
    # correct_symbols.loc[correct_symbols['exchangesymbol'].isin(['NasdaqGS', 'NasdaqGM']), 'exchangesymbol'] = 'NSDQ'
    # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'NasdaqCM', 'exchangesymbol'] = 'NSDQCM'
    # correct_symbols.loc[correct_symbols['exchangesymbol'] == 'ARCA', 'exchangesymbol'] = 'NYSEARCA'
    # correct_symbols['composite_pk_id'] = correct_symbols['tickersymbol'] + ':' + correct_symbols['exchangesymbol']
    # # correct_symbols = correct_symbols[correct_symbols['gicsindustry'].isin(['Energy Equipment and Services',
    # # 'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels'])]
    # correct_symbols = correct_symbols[correct_symbols['gicssector'] == 'Real Estate']
    # select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id in ('{}')".format("', '".join([str(x) for x in list(correct_symbols.composite_pk_id)]))
    # big_df = pd.read_sql(select, div._pg_df_engine)
    # div.run_rf_model(big_df)

    import time
    start = time.time()
    div = DivLoader()
    # div.count_div_paying_companies()
    div.to_pg()
    end = time.time()
    print(end - start)
    # acc = 0

    # div.energy_rankings()
    # div.load_banks()

    # sbtcommon = SbtCommon()
    # config = sbtcommon.get_sbt_config()
    # pg_snp = PostgresAccessor(config['postgres']['snpcompanyfinancials'])
    # select0 =  "SELECT guid FROM dev_snp_company WHERE industry_group IN ('Energy Equipment and Services', 'Gas Utilities', 'Independent Power and Renewable Electricity Producers', 'Oil, Gas and Consumable Fuels')"
    # guids = pd.read_sql(select0, pg_snp._engine)['guid'].astype(str).values.tolist()
    # composites = []
    # for guid in guids:
    #     response = div.query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", **{"index_name": "GUIDidx", "key": "guid", "operator": "eq", "value": guid})['Items']
    #     if response:
    #         composites.append(response[0]['composite_pk_id'])
    # select = "SELECT * FROM dev_dividend_model WHERE composite_pk_id IN ({});".format(str(composites)[1:-1])

    #

    # div.to_pg()
    # div.count_div_paying_companies()
    # acclst = []
    # for x in range(100):
    #     newacc = div.run_rf_model(big_df)
    #     print(newacc)
    #     acc = newacc
    #     acclst.append(newacc)
    # print(mean(acclst))
    # print(statistics.median(acclst))
    # print(max(acclst))
    # print(min(acclst))

    # div.load_trained_model()
    # div.tree_to_code()
    # div.n_estimators()
    # div.max_depth()
    # div.min_samples_split()
    # div.min_samples_leaf()
    # div.max_features()
    # print(div.predict_single('NVDA:NSDQ', '2019-09-01 00:00:00.000000'))
    # div.rankings()
