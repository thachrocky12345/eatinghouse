import logging
import os
import sys

import simplejson as json
import sqlalchemy
import pandas as pd
from functools import reduce
import datetime

from sqlalchemy import JSON, FLOAT, VARCHAR, text

# suppress warning SettingWithCopyWarning messages from pandas
pd.options.mode.chained_assignment = None

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']


class CompositeIndicator(object):

    def __init__(self):
        self._SUPPORTED_SECURITIES_TABLE_NAME = 'v2mv_sbt_company'
        self._RESULT_TABLENAME_PREFIX = 'test_new_loader_sbt_models'

        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # read the entire config file
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        ### PG
        # get the config for data factory DB
        self._pg_df = config['dev']['postgres']['datafactory']
        self._pg_df_engine = self._create_pg_engine(self._pg_df)

        self._pg_df_qa = config['qa']['postgres']['datafactory']
        self._pg_df_qa_engine = self._create_pg_engine(self._pg_df_qa)

        self._pg_df_prod = config['prod']['postgres']['datafactory']
        self._pg_df_prod_engine = self._create_pg_engine(self._pg_df_prod)

        # get the config for sbtcompanyfin DB
        self._pg_snpfin = config['dev']['postgres']['snpcompanyfinancials']
        self._pg_snpfin_engine = self._create_pg_engine(self._pg_snpfin)

        # get the config for XPF DB
        self._pg_snp = config['dev']['postgres']['snpsource']
        self._pg_snp_engine = self._create_pg_engine(self._pg_snp)

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_df_engine,
                             'QA': self._pg_df_qa_engine,
                             'PROD': self._pg_df_prod_engine}

        # dataframe to contain all the data necessary for an indicator
        self.composite_df = None
        self.result = None
        self.result_div = None

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def save_result(self):
        # create final df containing everything for each company
        res = self.result[
            ['composite_pk_id', 'model', 'rank', 'rating', 'score']
        ]
        # sort by score
        res = res.sort_values(by=['rank'], ascending=True).copy()

        res_div = self.result_div[
            ['composite_pk_id', 'model', 'rank', 'rating', 'score']
        ]
        # sort by score
        res_div = res_div.sort_values(by=['rank'], ascending=True).copy()
        self._logger.info(" DONE.")

        tic = datetime.datetime.now()
        # save to PG
        for env in ENVS_TO_UPDATE:
            res.to_sql(
                "sbt_indicator_composite",
                self.db_to_update.get(env.upper()),
                if_exists='replace',
                index_label='trading_item_id',
                dtype={
                    'model': JSON,
                    'score': FLOAT,
                    'rank': FLOAT,
                    'rating': VARCHAR,
                    'composite_pk_id': VARCHAR
                })

            res_div.to_sql(
                "sbt_indicator_div_composite",
                self.db_to_update.get(env.upper()),
                if_exists='replace',
                index_label='trading_item_id',
                dtype={
                    'model': JSON,
                    'score': FLOAT,
                    'rank': FLOAT,
                    'rating': VARCHAR,
                    'composite_pk_id': VARCHAR
                })
            tac = datetime.datetime.now()

            self._logger.info(" {}: DATA SAVED IN Dt={}.".format(
                env.upper(), tac - tic)
            )

            # create stats table
            self._create_stats_table(res, env.upper())

    def _create_stats_table(self, data=None, env='DEV'):

        if data is None:
            data = pd.read_sql_table(
                "sbt_indicator_composite",
                self.db_to_update.get(env)
            ).set_index('trading_item_id', drop=True, inplace=True)

        # rating stats table
        TABLE_NAME = "sbt_indicator_composite_rating_stats"
        # get the min/max for the model's rank (:= total number of points),
        # which is the most important result for CE
        df_stats = pd.DataFrame(
            [(x[1]['rating'],
              x[1]['rank']) for x in data.values],
            columns=['rating', 'rank']).groupby(by='rating') \
            .agg({"rank": [min, max, "count"]})
        # rename columns
        df_stats.columns = ['minRank', 'maxRank', 'total']
        # save rating stats
        df_stats.to_sql(TABLE_NAME,
                        self.db_to_update.get(env),
                        if_exists='replace',
                        index_label='rating')
        TABLE_NAME = "sbt_indicator_div_composite_rating_stats"
        df_stats.to_sql(TABLE_NAME,
                        self.db_to_update.get(env),
                        if_exists='replace',
                        index_label='rating')

        # rank stats table
        TABLE_NAME = "sbt_indicator_composite_score_stats"
        model_stat_df = data.agg({'rank': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minrank', 'maxrank', 'total']
        # stats per model (total within each rank bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['rank'], [-1000, 0, 20, 40, 60, 80, 100])
        )['rank'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        model_score_stat_df.to_sql(TABLE_NAME,
                                   self.db_to_update.get(env),
                                   if_exists='replace')
        TABLE_NAME = "sbt_indicator_div_composite_score_stats"
        model_score_stat_df.to_sql(TABLE_NAME,
                                   self.db_to_update.get(env),
                                   if_exists='replace')

    def _get_all_indicators_data(self):
        tables = {"capeff": "sbt_indicator_capeff",
                  "fin": "sbt_indicator_merton",
                  "val": "sbt_indicator_dcf",
                  "mom": "sbt_indicator_mmmomentum",
                  "div": "sbt_indicator_dividend"}
        # extra = {}

        # create main df
        self.data = {
            k: pd.read_sql_table(tables.get(k), self._pg_df_engine)
            for k, v in tables.items()
        }
        # self.data['div'].loc[self.data['div']['score'] < .5, 'rank'] = self.data['div'][self.data['div']['score'] < .5][
        #                                                                    'rank'] - 1

        # self.div_data = {
        #     k: pd.read_sql_table(extra.get(k), self._pg_df_engine)
        #     for k, v in extra.items()
        # }
        # create subset of main df
        composite_data = {
            k: v[["composite_pk_id", "rank"]]
            if k != "mom"
            else v[["composite_pk_id", "score"]] for k, v in self.data.items()
        }
        # normalize ranks (max = 100)
        # for id in ["fin", "val", "div"]:
        for id in ["fin", "val", "div"]:
            composite_data[id]["rank"] = composite_data[id]["rank"].apply(lambda x: x * 100)
        # rename rank/score columns (add suffix and rename score to rank for mom)
        [v.rename(columns={'rank': 'rank_{}'.format(k)}, inplace=True)
         if k != "mom"
         else v.rename(columns={'score': 'rank_{}'.format(k)}, inplace=True)
         for k, v in composite_data.items()]
        # create composite df
        self.composite_dividend_df = reduce(lambda x, y:
                                   pd.merge(x, y, on="composite_pk_id"),
                                   composite_data.values())
        div = composite_data.pop('div')
        self.composite_df = reduce(lambda x, y:
                                            pd.merge(x, y, on="composite_pk_id"),
                                            composite_data.values())

        # self.composite_df = pd.merge(self.composite_df, div, on='composite_pk_id', how='left')
        # self.composite_df.fillna(0, inplace=True)

        # take the mean along rows and add it to the df
        self.composite_df["average_rank"] = .3 * self.composite_df['rank_capeff'] + .475 * self.composite_df[
            'rank_fin'] + .2 * self.composite_df['rank_val'] + .025 * self.composite_df['rank_mom']

        self.composite_dividend_df["average_rank"] = .3 * self.composite_dividend_df['rank_fin'] + \
                                                     .1 * self.composite_dividend_df['rank_val'] + \
                                                     .6 * self.composite_dividend_df['rank_div']

        # Dividend at 40% subtract from other models
        # self.composite_df["average_rank_div"] = .3 * self.composite_df['rank_capeff'] + .475 * self.composite_df[
        #     'rank_fin'] + .2 * self.composite_df['rank_val'] + .025 * self.composite_df['rank_mom'] \
        #                                     + .05 * self.composite_df['rank_div']
        #
        # self.composite_df.sort_values('average_rank', inplace=True)
        # self.composite_df["average_rank"] = self.composite_df.mean(axis=1)

        self._logger.info("DONE.")

    def load_data(self):
        self._get_all_indicators_data()

    def rank(self):
        self.composite_df['percentile_rank'] = \
            100 * self.composite_df["average_rank"].rank(pct=True)
        self.composite_df['rank'] = \
            self.composite_df["percentile_rank"].rank(ascending=False)
        # sort by rank
        self.composite_df.sort_values(by="rank", ascending=True, inplace=True)

        self.composite_dividend_df['percentile_rank'] = \
            100 * self.composite_dividend_df["average_rank"].rank(pct=True)
        self.composite_dividend_df['rank'] = \
            self.composite_dividend_df["percentile_rank"].rank(ascending=False)
        # sort by rank
        self.composite_dividend_df.sort_values(by="rank", ascending=True, inplace=True)

        self._logger.info("DONE.")

    def transform_result(self):
        raw_data_descriptions = {
            'rank_capeff': 'Total points on Capital Efficiency indicator',
            'rank_val': 'Percentile rank on Valuation indicator',
            'rank_fin': 'Percentile rank on Financial indicator',
            'rank_div': 'Percentile rank on Dividend indicator',
            'rank_mom': 'Trending score on Momentum'
        }

        calculated_data_descriptions = {
            "average_rank": {"value": "Average rank", "units": "ratio"},
            "percentile_rank": {"value": "Percentile rank", "units": "percentage"},
            "rank": {"value": "Rank", "units": "integer"}
        }

        # add new cols: rank (based on score), rating, score (final_points)
        final_res = {
            v['composite_pk_id']: {
                'model': {
                    'composite_raw_data': {
                        k1: v1 for k1, v1 in v.items()
                        if k1 in ['rank_capeff',
                                  'rank_val',
                                  'rank_fin',
                                  'rank_mom']
                    },
                    'calculated_data': {
                        k1: {
                            'value': v1,
                            'calculation': v1,
                            'date_calculated': datetime.datetime.now().strftime(
                                "%Y-%m-%d"),
                            'rank': v1,
                            'description': calculated_data_descriptions[k1][
                                'value'],
                            'display_value_as':
                                calculated_data_descriptions[k1]['units']
                        } for k1, v1 in v.items()
                        if k1 in ['average_rank',
                                  'percentile_rank',
                                  'rank']
                    },
                    'date_calculated': datetime.datetime.now().strftime('%Y-%m-%d'),
                    'trading_item_id': "trading_item_id",
                    'score': v['average_rank'],
                    'value': v['average_rank'],
                    'rank': int(v['rank']),
                    'rating': 'N/A'
                },
                'score': v['average_rank'],
                'rank': v['rank'],
                'rating': 'N/A',
                'composite_pk_id': v['composite_pk_id']
            } for v in self.composite_df.T.to_dict().values()
        }
        # update model attribute with raw data descriptions
        {k: v['model']['composite_raw_data'].update(
            descriptions=raw_data_descriptions)
         for k, v in final_res.items()}

        # create final df to be saved
        self.result = pd.DataFrame.from_dict(final_res, orient="index")

        final_res_div = {
            v['composite_pk_id']: {
                'model': {
                    'composite_raw_data': {
                        k1: v1 for k1, v1 in v.items()
                        if k1 in ['rank_capeff',
                                  'rank_val',
                                  'rank_fin',
                                  'rank_div',
                                  'rank_mom']
                    },
                    'calculated_data': {
                        k1: {
                            'value': v1,
                            'calculation': v1,
                            'date_calculated': datetime.datetime.now().strftime(
                                "%Y-%m-%d"),
                            'rank': v1,
                            'description': calculated_data_descriptions[k1][
                                'value'],
                            'display_value_as':
                                calculated_data_descriptions[k1]['units']
                        } for k1, v1 in v.items()
                        if k1 in ['average_rank',
                                  'percentile_rank',
                                  'rank']
                    },
                    'date_calculated': datetime.datetime.now().strftime('%Y-%m-%d'),
                    'trading_item_id': "trading_item_id",
                    'score': v['average_rank'],
                    'value': v['average_rank'],
                    'rank': int(v['rank']),
                    'rating': 'N/A'
                },
                'score': v['average_rank'],
                'rank': v['rank'],
                'rating': 'N/A',
                'composite_pk_id': v['composite_pk_id']
            } for v in self.composite_dividend_df.T.to_dict().values()
        }
        # update model attribute with raw data descriptions
        {k: v['model']['composite_raw_data'].update(
            descriptions=raw_data_descriptions)
            for k, v in final_res_div.items()}

        # create final df to be saved
        self.result_div = pd.DataFrame.from_dict(final_res_div, orient="index")

        self._logger.info("DONE.")

    def run(self):
        self._logger.info(
            " COMPOSITE INDICATOR STARTED AT {}".format(
                datetime.datetime.now()
            )
        )
        tic = datetime.datetime.now()
        self.load_data()
        tac = datetime.datetime.now()
        self._logger.info(
            " DATA LOAD DONE IN {}.".format(tac - tic)
        )

        self.rank()
        # self.composite_df[self.composite_df['composite_pk_id'] == 'NVDA:NSDQ']

        # format results
        self.transform_result()

        # for row in pd.merge(self.result, self.result_div, on="composite_pk_id").sort_values('rank_y').iterrows():
        #     print(row[1]['composite_pk_id'], pd.read_sql("SELECT dividend_yield_percentage FROM mv_snapshot WHERE
        #     tickersymbol = '{}' AND is_primary_exchange AND exchange_country = 'USA'".format(row[1][
        #     'composite_pk_id'].split(':')[0]), self._pg_snp_engine).values.tolist()[0][0])
        # save results
        self.save_result()

        self._logger.critical(' COMPOSITE INDICATOR FINISHED.')


if __name__ == "__main__":
    composite = CompositeIndicator()
    composite.run()
