import datetime
import logging
import os
import sys

import certifi
import sqlalchemy
import pandas as pd
import numpy as np
import simplejson as json
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from pymongo import MongoClient
from environs import Env

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']

# read global vars from .env file
GLOBAL_VAR = Env()
GLOBAL_VAR.read_env()

# set variable to run loader either locally or not
try:
    run_locally = True if GLOBAL_VAR.bool("ES_RUN_LOCAL") else False
except:
    run_locally = False
if run_locally:
    # use this client when running this locally
    ES_CLIENT = {
        'dev': Elasticsearch([GLOBAL_VAR("ES_HOST_DEV_LOCAL")],
                             ca_certs=False, verify_certs=False,
                             ssl_show_warn=False),
        'qa': Elasticsearch([GLOBAL_VAR("ES_HOST_QA_LOCAL")],
                            ca_certs=False, verify_certs=False,
                            ssl_show_warn=False),
        'prod': Elasticsearch([GLOBAL_VAR("ES_HOST_PROD_LOCAL")],
                              ca_certs=False, verify_certs=False,
                              ssl_show_warn=False)
    }
else:
    # use this client when running this in DataPipeline
    ES_CLIENT = {
        'dev': Elasticsearch(
            [GLOBAL_VAR("ES_HOST_DEV")],
            use_ssl=True,
            ca_certs=certifi.where()),
        'qa': Elasticsearch(
            [GLOBAL_VAR("ES_HOST_QA")],
            use_ssl=True,
            ca_certs=certifi.where()),
        'prod': Elasticsearch(
            [GLOBAL_VAR("ES_HOST_PROD")],
            use_ssl=True,
            ca_certs=certifi.where())
    }

# use timestamp as index unique name
current = str(round(datetime.datetime.now().timestamp()))
INDEX_NAME = 'test_new_suggestions_schema'
TYPE_NAME = 'suggestions'

STREAMING_SUPPORTED_EXCHANGE_LIST = [
    'AMEX', 'BATS', 'ETF', 'NYSE',
    'NSDQ', 'NSDQCM', 'NYSEARCA', 'OTC'
]


class ElasticsearchDataLoader(object):

    def __init__(self):
        # table to read the ticker symbols from
        self._SUPPORTED_SECURITIES_TABLE_NAME = 'v2mv_sbt_company'

        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # read the entire config file
        # with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
        #     config = json.load(config)
        # read the category dict
        with open(os.path.join(sys.path[0], 'category_map.json')) as category:
            self.CATEGORY = json.load(category)
        # read mappings & settings for the suggestions index
        with open(os.path.join(sys.path[0], 'suggestions.json')) as mapping:
            self.MAPPINGS = json.load(mapping)

        # PG
        self._pg_snp_engine = self._create_pg_engine()
        # MONGO (PER ENV)
        self._mongo_client = {
            env.lower(): self._create_mongo_client(env) for env in ['dev', 'qa', 'prod']
        }

        # if a PG table exists when loading data, tell pandas to take this action
        self.action_to_take_if_table_exists = 'replace'

        # list of docs to be indexed into ES
        self.docs_list = []

        # exchangesymbol mapping
        self.EXCHANGE_MAPPING = {
            'Nasdaq': 'NSDQ',
            'NASDAQ': 'NSDQ',
            'NasdaqGS': 'NSDQ',
            'NasdaqGM': 'NSDQ',
            'NasdaqCM': 'NSDQ',
            'ARCA': 'NYSEARCA',
        }

        self.SB_EXCHANGE_MAPPING = {
            'TSX': 'TO',
            'LSE': 'L',
            'AIM': 'L',
            'SEHK': 'HK',
            'TSXV': 'V',
            'PAR': 'PA',
            'STO': 'ST',
            'BSE': 'BR',
            'JPX': 'T',
            'CSE': 'CO',
            'FWB': 'DE',
            'SIX': 'SW',
            'MCX': 'ME',
            'MCE': 'MC',
            'ATH': 'AT',
            'MIL': 'MI',
        }

        # list of items to be available in the suggestion
        # (key is the name of the item from S&P and value will be the label in ES)
        self.AVAILABLE_ITEMS = {
            'tickersymbol': 'symbol',
            'exchangesymbol': 'exchange_id',
            'exchangename': 'exchange_name',
            'exchangecurrency': 'exchange_currency',
            'exchangecountry': 'exchange_country',
            'is_primary_exchange': 'is_primary_exchange',
            'identifiervalue': 'global_id',
            'companyid': 'company_id',
            'tradingitemid': 'trading_item_id',
            'companyname': 'entity_name',
            'gicssector': 'gics_sector',
            'gicsgroup': 'gics_group',
            'gicsindustry': 'gics_industry',
            'gicssubindustry': 'gics_subindustry',
            'securityfeaturename': 'security_feature_name'
        }

    @staticmethod
    def _create_pg_engine():
        host = GLOBAL_VAR('SNP_DB_HOST')
        credentials = GLOBAL_VAR('SNP_DB_CREDENTIALS')
        user = GLOBAL_VAR('SNP_DB_USER')
        dbname = GLOBAL_VAR('SNP_DB_DATABASE')
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    @staticmethod
    def _create_mongo_client(env):
        return MongoClient(
            "mongodb+srv://{username}:{password}@{host}".format(
                host=GLOBAL_VAR("MONGO_HOST"),
                username=GLOBAL_VAR("MONGO_USER"),
                password=GLOBAL_VAR("MONGO_CREDENTIALS")
            )
        )

    def get_exchange_mapping(self, exchange_symbol, sb_map=False):
        if exchange_symbol is not None:
            if exchange_symbol.startswith('OTC'):
                exchange_mapping = 'OTC'
            else:
                exchange_mapping = \
                    self.EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol) \
                        if not sb_map else \
                    self.SB_EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol)
        else:
            self._logger.error(" EXCHANGE IS NONE.")
            exchange_mapping = exchange_symbol

        return exchange_mapping

    def _get_supported_securities(self):
        self.supported_securities_df = pd.read_sql(
            "select {} from {};".format(
                ', '.join(list(self.AVAILABLE_ITEMS.keys())),
                self._SUPPORTED_SECURITIES_TABLE_NAME),
            self._pg_snp_engine
        )

    def get_data_from_pg(self):
        self._logger.critical(' EXTRACTING DATA -- GETTING DATA FROM PG...')
        self._get_supported_securities()
        self._logger.critical("DONE")

    def transform_docs(self):
        # TODO: check for ETF
        self._logger.critical(
            ' TRANSFORMING DATA -- CREATING SCHEMA FOR ES...')
        # create the schema to be indexed into ES
        supported_securities_subset_df = \
            self.supported_securities_df.loc[:,
            list(self.AVAILABLE_ITEMS.keys())].copy()
        # rename columns to be used in ES
        supported_securities_subset_df.rename(columns=self.AVAILABLE_ITEMS,
                                       inplace=True)

        ### ADDITIONAL FIELDS ###
        # follow Nasdaq symbology
        # https://www.nasdaqtrader.com/content/technicalsupport/specifications/dataproducts/nasdaqfifthcharactersuffixlist.pdf
        supported_securities_subset_df['symbol_alias'] = \
            supported_securities_subset_df['symbol'].apply(
                lambda x: x.replace('.', '') if x.count('.') and len(x.split('.')[0]) >= 4 else None
            )

        # exchange mapping
        supported_securities_subset_df['exchange'] = \
            supported_securities_subset_df['exchange_id'].apply(
                lambda x: self.get_exchange_mapping(x)
            )

        # aliases for exchange
        supported_securities_subset_df['exchange_alias'] = \
            supported_securities_subset_df['exchange_id'].apply(
                lambda x: self.get_exchange_mapping(x, sb_map=True)
            )

        # create GUID (composite_pk_id)
        supported_securities_subset_df['composite_pk_id'] = \
            supported_securities_subset_df[['symbol', 'exchange']].apply(
                lambda x: ':'.join(x), axis=1
            )
        # create source
        supported_securities_subset_df['source'] = \
            supported_securities_subset_df['symbol'].apply(lambda x: 'S&P')
        # create is_etf (TODO: should come from Intrinio)
        supported_securities_subset_df['is_etf'] = \
            supported_securities_subset_df['security_feature_name'].apply(
                lambda x: True if x is not None and x.count('ETF') else False
            )
        # create is_reits
        supported_securities_subset_df['is_reits'] = \
            supported_securities_subset_df['security_feature_name'].apply(
                lambda x: True if x is not None and x.count('REIT') else False
            )
        # create is_mutual_fund
        supported_securities_subset_df['is_mutual_fund'] = \
            supported_securities_subset_df['security_feature_name'].apply(
                lambda x: True if x == 'Mutual Fund' else False
            )
        # create support_streaming
        supported_securities_subset_df['support_streaming'] = \
            supported_securities_subset_df['exchange'].apply(
                lambda x: True if x in STREAMING_SUPPORTED_EXCHANGE_LIST else False
            )
        # create timestamp for updates
        supported_securities_subset_df['updated_at'] = \
            supported_securities_subset_df['symbol'].apply(
                lambda
                    x: datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
        ###

        # replace 'nan' by None
        supported_securities_subset_df.replace({np.nan: None}, inplace=True)

        # parse each item into the schema for ES
        self.docs_list = \
            supported_securities_subset_df.to_dict(orient='records')
        self._logger.critical("DONE.")

    def index_docs(self, env=None, delete_index=True):
        if env is not None:
            self._logger.critical(' INDEXING DOCS INTO ES {}...'.format(env))
            # this works for options (indexing per env)
            list_of_envs_to_update = [env.lower()]
        else:
            self._logger.critical(' INDEXING DOCS INTO ALL ES ENVS...')
            list_of_envs_to_update = ENVS_TO_UPDATE
        # create the actions for the bulk indexing
        actions = [
            {
                "_index": INDEX_NAME,
                "_type": TYPE_NAME,
                "_source": doc
            }
            for doc in self.docs_list
        ]
        if delete_index:
            # delete index before creating new one
            [client.indices.delete(index=INDEX_NAME, ignore=[400, 404])
             for env, client in ES_CLIENT.items() if env in list_of_envs_to_update]
            # create index
            [client.indices.create(index=INDEX_NAME, body=self.MAPPINGS)
             for env, client in ES_CLIENT.items() if env in list_of_envs_to_update]
        # bulk index docs
        [bulk(client, actions) for env, client in ES_CLIENT.items() if env in list_of_envs_to_update]
        self._logger.critical("DONE.")

    def get_static_dataset_from_mongo(self):
        self._logger.critical(" GETTING STATIC SYMBOLS FROM MONGODB...")
        # get the db
        env = "dev"
        db = self._mongo_client.get(env)[GLOBAL_VAR("MONGO_DATABASE_{}".format(env.upper()))]
        # get the collections
        static_dataset_collection = db.static_sbt_symbol_exchange_mapping
        # parse Collection into list of dict
        static_dataset_collection_list = \
            [x for x in static_dataset_collection.find()]
        # remove _id attribute
        for i, x in enumerate(static_dataset_collection_list):
            static_dataset_collection_list[i].pop('_id')
        # add updated_at field
        [x.update(
            updated_at=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ) for x in static_dataset_collection_list]

        df = pd.DataFrame(static_dataset_collection_list)

        # remove unnecessary columns
        df.drop(
            columns=['category', 'exchange_country',
                     'exchange_currency',
                     'primary', 'quandl_code',
                     'table_mapping'],
            axis=1,
            inplace=True
        )
        # replace NaNs with empty string
        df.replace({np.nan: None}, inplace=True)

        # update docs_list to use the same indexing method
        self.docs_list = list(df.to_dict(orient='records'))
        # call index method
        self.index_docs(delete_index=False)

        self._logger.critical(" DONE.")

    def get_options_symbols_from_mongo(self):
        for env in ENVS_TO_UPDATE:
            self._logger.critical(" GETTING OPTIONS FROM MONGODB {}...".format(env.upper()))
            # making sure env is lowercase
            env = env.lower()
            # get the db
            db = self._mongo_client.get(env)[GLOBAL_VAR("MONGO_DATABASE_{}".format(env.upper()))]
            # get the collections
            symbol_options_collection = db.symbol_expiration_details
            # parse Collection into list of dict
            symbol_options_collection_list = \
                [x for x in symbol_options_collection.find().sort("$natural")]
            # remove _id attribute
            for i, x in enumerate(symbol_options_collection_list):
                symbol_options_collection_list[i].pop('_id')
            # add updated_at field
            [x.update(
                updated_at=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ) for x in symbol_options_collection_list]

            # flatten list
            temp = []
            for x in symbol_options_collection_list:
                for y in x['data']:
                    y.update(id2=x['id'], updated_at=x['updated_at'])
                    temp.append(y)

            # create df
            df = pd.DataFrame(temp)

            # rename columns
            df.rename(columns={
                'id': 'entity_name',
                'id2': 'id',
                'strikePrice': 'strike_price'
            }, inplace=True)

            # create is_option = True column
            df['is_option'] = True
            df['source'] = 'IEX'
            df['symbol_alias'] = df['id']

            # replace NaNs with empty string
            df.replace({np.nan: None}, inplace=True)

            # create date from string
            df['expiration_date'] = df['expirationDate'].apply(
                lambda x: datetime.datetime.strptime(x, '%Y%m%d').strftime('%Y-%m-%d'))
            # create timestamp from string
            df['expiration_timestamp'] = df['expirationDate'].apply(
                lambda x: int(datetime.datetime.strptime(x, '%Y%m%d').timestamp()))

            # columns to be indexed (ES schema)
            final_df = df[
                ['symbol', 'symbol_alias', 'entity_name', 'source',
                 'expiration_date', 'expiration_timestamp',
                 'side', 'strike_price', 'is_option', 'updated_at']
            ]

            # update docs_list to use the same indexing method
            self.docs_list = list(final_df.to_dict(orient='records'))
            # call index method
            self.index_docs(env=env, delete_index=False)

            self._logger.critical(" DONE.")

    def load_docs_into_es(self):
        try:

            self.get_data_from_pg()
            self.transform_docs()
            self.index_docs()
            # process additional dataset
            self.get_static_dataset_from_mongo()
            # process options
            # self.get_options_symbols_from_mongo()

            self._logger.critical("Done.")

        except Exception as e:

            self._logger.error(" AN ERROR OCCURRED IN ES DATALOADER: {}".format(e))


if __name__ == "__main__":
    esdl = ElasticsearchDataLoader()
    esdl.load_docs_into_es()
