#!/usr/bin/env bash

aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_bonds/cbonds_dataload.py /home/ec2-user/cbonds_dataload.py
aws s3 cp s3://sbt-datapipeline-assets/loaders/sbt_bonds/.env /home/ec2-user/.env

echo "Running SBT Bonds loader..."
python /home/ec2-user/cbonds_dataload.py