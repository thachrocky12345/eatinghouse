import requests
import json
from sbt_common import SbtGlobalCommon

class UrlAccessor :
  """
      The UrlQuery class is the super class for all URL query objects.
  """
  _max_tries  = 4
  _sleep_time = 15

  def __init__(self, protocol, domain_name, port=80, user_name = None, 
               credentials = None, useport = False) :
    """
       Constructor method used to initialize the class
    """
    self._sbtcommon = SbtGlobalCommon
    self._logger = self._sbtcommon.get_global_logger()
    self._useport = useport
    self._protocol = protocol
    self._domain_name = domain_name
    self._port = port
    self._user_name = user_name
    self._credentials = credentials

  def _get_formatted_domain (self):
    """
      Returns the formatted URL domain
      
      Returns:
          str: Formatted domain URL with port     
    """
    if self._useport == False:
      #TODO: This class needs to provide generic access to urls without ports
      pass
    elif self._port == 80 or self._port == 443 :
      return self._protocol + '://' + self._domain_name
    else :
      return self._protocol + '://' + self._domain_name + ":" + str(self._port)

  def _query_url (self, url, method='GET'):
    """
      Query a specified URL and allows for retries and sleep time.
   
      Args:
          url(str)  : URL to be called 
      
      Returns:
          dict: Response for API call     
    """
    counter = 1
    data = {}
    process = True
    response = None

    while process :
      try :
        self._logger.debug(url)
        basic_auth = self._get_basic_auth()

        if method.upper() == 'GET' :
          response = requests.get(url, auth=basic_auth)
        elif method.upper() == 'POST' :
          response = requests.post(url, auth=basic_auth)
            
        data = json.loads(response.text)
        process = False

      except Exception as exc:
        self._logger.info(exc)
        if response is not None and \
        self._sbtcommon.stringutil.is_not_empty(response.text) :
          self._logger.info("Response Error : " + str(response.text))        
        if counter == self._max_tries :
          raise exc
        else :
          self._logger.info("API Call " + url + " failed. On try " + 
                           str(counter) + " of " + str(self._max_tries))
          self._logger.info("Start sleeping for  " + str(self._sleep_time) + 
                           " seconds.")
          self._sbtcommon.sleep(self._sleep_time)
          self._logger.info("Finished sleeping for  " + str(self._sleep_time) + 
                           " seconds trying again.")
          counter += 1

    return data
  
  def _get_basic_auth (self):
    basic_auth = None
    if self._sbtcommon.stringutil.is_not_empty(self._user_name) and \
    self._sbtcommon.stringutil.is_not_empty(self._credentials) :
      basic_auth = requests.auth.HTTPBasicAuth(
            self._user_name,
            self._credentials) 
      
    return basic_auth   