from dd_accessor import DynamoAccessor
from threading import Lock

class DataAdminAccessor(DynamoAccessor):
  _table_data_category = 'SBT_DATA_CATEGORY'
  _data_categories = []
  _data_categories_loadtimestamp = None   
  
  def query_category_list (self, timeseries_only=False):
    categories = self.query_data_categories()

    category_list = set()

    for cat in categories :
      if not timeseries_only or cat['classification'] == 'timeseries':
        category_list.add(cat['category']) 
    
    return sorted(category_list)
  
  def query_data_categories (self):
    """
      Returns the list of all data categories.   
    
      Returns :
        list : Data Categories
    """     
    process = False
    
    if self._data_categories_loadtimestamp is None :
      process = True
    else :  
      now = self._sbtcommon.dateutil.get_current_timestamp()
      diff = now - self._data_categories_loadtimestamp
      if diff.total_seconds() > 3600 :
        process = True
    
    if process :
      with Lock() :
        self.__class__._data_categories = self._scan_table(
                                          self._table_data_category,
                                          None)
        self.__class__._data_categories_loadtimestamp = \
        self._sbtcommon.dateutil.get_current_timestamp()
        
        self._logger.info('Reload data categories from DynamoDB')
    
    return self._data_categories    

if __name__ == '__main__':  
  da = DataAdminAccessor()
  print(da.query_category_list(timeseries_only=False))