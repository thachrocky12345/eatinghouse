import importlib
import time
import datetime
from article_utils import ArticleHelper
from intrinio_api import IntrinioApi
from portfolio_api import PortfolioApi
from collections import OrderedDict
from enum import Enum
from sbt_common import SbtCommon
from threading import Lock
from dd_accessor import DynamoAccessor
import xml.etree.ElementTree


class SymbolMappingTemplateType(Enum):
    """
    Enumeration of symbol mapping templates used to assign
    the correct table mappings.
  """
    INDUSTRIAL = 'Industrial'
    FINANCE = 'Finance'
    STANDARD = 'Standard'
    BANKS = 'Banks'
    INSURANCE = 'Insurance'
    UTILITY = 'Utility'
    REAL_ESTATE = 'Real Estate'
    FINANCIAL_SERVICES = 'Financial Services'
    CAPITAL_MARKETS = 'Capital Markets'
    CBONDS_USA = 'CBONDS-USA'


class TableMappingGuid(Enum):
    """
    Enumeration of supported vendors
  """
    US_COMPANY_STOCK_PRICE = '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
    US_COMPANY = 'f328ff7c-9f48-49b6-9ebf-5edb12852eb5'
    US_INDEX_STOCK_PRICE = '1f2fe84b-c3a8-4f36-a06d-598170264a6a'
    COMPANY = 'f133bde4-4d9e-489e-8d65-bf826cc9a333'
    US_FUNDAMENTALS_TIMESERIES_ANNUALLY = '935ddb42-898e-4a56-8833-ed1dca9b41a1'
    US_FUNDAMENTALS_TIMESERIES_QUARTERLY = 'ba0dd814-2d8d-4d07-b616-467f721dc01c'
    US_BOND_TRADING = '6d93b9ad-6f09-4485-ab18-f1ef72b76547'
    CRYPTOCURRENCY = '24d567e0-130a-4144-88e3-230f70e734af'


class Vendors(Enum):
    """
    Enumeration of supported vendors
  """
    INTRINIO = 'intrinio'
    QUANDL = 'quandl'
    STANDARD_AND_POORS = 'snp'
    FRED = 'fred'
    SBT_PORTOLIO = 'sbt_portfolio'


class TableMappingDataType(Enum):
    """
    TableDataType is an enumeration used to help centralize
    the various table data type into one class/enum.
  """
    ARTICLE = 'article'
    COMPANY = 'company'
    FINANCIAL = 'financial'
    OWNERSHIP = 'ownership'
    TIMESERIES = 'timeseries'


class TableAttributeMapping():
    """
    TableAttributeMapping object used to encapsulate the logic around the
    table attribute mappings.
  """

    def __init__(self, conf=None):
        """
      Constructor
    """
        self._sbtcommon = SbtCommon()
        self._logger = self._sbtcommon.get_global_logger()
        self._conf = conf

    def get_guid(self):
        """
      Returns GUID

      Returns :
        str : GUID
    """
        return self._get_value_from_configuration('guid')

    def get_id(self):
        """
      Returns ID

      Returns :
        str : ID
    """
        return self._get_value_from_configuration('id')

    def get_data_type(self):
        """
      Returns Data Type

      Returns :
        str : Data Type
    """
        return self._get_value_from_configuration('data_type')

    def get_description(self):
        """
      Returns description

      Returns :
        str : Description
    """
        return self._get_value_from_configuration('description')

    def get_computed_field(self):
        """
      Returns computed field

      Returns :
        str : computed field
    """
        return self._get_value_from_configuration('computed_field')

    def get_type(self):
        """
      Returns type

      Returns :
        str : Type
    """
        return self._get_value_from_configuration('type')

    def is_default(self):
        """
      Returns true if the id is a default display value

      Returns :
        str : True if the value is a default
    """
        return self._get_value_from_configuration('default')

    def get_vendor_attribute_id(self, vendor):
        """
      Returns vendor attribute id

      Args :
        vendor : vendor ID

      Returns :
        str : Vendor attribute id
    """
        v_id = None

        vendor_mapping = self._get_value_from_configuration('vendor_mapping')

        if self._sbtcommon.collectionsutil.is_not_empty(vendor_mapping) and \
                vendor in vendor_mapping.keys():
            v_id = vendor_mapping[vendor]['id']

        return v_id

    def get_vendor_attribute_formula(self, vendor):
        """
      Returns vendor attribute formula

      Args :
        vendor : vendor formula

      Returns :
        List : Vendor attribute formula
    """
        v_form = None

        vendor_mapping = self._get_value_from_configuration('vendor_mapping')

        if self._sbtcommon.collectionsutil.is_not_empty(vendor_mapping) and \
                vendor in vendor_mapping.keys():
            v_form = vendor_mapping[vendor]['formula']

        return v_form

    def get_vendor_attribute_ids(self, vendor):
        """
      Returns vendor attribute ids

      Args :
        vendor : vendor IDS

      Returns :
        List : Vendor attribute id
    """
        v_ids = None

        vendor_mapping = self._get_value_from_configuration('vendor_mapping')

        if self._sbtcommon.collectionsutil.is_not_empty(vendor_mapping) and \
                vendor in vendor_mapping.keys():
            v_ids = vendor_mapping[vendor]['ids']

        return v_ids

    def get_vendor_data_type(self, vendor):
        """
      Returns vendor data type

      Args :
        vendor : vendor ID

      Returns :
        str : Vendor Data Type
    """
        v_data_type = None

        vendor_mapping = self._get_value_from_configuration('vendor_mapping')

        if self._sbtcommon.collectionsutil.is_not_empty(vendor_mapping) and \
                vendor in vendor_mapping.keys():
            v_data_type = vendor_mapping[vendor]['data_type']

        return v_data_type

    def get_configuration(self):
        """
      Returns configuration used to create object

      Returns :
        dict : Dictionary representing original JSON Configuration
    """
        return self._conf

    def _set_value_in_configuration(self, attribute, value):
        """
      Sets the specified value from the configuration.

      Args :
        attribute(str) : Requested attribute
        value(str) : Value

    """
        if self._conf is None:
            self._conf = self.default_table_mapping_conf

        self._conf[attribute] = value

    def _get_value_from_configuration(self, attribute):
        """
      Retrieves a specified value from the json configuration.

      Args :
        attribute(str) : Requested attribute

      Returns
        any : Value of requested attribute
    """
        ret_value = None

        if self._conf is not None and attribute in self._conf.keys():
            ret_value = self._conf[attribute]

        return ret_value


class TableMapping():
    """
    TableMapping object used to encapsulate the logic around the
    table mappings.
  """

    default_table_mapping_conf = {
        "active": True,
        "code": "N/A",
        "data_type": None,
        "default_vendor": 'N/A',
        "long_description": 'N/A',
        "name": "N/A",
        "short_description": "N/A",
        "table_name": "N/A",
        "type": [],
        "load_data": False,
        "vendor_mapping": {}
    }

    def __init__(self, conf=None, attribute_confs=None, data_types=None):
        """
      Constructor
    """
        self._sbtcommon = SbtCommon()
        self._logger = self._sbtcommon.get_global_logger()
        self._conf = conf
        self._data_type_description = None
        self._data_type_name = None
        self._attributes = []
        data_type = self.get_data_type()
        if self._sbtcommon.collectionsutil.is_not_empty(attribute_confs):
            for attr in attribute_confs:
                self._attributes.append(TableAttributeMapping(attr))

        if self._sbtcommon.collectionsutil.is_not_empty(data_types) and \
                self._sbtcommon.stringutil.is_not_empty(data_type) and \
                data_type in data_types.keys():
            self._data_type_description = data_types[data_type]['description']
            self._data_type_name = data_types[data_type]['name']

    def get_guid(self):
        """
      Returns GUID

      Returns :
        str : GUID
    """
        return self._get_value_from_configuration('guid')

    def set_guid(self, guid):
        """
      Sets GUID

      Args :
        guid(str) : GUID

    """
        self._set_value_in_configuration('guid', guid)

    def get_code(self):
        """
      Returns Code

      Returns :
        str : Code
    """
        return self._get_value_from_configuration('code')

    def set_code(self, code):
        """
      Sets Code

      Args :
        code(str) : Code

    """
        self._set_value_in_configuration('code', code)

    def get_format_name(self):
        """
      Returns Format Name

      Returns :
        str : Format Name
    """
        fc = self._get_value_from_configuration('format_name')

        if self._sbtcommon.stringutil.is_empty(fc):
            fc = 'single_value'

        return fc

    def set_format_name(self, code):
        """
      Sets Format Name

      Args :
        code(str) : Format Name

    """
        self._set_value_in_configuration('format_name', code)

    def get_default_vendor(self):
        """
      Returns default vendor

      Returns :
        str : default vendor
    """
        return self._get_value_from_configuration('default_vendor')

    def set_default_vendor(self, default_vendor):
        """
      Sets default vendor

      Args :
        default_vendor(str) : default vendor

    """
        self._set_value_in_configuration('default_vendor', default_vendor)

    def get_long_description(self):
        """
      Returns long description

      Returns :
        str : long description
    """
        return self._get_value_from_configuration('long_description')

    def set_long_description(self, long_description):
        """
      Sets long description

      Args :
        long_description(str) : long description

    """
        self._set_value_in_configuration('long_description', long_description)

    def get_short_description(self):
        """
      Returns short description

      Returns :
        str : short description
    """
        return self._get_value_from_configuration('short_description')

    def set_short_description(self, short_description):
        """
      Sets Short description

      Args :
        short_description(str) : Short description

    """
        self._set_value_in_configuration('short_description',
                                         short_description)

    def get_name(self):
        """
      Returns table name

      Returns :
        str : table name
    """
        return self._get_value_from_configuration('name')

    def set_name(self, name):
        """
      Sets name

      Args :
        name(str) : Name

    """

        self._set_value_in_configuration('name', name)

        # TODO : Remove this code after talking to Yonathan
        if name[:1] == "_":
            self._set_value_in_configuration('table_name', name[1:])
        else:
            self._set_value_in_configuration('table_name', name)

    def get_data_type_name(self):
        """
      Returns data type name

      Returns :
        str : data type name
    """
        return self._data_type_name

    def get_data_type_description(self):
        """
      Returns data type description

      Returns :
        str : data type description
    """
        return self._data_type_description

    def get_data_type(self):
        """
      Returns data type

      Returns :
        str : data type
    """
        return self._get_value_from_configuration('data_type')

    def set_data_type(self, data_type):
        """
      Sets data type

      Args :
        data_type(str) : data type

    """
        self._set_value_in_configuration('data_type', data_type)

        # TODO : Remove this code after talking to Yonathan
        self.config['type'] = [data_type]

    def get_modifications(self):
        """
      Returns modifications that were logged.

      Returns :
        list : modifications that were logged.
    """
        modifications = self._get_value_from_configuration('modifications')

        if modifications is None:
            modifications = []

        return modifications

    def set_modification(self, user_name=None, description=None, dt=None):
        """
      Sets modification

      Args :
        user_name(str) : User (will default to N/A)
        description(str) : Description of change (will default to N/A)
        dt(str) : Date and time of the modification (will default to now)

    """
        modifications = self._get_value_from_configuration('modifications')

        if modifications is None:
            self._set_value_in_configuration('modifications', [])

        if self._sbtcommon.stringutil.is_empty(user_name):
            user_name = 'N/A'

        if self._sbtcommon.stringutil.is_empty(description):
            description = 'N/A'

        if self._sbtcommon.stringutil.is_empty(dt):
            dt = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())

        new_mod = {}
        new_mod['name'] = user_name
        new_mod['datetime'] = dt
        new_mod['description'] = description

        if self._conf is not None:
            self._conf['modifications'].append(new_mod)

    def get_vendor_mappings(self):
        """
      Returns vendor mappings

      Returns :
        dict : vendor mappings
    """
        vendors = self._get_value_from_configuration('vendor_mapping')

        if vendors is None:
            vendors = {}

        return vendors

    def set_vendor_mappings(self, mappings=None):
        """
      Sets vendor mappings

      Args :
        user_name(str) : User (will default to N/A)
        description(str) : Description of change (will default to N/A)
        dt(str) : Date and time of the modification (will default to now)

    """

        vendors = self._get_value_from_configuration('vendor_mappings')

        if vendors is None and mappings is None:
            self._set_value_in_configuration('vendor_mappings', {})
        else:
            self._set_value_in_configuration('vendor_mappings', mappings)

    def get_default_vendor_mapping(self):
        """
      Returns default vendor mapping

      Returns :
        dict : default vendor mapping
    """
        vendor_mappngs = self.get_vendor_mappings()
        d_vendor = self.get_default_vendor()
        if self._sbtcommon.stringutil.is_not_empty(d_vendor) and \
                d_vendor in vendor_mappngs.keys():
            return vendor_mappngs[self.get_default_vendor()]

    def get_value_attributes_metadata(self):
        confs = []

        for attr in self.get_value_attributes():
            conf = attr.get_configuration().copy()
            if 'computed_field' in conf:
                conf.pop('computed_field')
            conf.pop('type')
            conf.pop('guid')
            conf.pop('data_type')
            conf.pop('vendor_mapping')
            if TableMappingGuid.US_COMPANY_STOCK_PRICE.value == self.get_guid() and \
                    (conf['id'] == 'ex_dividend' or conf[
                        'id'] == 'split_ratio'):
                self._logger.debug('Exclude ' + conf['id'])
            else:
                confs.append(conf)

        return confs

    def get_attributes(self):
        """
      Returns table attributes

      Returns :
        TableAttributeMapping : Table Attributes
    """
        return self._attributes

    def get_key_attribute(self):
        """
      Returns the primary key attribute

      Returns :
        TableAttributeMapping : Primary Key
    """
        attribute = None

        if self._sbtcommon.collectionsutil.is_not_empty(self.get_attributes()):
            for attr in self.get_attributes():
                if attr.get_type() == 'key':
                    attribute = attr
                    break

        return attribute

    def get_range_attribute(self):
        """
      Returns the range attribute

      Returns :
        TableAttributeMapping : Range Attribute
    """
        attribute = None

        if self._sbtcommon.collectionsutil.is_not_empty(self.get_attributes()):
            for attr in self.get_attributes():
                if attr.get_type() == 'range':
                    attribute = attr
                    break

        return attribute

    def get_calculated_attributes(self):
        """
      Returns any attribute of type calculate

      Returns :
        TableAttributeMapping : Calculate Attribute
    """
        attributes = []

        if self._sbtcommon.collectionsutil.is_not_empty(self.get_attributes()):
            for attr in self.get_attributes():
                if attr.get_type() == 'calculate':
                    attributes.append(attr)

        return attributes

    def get_value_attributes(self):
        """
      Returns any attribute of type value

      Returns :
        TableAttributeMapping : Value Attribute
    """
        attributes = []

        if self._sbtcommon.collectionsutil.is_not_empty(self.get_attributes()):
            for attr in self.get_attributes():
                if attr.get_type() == 'value':
                    attributes.append(attr)

        return attributes

    def get_table_names(self):
        """
      Returns vendor name

      Returns :
        str : vendor name
    """
        table_names = []
        name = self.get_name()

        if self._sbtcommon.stringutil.is_not_empty(name):
            if name[:1] == '_':
                for vendor in self.get_vendor_mappings().keys():
                    table_names.append(vendor.upper() + name)
            else:
                table_names.append(name)

        return table_names

    def get_table_name(self, vendor=None):
        """
      Returns vendor name

      Returns :
        str : vendor name
    """
        table_name = None
        name = self.get_name()
        selected_vendor = None

        if self._sbtcommon.stringutil.is_empty(vendor):
            selected_vendor = self.get_default_vendor()
        elif self._sbtcommon.collectionsutil.is_not_empty(
                self.get_vendor_mappings()):
            for v in self.get_vendor_mappings().keys():
                if v.lower() == vendor.lower():
                    selected_vendor = v

        if self._sbtcommon.stringutil.is_not_empty(name):
            table_name = name
            if table_name[:1] == '_' and \
                    self._sbtcommon.stringutil.is_not_empty(selected_vendor):
                table_name = selected_vendor.upper() + table_name

        return table_name

    def get_configuration(self):
        """
      Returns configuration used to create object

      Returns :
        dict : Dictionary representing original JSON Configuration
    """
        return self._conf

    def can_load_data(self):
        """
      Determine if this mapping should load data through sbt_loader

      Returns :
        boolean : True if mapping should load_data
    """
        load_data = self._get_value_from_configuration('load_data')
        if load_data is None:
            load_data = False

        return load_data

    def requires_last_filing_date(self, vendor=None):
        mapping = None
        if vendor:
            mapping = self.get_vendor_mappings()[vendor]
        else:
            mapping = self.get_default_vendor_mapping()

        return 'load' in mapping and \
               'latest_filing_date_required' in mapping['load'] and \
               mapping['load']['latest_filing_date_required']

    def is_active(self):
        """
      Current status of the mapping

      Returns :
        boolean : True if mapping is active
    """
        return self._get_value_from_configuration('active')

    def set_active(self, active):
        """
      Sets status of the mapping

      Args :
        active(boolean) : True indicates it is active
    """
        return self._set_value_in_configuration('active', active)

    def is_timeseries_data_type(self):
        """
      Determines if object is of timeseries data type.

      Returns :
        boolean : True the data type is timeseries
    """
        return self.is_of_data_type(TableMappingDataType.TIMESERIES.value)

    def is_of_data_type(self, data_type_name):
        """
      Determines if object is of a specific data type.

      Args :
        data_type_name(str) : Data Type name (timeseries, financial,
                              ownership, company, article)

      Returns :
        boolean : True the data type names match
    """
        return self._sbtcommon.stringutil.is_not_empty(data_type_name) and \
               data_type_name.lower() == self.get_data_type_name()

    def _set_value_in_configuration(self, attribute, value):
        """
      Sets the specified value from the configuration.

      Args :
        attribute(str) : Requested attribute
        value(str) : Value

    """
        if self._conf is None:
            self._conf = self.default_table_mapping_conf

        self._conf[attribute] = value

    def _get_value_from_configuration(self, attribute):
        """
      Retrieves a specified value from the json configuration.

      Args :
        attribute(str) : Requested attribute

      Returns
        any : Value of requested attribute
    """
        ret_value = None

        if self._conf is not None and attribute in self._conf.keys():
            ret_value = self._conf[attribute]

        return ret_value


class MappingAccessor(DynamoAccessor):
    """
    Class is used to access table mapping information
  """
    _symbol_template_table_mappings = {
        SymbolMappingTemplateType.FINANCE.value + '_USA':
            [
                '154d8eb4-8139-429c-955b-ef1f43e3a80b',
                '8275cebe-49e9-4339-a54d-2fa9d989d382',
                '1dbdb6d2-5df0-4644-a12d-3593288510d0',
                '0dcb19c9-a989-4bdb-b72d-9195069262d3',
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                'f328ff7c-9f48-49b6-9ebf-5edb12852eb5',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"],
        SymbolMappingTemplateType.INDUSTRIAL.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f328ff7c-9f48-49b6-9ebf-5edb12852eb5',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.STANDARD.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.BANKS.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.INSURANCE.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.UTILITY.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.REAL_ESTATE.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.FINANCIAL_SERVICES.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.CAPITAL_MARKETS.value + '_USA':
            [
                'a161dc80-f02f-4193-8743-644a8a6a3725',
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '089172ff-da0b-4ac7-95e9-5a3ae4d3c23c',
                '4916a49c-7757-4817-8e07-64013a648a01',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '16f4fcb1-d987-4052-bc63-3ae1c738b9c5',
                'fb39c18c-3bc3-49ef-9e60-0912af70e1ea',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1"
            ],
        SymbolMappingTemplateType.STANDARD.value + '_CAN':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.BANKS.value + '_CAN':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.INSURANCE.value + '_CAN':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.UTILITY.value + '_CAN':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.REAL_ESTATE.value + '_CAN':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.FINANCIAL_SERVICES.value + '_CAN':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.CAPITAL_MARKETS.value + '_CAN':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.STANDARD.value + '_GBR':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.BANKS.value + '_GBR':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.INSURANCE.value + '_GBR':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.UTILITY.value + '_GBR':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.REAL_ESTATE.value + '_GBR':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.FINANCIAL_SERVICES.value + '_GBR':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ],
        SymbolMappingTemplateType.CAPITAL_MARKETS.value + '_GBR':
            [
                '29700656-448b-4622-9ad7-5bb652906c97',
                'f133bde4-4d9e-489e-8d65-bf826cc9a333',
                '78a4eb9b-766f-4c4e-9556-b6c9a8e26006',
                '4f4cecd9-a001-4d19-b4a7-d9efd3577c28',
                'ca46a521-8e0d-4f99-b02a-de1cf4f7aa09',
                "ba0dd814-2d8d-4d07-b616-467f721dc01c",
                "935ddb42-898e-4a56-8833-ed1dca9b41a1",
                '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
            ]
    }

    _ts_range_dict = {
        "computed_field": "timestamp",
        "data_type": "String",
        "default": False,
        "description": "Date",
        "guid": "<GUID>",
        "id": "date",
        "type": "range",
        "vendor_mapping": {
        }
    }

    _ts_key_dict = {
        "data_type": "String",
        "default": False,
        "description": "Global Unique Identdifier",
        "guid": "<GUID>",
        "id": "guid",
        "type": "key"
    }

    table_sbt_metadata_table_data_load = 'SBT_METADATA_TABLE_DATA_LOAD'

    _valid_fundamentals_exchange_types = ['STOCK', 'MUTUALFUND']
    _cache_loadtimestamp = None
    _data_types = {}
    _table_mappings = {}
    _vendor_exchanges = {}
    _exchanges = {}

    def __init__(self):
        """
      Constructor
    """
        super().__init__(aws_profile_name=None,
                         aws_region_name=None,
                         aws_end_point_url=None)
        self._class_instances = {}

        self._symbol_exchange_mapping_source = 'S&P'

        self._table_symbol_exchange_mapping = \
            self._get_environment_table_name(
                'SBT_SYMBOL_EXCHANGE_MAPPING')
        self._table_sbt_metadata_data_load = \
            self._get_environment_table_name(
                'SBT_METADATA_TABLE_DATA_LOAD')
        self._table_sbt_metadata_table_mapping = \
            self._get_environment_table_name(
                'SBT_METADATA_TABLE_MAPPING')
        self._table_sbt_metadata_table_attribute_mapping = \
            self._get_environment_table_name(
                'SBT_METADATA_TABLE_ATTRIBUTE_MAPPING')
        self._table_sbt_data_type = self._get_environment_table_name(
            'SBT_DATA_TYPE')
        self._table_exchange = self._get_environment_table_name('SBT_EXCHANGE')

    def get_sem_table_mappings(self,
                               symbol_template_type,
                               country_code):
        mapping = SymbolMappingTemplateType(symbol_template_type)

        return list(self._symbol_template_table_mappings[
                        mapping.value + '_' + country_code])

    def create_symbol_mapping(self, symbol, exchange,
                              entity_name, symbol_template_type,
                              **kwargs):
        symbol_mapping = {}

        symbol_type = kwargs.get('symbol_type', None)
        third_party_codes = kwargs.get('third_party_codes', None)
        guid = kwargs.get('guid', None)
        sbt_company_id = kwargs.get('sbt_company_id', None)
        source = kwargs.get('source', self._symbol_exchange_mapping_source)
        primary = kwargs.get('primary', False)
        tags = kwargs.get('tags', None)
        sb_portfolio_mapping = kwargs.get('sb_portfolio_mapping', None)

        exchange_data = self.get_exchanges()[exchange]

        res = self.unique_symbol_exchange_mapping(symbol, exchange)

        # create GUID for company if it doesn't exist
        if not guid:
            guid = res.get('guid') if 'guid' in res else str(self._sbtcommon.get_uuid())
            if not sbt_company_id and \
                    exchange_data[
                        'type'] in self._valid_fundamentals_exchange_types:
                sbt_company_id = guid
                print('SET sbt_company_id ' + sbt_company_id)

        if not sbt_company_id and \
                exchange_data[
                    'type'] in self._valid_fundamentals_exchange_types:
            sbt_company_id = str(self._sbtcommon.get_uuid())

        symbol_mapping['symbol'] = symbol.upper()
        symbol_mapping['exchange'] = exchange.upper()
        symbol_mapping['exchange_name'] = exchange_data['description']
        symbol_mapping['exchange_type'] = exchange_data['type']
        symbol_mapping['entity_name'] = entity_name
        symbol_mapping['exchange_country'] = exchange_data['country_code']
        symbol_mapping['exchange_currency'] = exchange_data['currency_code']
        symbol_mapping['supports_streaming'] = exchange_data.get(
            'supports_streaming', False)
        symbol_mapping['source'] = source
        symbol_mapping['primary'] = primary

        if sb_portfolio_mapping:
            symbol_mapping['sb_portfolio_mapping'] = sb_portfolio_mapping

        if sbt_company_id:
            symbol_mapping['sbt_company_id'] = sbt_company_id

        if symbol_type:
            symbol_mapping['symbol_type'] = symbol_type
        if tags:
            symbol_mapping['tags'] = tags
        symbol_mapping['guid'] = guid
        symbol_mapping[
            'composite_pk_id'] = symbol.upper() + ':' + exchange.upper()
        symbol_mapping['load_timestamp'] = '{:%m-%d-%Y %H:%M:%S GMT}'.format(
            datetime.datetime.utcnow())

        smtt = SymbolMappingTemplateType(symbol_template_type)
        sem_mappings = exchange_data.get('template_mapping', {}).get(
            smtt.value, [])

        if not sem_mappings:
            self._logger.error('Template mapping not found in exchange.')
            sem_mappings = self.get_sem_table_mappings(symbol_template_type,
                                                       exchange_data[
                                                           'country_code'])

        symbol_mapping['category'] = sem_mappings
        symbol_mapping['table_mapping'] = sem_mappings
        # add the global identifier
        symbol_mapping['globalid'] = kwargs['globalid']
        # add is_etf
        symbol_mapping['is_etf'] = kwargs['is_etf']
        # GICS
        symbol_mapping['gsector'] = kwargs.get('gsector', None)
        symbol_mapping['ggroup'] = kwargs.get('ggroup', None)
        symbol_mapping['gind'] = kwargs.get('gind', None)
        symbol_mapping['gsubind'] = kwargs.get('gsubind', None)

        if third_party_codes:
            for k, v in third_party_codes.items():
                symbol_mapping[k] = v

        return symbol_mapping

    def query_table_by_mapping(self, table_mapping, key_value,
                               exchange=None,
                               range_name=None,
                               range_value=None,
                               vendor=None):
        """
      Queries the table associated with the vendor and table mapping and
      returns the results.  This method isolates that caller from knowing
      the specifics of the query and allows multiple databases to return
      the same base result.


      Args :
        table_mapping(*)        : Table Mapping or Table Mapping GUID
        key_value(str)          : This is typically the GUID, but
                                  you can pass the SYMBOL
        exchange(str)           : If provided a lookup will be done to
                                  find the tables KEY
        range_value(*)          : The range value associated with the
                                  table mapping.
        vendor(str)             : Vendor Name. if none is provided the
                                  default is used.

      Returns :
        (collection) : Values in the table that match the key and range.

      Exceptions :
        Raises an exception if the the table mapping or symbol lookup
        fails.
    """
        ret_value = []

        temp_table_mapping = self._get_query_table_mapping(table_mapping)

        if self._sbtcommon.stringutil.is_empty(vendor):
            vendor = temp_table_mapping.get_default_vendor()

        if vendor == Vendors.STANDARD_AND_POORS.value:
            ret_value = self._query_preloaded_table(temp_table_mapping,
                                                    key_value,
                                                    exchange=exchange,
                                                    range_name=range_name,
                                                    range_value=range_value,
                                                    vendor=vendor)
        else:
            ret_value = self._query_other_table(temp_table_mapping, key_value,
                                                exchange=exchange,
                                                range_value=range_value,
                                                vendor=vendor)

        return ret_value

    def clone_table_mapping(self, guid, changes, field_dict,
                            symbol, exchange):
        with Lock():
            table_mapping = self.get_table_mapping(guid)

            if table_mapping is None:
                raise Exception('GUID Not found.')

            sem = self.unique_symbol_exchange_mapping(symbol, exchange)

            if sem is None:
                raise Exception('Symbol Exchange Mapping Not found.')

            cloned_config = table_mapping.get_configuration()

            guid = self._sbtcommon.get_uuid()
            while guid in self._table_mappings.keys():
                guid = self._sbtcommon.get_uuid()
            cloned_config['guid'] = str(guid)

            if self._sbtcommon.collectionsutil.is_not_empty(changes):
                for k, v in changes.items():
                    if k in cloned_config.keys():
                        cloned_config[k] = v

            self._populate_table_vendor_data(cloned_config,
                                             symbol,
                                             exchange)

            self._save(self._table_sbt_metadata_table_mapping, cloned_config)
            if self._sbtcommon.collectionsutil.is_not_empty(field_dict):
                self._batch_save(
                    self._table_sbt_metadata_table_attribute_mapping,
                    self._create_table_attributes(guid,
                                                  cloned_config[
                                                      'default_vendor'],
                                                  field_dict))

            sem['entity_name'] = cloned_config['short_description']
            if 'table_mapping' not in sem.keys():
                sem['table_mapping'] = []

            if str(guid) not in sem['table_mapping']:
                sem['table_mapping'].append(str(guid))

            self._save(self._table_symbol_exchange_mapping, sem)

            self.__class__._cache_loadtimestamp = None

    def unique_table_data_load(self, table_mapping_guid, symbol_mapping_guid):
        ret_value = {}

        if self._sbtcommon.stringutil.is_not_empty(table_mapping_guid) and \
                self._sbtcommon.stringutil.is_not_empty(symbol_mapping_guid):
            ret_value = self._unique_item(self._table_sbt_metadata_data_load,
                                          'table_mapping_guid',
                                          table_mapping_guid,
                                          range_name='symbol_mapping_guid',
                                          range_value=symbol_mapping_guid)

        return ret_value

    def query_table_data_load(self, table_mapping_guid,
                              symbol_mapping_guid=None):
        ret_val = []

        if self._sbtcommon.stringutil.is_empty(table_mapping_guid):
            return ret_val

        if self._sbtcommon.stringutil.is_empty(symbol_mapping_guid):
            ret_val = self._query_table(self._table_sbt_metadata_data_load,
                                        'table_mapping_guid',
                                        table_mapping_guid)
        else:
            ret_val = self._query_table(self._table_sbt_metadata_data_load,
                                        'table_mapping_guid',
                                        table_mapping_guid,
                                        range_name='symbol_mapping_guid',
                                        range_value=symbol_mapping_guid)

        return ret_val

    def supports_stansberry_content(self, symbol_mapping):
        ret = False

        if not symbol_mapping or \
                symbol_mapping.get('exchange_type',
                                   'NA') not in self._valid_fundamentals_exchange_types:
            return ret

        if symbol_mapping.get('exchange_country', 'USA') == 'USA' or \
                'sb_portfolio_mapping' in symbol_mapping:
            ret = True

        return ret

    def query_symbol_exchange_mappings(self, symbol):
        """
      Returns all symbol mappings for symbol.

      Args :
        sybol(str) : Symbol

      Returns :
        list : Symbol Exchange Mappings
    """
        ret_value = []

        if self._sbtcommon.stringutil.is_not_empty(symbol):
            ret_value = self._query_table(self._table_symbol_exchange_mapping,
                                          'symbol',
                                          symbol.upper())

        return ret_value

    def query_symbol_exchange_mapping_by_company_id(self, co_id):
        """
      Returns all symbol mappings associated with a company id.

      Args :
        co_id(str) : GUID

      Returns :
        list : Symbol Exchange Mappings
    """
        ret_value = []

        if self._sbtcommon.stringutil.is_not_empty(co_id):
            ret_value = self._query_table(self._table_symbol_exchange_mapping,
                                          'sbt_company_id',
                                          co_id,
                                          index_name='SBTCOIDidx')

        return ret_value

    def query_symbol_exchange_mapping_by_guid(self, guid):
        """
      Returns all symbol mappings associated with a guid.

      Args :
        guid(str) : GUID

      Returns :
        list : Symbol Exchange Mappings
    """
        ret_value = []

        if self._sbtcommon.stringutil.is_not_empty(guid):
            ret_value = self._query_table(self._table_symbol_exchange_mapping,
                                          'guid',
                                          guid,
                                          index_name='GUIDidx')

        return ret_value

    def parse_mapping_symbol(self, symbol):
        if not symbol:
            return None, None, None

        symbol = symbol.upper()
        new_symbol = symbol
        exchange = None
        exchange_country = None

        if '~' in symbol:
            parts = symbol.split('~')
            new_symbol = parts[0]
            exchange = parts[1]
        elif ':' in symbol:
            parts = symbol.split(':')
            new_symbol = parts[0]
            exchange = parts[1]

        if exchange == 'N/A' :
            exchange = None 

        if exchange:
            ex = self.get_exchanges().get(exchange, {})
            if ex:
                exchange_country = ex.get('country_code', 'USA')

        return new_symbol, exchange, exchange_country

    def unique_stock_symbol_exchange_mapping(self, symbol,
                                             exchange=None,
                                             replace_alt_symbol=True):
        """
      Returns a unique symbol mapping object.

      Args :
        symbol(str) : Symbol
        exchange(str) : Exchange

      Returns :
        dict : Symbol Exchange Mapping
    """
        e_mapping = {}

        if self.load_cache():
            self._set_cached_data()

        if not symbol:
            return e_mapping

        symbol = symbol.upper()

        if '~' in symbol:
            parts = symbol.split('~')
            symbol = parts[0]
            exchange = parts[1]
        elif ':' in symbol:
            parts = symbol.split(':')
            symbol = parts[0]
            exchange = parts[1]

        if exchange == 'N/A' :
            exchange = None 

        if exchange:
            exchange = exchange.upper()
            # quick fix for portfolios that use a
            # different exchange symbol for NasdaQ
            if exchange in ['NASDAQ']:
                exchange = 'NSDQ'

        if self._sbtcommon.validate_uuid(symbol.lower()):
            results = self.query_symbol_exchange_mapping_by_guid(
                symbol.lower())

            e_mapping = self._get_stock_symbol_exchange_mapping(results,
                                                                exchange=exchange)

        elif not exchange:
            results = self._query_table(self._table_symbol_exchange_mapping,
                                        'symbol',
                                        symbol)

            if not results:
                results = self._get_alternate_symbol_results(symbol, None,
                                                             replace_alt_symbol)

            if not results:
                e_mapping = self._query_sb_non_us_symbol(symbol)
            else:
                e_mapping = self._get_stock_symbol_exchange_mapping(results)

        else:
            exchange = exchange.upper()

            results = self._unique_item(
                self._table_symbol_exchange_mapping,
                'symbol', symbol,
                range_name='exchange',
                range_value=exchange)

            if not results:
                results = self._get_unique_alternate_symbol_result(symbol,
                                                                   exchange,
                                                                   replace_alt_symbol)

            if results:
                e_mapping = results

        return e_mapping

    def unique_symbol_exchange_mapping(self, symbol, exchange=None,
                                       replace_alt_symbol=True):
        """
      Returns a unique symbol mapping object.

      Args :
        symbol(str) : Symbol
        exchange(str) : Exchange

      Returns :
        dict : Symbol Exchange Mapping
    """
        e_mapping = {}

        if self._sbtcommon.stringutil.is_empty(symbol):
            return e_mapping

        symbol = symbol.upper()

        if '~' in symbol:
            parts = symbol.split('~')
            symbol = parts[0]
            exchange = parts[1]
        elif ':' in symbol:
            parts = symbol.split(':')
            symbol = parts[0]
            exchange = parts[1]

        if exchange == 'N/A' :
            exchange = None 

        if self._sbtcommon.validate_uuid(symbol.lower()):
            results = self.query_symbol_exchange_mapping_by_guid(
                symbol.lower())

            e_mapping = self._get_symbol_exchange_mapping(results,
                                                          exchange=exchange)

        elif not exchange:
            results = self._query_table(self._table_symbol_exchange_mapping,
                                        'symbol',
                                        symbol)

            if not results:
                results = self._get_alternate_symbol_results(symbol, None,
                                                             replace_alt_symbol)

            if not results:
                e_mapping = self._query_sb_non_us_symbol(symbol)
            else:
                e_mapping = self._get_symbol_exchange_mapping(results,
                                                              exchange=exchange)
        else:
            exchange = exchange.upper()

            results = self._unique_item(
                self._table_symbol_exchange_mapping,
                'symbol', symbol,
                range_name='exchange',
                range_value=exchange)

            if not results:
                results = self._get_unique_alternate_symbol_result(symbol,
                                                                   exchange,
                                                                   replace_alt_symbol)

            if results:
                e_mapping = results

        return e_mapping

    def scan_symbol_exchange_mapping_for_sb_portfolios(self,
                                                       primary_only=False):
        """
      Returns all the Stansberry Portfolio stocks contained in the
      SBT_SYMBOL_EXCHANGE_MAPPING table.

      Returns :
        list : Symbol Exchange Mapping dictionaries
    """
        filters = [self._create_filter_expression('sb_portfolio_mapping',
                                                  'exists',
                                                  None)]

        if primary_only:
            filters.append(self._create_filter_expression('primary',
                                                          'eq',
                                                          primary_only))

        return self._scan_table(self._table_symbol_exchange_mapping,
                                self._build_filter_expression(filters))

    def save_symbol_exchange_mapping(self, ex_map):
        """
      Saves a symbol exchange mapping

      Args:
        ex_map(dict) : Symbol Exchange Mapping
    """
        if self._sbtcommon.collectionsutil.is_not_empty(ex_map):
            self._save(self._table_symbol_exchange_mapping, ex_map)

    def scan_symbol_exchange_mapping(self,
                                     primary_only=False,
                                     symbol_starts_with=None,
                                     symbol_contains=None,
                                     exchange_type=None):
        """
      Retrieve all symbol exchange mappings from the database.

      Returns :
        list : All Symbol Exchange Mappings
    """
        filters = None

        if primary_only:
            filters = []
            filters.append(self._create_filter_expression('primary',
                                                          'eq',
                                                          primary_only))

        if symbol_starts_with:
            if filters is None:
                filters = []

            filters.append(self._create_filter_expression('symbol',
                                                          'starts_with',
                                                          symbol_starts_with))

        if symbol_contains:
            if filters is None:
                filters = []

            filters.append(self._create_filter_expression('symbol',
                                                          'contains',
                                                          symbol_contains))

        if exchange_type:
            if filters is None:
                filters = []

            filters.append(self._create_filter_expression('exchange_type',
                                                          'eq',
                                                          exchange_type))

        return self._scan_table(self._table_symbol_exchange_mapping,
                                self._build_filter_expression(filters))

    def save_table_mapping(self, table_mapping):
        if table_mapping is None:
            raise Exception('The Table Mapping object can not be None.')

        if self.load_cache():
            self._set_cached_data()

        if self._sbtcommon.stringutil.is_empty(
                table_mapping.get_data_type()) or \
                table_mapping.get_data_type() not in self._data_types.keys():
            raise Exception('The data type is not valid.')

        config = table_mapping.get_configuration()
        if self._sbtcommon.stringutil.is_empty(table_mapping.get_guid()):
            guid = self._sbtcommon.get_uuid()
            while guid in self._table_mappings.keys():
                guid = self._sbtcommon.get_uuid()
            config['guid'] = guid

        ret_data = TableMapping(config, self._data_types)
        self._save(self._table_sbt_metadata_table_mapping, config)
        self.__class__._cache_loadtimestamp = None

        return ret_data

    def get_table_mapping(self, guid):
        """
      Returns TableMapping object that matches the guid that is provided.

      Args :
        guid(str) : Unique Identifier

      Returns :
        TableMapping : TableMapping Object
    """
        if self.load_cache():
            self._set_cached_data()

        if guid in self._table_mappings.keys():
            return self._table_mappings[guid]
        else:
            return None

    def get_table_mappings_by_name_and_code(self, name, code='N/A'):
        """
      Returns a TableMapping objects that matches the table name and code.

      Args :
        table_name(str) : Table Name
        code(str) : Code

      Returns :
        TableMapping : TableMapping Object
    """

        ret_data = None

        for tm in self.get_table_mappings():
            if tm.get_name() == name and \
                    tm.get_code() == code:
                ret_data = tm
                break

        return ret_data

    def get_table_mappings_by_table_name(self, table_name):
        """
      Returns a list TableMapping objects that match the table name.

      Args :
        table_name(str) : Table Name

      Returns :
        list : TableMapping Objects
    """

        ret_data = []

        for tm in self.get_table_mappings():
            if tm.get_table_name() == table_name:
                ret_data.append(tm)

        return ret_data

    def get_table_mappings_by_data_type_name(self, data_type_names):
        """
      Returns a list TableMapping objects.

      Args :
        data_type_names(list) : List of datatype names

      Returns :
        list : TableMapping Objects
    """

        ret_data = []

        for tm in self.get_table_mappings():
            for dt in data_type_names:
                if tm.is_of_data_type(dt):
                    ret_data.append(tm)

        return ret_data

    def get_table_mappings_requiring_data_laod(self):
        mappings = self.get_table_mappings()

        p_mappings = []

        for mapping in mappings:
            if mapping.can_load_data():
                p_mappings.append(mapping)

        return p_mappings

    def get_table_mappings(self):
        """
      Returns a list TableMapping objects.

      Returns :
        list : TableMapping Objects
    """
        if self.load_cache():
            self._set_cached_data()

        return list(self._table_mappings.values())

    def get_exchanges(self):
        if self.load_cache():
            self._set_cached_data()

        return self._exchanges

    def get_exchange(self, vendor, vendor_exchange_code):
        """
      Returns the exchange associated with the vendor and
      vendor code.

      Args:
        vendor(str)               : Vendor ID String
        vendor_exchange_code(str) : Vendor Exchange Code

      Returns :
        dict : Exchange
    """
        ret_value = None

        if self.load_cache():
            self._set_cached_data()

        if vendor in self._vendor_exchanges.keys() and \
                vendor_exchange_code in self._vendor_exchanges[vendor].keys():
            ret_value = self._vendor_exchanges[vendor][vendor_exchange_code]

        return ret_value

    def _get_unique_alternate_symbol_result(self, symbol,
                                            exchange=None,
                                            replace_alt_symbol=True):
        u_result = None

        alt_results = self._get_alternate_symbol_results(symbol, exchange,
                                                         replace_alt_symbol)

        if alt_results and len(alt_results) == 1:
            u_result = alt_results[0]

        return u_result

    def _get_alternate_symbol_results(self, symbol,
                                      exchange=None,
                                      replace_alt_symbol=True):
        results = None

        alt_symbol = self._get_alternate_stock_symbol(symbol, exchange)

        if alt_symbol:
            t_results = self._query_table(
                self._table_symbol_exchange_mapping,
                'symbol', alt_symbol)

            if t_results and len(t_results) == 1 and \
                    t_results[0].get('exchange_type',
                                     'NA') in self._valid_fundamentals_exchange_types and \
                    t_results[0].get('exchange_country', 'USA') == 'USA' and \
                    t_results[0]['symbol'].replace('.', '') == symbol.replace(
                '.', ''):
                results = t_results
                if replace_alt_symbol:
                    results[0]['symbol'] = symbol

        return results

    def _get_alternate_stock_symbol(self, symbol, exchange):
        alt_symbol = None
        if not symbol:
            return alt_symbol

        try:
            ex = None
            if exchange:
                ex = self.get_exchanges().get(exchange, None)

            if exchange and (not ex or \
                             ex.get('type',
                                    'NA') not in self._valid_fundamentals_exchange_types or \
                             ex.get('country_code', 'NA') != 'USA'):
                return alt_symbol

            if '.' not in symbol and len(symbol) == 5:
                alt_symbol = symbol[:4] + '.' + symbol[4:]

            if '.' in symbol and len(symbol) == 6:
                alt_symbol = symbol.replace('.', '')

            if alt_symbol:
                self._logger.info(
                    'Requested alternate symbol setup for ' + symbol +
                    ' : ' + alt_symbol)
        except Exception:
            self._logger.info(
                'Failed to convert to alternate symbol for ' + symbol)

        return alt_symbol

    def _get_symbol_exchange_mapping(self, results, exchange=None):
        e_mapping = {}

        if not results:
            return e_mapping

        compare_exch = exchange
        if not compare_exch:
            compare_exch = results[0]['exchange']
        else:
            compare_exch.upper()

        # remove non-S&P data
        results = [x for x in results if x.get('source') == 'S&P']

        if results[0].get('exchange_type',
                          'NA') in self._valid_fundamentals_exchange_types or \
                self._is_stock_exchange(compare_exch):
            e_mapping = self._get_stock_symbol_exchange_mapping(results,
                                                                exchange=exchange)
        else:
            e_mapping = results[0]

        return e_mapping

    def _get_stock_symbol_exchange_mapping(self, results, exchange=None):
        e_mapping = {}

        if not results:
            return e_mapping

        if len(results) == 1 and \
                results[0][
                    'exchange_type'] in self._valid_fundamentals_exchange_types:
            e_mapping = results[0]
        else:
            sym_results = list(filter(lambda s:
                                      s[
                                          'exchange_type'] in self._valid_fundamentals_exchange_types,
                                      results))

            e_mapping = self._get_stock_mapping(sym_results, exchange=exchange)

            self._populate_associated_stock_exchanges(e_mapping, sym_results)

        return e_mapping

    def _get_stock_mapping(self, sym_results, exchange=None):
        e_mapping = None

        if not sym_results:
            return e_mapping

        if exchange:
            sym_results = list(filter(lambda f: f['exchange'] == exchange,
                                      sym_results))

        prim_results = list(filter(lambda s: s.get('primary', False),
                                   sym_results))

        if not exchange:
            # if no exchange is provided, pick only results
            # that trade in the USA or Canada
            prim_results = [x for x in sym_results
                            if x['exchange_country'] in ['USA', 'TSX']]

        search_sym = None

        if not prim_results:
            search_sym = sym_results
        elif len(prim_results) == 1:
            e_mapping = prim_results[0]
        else:
            search_sym = prim_results

        if search_sym:
            for sym in search_sym:
                if sym['exchange_country'] == 'USA':
                    e_mapping = sym
                    break

            if not e_mapping:
                e_mapping = search_sym[0]

        return e_mapping

    def _populate_associated_stock_exchanges(self, e_mapping,
                                             sym_results):
        if e_mapping and sym_results:
            associated_exchanges = []
            for sym in sym_results:
                if sym['guid'] == e_mapping.get('guid', '') and \
                        sym['exchange'] != e_mapping.get('exchange',
                                                         sym['exchange']):
                    associated_exchanges.append(sym['exchange'])

            if associated_exchanges:
                e_mapping['associated_exchanges'] = associated_exchanges

    def _is_stock_exchange(self, exchange_code):
        ret_value = False

        if not exchange_code:
            return ret_value

        ex = self._exchanges.get(exchange_code, None)

        if ex and ex['type'] in self._valid_fundamentals_exchange_types:
            ret_value = True

        return ret_value

    def _load_data_dynamically(self,
                               table_mapping,
                               vendor,
                               key_value):

        v_mapping = None
        if self._sbtcommon.stringutil.is_not_empty(vendor) and \
                vendor in table_mapping.get_vendor_mappings().keys():
            v_mapping = table_mapping.get_vendor_mappings()[vendor]

        if self._sbtcommon.collectionsutil.is_empty(v_mapping):
            return

        sems = self.query_symbol_exchange_mapping_by_guid(key_value)

        if self._sbtcommon.collectionsutil.is_empty(sems):
            return

        symbol_mappings = []
        symbol_mappings.append(sems[0])

        if table_mapping.is_timeseries_data_type() and \
                'extraction' in v_mapping.keys() and \
                'custom' in v_mapping['extraction'].keys() and \
                'parameters' in v_mapping['extraction']['custom'].keys() and \
                self._sbtcommon.collectionsutil.is_not_empty(
                    v_mapping['extraction']
                    ['custom']['parameters']):
            try:
                params = v_mapping['extraction']['custom']['parameters']
                for p in params:
                    if p['action'] == 'calculate' and \
                            'static_start_value' in p.keys():
                        p['action'] = 'static'
                        p['value'] = p['static_start_value']

                tl = TimeseriesLoader(
                    table_mapping,
                    symbol_mappings,
                    override_vendor_mapping=v_mapping,
                    vendor=vendor)
                tl.load_data()
            except Exception as ex:
                self._logger.error(str(ex))

    def _can_load_data_dynamically(self, table_mapping,
                                   vendor):
        ret_value = False
        all_vendor_mappings = table_mapping.get_vendor_mappings()
        if vendor in all_vendor_mappings.keys():
            v_mappings = all_vendor_mappings[vendor]
            if 'load' in v_mappings.keys() and \
                    'only_if_values_exists' in v_mappings['load'].keys() and \
                    v_mappings['load']['only_if_values_exists']:
                ret_value = True

        return ret_value

    def _get_query_table_mapping(self, table_mapping):

        temp_table_mapping = table_mapping
        if table_mapping is not None and isinstance(table_mapping, str) and \
                self._sbtcommon.validate_uuid(table_mapping):
            temp_table_mapping = self.get_table_mapping(table_mapping)

        if temp_table_mapping is None or not isinstance(temp_table_mapping,
                                                        TableMapping):
            raise Exception('Table mapping could not be found.')
        return temp_table_mapping

    def _populate_table_vendor_data(self, cloned_config,
                                    symbol, exchange):
        vendor = cloned_config['default_vendor']
        if 'vendor_mapping' in cloned_config.keys() and \
                vendor in cloned_config['vendor_mapping'].keys():
            vendor_mapping = cloned_config['vendor_mapping'][vendor]
            vendor_mapping['vendor_code'] = exchange + '/' + symbol
            vendor_mapping['source'] = cloned_config['short_description']
            vendor_mapping['extraction']['standard']['vendor_code'] = \
                exchange + '/' + symbol
            params = vendor_mapping['extraction']['custom'][
                'parameters']
            for p in params:
                if p['input'] == 'code':
                    p['value'] = symbol
                elif p['input'] == 'database':
                    p['value'] = exchange

    def _query_sb_non_us_symbol(self, symbol):
        e_mapping = {}

        t_sym, t_exc = self._get_sb_non_us_symbol(symbol)

        if t_sym:
            results = self._unique_item(
                self._table_symbol_exchange_mapping,
                'symbol', t_sym,
                range_name='exchange',
                range_value=t_exc)

            if results:
                e_mapping = results
            elif t_exc and t_exc == 'SEHK' and t_sym.startswith('0') and \
                    t_sym.isnumeric():
                t_sym = str(int(t_sym))
                results = self._unique_item(
                    self._table_symbol_exchange_mapping,
                    'symbol', t_sym,
                    range_name='exchange',
                    range_value=t_exc)

                if results:
                    e_mapping = results
            elif t_exc and t_exc == 'OM' and '-' in t_sym:
                t_sym = t_sym.replace('-', ' ')
                results = self._unique_item(
                    self._table_symbol_exchange_mapping,
                    'symbol', t_sym,
                    range_name='exchange',
                    range_value=t_exc)

                if results:
                    e_mapping = results

        return e_mapping

    def _get_sb_non_us_symbol(self, symbol):
        ret_symbol = None
        ret_exchange = None

        delimiter = None
        if '.' in symbol and '-' in symbol:
            delimiter = '.'
        else:
            if '.' in symbol:
                delimiter = '.'
            if '-' in symbol:
                delimiter = '-'

        if not delimiter:
            return ret_symbol, ret_exchange

        parts = symbol.split(delimiter)
        p_len = len(parts)

        sb_ext = delimiter + parts[(p_len - 1)]

        for e in list(self.get_exchanges().values()):
            e_ext = e.get('stansberry_extension', [])

            if (isinstance(e_ext, str) and e_ext == sb_ext) or \
                    (isinstance(e_ext, list) and sb_ext in e_ext):
                ret_exchange = e['code']
                break

        if ret_exchange:
            ret_symbol = self.build_sb_non_us_symbol(parts, delimiter, p_len)

        return ret_symbol, ret_exchange

    def build_sb_non_us_symbol(self, parts, delimiter, p_len):
        counter = 1
        ret_symbol = ''
        for s in parts:
            if counter < p_len:
                if ret_symbol:
                    ret_symbol = ret_symbol + delimiter

                ret_symbol = ret_symbol + s
                counter = counter + 1

        return ret_symbol

    def _create_table_attributes(self, guid, vendor, field_dict):
        a_configs = []
        key_dict = self._ts_key_dict.copy()
        key_dict['guid'] = str(guid)
        a_configs.append(key_dict)
        range_dict = self._ts_range_dict.copy()
        range_dict['guid'] = str(guid)
        range_dict['vendor_mapping'][vendor] = {
            "data_type": "String",
            "id": "date"
        }
        a_configs.append(range_dict)
        default = True
        for field_key in field_dict.keys():
            if field_key != 'date':
                value_dict = {}
                value_dict['guid'] = str(guid)
                value_dict['data_type'] = "BigDecimal"
                value_dict['type'] = "value"
                value_dict['id'] = field_key.replace('_', '')
                value_dict['default'] = default
                value_dict['description'] = field_key.replace('_', ' ')
                temp_vendor = {}
                temp_vendor['data_type'] = "BigDecimal"
                temp_vendor['id'] = field_key.replace('_', '_')
                value_dict['vendor_mapping'] = {}
                value_dict['vendor_mapping'][vendor] = temp_vendor
                default = False
                a_configs.append(value_dict)

        return a_configs

    def _set_cached_data(self):
        """
      Set the cached values within the class.
    """
        with Lock():
            if self.load_cache():
                self._set_exchanges()
                data = self._scan_table(self._table_sbt_data_type, None)

                for t in data:
                    self.__class__._data_types[t['guid']] = t

                data = self._scan_table(self._table_sbt_metadata_table_mapping,
                                        None)

                for tm in data:
                    attributes = self._query_table(
                        self._table_sbt_metadata_table_attribute_mapping,
                        'guid',
                        tm['guid'])

                    self.__class__._table_mappings[tm['guid']] = TableMapping(
                        tm,
                        attributes,
                        self._data_types)

                self.__class__._cache_loadtimestamp = \
                    self._sbtcommon.dateutil.get_current_timestamp()

    def _set_exchanges(self):
        """
      Sets _vendor_exchanges class variable
    """
        exchanges = self._scan_table(self._table_exchange, None)
        for exchange in exchanges:
            self.__class__._exchanges[exchange['code']] = exchange

            if 'vendor_mapping' not in exchange.keys():
                continue

            for v_key, v_value in exchange['vendor_mapping'].items():
                if v_key not in self._vendor_exchanges.keys():
                    self.__class__._vendor_exchanges[v_key] = {}
                for v_code in v_value:
                    if v_code in self._vendor_exchanges[v_key].keys():
                        continue
                    self.__class__._vendor_exchanges[v_key][v_code] = \
                        exchange

    def _query_preloaded_table(self, table_mapping, key_value,
                               exchange=None,
                               range_name=None,
                               range_value=None,
                               vendor=None):
        results = []
        snp_map = table_mapping.get_vendor_mappings().get(
            vendor, {}).get('accessor', {})
        query = snp_map.get('method', None)
        if query:
            tp_inst = self._get_instance(snp_map)
            if tp_inst:
                symbol_exch_mapping = \
                    self.unique_symbol_exchange_mapping(key_value,
                                                        exchange=exchange)
                if symbol_exch_mapping:
                    parameter_def = snp_map.get('parameters', [])
                    parameter_values = {}
                    parameter_values[
                        'symbol_exchange_mapping'] = symbol_exch_mapping

                    param = self._create_parameters_dictionary(
                        parameter_values,
                        parameter_def,
                        range_name,
                        range_value)
                    results = getattr(tp_inst, query)(**param)

        return results

    def _query_other_table(self, table_mapping, key_value,
                           exchange=None, range_value=None,
                           vendor=None):

        ret_value = []

        table_name = self._get_environment_table_name(table_mapping.get_table_name(vendor))
        if self._sbtcommon.stringutil.is_empty(table_name) or \
                not self._table_exists(table_name):
            raise Exception('Table does not exist for vendor within mapping.')

        if self._sbtcommon.stringutil.is_empty(key_value):
            raise Exception('Key value cannot be empty.')

        temp_key_value = key_value
        if self._sbtcommon.stringutil.is_not_empty(exchange) or \
                not self._sbtcommon.validate_uuid(temp_key_value):
            sem = self.unique_symbol_exchange_mapping(key_value, exchange)
            if self._sbtcommon.collectionsutil.is_not_empty(sem):
                temp_key_value = sem['guid']
            else:
                temp_key_value = None

        if self._sbtcommon.stringutil.is_empty(table_name):
            raise Exception('Key value cannot be resolved to a valid GUID.')

        key_id = table_mapping.get_key_attribute().get_id()
        if self._sbtcommon.stringutil.is_empty(key_id):
            key_id = 'guid'

        range_id = None
        if self._sbtcommon.stringutil.is_not_empty(range_value):
            range_id = table_mapping.get_range_attribute().get_id()

        results = self._query_table(table_name,
                                    key_id, temp_key_value,
                                    range_name=range_id,
                                    range_value=range_value)

        if self._sbtcommon.collectionsutil.is_empty(results) and \
                self._can_load_data_dynamically(table_mapping, vendor):
            self._load_data_dynamically(table_mapping,
                                        vendor,
                                        key_value)
            results = self._query_table(table_name,
                                        key_id, temp_key_value,
                                        range_name=range_id,
                                        range_value=range_value)

        if self._sbtcommon.collectionsutil.is_not_empty(results):
            ret_value = sorted(results, key=lambda k: k['timestamp'],
                               reverse=False)

        return ret_value

    def _create_parameters_dictionary(self, parameter_values,
                                      parameter_def,
                                      range_name,
                                      range_value):
        """
      Creates a dictionary of the parameters to be past to a method

      Args :
        parameter_values(dict) : Dictionary of parameters that can be used
        parameter_def(list) : List of parameter definitions associated with
                              method
    """
        params = OrderedDict()
        parameter_values_keys = parameter_values.keys()
        if self._sbtcommon.collectionsutil.is_not_empty(parameter_def):
            for param in parameter_def:
                action = param['action'].lower()
                value = param['value']
                if range_name and range_value and param['input'] == range_name:
                    params[param['input']] = range_value
                elif (action == 'replace' or action == 'provided') and \
                        value in parameter_values_keys:
                    params[param['input']] = parameter_values[value]
                elif action == 'calculate':
                    params[param['input']] = \
                        self._get_parameter_calculated_value(param['input'],
                                                             param['type'],
                                                             param['value'])
                elif action == 'static':
                    if value == '*None':
                        params[param['input']] = None
                    else:
                        params[param['input']] = value
                else:
                    raise Exception('Cannot map parameters')

        return params

    def _get_parameter_calculated_value(self, param, typ, value):
        """
      Performs a calculation on a parameter

      Args :
        param(str) : Parameter Name
        typ(str) : Parameter data type
        value : Value used in calculation

      Returns :
        (any) : Calculated Value
    """
        ret_value = None

        if param.endswith('_date') and \
                typ.lower() == 'string' and \
                (value.startswith('-') or value.startswith('+')):
            ret_value = self._sbtcommon.dateutil.get_relative_date(
                months=0, date_format='%Y%m%d', **{'days': int(value)})

        return ret_value

    def _get_instance(self, class_dict):
        ret_inst = None
        module_name = class_dict.get('module', None)
        class_name = class_dict.get('class', None)
        if module_name and class_name:
            key = module_name + '~' + class_name
            if key in self._class_instances:
                ret_inst = self._class_instances[key]
            else:
                class_module = importlib.import_module(module_name)
                ret_class = getattr(class_module, class_name)
                ret_inst = ret_class()
                with Lock():
                    self._class_instances[key] = ret_inst

        return ret_inst

    def load_cache(self):
        """
      Populates cached values in the class.
    """
        load = False

        if self._cache_loadtimestamp is None or \
                self._sbtcommon.collectionsutil.is_empty(
                    self._table_mappings) or \
                self._sbtcommon.collectionsutil.is_empty(self._data_types):
            load = True
        else:
            now = self._sbtcommon.dateutil.get_current_timestamp()
            diff = now - self._cache_loadtimestamp
            if diff.total_seconds() > 3600:
                load = True

        return load


class PortfolioListLoader(DynamoAccessor):
    def __init__(self):
        super().__init__(aws_profile_name=None,
                         aws_region_name=None,
                         aws_end_point_url=None)
        self._mp_accessor = MappingAccessor()
        self._intrinio_api = IntrinioApi()
        self._portfolio_api = PortfolioApi()

    def load_data(self):
        self._create_portfolio_lists()
        self._load_portfolio_list_stock_previous_day()
        self._load_top_performers()

    def _get_new_company(self, symbol, name):
        company = self._get_company_data_from_vendor(symbol)
        if self._sbtcommon.collectionsutil.is_empty(company):
            company = {
                "name": name,
                "ticker": symbol
            }

        return company

    def _get_company_data_from_vendor(self, symbol):
        company = {}

        try:
            company = self._intrinio_api.get_company(symbol)
        except Exception as exc:
            self._logger.error(
                "Unable to find company " + symbol + ":" + str(exc))
            company = {}

        return company

    def _create_portfolio_lists(self):
        """
      Creates portfolio lists
    """
        current_date = self._sbtcommon.dateutil.get_current_date_string()

        cur_list = self._query_table(self._get_environment_table_name('SBT_PORTFOLIO_LIST'),
                                     'list_name',
                                     'FIVE_DAY_MOVERS',
                                     range_name='date',
                                     range_value=current_date)

        if self._sbtcommon.collectionsutil.is_not_empty(cur_list):
            self._logger.info('Lists are already loaded for : ' +
                              current_date)
            return

        table_mapping = \
            self._mp_accessor.get_table_mapping(
                TableMappingGuid.US_COMPANY_STOCK_PRICE.value)

        portfolios = \
            self._mp_accessor.scan_symbol_exchange_mapping_for_sb_portfolios()

        top_five_day_movers = []
        top_thirty_day_movers = []

        for p in portfolios:
            results = self._mp_accessor.query_table_by_mapping(table_mapping,
                                                               p["guid"])

            if self._sbtcommon.collectionsutil.is_empty(results):
                continue

            sorted_results = sorted(results,
                                    key=lambda k: k['timestamp'],
                                    reverse=True)

            current_price = sorted_results[0]['values']['adj_close']

            if current_price == 0:
                continue

            if len(sorted_results) >= 5 and \
                    sorted_results[4]['values']['adj_close'] > 0:
                five_day = sorted_results[4]['values']['adj_close']
                value = \
                    (current_price - five_day) / five_day
                top_five_day_movers.append({
                    "guid": p["guid"],
                    "name": p["entity_name"],
                    "symbol": p["symbol"],
                    "change_value": value,
                    "change_percentage": (value * 100)
                })

            if len(sorted_results) >= 30 and \
                    sorted_results[29]['values']['adj_close'] > 0:
                thirty_day = sorted_results[29]['values']['adj_close']
                value = \
                    (current_price - thirty_day) / thirty_day
                top_thirty_day_movers.append({
                    "guid": p["guid"],
                    "name": p["entity_name"],
                    "symbol": p["symbol"],
                    "change_value": value,
                    "change_percentage": (value * 100)
                })

        sorted_top_five_day_movers = \
            sorted(top_five_day_movers,
                   key=lambda k: k['change_value'],
                   reverse=True)

        counter = 1
        for five in sorted_top_five_day_movers:
            five['rank'] = counter
            counter = counter + 1

        sorted_top_thirty_day_movers = \
            sorted(top_thirty_day_movers,
                   key=lambda k: k['change_value'],
                   reverse=True)

        counter = 1
        for thirty in sorted_top_thirty_day_movers:
            thirty['rank'] = counter
            counter = counter + 1

        timestamp = 0
        pattern = '%Y-%m-%d %H:%M:%S'
        time_value = time.strptime(current_date + ' 00:00:00', pattern)
        try:
            timestamp = int(time.mktime(time_value))
        except:
            ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
                                   tzinfo=datetime.timezone.utc)
            timestamp = (datetime.datetime(*time_value[:6],
                                           tzinfo=datetime.timezone.utc) - ep).total_seconds()

        self._save(self._get_environment_table_name('SBT_PORTFOLIO_LIST'),
                   {'list_name': 'FIVE_DAY_MOVERS',
                    'date': current_date,
                    'timestamp': timestamp,
                    'values': sorted_top_five_day_movers})

        self._save(self._get_environment_table_name('SBT_PORTFOLIO_LIST'),
                   {'list_name': 'THIRTY_DAY_MOVERS',
                    'date': current_date,
                    'timestamp': timestamp,
                    'values': sorted_top_thirty_day_movers})

    def _load_portfolio_list_stock_previous_day(self):
        list_names = ['NEWEST_RECOMMENDATIONS', 'CONVICTION_BUYS']

        filters = list()
        filters.append(
            self._create_filter_expression('symbols', "exists", None))
        filter_exp = self._build_filter_expression(filters)
        articles = self._scan_table('articles', filter_exp)

        for list_name in list_names:

            current_date = self._sbtcommon.dateutil.get_current_date_string()

            recommendations = {}
            for article in articles:
                if len(article['symbols']) == 0:
                    continue

                # ST-2275: Skip if Newswire or Ten Stock Trader
                if list_name == 'NEWEST_RECOMMENDATIONS' \
                        and (ArticleHelper.is_newswire(article)
                             or ArticleHelper.has_publication_code(article,
                                                                   'ttt')):
                    continue

                self._populate_previous_day_list(
                    article.get('createdAt', article.get('modifiedAt')),
                    self._get_previous_day_stock_price_filtered_list(list_name,
                                                                     article),
                    recommendations)

            if len(recommendations) == 0:
                return

            sorted_recommendations = sorted(list(recommendations.values()),
                                            key=lambda k: k['timestamp'],
                                            reverse=True)

            if list_name == 'CONVICTION_BUYS':
                self._populate_previous_day_stock_price(sorted_recommendations)
                sorted_recommendations = self._get_sorted_conviction_values(
                    sorted_recommendations)
                sorted_recommendations = sorted_recommendations[0:5]
            elif len(sorted_recommendations) > 15:
                sorted_recommendations = sorted_recommendations[0:15]
                self._populate_previous_day_stock_price(sorted_recommendations)

            timestamp = 0
            pattern = '%Y-%m-%d %H:%M:%S'
            time_value = time.strptime(current_date + ' 00:00:00', pattern)
            try:
                timestamp = int(time.mktime(time_value))
            except:
                ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
                                       tzinfo=datetime.timezone.utc)
                timestamp = (datetime.datetime(*time_value[:6],
                                               tzinfo=datetime.timezone.utc) - ep).total_seconds()

            record = {'list_name': list_name,
                      'date': current_date, 'timestamp': timestamp,
                      'values': sorted_recommendations}
            self._save(self._get_environment_table_name('SBT_PORTFOLIO_LIST'), record)

    def _get_sorted_conviction_values(self, sorted_recommendations):
        symbols = []
        for c_value in sorted_recommendations:
            symbols.append(c_value['symbol'])
        changes = self._get_conviction_buys_percentage_change(symbols)

        for c_value in sorted_recommendations:
            if c_value['symbol'] in changes:
                c_value['change_value'] = changes[c_value['symbol']][
                    'change_value']
                c_value['change_percentage'] = changes[c_value['symbol']][
                    'change_percentage']
            else:
                c_value['change_value'] = 0
                c_value['change_percentage'] = 0

        final_sorted = sorted(sorted_recommendations,
                              key=lambda k: k['change_value'],
                              reverse=True)

        counter = 1
        for fs in final_sorted:
            fs['rank'] = counter
            counter = counter + 1

        return final_sorted

    def _get_previous_day_stock_price_filtered_list(self, list_name, article):
        filtered_list = []

        filtered_results = None
        if list_name == 'NEWEST_RECOMMENDATIONS':
            filtered_results = filter(lambda x: x['analysis'] == 'recommended',
                                      article['symbols'])
        elif list_name == 'CONVICTION_BUYS':
            filtered_results = filter(lambda x: x['best_buy'],
                                      article['symbols'])

        if filtered_results is not None:
            filtered_list = list(filtered_results)

        return filtered_list

    def _populate_previous_day_stock_price(self, stock_price_list):
        if self._sbtcommon.collectionsutil.is_empty(stock_price_list):
            return

        counter = 1
        for s_recom in stock_price_list:
            s_recom['rank'] = counter
            stock_price = 0.00

            stock_table_mapping = self._mp_accessor.get_table_mapping(
                TableMappingGuid.US_COMPANY_STOCK_PRICE.value)

            results = self._mp_accessor.query_table_by_mapping(
                stock_table_mapping, s_recom['guid'])

            if self._sbtcommon.collectionsutil.is_empty(results):
                continue

            sorted_results = sorted(results, key=lambda k: k['timestamp'],
                                    reverse=True)
            temp_stock = sorted_results[0]
            if 'values' in temp_stock and 'adj_close' in temp_stock['values']:
                stock_price = temp_stock['values']['adj_close']

            s_recom['stock_price'] = stock_price
            counter = counter + 1

    def _populate_previous_day_list(self, timestamp, filtered_results,
                                    previous_day_list):
        if self._sbtcommon.collectionsutil.is_empty(filtered_results):
            return

        for r in filtered_results:
            symbol = r['symbol']
            if symbol not in previous_day_list:
                rec_symbol = {}
                symbol_mapping = self._mp_accessor.unique_symbol_exchange_mapping(
                    symbol)
                if symbol_mapping:
                    rec_symbol['guid'] = symbol_mapping['guid']
                    rec_symbol['symbol'] = symbol_mapping['symbol']
                    rec_symbol['name'] = symbol_mapping['entity_name']
                    rec_symbol['timestamp'] = timestamp
                    previous_day_list[symbol] = rec_symbol
            elif timestamp > previous_day_list[symbol]['timestamp']:
                previous_day_list[symbol]['timestamp'] = timestamp

    def _load_top_performers(self):
        current_date = self._sbtcommon.dateutil.get_current_date_string()

        timestamp = 0
        pattern = '%Y-%m-%d %H:%M:%S'
        time_value = time.strptime(current_date + ' 00:00:00', pattern)
        try:
            timestamp = int(time.mktime(time_value))
        except:
            ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
                                   tzinfo=datetime.timezone.utc)
            timestamp = (datetime.datetime(*time_value[:6],
                                           tzinfo=datetime.timezone.utc) - ep).total_seconds()

        base_url = "https://publishers.tradesmith.com/webservices/TradeService.asmx/GetInnerTop10GainsByPortfolioIds"
        guid = "Ex1mSRW2EkelrMyFZaSx1g"
        ids = "3423,3101,3093,3098,3099,3100,3415,3095,3102,3090,3096"
        url = base_url + "?guid=" + guid + "&portfolioIds=" + ids

        try:
            rval = None
            req = self._sbtcommon._get_request(url, "GET", None, None, None)
            if req.ok:
                rval = req.content.decode()

            if rval is None:
                return

            e = xml.etree.ElementTree.fromstring(rval)

            data = e.findall(
                './/{http://tempuri.org/}Data//{http://tempuri.org/}ListDTO//{http://tempuri.org/}List//{http://tempuri.org/}InnerSpecialTradeView')
            top_recommendations = {}

            for child in data:
                symbol = child.find('{http://tempuri.org/}Symbol').text
                p_change = child.find('{http://tempuri.org/}PercentGain').text

                symbol_mapping = self._mp_accessor.unique_symbol_exchange_mapping(
                    symbol)
                if symbol_mapping:
                    v = float(p_change)
                    if symbol in top_recommendations:
                        if top_recommendations[symbol][
                            'change_percentage'] < v:
                            top_recommendations[symbol][
                                'change_percentage'] = v
                            top_recommendations[symbol][
                                'change_value'] = round(v / 100, 4)
                    else:
                        top_recommendations[symbol] = {
                            "guid": symbol_mapping["guid"],
                            "name": symbol_mapping["entity_name"],
                            "symbol": symbol,
                            "change_value": round(v / 100, 4),
                            "change_percentage": v
                        }

            sorted_recs = sorted(list(top_recommendations.values()),
                                 key=lambda k: k['change_percentage'],
                                 reverse=True)

            record = {'list_name': "TOP_RECOMMENDATIONS",
                      'date': current_date, 'timestamp': timestamp,
                      'values': sorted_recs}
            self._save(self._get_environment_table_name('SBT_PORTFOLIO_LIST'), record)
        except Exception as e:
            self._logger.error("Failed to load top performers : " + str(e))

    def _get_conviction_buys_percentage_change(self, conviction_buys):
        conviction_buys_results = []

        data = self._get_portfolio_list_ids()

        for list_id in data:
            position_data = self._portfolio_api.get_position_local(list_id)
            if position_data is None or not position_data.get('success',
                                                              False) or \
                    'position' not in position_data or \
                    'data' not in position_data['position'] or \
                    'positions' not in position_data['position']['data']:
                continue

            for positions in position_data['position']['data']['positions']:
                self._append_to_conviction_buys_results(positions,
                                                        conviction_buys,
                                                        conviction_buys_results)

        sorted_cv = sorted(conviction_buys_results,
                           key=lambda k: k['change_value'], reverse=True)

        final_list = {}
        for v in sorted_cv:
            if v['symbol'] not in final_list:
                final_list[v['symbol']] = v

        return final_list

    def _get_portfolio_list_ids(self):
        ids = []

        data = self._portfolio_api.get_all_portfolio_info()
        if data and data.get('success', False):
            for tab in data.get('tabinfo', []):
                if 'Id' in tab:
                    ids.append(tab['Id'])

        return ids

    def _append_to_conviction_buys_results(self, positions,
                                           conviction_buys,
                                           conviction_buys_results):

        for groups in positions.get('groupPositions', []):
            symbol = None
            change = 0
            change_percentage = 0

            if 'columns' not in groups or \
                    'tickerPositionDesc' not in groups['columns'] or \
                    'dataSets' not in groups['columns'][
                'tickerPositionDesc'] or \
                    'return' not in groups['columns'] or \
                    'result' not in groups['columns']['return'] or \
                    not groups['columns']['return']['result']:
                continue

            for desc in groups['columns']['tickerPositionDesc']['dataSets']:
                if "Symbol" in desc:
                    symbol = desc['Symbol']

            if "return" in groups['columns'] and \
                    'result' in groups['columns']['return']:
                change_percentage = groups['columns']['return']['result']
                change = change_percentage / 100

            if symbol and symbol in conviction_buys:
                conviction_buys_results.append(
                    {"symbol": symbol,
                     "change_value": change,
                     "change_percentage": change_percentage})


class TimeseriesLoader(DynamoAccessor):
    """
    Used to load timeseries data in the data store.
  """

    def __init__(self, table_mapping,
                 symbol_mappings,
                 override_vendor_mapping=None,
                 vendor=None):
        """
      Constructor

      Args :
        table_mapping(TableMapping) : Table Mapping Object
        symbol_mappings(dict) : Symbol Exchange Mapping
        override_vendor_mapping(dict) : Overrides vendor mapping
        vendor(str) : Vendor key
    """

        super().__init__(aws_profile_name=None,
                         aws_region_name=None,
                         aws_end_point_url=None)

        if symbol_mappings is None:
            raise Exception('Symbol Mappings cannot be null.')

        if table_mapping is None:
            raise Exception('Table Mapping cannot be null.')

        if table_mapping.get_key_attribute() is None:
            raise Exception('Key Attribute is required.')

        if table_mapping.get_range_attribute() is None:
            raise Exception('Range Attribute is required.')

        if self._sbtcommon.collectionsutil.is_empty(
                table_mapping.get_value_attributes()):
            raise Exception('Value attributes cannot be empty.')

        self._table_mapping = table_mapping

        if self._sbtcommon.stringutil.is_empty(vendor):
            self._vendor = self._table_mapping.get_default_vendor()
        else:
            self._vendor = vendor

        self._vendor_mappings = None
        if self._vendor in table_mapping.get_vendor_mappings().keys():
            self._vendor_mappings = table_mapping.get_vendor_mappings()[
                self._vendor]

        if self._sbtcommon.collectionsutil.is_empty(self._vendor_mappings):
            raise Exception('Vendor Mappings cannot be empty.')

        if self._sbtcommon.collectionsutil.is_not_empty(
                override_vendor_mapping):
            self._vendor_mappings = override_vendor_mapping

        self._reload = False
        if 'reload' in self._vendor_mappings['load'].keys():
            self._reload = self._vendor_mappings['load']['reload']

        self._extraction_type = self._vendor_mappings['extraction']['type']
        self._load_type = self._vendor_mappings['load']['type']

        self._symbol_mappings = symbol_mappings
        self._standard_load = True
        self._standard_extraction = True
        self._extract_method = None
        self._extract_parameters = None
        self._extraction_class_instance = None
        if self._extraction_type.lower() != 'standard':
            self._standard_extraction = False
            extraction_module = self._vendor_mappings['extraction'][
                self._extraction_type]['module']
            extraction_class = self._vendor_mappings['extraction'][
                self._extraction_type]['class']
            self._extraction_method = self._vendor_mappings['extraction'][
                self._extraction_type]['method']
            self._extraction_parameters = self._vendor_mappings['extraction'][
                self._extraction_type]['parameters']
            module = importlib.import_module(extraction_module)
            my_class = getattr(module, extraction_class)
            self._extraction_class_instance = my_class()

    def load_data(self):
        """
      This method loads time series data for a specified vendor.
    """
        guids = []

        for s_mapping in self._symbol_mappings:
            extracted_data = None
            success = {}
            success['guid'] = s_mapping['guid']
            try:
                if self._standard_extraction:
                    extracted_data = self._standard_extraction(s_mapping)
                else:
                    extracted_data = self._non_standard_extraction(s_mapping)

                converted_data = self._get_converted_extract_data(s_mapping,
                                                                  extracted_data)

                if self._sbtcommon.collectionsutil.is_not_empty(
                        converted_data):
                    if self._standard_load:
                        self._standard_data_load(s_mapping, converted_data)
                    else:
                        self._non_standard_data_load(s_mapping, converted_data)

                success['success'] = True
            except Exception as e:
                success['success'] = False
                success['error'] = str(e)

            guids.append(success)

        return guids

    def _standard_data_load(self, s_mapping, data):
        """
      This method is called if the standard load process
      is used for a vendor.

      Args :
        s_mapping(dict) : Symbol Exchange Mapping
        data(list) : Data to be loaded

    """
        load_data = []

        table_name = self._table_mapping.get_table_name()
        key_id = self._table_mapping.get_key_attribute().get_id()
        key_value = self._get_key_value(s_mapping)
        range_id = self._table_mapping.get_range_attribute().get_id()

        sorted_data = []
        if self._sbtcommon.collectionsutil.is_not_empty(data):
            sorted_data = sorted(data, key=lambda k: k[range_id], reverse=True)

        last_date = '0000-00-00'
        check_data = []

        if not self._reload:
            check_data = self._query_table(table_name,
                                           key_id,
                                           key_value)
        else:
            self._logger.info('Reloading data for guid : ' + key_id)

        if self._sbtcommon.collectionsutil.is_not_empty(check_data):
            sorted_check_data = sorted(check_data, key=lambda k: k[range_id],
                                       reverse=True)
            last_date = sorted_check_data[0][range_id]

        for d in sorted_data:
            if d[range_id] > last_date:
                load_data.append(d)
            else:
                break

        self._batch_save(self._table_mapping.get_table_name(), load_data)

    def _non_standard_data_load(self, data):
        """
      This method is called if code has been
      developed to load a vendors data.

      Args :
        s_mapping(dict) : Symbol Exchange Mapping
    """
        self._logger.info('_non_standard_data_load data ' +
                          str(data))

        self._logger.error('Method is not implemented for Time Series data.')

    def _standard_extraction(self, s_mapping):
        """
      This method is called if the standard extraction process
      is used for a vendor.

      Args :
        s_mapping(dict) : Symbol Exchange Mapping

      Returns :
        list : List of dictionaries derived from JSON
    """

        self._logger.info('_standard_extraction symbol exchange mapping ' +
                          str(s_mapping))

        self._logger.error('Method is not implemented for Time Series data.')
        return []

    def _non_standard_extraction(self, s_mapping):
        """
      This method is called if code has been
      developed to extract vendor data.

      Args :
        s_mapping(dict) : Symbol Exchange Mapping

      Returns :
        list : List of dictionaries derived from JSON
    """
        return_data = []

        available_param = s_mapping.copy()

        method_params = self._create_parameters_dictionary(available_param,
                                                           self._extraction_parameters)
        self._logger.info(method_params)
        response = getattr(self._extraction_class_instance,
                           self._extraction_method)(**method_params)
        if self._sbtcommon.collectionsutil.is_not_empty(response):
            return_data = response

        return return_data

    def _get_converted_extract_data(self, s_mapping, extracted_data):
        """
      Converts all extracted values for a symbol exhange mapping into
      the time series format.

      Args :
        extracted_data(list) : Data extracted from a vendor
        s_mapping(dict) : Symbol exchange mapping

      Returns :
        (list) : Time Series Data
    """
        converted_data = []

        if self._sbtcommon.collectionsutil.is_not_empty(extracted_data):
            for e_data in extracted_data:
                ts_record = self._create_timeseries_record(s_mapping, e_data)
                if self._sbtcommon.collectionsutil.is_not_empty(ts_record):
                    converted_data.append(ts_record)

        return converted_data

    def _create_parameters_dictionary(self, parameter_values, parameter_def):
        """
      Creates a dictionary of the parameters to be past to a method

      Args :
        parameter_values(dict) : Dictionary of parameters that can be used
        parameter_def(list) : List of parameter definitions associated with
                              method
    """
        params = OrderedDict()
        parameter_values_keys = parameter_values.keys()
        if self._sbtcommon.collectionsutil.is_not_empty(parameter_def):
            for param in parameter_def:
                action = param['action'].lower()
                value = param['value']
                if action == 'replace' and value in parameter_values_keys:
                    params[param['input']] = parameter_values[value]
                elif action == 'calculate':
                    params[param['input']] = \
                        self._get_parameter_calculated_value(param['input'],
                                                             param['type'],
                                                             param['value'])
                elif action == 'static':
                    params[param['input']] = value
                else:
                    raise Exception('Cannot map parameters')

        return params

    def _get_parameter_calculated_value(self, param, typ, value):
        """
      Performs a calculation on a parameter

      Args :
        param(str) : Parameter Name
        typ(str) : Parameter data type
        value : Value used in calculation

      Returns :
        (any) : Calculated Value
    """
        ret_value = None

        if param.endswith('_date') and \
                typ.lower() == 'string' and \
                (value.startswith('-') or value.startswith('+')):
            ret_value = self._sbtcommon.dateutil.get_relative_date(
                months=0, date_format='%Y%m%d', **{'days': int(value)})

        return ret_value

    def _create_timeseries_record(self, symbol_mapping, row_value):
        """
      Create a Time Series dictionary

      Args :
        symbol_mapping(dict) : Symbol Exchange Mapping
        row_value(dict) : Dictionary of values to be converted.

      Returns :
        (dict) : Time Series Dictionary
    """
        row = {}
        key_value = self._get_key_value(symbol_mapping)
        range_value = self._get_range_value(row_value)

        if self._sbtcommon.stringutil.is_empty(key_value) or \
                self._sbtcommon.stringutil.is_empty(range_value):
            return row

        row[self._table_mapping.get_key_attribute().get_id()] = key_value
        row[self._table_mapping.get_range_attribute().get_id()] = range_value

        computed_field = \
            self._table_mapping.get_range_attribute().get_computed_field()
        if self._sbtcommon.stringutil.is_not_empty(computed_field):
            row[computed_field] = \
                self._get_computed_value(computed_field,
                                         self._table_mapping.get_range_attribute(),
                                         range_value)

        values = {}

        for attr in self._table_mapping.get_value_attributes():
            values[attr.get_id()] = \
                self._get_value(attr.get_vendor_attribute_id(self._vendor),
                                attr.get_vendor_data_type(self._vendor),
                                row_value)

        row['values'] = values

        return row

    def _get_computed_value(self, computed_field, attr, value):
        """
      Generates a computed value for the field name.

      Args :
        computed_field(str) : Computed value id
        attr_type(str) : Data Type of the computed value
        value : Source value to compute the value

      Returns :
        (any) Computed Value
    """
        computed_value = 'N/A'

        if computed_field == 'timestamp':
            pattern = '%Y-%m-%d %H:%M:%S'
            time_value = time.strptime(value + ' 00:00:00', pattern)
            try:
                computed_value = int(time.mktime(time_value))
            except:
                ep = datetime.datetime(1970, 1, 1, 0, 0, 0,
                                       tzinfo=datetime.timezone.utc)
                computed_value = (datetime.datetime(*time_value[:6],
                                                    tzinfo=datetime.timezone.utc) - ep).total_seconds()

        return computed_value

    def _get_range_value(self, resp_dict):
        """
      Retrieves the range value from the response dictionary associated
      with the range key.

      Args :
        resp_dict(dict) : Dictionary containing value to be pulled

      Returns :
        (any) : Value
    """
        range_attr = self._table_mapping.get_range_attribute()
        return self._get_value(
            range_attr.get_vendor_attribute_id(
                self._vendor),
            range_attr.get_vendor_data_type(
                self._vendor),
            resp_dict)

    def _get_key_value(self, symbol_mapping):
        """
      Retrieves the key value from the response dictionary associated
      with the key.

      Args :
        resp_dict(dict) : Dictionary containing value to be pulled

      Returns :
        (any) : Value
    """
        key_attr = self._table_mapping.get_key_attribute()
        return symbol_mapping[key_attr.get_id().lower()]

    def _get_value(self, id_key, attr_type, resp_dict):
        """
      Retrieves the value from the response dictionary associated
      with the key.

      Args :
        id_key(str) : Identifies value to be pulled from Dictionary
        attr_type(str) : Data Type of the attribute
        resp_dict(dict) : Dictionary containing value to be pulled

      Returns :
        (any) : Value
    """
        value = None

        is_bigdec = self._is_attr_type_bigdecimal(attr_type)
        is_str = self._is_attr_type_string(attr_type)

        # Set default value for attribute type
        if is_bigdec:
            value = 0
        elif is_str:
            value = 'N/A'

        if self._sbtcommon.collectionsutil.is_not_empty(resp_dict) and \
                id_key in resp_dict.keys():
            value = resp_dict[id_key]

        return value

    def _is_attr_type_bigdecimal(self, attr_type):
        """
      Determines whether an attribute type is a big decimal

      Args :
        attr_type(str) : Attribute Type

      Returns :
        (bool) : True if the attribute type is a big decimal, otherwise false
    """
        return self._sbtcommon.stringutil.is_not_empty(attr_type) and \
               attr_type.upper() == 'BIGDECIMAL'

    def _is_attr_type_string(self, attr_type):
        """
      Determines whether an attribute type is a string

      Args :
        attr_type(str) : Attribute Type

      Returns :
        (bool) : True if the attribute type is a string, otherwise false
    """
        return self._sbtcommon.stringutil.is_not_empty(attr_type) and \
               attr_type.upper() == 'STRING'


class DataLoader():
    """
    Used to load data into the data store.
  """

    def __init__(self):
        """
      Constructor
    """
        self._mp_accessor = MappingAccessor()
        self._portfolio_list_loader = PortfolioListLoader()
        self._sbtcommon = SbtCommon()
        self._logger = self._sbtcommon.get_global_logger()

    def load_data(self):
        """
      Loads all mapping data into the appropriate datastore.
    """
        symbol_mappings_dict = {}
        symbol_mappings = self._mp_accessor.scan_symbol_exchange_mapping()
        for sm in symbol_mappings:
            if sm['guid'] not in symbol_mappings_dict.keys():
                symbol_mappings_dict[sm['guid']] = sm

        table_mappings = self._mp_accessor.get_table_mappings_requiring_data_laod()
        for table_mapping in table_mappings:
            data_load = self._get_table_mapping_data_load(table_mapping,
                                                          symbol_mappings_dict)

            if self._sbtcommon.collectionsutil.is_empty(data_load):
                continue

            self._mp_accessor._batch_save(
                self._mp_accessor.table_sbt_metadata_table_data_load,
                data_load)

            for vdr in table_mapping.get_vendor_mappings().keys():
                vendor_symbol_mappings = self._get_vendor_symbol_mappings(
                    data_load,
                    symbol_mappings_dict,
                    vdr)

                if self._sbtcommon.collectionsutil.is_empty(
                        vendor_symbol_mappings):
                    continue

                if table_mapping.is_timeseries_data_type():
                    tl = TimeseriesLoader(table_mapping,
                                          vendor_symbol_mappings,
                                          vendor=vdr)
                    processed_guids = tl.load_data()
                    self._set_vendor_timestamp(data_load, processed_guids, vdr)

            self._set_data_load_process(data_load)
            self._mp_accessor._batch_save(
                self._mp_accessor.table_sbt_metadata_table_data_load,
                data_load)
        self._post_processing()

    def _post_processing(self):
        """
      Runs post processing tasks
    """
        self._portfolio_list_loader.load_data()

    def _set_data_load_process(self, data_load):
        """
      Sets the data load dictionary to indicate that it needs
      to be loaded into the system.

      Args :
        data_load(list) : List of data load dictionaries
    """
        for dl in data_load:
            process = False

            status_code = 0

            if 'vendor_mapping' in dl.keys():
                for v in dl['vendor_mapping']:
                    if dl['vendor_mapping'][v]['load_timestamp'] == \
                            '00-00-0000 00:00:00 GMT':
                        process = True
                        status_code = 1
                    elif dl['vendor_mapping'][v]['failed_to_load']:
                        status_code = 2

            dl['status_code'] = status_code

            if dl['process'] != process:
                dl['process'] = process

    def _set_vendor_timestamp(self, data_load, symbol_mapping_guids, vendor):
        """
      Sets the vendor timestamp after the load process is complete.
      Also, set the record in an error state if an error occurred.

      Args :
        data_load(list) : List of data load dictionaries
        symbol_mapping_guids(list) : List of dictionaries for processed symbols
        vendor(str) : Vendor Identifier
    """
        timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(
            datetime.datetime.utcnow())
        success_guids = [d['guid'] for d in list(filter(lambda x:
                                                        x['success'] == True,
                                                        symbol_mapping_guids))]

        failed_filter = list(filter(lambda x: x['success'] == False,
                                    symbol_mapping_guids))

        for dl in data_load:
            if 'vendor_mapping' not in dl.keys() or \
                    vendor not in dl['vendor_mapping'].keys() or \
                    dl['vendor_mapping'][vendor]['load_timestamp'] != \
                    '00-00-0000 00:00:00 GMT':
                continue

            failed = False
            failed_guid = []

            if dl['symbol_mapping_guid'] not in success_guids and \
                    len(failed_filter) > 0:
                failed_guid = list(
                    filter(lambda x: x['guid'] == dl['symbol_mapping_guid'],
                           failed_filter))

                failed = len(failed_guid) > 0

            if failed or dl['symbol_mapping_guid'] in success_guids:
                dl['vendor_mapping'][vendor]['load_timestamp'] = timestamp
                dl['vendor_mapping'][vendor]['failed_to_load'] = failed
                if failed:
                    dl['vendor_mapping'][vendor]['error_message'] = \
                        failed_guid[0]['error']

    def _get_vendor_symbol_mappings(self, data_load,
                                    symbol_mappings_dict,
                                    vendor):
        """
      Returns a list of symbols mappings based on the
      data load objects

      Args :
        data_load(list) : List of data load dictionaries
        symbol_mappings_dict(dict) : Dictionary of available symbol exch maps
        vendor(str) : Vendor ID

      Returns :
        (list) Symbol Exchange Mappings

    """
        symbol_mappings = []
        for dl in data_load:
            if 'vendor_mapping' in dl.keys() and \
                    vendor in dl['vendor_mapping'].keys() and \
                    dl['vendor_mapping'][vendor]['load_timestamp'] == \
                    '00-00-0000 00:00:00 GMT' and \
                    dl['symbol_mapping_guid'] in symbol_mappings_dict.keys():
                symbol_mappings.append(
                    symbol_mappings_dict[dl['symbol_mapping_guid']])

        return symbol_mappings

    def _get_table_mapping_data_load(self, table_mapping,
                                     symbol_mappings_dict):
        """
      Returns data load dictionaries associated with the table and symbol
      mappings

      Args :
        table_mapping(TableMapping) : Table Mapping Object
        symbol_mappings_dict(dict) : Dictionary of symbol exchange mappings

      Returns :
        (list) : List of Data Load Dictionaries
    """
        pull_date = self._sbtcommon.dateutil.get_current_date_string()
        vendors = table_mapping.get_vendor_mappings().keys()

        existing_data_load = self._mp_accessor._query_table(
            MappingAccessor.table_sbt_metadata_table_data_load,
            'table_mapping_guid', table_mapping.get_guid())

        ret_data = []
        existing_data_load_dict = {}
        for dl in existing_data_load:
            if dl['process']:
                ret_data.append(dl)
            existing_data_load_dict[dl['symbol_mapping_guid']] = dl

        if self._sbtcommon.collectionsutil.is_not_empty(ret_data):
            return ret_data

        processed_guids = []
        for symbol_mapping in list(symbol_mappings_dict.values()):
            if symbol_mapping['guid'] in processed_guids or \
                    'table_mapping' not in symbol_mapping.keys() or \
                    table_mapping.get_guid() not in symbol_mapping[
                'table_mapping']:
                continue

            data_load = \
                self._get_data_load(table_mapping, symbol_mapping,
                                    existing_data_load_dict, vendors,
                                    pull_date)

            if self._sbtcommon.collectionsutil.is_not_empty(data_load):
                ret_data.append(data_load)

            processed_guids.append(symbol_mapping['guid'])

        return ret_data

    def _get_data_load(self, table_mapping, symbol_mapping,
                       existing_data_load_dict,
                       vendors, pull_date):
        """
      Returns a populated data load object.

      Args :
        table_mapping(TableMapping) : Table Mapping Object
        symbol_mapping(dict) : Symbol Exchange Mapping
        existing_data_load_dict(dict) : Existing dataload objects
        vendors(list) : Vendor ID's
        pull_date(str) : Date indicating when the data was retrieved

      Returns :
        (dict)
    """
        load = None
        data_load = None
        if symbol_mapping['guid'] in existing_data_load_dict.keys():
            data_load = existing_data_load_dict[symbol_mapping['guid']]

        temp_load = None
        if self._sbtcommon.collectionsutil.is_not_empty(data_load):
            temp_load = data_load
        else:
            temp_load = {}
            temp_load['table_mapping_guid'] = table_mapping.get_guid()
            temp_load['symbol_mapping_guid'] = symbol_mapping['guid']

        temp_load['symbol'] = symbol_mapping['symbol']
        temp_load['table_name'] = table_mapping.get_name()

        if 'vendor_mapping' not in temp_load.keys():
            temp_load['vendor_mapping'] = {}

        process = False
        for v in vendors:
            if self._skip_processing(table_mapping, symbol_mapping, v):
                continue

            process = True
            if v not in temp_load['vendor_mapping'].keys():
                vendor_load = {}
                temp_load['vendor_mapping'][v] = vendor_load

            if 'error_message' in temp_load['vendor_mapping'][v].keys():
                temp_load['vendor_mapping'][v].pop('error_message')

            if 'failed_to_load' in temp_load['vendor_mapping'][v].keys():
                temp_load['vendor_mapping'][v].pop('failed_to_load')

            temp_load['vendor_mapping'][v]['table_name'] = \
                table_mapping.get_table_name(vendor=v)
            temp_load['vendor_mapping'][v]['load_timestamp'] = \
                '00-00-0000 00:00:00 GMT'
            temp_load['vendor_mapping'][v]['pull_date'] = pull_date

        if process:
            temp_load['process'] = process
            temp_load['status_code'] = 1
            load = temp_load

        return load

    def _skip_processing(self, table_mapping, symbol_mapping,
                         vend):
        """
      Checks to see if the symbol exchange mapping should be processed.

      Args :
        s_mapping(dict) : Symbol Exchange Mapping

      Returns :
        boolean : True to skip processing
    """
        skip_processing = False
        load_only_if_values_exists = False
        vendor_mappings = None

        if vend in table_mapping.get_vendor_mappings().keys():
            vendor_mappings = table_mapping.get_vendor_mappings()[vend]

        if self._sbtcommon.collectionsutil.is_empty(vendor_mappings):
            skip_processing = True
        elif 'only_if_values_exists' in vendor_mappings['load'].keys():
            load_only_if_values_exists = vendor_mappings['load'][
                'only_if_values_exists']

        # If guid is not valid for the symbol exchange mapping
        if not skip_processing and \
                ('table_mapping' not in symbol_mapping.keys() or \
                 table_mapping.get_guid() not in symbol_mapping[
                     'table_mapping']):
            skip_processing = True

        # If the _load_only_if_values_exists attribute is true load only if data
        # is already available for the mapping
        if not skip_processing and load_only_if_values_exists:
            check = self._mp_accessor._query_table(
                table_mapping.get_table_name(vendor=vend),
                table_mapping.get_key_attribute().get_id(),
                symbol_mapping['guid'])
            if self._sbtcommon.collectionsutil.is_empty(check):
                self._logger.info(symbol_mapping['symbol'] +
                                  ' has not been loaded into the table')
                skip_processing = True

        return skip_processing


class MPAccessor(DynamoAccessor):
    _table_name = 'SBT_SYMBOL_EXCHANGE_MAPPING'

    def __init__(self, aws_profile_name=None, aws_region_name=None,
                 aws_end_point_url=None):
        super().__init__(aws_profile_name, aws_region_name, aws_end_point_url)
        self._ids = None

    def scan_for_commodities(self, table_name='SBT_SYMBOL_EXCHANGE_MAPPING'):
        filter_expression = 'attribute_exists(commodity_code)'
        return self._scan_table(table_name=table_name,
                                filter_exp=filter_expression)

    def scan_for_ids(self):
        items = self._scan_table(table_name=self._table_name, filter_exp=None)
        guids = set()
        for item in items:
            guids.add(item['guid'])

        self._ids = guids

    # Takes a list of tags
    def symbol_by_tag(self, tags):
        if len(tags) > 1:
            filter_str = 'tags contains ' + tags[0]
            for tag in tags[1:]:
                filter_str += ' OR tags contains {}'.format(tag)
            items = self._scan_table_with_filter_str(self._table_name,
                                                     filter_str)
        else:
            items = self._scan_table_with_filter_str(self._table_name,
                                                     'tags contains {}'.format(
                                                         tags[0]))
        return items

    def create_id(self, symbol, exchange, **kwargs):
        if not self._ids:
            self.scan_for_ids()

        while True:
            new_id = str(self._sbtcommon.get_uuid())
            if new_id not in self._ids:
                self._ids.add(new_id)
                break

        item = {'symbol': symbol, 'exchange': exchange, 'guid': new_id,
                **kwargs}
        self._save(table_name=self._table_name, data=item)
        return new_id
