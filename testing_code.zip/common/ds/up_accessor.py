import base64
import os
import logging
import traceback
import hashlib
import datetime
import simplejson as json
import psycopg2
import string
import random

from django.core.validators import validate_email
from django.core.exceptions import ValidationError

from enum import Enum
from sbt_common import SimpleJsonDateTimeEncoder
from sbt_common import SbtGlobalCommon
from sbt_common import timing
from pg_accessor import PostgresAccessor
from ast import literal_eval
from sbt_common import deprecated
from barchart_accessor import BarchartAccessor
from services.sbt_email import send_email

MAXINT = 2147483647


class RegistrationException(ValueError):
    """
    Exception is raise login is invalid.
  """
    pass


class LoginException(ValueError):
    """
    Exception is raise login is invalid.
  """
    pass


class IamException(ValueError):
    """
    Exception is raise login is invalid.
  """
    pass


class Status(Enum):
    ACTIVE = 1
    PENDING = 2
    DELETED = 3


class UserProfileAction(Enum):
    LOGIN = 'LOGIN'
    LOG_OFF = 'LOGOFF'
    IMPERSONATION = 'IMPERSONATION'
    REGISTRATION = 'REGISTRATION'
    FAILED_REGISTRATION = 'FAILED REGISTRATION'
    FAILED_LOGIN = 'FAILED LOGIN'
    REGISTRATION_ACTIVATION = 'REGISTRATION ACTIVATION'


class UserProfileRole(Enum):
    FREE_USER = '238761b9-a22e-4e52-b4b8-c44e66354d31'
    ALLIANCE = '4c24604a-9515-485c-a256-556daf68c38d'


class UserProfileType(Enum):
    FREE_USER = '20a45d6f-7d71-44cc-9737-f727433c1568'
    STANSBERRY_USER = '5c8cbe03-1485-43eb-9e55-38eff445f93e'


class UserProfileUtility():

    @staticmethod
    def get_decoded_value(value):
        return SbtGlobalCommon.securityutil.base64_to_string(
            UserProfileUtility.get_encoded_value(value))

    @staticmethod
    def get_encoded_value_string(value):
        return UserProfileUtility.get_encoded_value(value).decode('utf-8')

    @staticmethod
    def get_encoded_value(value):
        if value and isinstance(value, str) and \
                not SbtGlobalCommon.securityutil.is_base64(value.encode(
                    encoding='utf_8')):
            value = SbtGlobalCommon.securityutil.string_to_base64(value)

        if value and isinstance(value, str):
            value = value.encode(encoding='utf_8')

        return value


class IamAccessor(PostgresAccessor):
    def __init__(self):
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_logger(logging.INFO, type(self).__name__,
                                                  None, "asctime", "name", "levelname", "funcName", "message")

        self._config = SbtGlobalCommon.get_sbt_config()['security']
        self._iam = self._config['iam']

        self._admins = self._config.get('admins', None)
        if self._admins:
            self._logger.info('Admins : ' + str(self._admins))

        self._white_list = self._config.get('white_list', None)
        if self._white_list:
            self._logger.info('White Listed environment : ' + str(self._white_list))

        self._free_publications = \
            self._config.get('free_publications', {})

    @timing
    def authenticate(self, email64, pwd64):
        """
    Authenticates the specified terminal user in IAM
    :param email64:
    :param pwd64:
    :return:
    """
        self._logger.info("Performing IAM authentication")

        rval = False
        snaid = ""
        affiliate_id = ""

        if not email64:
            self._logger.error("Base64 email not provided")
        elif not pwd64:
            self._logger.error("Base64 pwd not provided")
        elif self._is_white_listed(email64):
            try:
                email64 = UserProfileUtility.get_encoded_value_string(email64)
                pwd64 = UserProfileUtility.get_encoded_value_string(pwd64)

                headers = {'Token': self._iam['iam_token']}
                url = self._iam['iam_auth']
                url += '/username/' + email64
                url += '/password/' + pwd64

                self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
                res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)

                if res and 'customerNumber' in res:
                    snaid = res['customerNumber']
                    affiliate_id = res.get('affiliateLevelBrand', '-1')
                    rval = self._has_access(snaid)
                else:
                    self._logger.warn('IAM Authentication Failed')
            except Exception as e:
                self._logger.error('Encountered exception: ' + str(e))
        else:
            self._logger.error('User "' + email64 + '" is not white listed')

        return rval, snaid, affiliate_id

    def get_subscriptions(self, snaid):
        """
    Retrieves the specified users subscriptions
    :param snaid:
    :return:
    """
        self._logger.info('Retrieving subscriptions for user snaid: ' + snaid)

        rval = []

        try:
            headers = {'Token': self._iam['iam_token']}
            url = self._iam['iam_subs']
            url += '/' + snaid

            self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
            res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)

            if res:
                self._append_free_subscriptions(snaid, res)
                rval = res
            else:
                self._logger.info('Failed to retrieve subscriptions for user: ' + snaid)
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e))

        return rval

    def get_address_data(self, snaid):
        self._logger.info('Retrieving addres info for: ' + snaid)

        headers = {'Token': self._iam['iam_token']}
        url = self._iam['iam_addr']
        url += '/' + snaid

        self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
        return self._sbtcommon.makerequest(url, 'GET', None, None, headers)

    def get_name(self, snaid):
        """
    Retrieves the specified users first and last name
    :param snaid:
    :return:
    """
        self._logger.info('Retrieving name for: ' + snaid)

        res = self.get_address_data(snaid)

        if res and 'firstName' in res and 'lastName' in res:
            if res['firstName']:
                rval = res['firstName']

            if res['lastName']:
                if len(rval) > 0:
                    rval = rval + ' '
                rval = rval + res['lastName']
        else:
            self._logger.warn('Unable to retrieve name for: ' + snaid)

        return rval

    def change_password(self, user_name, credentials):
        if not user_name or not credentials:
            self._logger.error('Failed to provide user_name or password')
            return False

        converted_user_name = UserProfileUtility.get_decoded_value(user_name)
        converted_credentials = UserProfileUtility.get_decoded_value(credentials)

        headers = {'Token': self._iam['iam_password_token'], 'Content-Type': 'application/json'}
        url = self._iam['iam_password_reset']

        data = {
            'username': converted_user_name,
            "newPassword": converted_credentials
        }

        self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
        res = self._sbtcommon.makerequest(url, 'POST', data, None, headers)

        if res and res.get('status', 'FAILED') == 'OK' and \
                res.get('errorCode', -1) == 0:
            return True
        else:
            self._logger.error('Failed to change password : (' +
                               str(res.get('errorCode', -1)) + ') ' +
                               res.get('message', 'Failed to change password.'))
            return False

    def create_new_user(self, email,
                        first_name, last_name,
                        apply_white_list=True):

        if not email or not first_name or not last_name:
            raise IamException('Required parameters ' +
                               '(email,first_name, and last_name) were not ' +
                               'provided.')

        if apply_white_list and not self._is_white_listed(email):
            raise IamException(email + ' is white listed.')

        rval = {}

        headers = {'x-api-key': self._iam['iam_eletter_token'], 'Content-Type': 'application/json'}
        url = self._iam['iam_eletter_create']

        data = {
            "batchId": None,
            "email": email,
            "leadId": "",
            "emailTemplateUrl": "",
            "emailSubject": "",
            "firstName": first_name,
            "lastName": last_name,
            "street": "",
            "city": "",
            "state": "",
            "zipcode": "",
            "address": "",
            "country": "",
            "phone": "",
            "pubCode": self._iam['iam_eletter_pub_code'],
            "campaignId": "",
            "effortId": "",
            "brandId": self._iam['iam_eletter_brand_id'],
            "baseUrl": "",
            "assetId": "",
            "level": "",
            "doubleOptInParams": "",
            "campaignType": "",
            "placementId": "",
            "coiOptinSource": "",
            "source": self._iam['iam_eletter_source'],
            "snaid": "",
            "crmId": "",
            "encryptedSnaid": None,
            "issms": False,
            "isdnp": False,
            "createdBy": None,
            "affiliateId": None,
            "pubType": None,
            "referrerSnaid": None,
            "utm_campaign": "",
            "utm_content": "",
            "utm_medium": "",
            "utm_source": "",
            "utm_term": "",
            "signUpDate": None,
            "authOptIn": self._iam['iam_eletter_auth_opt_in']
        }

        self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
        res = self._sbtcommon.makerequest(url, 'POST', [data], None, headers)

        if res and isinstance(res, list) and len(res) > 0:
            temp = res[0]
            if temp.get('success', True) and \
                    temp.get('snaid', '').upper().startswith('SAC'):
                rval = temp
            else:
                raise IamException('The create eletter API was not successful')
        else:
            raise IamException('Did not receive a response from create eletter API')

        return rval

    def get_stansberry_affiliate(self):
        return "1001"

    def get_investor_affiliate(self):
        return self._iam.get('"iam_eletter_brand_id"', '1003')

    def _has_access(self, snaid):
        rval = False

        headers = {'Token': self._iam['iam_token']}

        if snaid:
            url = self._iam['iam_subs']
            url += '/' + snaid
            self._logger.debug(
                'Get Request url: ' + url + '\nHeaders: ' + str(headers))
            res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)
            if res:
                for i in res:
                    item = i['id']['item']
                    if item and item['itemNumber'] in ['TRM', 'FTRM']:
                        self._logger.info('Authenticated: ' + snaid)
                        rval = True
                        break
                if not rval:
                    self._logger.info('TRM access denied for customer: ' + snaid)

        return rval

    def _append_free_subscriptions(self, snaid, publications):
        if not snaid or publications is None:
            return

        user_pub_nos = []
        for p in publications:
            user_pub = p.get('id', {}).get('item', {}).get('itemNumber', '')
            if user_pub:
                user_pub_nos.append(user_pub)

        for f in self._free_publications.items():
            if f[0] in user_pub_nos:
                continue

            ent = {
                "memberOrg": None,
                "memberCat": None,
                "expirationDate": "0000-00-00",
                "levelWeight": 100,
                "startDate": "2018-08-16",
                "circStatus": "R",
                "deliveryCode": None,
                "issuesRemaining": 0,
                "finalExpirationDate": "0000-00-00",
                "renewMethod": "A",
                "subType": None,
                "termNumber": 0,
                "temp": False,
                "term": 0,
                "level": "LIFETIME",
                "status": "ACTIVE",
                "id": {
                    "customerNumber": snaid,
                    "subRef": "",
                    "item": {
                        "itemNumber": f[0],
                        "itemDescription": f[1],
                        "itemType": ""
                    }
                }
            }

            publications.append(ent)

    def _is_white_listed(self, email):
        white_listed = False

        if email and self._white_list:
            string_email = None

            if isinstance(email, str) and \
                    SbtGlobalCommon.securityutil.is_base64(email.encode(encoding='utf_8')):
                email = email.encode(encoding='utf_8')

            if self._sbtcommon.securityutil.is_base64(email):
                string_email = self._sbtcommon.securityutil.base64_to_string(email)
            else:
                string_email = email

            email_parts = string_email.split('@')

            if (string_email in self._white_list.get('users', [])) or \
                    (len(email_parts) > 1 and \
                     email_parts[1] in self._white_list.get('domains', [])):
                white_listed = True
        else:
            white_listed = True

        return white_listed


class UserProfileAccessor(PostgresAccessor):
    """
  Class for accessing user profile database
  """
    _entitle = None
    _tctxapi = None
    _configured = False

    def __init__(self, config=None):
        """
    Initialize
    :param config:
    """
        self._sbtcommon = SbtGlobalCommon
        self._logger = self._sbtcommon.get_logger(logging.INFO, type(self).__name__,
                                                  None, "asctime", "name", "levelname", "funcName", "message")

        self._barchart_accessor = BarchartAccessor()

        self._logger.info("Initializing...")
        if not config:
            temp = SbtGlobalCommon.get_sbt_config()
            config = temp['services']['user']

        self.config = config
        self.pgconfig = self._sbtcommon.get_sbt_config()['postgres']['userprofile']

        super().__init__(self.pgconfig, self._logger)
        self._configure()
        self._logger.info('Initialized!')

    def _configure(self):
        """
      Configure User Profile Settings
    """
        self._logger.info('Configuring...')

        self._entitle = self.config['ent_url'], self.config['ent_token']
        self._logger.info('Entitlement url: ' + self._entitle[0] + ', Token ' +
                          self._entitle[1])
        self._tctxapi = self.config['ctx_url'], self.config['ctx_key']
        self._logger.info('TS Context url: ' + self._entitle[0] + ', ApiKey ' +
                          self._entitle[1])
        self._page_pref_attrs = ["dashboard", "crypto", "summary", "model",
                                 "screener", "list", "research", "home", "chart_grid", "portfolio"]

        tables = self._get_db_tables()
        self._table_columns = {table[0]: self._get_table_fields(table[0]) for table in tables}

        self._page_prefs = [
            "dashboard",
            "crypto",
            "summary",
            "model",
            "screener",
            "list",
            "research",
            "home",
            "chart_grid",
            "portfolio"
        ]

        self._admins = self.config.get('admins', None)
        if self._admins:
            self._logger.info('Admins : ' + str(self._admins))

        self._white_list = self.config.get('white_list', None)
        if self._white_list:
            self._logger.info('White Listed environment : ' + str(self._white_list))

        self._registered_user_template_file = \
            os.path.join(os.path.dirname(__file__), '..', '..',
                         '..', 'config', 'registered_user_template.json')

        self._registered_user_template = None
        self._get_registered_user_template()

        if self._registered_user_template:
            self._logger.info('Template: ' + json.dumps(
                self._registered_user_template))

        self._iam = self.config['iam']
        self._logger.info('iam config: ' + str(self._iam))
        UserProfileAccessor._configured = True

        self._authentication_accessor = IamAccessor()

        self._logger.info('Configured')

    @staticmethod
    def isconfigured():
        """
    :return: True if this instance has been configured, false otherwise
    """
        return UserProfileAccessor._configured

    def activate(self, activation_id, ip_address=None,
                 apply_access_token_timeout=True):
        ret_value = False

        if not activation_id and \
                not SbtGlobalCommon.validate_uuid(activation_id):
            raise RegistrationException('No activation id was provided or is invald')

        current_ts = datetime.datetime.now(datetime.timezone.utc)

        table = "user_profile"
        sql = 'SELECT guid, user_name, access_token_timestamp FROM user_profile WHERE access_token=%s'

        values = [activation_id]

        data = self._execute_query(sql, values)

        if not data:
            raise RegistrationException('Activation id does not exist in database.')

        guid = data[0]['guid']
        user_name = data[0]['user_name']
        access_timestamp = data[0]['access_token_timestamp']

        if apply_access_token_timeout and current_ts > access_timestamp:
            self.deleteprofile(user_name)
            raise RegistrationException('Activation code is no longer valid.')

        sql = 'UPDATE ' + table + ' SET status=%s' + \
              ', modified=%s' + \
              ', access_token=null, access_token_timestamp=null WHERE ' + \
              'user_name=%s'

        values = [Status.ACTIVE.value,
                  str(datetime.datetime.now().isoformat()),
                  user_name]

        self._execute_dml(sql, values, raise_exception=True)

        sql = 'SELECT status FROM ' + table + ' WHERE user_name=%s'

        values = [user_name]

        data = self._execute_query(sql, values)

        if data and data[0]['status'] == Status.ACTIVE.value:
            action = {}
            action['user_id'] = guid
            action['description'] = 'Registered Activation For User : ' + user_name
            if ip_address:
                action['ip_address'] = ip_address

            self.add_user_profile_log(
                UserProfileAction.REGISTRATION_ACTIVATION.value,
                **action)
            ret_value = True

        return ret_value

    @timing
    def authenticate(self, user_name, password, ip_address,
                     impersonate_user_name=None):
        ret_profile = None

        if not user_name or not password:
            raise LoginException('Failed to provide user_name and/or password')

        password = UserProfileUtility.get_encoded_value(password)

        profile = self.get_profile_by_user_name(user_name,
                                                clean_profile=False,
                                                include_prefs=False)

        login_action = UserProfileAction.LOGIN.value
        log_kargs = {}
        if ip_address:
            log_kargs['ip_address'] = ip_address
        authenticated = False

        if self._is_valid_profile(profile):
            log_kargs['user_id'] = profile['guid']
            if self._is_password(profile, password):
                self._update_authenticated_user_profile(user_name, password,
                                                        ip_address, profile)

                authenticated = True
            elif profile.get('user_profile_type_id', 'N/A') in \
                    [UserProfileType.STANSBERRY_USER.value,
                     UserProfileType.FREE_USER.value]:
                self._logger.info('Profile : Authenticating against IAM for user ' +
                                  user_name)

                authenticated, profile = \
                    self._get_iam_authenticated_user_profile(
                        user_name,
                        password,
                        profile)

        elif not profile:
            self._logger.info('No Profile : Authenticating against IAM for user ' +
                              user_name)

            authenticated, profile = \
                self._get_iam_authenticated_user_profile(user_name,
                                                         password,
                                                         None,
                                                         new_profile=True)

        if authenticated and profile:
            ret_profile, login_action = \
                self._get_authenticated_user_data(profile, log_kargs,
                                                  impersonate_user_name=impersonate_user_name)
        elif profile:
            self._logger.info('Profile : Failed authentication for user ' +
                              user_name)
            self.update_failed_login_fields(profile)
            login_action = UserProfileAction.FAILED_LOGIN.value
            log_kargs['description'] = 'Bad password by : ' + \
                                       user_name
        else:
            self._logger.info('Failed authentication for user ' +
                              user_name)
            login_action = UserProfileAction.FAILED_LOGIN.value
            log_kargs['description'] = 'Unable to authenticate user : ' + \
                                       user_name

        self.add_user_profile_log(login_action, **log_kargs)

        return ret_profile

        rval = True

    def add_profile(self, profile, update=False):
        """
    Adds a new user profile if it doesn't exist
    :param profile:
    :type profile: json dict
    """
        self._logger.debug('Adding user profile...')

        values = []
        absent = []
        safepwd = None
        email = profile['email']

        if not update and self.profile_exists(email):
            self._logger.error('ERROR: User ' + email + ' exists')
            return False
        else:
            table = "user_profile"
            fields = self._table_columns[table].copy()

            if update:
                safepwd = profile['passwd'], profile['salt']
                fields.remove('created')
            elif 'created' not in profile:
                profile['created'] = str(datetime.datetime.now().isoformat())

            profile['modified'] = str(datetime.datetime.now().isoformat())
            profile['page_prefs'] = self.page_prefs_json(profile)

            if 'passwd' not in profile:
                self._logger.error('ERROR: Creating user ' + email + ' without password')
                return False
            else:
                if 'guid' not in profile:
                    guid = None
                else:
                    guid = (profile['guid'] if self._sbtcommon.validate_uuid(profile['guid'])
                            else (str(self._sbtcommon.get_uuid())))
                    # TODO: else None let postgres generate
                if guid: profile['guid'] = guid

                for f in fields:  # for each table field
                    if profile.get(f, None):  # if incomming profile has field f
                        if f == 'passwd':
                            if safepwd is None:
                                pwd = self._sbtcommon.securityutil.base64_to_string(profile[f])
                                safepwd = self.preppwd(pwd)  # md5 pwd + salt
                            values.append(safepwd[0])  # pwd
                        else:
                            values.append(profile[f])
                    elif f == 'salt':
                        values.append(safepwd[1])
                    else:
                        self._logger.debug('No value for field ' + f + ' in profile')
                        absent.append(f)

                fields = [f for f in fields if f not in absent]
                if not guid and 'guid' in fields:
                    fields.remove(guid)

                try:
                    self._logger.debug('fields: ' + str(fields))
                    self._logger.debug('values: ' + str(values))
                    if update:
                        builder = self.create_django_update_builder(table, fields, values,
                                                                    'email', profile['email'])
                        self._execute_django_dml(builder)
                    else:
                        builder = self.create_django_insert_builder(table, fields, values)
                        self._execute_django_dml(builder)
                        self._insert_role_tp_history(profile, safepwd[0], safepwd[1])
                    if not guid:
                        guid = self.get_user_id(email)
                        profile['guid'] = guid

                except Exception as e:
                    self._logger.exception('Encountered exception in add_profile')
                    return False

        return True

    def update_profile(self, profile):
        """
    Replace an existing profile with a newly specified profile
    :param profile: Is the newly specified profile
    :return: True if successful, False otherwise
    """
        self._logger.debug('Updating user profile...')
        self._logger.debug(profile)
        email = profile['email']
        try:
            if 'guid' not in profile:
                profile['guid'] = self.get_user_id(email)
            creds = self.get_user_creds(profile['guid'])
            profile['passwd'] = '' if not creds else creds[0]
            profile['salt'] = '' if not creds else creds[1]
            rval = self.add_profile(profile, True)
        except Exception as e:
            self._logger.exception('Encountered exception when updating profile')
            rval = False

        if not rval:
            self._logger.error('Unable to update profile for user ' + email)

        return rval

    def get_guid_with_snaid(self, snaid):
        guid = None

        if not snaid:
            return guid

        sql = "SELECT guid FROM user_profile WHERE snaid=%s"

        res = self._execute_query(sql, [snaid])

        if res and len(res) == 1:
            guid = res[0]['guid']

        return guid

    def update_affiliate_id(self, guid, affiliate_id):
        if not guid or not affiliate_id:
            return

        sql = "UPDATE user_profile SET affiliate_id='" + affiliate_id + "', " + \
              "modified = '" + str(datetime.datetime.now().isoformat()) + \
              "' WHERE guid='" + guid + "'"

        self._execute_dml(sql, None, raise_exception=True)

    def update_username_email(self, guid, user_name, email):
        if not guid or not user_name or not email:
            return

        sql = "UPDATE user_profile SET user_name='" + user_name + "', " + \
              "email='" + email + "', " + \
              "modified = '" + str(datetime.datetime.now().isoformat()) + \
              "' WHERE guid='" + guid + "'"

        self._execute_dml(sql, None, raise_exception=True)

    def update_snaid(self, guid, snaid):
        if not guid or not snaid:
            return

        sql = "UPDATE user_profile SET snaid='" + snaid + "', " + \
              "modified = '" + str(datetime.datetime.now().isoformat()) + \
              "' WHERE guid='" + guid + "'"

        self._execute_dml(sql, None, raise_exception=True)

    @timing
    def update_credentials(self, guid, npwd):
        """
    Update the stored credentials for the specified user
    :param guid: Is the specified user
    :param npwd: Is the updated value for user pwd
    :return: True if updated successfully, false otherwise
    """
        pwd = UserProfileUtility.get_decoded_value(npwd)
        safepwd = self.preppwd(pwd)  # md5 pwd + salt
        table = "user_profile"
        fields = ['passwd', 'salt']
        values = list(safepwd)

        try:
            self._logger.debug('fields: ' + str(fields))
            self._logger.debug('values: ' + str(values))
            builder = (self.create_django_update_builder(table, fields, values, 'guid', guid))
            self._execute_django_dml(builder)
            rval = True
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e) + ' updating password')
            rval = False

        return rval

    def deleteprofile(self, email):
        """
    Deletes a user profile if it exists
    :param email:
    :return:
    """
        self._logger.info('Deleting user profile...')
        rval = True

        guid = self.get_user_id(email)

        if not guid:
            rval = False
        else:
            try:
                table = "user_profile"
                builder = self.create_django_delete_builder(table, 'guid', guid)
                res = self._execute_django_dml(builder)
                if res: self._logger.info('Delete results: ' + str(res))
            except Exception as e:
                self._logger.error('Encountered exception: ' + str(e))
                rval = False

        return rval

    @timing
    def get_user_id(self, email):
        """
    Retreives the user id corresponding to the specified email
    :param email: Is the target email
    :return: None if the email does not exists in up DB string guid otherwise
    """
        rval = None
        table = "user_profile"

        try:
            sql = 'SELECT guid FROM ' + table + \
                  ' WHERE lower(email) = %s'
            res = self._execute_query(sql, [email.lower()])

            if res and len(res) == 1: rval = res[0]['guid']
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e))

        return rval

    @timing
    def get_user_creds(self, guid):
        """
    Retrieves the stored credentials for the specified user
    :param guid: Is the guid for the user to be retrieved
    :return: md5 pwd + salt if success, none otherwise
    """
        rval = None
        table = "user_profile"
        fields = ['passwd', 'salt']
        qfield = table + '.' + 'guid__eq'

        try:
            query = self.create_django_query_builder(table, fields, [{qfield: guid}])
            res = self._execute_django_query(query)

            if res and len(res) == 1: rval = res[0]['passwd'], res[0]['salt']
        except Exception as e:
            self._logger.error('Encountered exception:' + str(e))

        return rval

    def get_user_email(self, guid):
        """
    Retrieves the email corresponding to the specified guid
    :param guid: Is the target guid
    :return: None if guid does not exists in up DB string email otherwise
    """
        rval = None
        table = "user_profile"
        fields = 'email'
        qfield = table + '.' + 'guid__eq'

        try:
            query = self.create_django_query_builder(table, fields, [{qfield: guid}])
            res = self._execute_django_query(query)

            if res and len(res) == 1: rval = res[0]['email']
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e))

        return rval

    @timing
    def get_profile_by_user_name(self, user_name,
                                 clean_profile=True,
                                 include_prefs=True):
        """
    Retrieves the user profile for the specified email
    :param email: Is the target email
    :return: None if the profile for email does not exists, profile otherwise
    """
        self._logger.info('Retrieving user profile for ' + user_name + '...')
        rval = {}
        #
        try:
            table = "user_profile"
            fields = self._table_columns[table].copy()
            if 'banned' in fields: fields.remove('banned')

            select_fields = " ,".join(fields)

            sql = 'SELECT ' + select_fields + ' FROM ' + table + \
                  ' WHERE lower(user_name) = %s'
            res = self._execute_query(sql, [user_name.lower()])

            if res and len(res) == 1:
                rval = res[0].copy()
                guid = rval['guid']
                chat_id = self._get_chat_id(guid)
                if chat_id:
                    rval['chat_id'] = chat_id
                rval['modified'] = str(rval['modified'])
                rval['created'] = str(rval['created'])
                self._logger.debug('rval: ' + str(rval))
                if include_prefs:
                    rval = self.get_page_prefs(rval)
                self._logger.debug('Profile...\n' + json.dumps(rval, cls=SimpleJsonDateTimeEncoder))
            elif not res:
                self._logger.info('No query results')
            else:
                self._logger.debug('Exact user results != 1')
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e) +
                               '\nTraceback: ' + traceback.format_exc())

        if clean_profile:
            self._clean_profile(rval)

        rval = json.dumps(rval, cls=SimpleJsonDateTimeEncoder)
        return json.loads(rval)

    @timing
    def getprofile(self, email=''):
        """
    Retrieves the user profile for the specified email
    :param email: Is the target email
    :return: None if the profile for email does not exists, profile otherwise
    """
        self._logger.info('Retrieving user profile for ' + email + '...')
        rval = None
        #
        try:
            table = "user_profile"
            fields = self._table_columns[table].copy()
            if 'banned' in fields: fields.remove('banned')
            fields = [e for e in fields if e not in ('passwd', 'salt')]  # rm passwd, salt

            select_fields = " ,".join(fields)

            sql = 'SELECT ' + select_fields + ' FROM ' + table + \
                  ' WHERE lower(email) = %s'
            res = self._execute_query(sql, [email.lower()])

            if res and len(res) == 1:
                rval = res[0].copy()
                guid = rval['guid']
                rval['modified'] = str(rval['modified'])
                rval['created'] = str(rval['created'])
                self._logger.debug('rval: ' + str(rval))
                rval = self.get_page_prefs(rval)
                self._logger.debug('Profile...\n' + json.dumps(rval, cls=SimpleJsonDateTimeEncoder))
            elif not res:
                self._logger.info('No query results')
            else:
                self._logger.debug('Exact user results != 1')
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e) +
                               '\nTraceback: ' + traceback.format_exc())

        user_profile_type_id = rval.get('user_profile_type_id', None)
        rval['user_profile_type'] = 'UNKNOWN'
        if user_profile_type_id == UserProfileType.FREE_USER.value:
            rval['user_profile_type'] = 'FREE_USER'
        elif user_profile_type_id == UserProfileType.STANSBERRY_USER.value:
            rval['user_profile_type'] = 'STANSBERRY_USER'

        rval = json.dumps(rval, cls=SimpleJsonDateTimeEncoder)
        return json.loads(rval)

    @timing
    def get_email_by_snaid(self, snaid=''):
        """
    Retrieves the user profile for the specified snaid
    :param snaid: Is the target snaid
    :return: None if the profile for snaid does not exists, email otherwise
    """
        self._logger.info('Retrieving user profile for ' + snaid + '...')
        rval = None
        #
        try:
            table = "user_profile"
            fields = self._table_columns[table].copy()
            if 'banned' in fields: fields.remove('banned')
            fields = [e for e in fields if e not in ('passwd', 'salt')]  # rm passwd, salt
            qfield = table + '.' + 'snaid__eq'
            query = self.create_django_query_builder(table, fields, [{qfield: snaid}])
            res = self._execute_django_query(query)

            if res and len(res) == 1:
                rval = res[0]['email']
            elif not res:
                self._logger.info('No query results')
            else:
                self._logger.debug('Exact user results != 1')
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e) +
                               '\nTraceback: ' + traceback.format_exc())

        return rval

    def getusers(self):
        """
    Retrieves the list of all users (email)
    :return: List of all user emails rval
    """
        rval = []

        try:
            table = "user_profile"
            fields = self._table_columns[table].copy()
            fields.append('guid')
            query = self.create_django_query_builder(table, fields)
            res = self._execute_django_query(query)

            if res:
                self._logger.info('res: ' + str(res))
                for r in res: rval.append(r['email'])
                self._logger.info('Profile...\n' + str(rval))
            else:
                self._logger.debug('No users found')
        except Exception as e:
            self._logger.info('Encountered exception: ' + str(e))

        return rval

    def profile_exists(self, email):
        """
    Determines whether or not the specified user exists
    :param email:
    :return: True if user profile exists false otherwise
    """
        try:
            sql = 'SELECT guid FROM user_profile WHERE lower(email) = %s'
            res = self._execute_query(sql, [email.lower()])
            rval = True if res else False

            if rval: self._logger.debug('Profile exists for user ' + email)
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e))
            rval = False

        return rval

    def update_failed_login_fields(self, profile, reset=False):
        success = False

        if not profile or 'guid' not in profile:
            return success

        table = "user_profile"
        fields = ['failed_login_count', 'last_failed_login_attempt']
        values = []
        if reset:
            values = [0, None]
        else:
            count = profile.get('failed_login_count', 0) + 1
            values = [count, datetime.datetime.now()]

        try:
            self._logger.debug('fields: ' + str(fields))
            self._logger.debug('values: ' + str(values))
            builder = (self.create_django_update_builder(table, fields, values, 'guid',
                                                         profile['guid']))
            self._execute_django_dml(builder)
            success = True
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e) + ' updating login failure')

        return success

    def updatepasswd(self, email, cpwd, npwd):
        """
    Update user passwd
    :param email:
    :param cpwd: current passwd
    :param npwd: new passwd
    """
        rval = False
        msg = None

        if self.authpasswd(email, base64.b64encode(cpwd.encode('utf-8')))[0]:
            self._authentication_accessor.change_password(email, npwd)
            safepwd = self.preppwd(npwd)  # md5 pwd + salt
            table = "user_profile"
            fields = ['passwd', 'salt']
            values = list(safepwd)
            try:
                self._logger.debug('fields: ' + str(fields))
                self._logger.debug('values: ' + str(values))
                builder = (self.create_django_update_builder(table, fields, values, 'email',
                                                             email))
                self._execute_django_dml(builder)
                rval = True
            except Exception as e:
                self._logger.error('Encountered exception: ' + str(e) + ' updating password')
        else:
            msg = 'Current password incorrect'
            self._logger.info(msg)

        return rval, msg

    @deprecated('Functionality migrated to IamAccessor')
    def get_iam_address_data(self, snaid):
        self._logger.info('Retrieving addres info for: ' + snaid)

        headers = {'Token': self._iam['iam_token']}
        url = self._iam['iam_addr']
        url += '/' + snaid

        self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
        return self._sbtcommon.makerequest(url, 'GET', None, None, headers)

    @deprecated('Functionality migrated to IamAccessor')
    def get_iam_name(self, snaid):
        """
    Retrieves the specified users first and last name
    :param snaid:
    :return:
    """
        self._logger.info('Retrieving name for: ' + snaid)

        res = self.get_iam_address_data(snaid)

        if res and 'firstName' in res and 'lastName' in res:
            if res['firstName']:
                rval = res['firstName']

            if res['lastName']:
                if len(rval) > 0:
                    rval = rval + ' '
                rval = rval + res['lastName']
        else:
            self._logger.warn('Unable to retrieve name for: ' + snaid)

        return rval

    def get_iam_attribute(self, snaid, attribute):
        """

    :param snaid:
    :param attribute:
    :return:
    """
        self._logger.info('Retrieving name for: ' + snaid)

        rval = ''
        headers = {'Token': self._iam['iam_token']}
        url = self._iam['iam_addr']
        url += '/' + snaid

        self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
        res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)

        if res and attribute in res:
            rval = res[attribute]
        else:
            self._logger.warn('Unable to retrieve ' + attribute + ' for: ' + snaid)

        return rval

    @deprecated('Functionality migrated to IamAccessor')
    def iam_auth(self, email64, pwd64):
        """
    Authenticates the specified terminal user in IAM
    :param email64:
    :param pwd64:
    :return:
    """
        self._logger.info("Performing IAM authentication")

        rval = False
        snaid = ""
        if not email64:
            self._logger.error("Base64 email not provided")
        elif not pwd64:
            self._logger.error("Base64 pwd not provided")
        elif self._is_white_listed(email64):
            try:
                if not self._sbtcommon.securityutil.is_base64(email64):
                    email64 = self._sbtcommon.securityutil.string_to_base64(email64)
                    email64 = email64.decode('utf-8')

                if isinstance(email64, bytes):
                    email64 = email64.decode('utf-8')

                if isinstance(pwd64, bytes):
                    pwd64 = pwd64.decode('utf-8')

                headers = {'Token': self._iam['iam_token']}
                url = self._iam['iam_auth']
                url += '/username/' + email64
                url += '/password/' + pwd64

                self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
                res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)

                if res and 'customerNumber' in res:
                    snaid = res['customerNumber']
                    if snaid != "":
                        url = self._iam['iam_subs']
                        url += '/' + snaid
                        self._logger.debug(
                            'Get Request url: ' + url + '\nHeaders: ' + str(headers))
                        res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)
                        if res:
                            for i in res:
                                item = i['id']['item']
                                if item and item['itemNumber'] == 'TRM':
                                    self._logger.info('Authenticated: ' + snaid)
                                    rval = True
                                    break
                            if not rval:
                                self._logger.info('TRM access denied for customer: ' + snaid)
                else:
                    self._logger.warn('IAM Authentication Failed')
            except Exception as e:
                self._logger.error('Encountered exception: ' + str(e))
        else:
            self._logger.error('User "' + email64 + '" is not white listed')

        return rval, snaid

    @deprecated('Functionality migrated to IamAccessor')
    def get_subscriptions(self, snaid):
        """
    Retrieves the specified users subscriptions
    :param snaid:
    :return:
    """
        self._logger.info('Retrieving subscriptions for user: ' + snaid)

        rval = []

        try:
            headers = {'Token': self._iam['iam_token']}
            url = self._iam['iam_subs']
            url += '/' + snaid

            self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))
            res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)

            if res:
                rval = res
            else:
                self._logger.info('Failed to retrieve subscriptions for user: ' + snaid)
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e))

        return rval

    def iam_list_brandIDs(self, email):
        self._logger.debug("Calling IAM ListBrandID")

        rval = {}
        exists = False

        if not email:
            self._logger.error("Email not provided")
        else:
            headers = {'Token': self._iam['iam_token']}
            iamurl = self._iam['iam_list_brandids']
            data = {'username': email}

            try:
                self._logger.debug('Get Request url: ' + iamurl + '\nHeaders: ' + str(headers))
                res = self._sbtcommon.makerequest(iamurl, 'POST', data, None, headers)

                if res:
                    rval = res
                    exists = len(res) > 0

            except Exception as e:
                self._logger.error('Encountered exception: ' + str(e))

        return rval, exists

    def request_reset(self, email):
        """

    :param email:
    :return:
    """
        self._logger.info('Requesting pwd reset for user: ' + email)

        rval = False
        msg = ''
        try:
            brandids, success = self.iam_list_brandIDs(email)

            if success:
                if self._authentication_accessor.get_investor_affiliate() in brandids:
                    headers = {"Token": self._iam["iam_password_token"]}
                elif self._authentication_accessor.get_stansberry_affiliate() in brandids:
                    headers = {"'Token": self._iam["iam_token"]}
                else:
                    msg = ("Invalid email address: " + email)
                    return rval, msg

                url = self._iam['iam_reset']
                data = {'email': email}

                self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))

                res = self._sbtcommon.makerequest(url, 'POST', data, None, headers)

                if res and 'status' in res:
                    rval = res['status'] == 'OK'
                    msg = 'Password reset token sent to email: ' + email
                else:
                    msg = 'Password reset request denied for user: ' + email
            else:
                msg = "Invalid email address: " + email

        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e))

        return rval, msg

    def validate_reset(self, token, email, npwd):
        """

    :param email:
    :return:
    """
        self._logger.info('Validating pwd reset for user: ' + email)

        rval = False
        msg = ''
        try:
            headers = {'Token': self._iam['iam_token']}
            url = self._iam['iam_reset_validate']
            data = {'token': token}

            self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))

            res = self._sbtcommon.makerequest(url, 'POST', data, None, headers)

            if res and 'email' in res and res['email'] == email:
                self._logger.info('Token validated, processing reset')
                headers = {'Token': self._iam['iam_token_']}
                url = self._iam['iam_reset_process']
                data = {
                    'token': token,
                    'password': npwd,
                    'username': email
                }
                res = self._sbtcommon.makerequest(url, 'POST', data, None, headers)
                if res and 'status' in res:
                    rval = res['status'] == 'OK'
                    msg = 'Password reset success!'
                else:
                    msg = 'Password reset process failed for user: ' + email
            else:
                msg = 'Password reset token invalid for user: ' + email
        except Exception as e:
            self._logger.error('Encountered exception: ' + str(e))

        return rval, msg

    @timing
    def authpasswd(self, email, pwd64):
        """
    Authenticates the password for the specified user against stored
    :param email:
    :param pwd64:
    :return: true if pwd64 is equivalent false otherwise
    """
        self._logger.info('Authenticating ' + email)
        rval = False
        msg = ""
        snaid_val = ""

        if email and not self._is_white_listed(email):
            self._logger.error('User "' + email + '" is not white listed')
            msg = 'Failed to authenticate ' + email
            return rval, msg, snaid_val

        try:
            table = "user_profile"
            fields = ['passwd', 'salt', 'snaid']
            select_fields = " ,".join(fields)

            sql = 'SELECT ' + select_fields + ' FROM ' + table + \
                  ' WHERE lower(email) = %s'
            res = self._execute_query(sql, [email.lower()])

            if res and len(res) == 1:
                exp = res[0]['passwd']
                salt = res[0]['salt']
                snaid_val = res[0]['snaid']
                pwd = self._sbtcommon.securityutil.base64_to_string(pwd64) + salt
                md5 = hashlib.md5()
                md5.update(pwd.encode())
                act = md5.hexdigest()
                rval = act == exp
                self._logger.debug('exp: ' + exp + ' act: ' + act)
        except Exception as e:
            msg = 'Failed to authenticate ' + email
            self._logger.error('Encountered exception: ' + str(e))

        return rval, msg, snaid_val

    @timing
    def getloid(self, oid=None):
        """
    Retreives the large object for the specified oid in string format
    :param oid:
    :return:
    """
        lo = self._retrieve_large_object(oid) if oid else None
        if not lo: self._logger.error('Cannot retrieve object id None')

        return lo

    @staticmethod
    def preppwd(passwd):
        """
    Generates MD5 digest of the input stream concatenated with time now
    :param passwd:
    :return: the digest value and time now string
    """
        salt = datetime.datetime.now().isoformat()
        pwd = passwd + salt
        md5 = hashlib.md5()

        md5.update(pwd.encode())

        return md5.hexdigest(), salt

    def getentitlements(self, email):
        """
    Retrieves the list of subscriptions entitled to the specified user
    :param email:
    :return: list of dict name pubcode, level
    """
        self._logger.debug('Requesting entitlements for ' + email + '...')

        rval = []
        headers = {'Token': self._entitle[1]}
        url = self._entitle[0] + email + '/'

        self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers))

        res = self._sbtcommon.makerequest(url, 'GET', None, None, headers)

        if res:
            self._logger.debug('Entitlements for ' + email + '\n' + str(res))
            rval = res
        else:
            self._logger.info('No response received from entitlement request')

        return rval

    def get_tscontext(self, email):
        """
    Retrieves the TS context for the specified user
    :param email:
    :return: list of dict name pubcode, level
    """
        self._logger.info('Requesting TS Context for ' + email + '...')

        rval = None
        url = self._tctxapi[0]
        headers = {
            'Content-type': 'application/json',
            'Accept': 'application/json',
            'LicenseKey': self._tctxapi[1]
        }
        qt = "user_profile"
        qf = self._table_columns[qt].copy()
        select_fields = " ,".join(qf)

        sql = 'SELECT ' + select_fields + ' FROM ' + qt + \
              ' WHERE lower(email) = %s'
        qr = self._execute_query(sql, [email.lower()])

        if qr: self._logger.debug(str(qr))

        if qr and len(qr) == 1:
            tsusr = qr[0]['tradestop_user']
            tspwd = qr[0]['tradestop_pwd']
            data = {
                'UserName': tsusr,
                'Password': tspwd
            }
            self._logger.debug('Get Request url: ' + url + '\nHeaders: ' + str(headers) +
                               '\nBody: ' + str(data))
            res = self._sbtcommon.makerequest(url, 'POST', data, None, headers)
            if res and 'ContextKey' in res:
                self._logger.info('TS Context for ' + email + '\n' + str(res))
                rval = res['ContextKey']
            else:
                self._logger.info('User ' + email + ' context not created')

        return rval

    def get_screeners(self, email):
        """
    :param email:
    :return:
    """
        response = []
        userid = self.get_user_id(email)

        if userid:
            try:
                table = "user_profile_screener"
                fields = self._table_columns[table].copy()
                qfield = table + '.' + 'userid__eq'
                fields.remove('created_at')
                query = self.create_django_query_builder(table, fields, [{qfield: userid}])
                res = self._execute_django_query(query)
                if res and len(res) > 0:
                    response = [{
                        'listid': y['listid'],
                        'name': y['name'],
                        'timestamp': str(y['updated_at']),
                        'filters': [{'field': f, 'operator': o, 'value': v} for f, o, v in
                                    zip(y['fields'].split('; '),
                                        y['operators'].split('; '),
                                        y['values'].split('; '))]} for y in
                        [x for x in res]]
                else:
                    self._logger.debug(' User {} has no screener saved.'.format(email))
            except Exception as e:
                self._logger.error('Exception encountered: ' + str(e))
        else:
            self._logger.info('User ' + email + ' does not exists')
        return response

    def _check_screener_name(self, table, userid, name):
        """
    This method will check for existing combination of userid + name
    :param table:
    :param userid:
    :param name:
    :return:
    """
        qfields = [
            {table + '.userid': userid},
            {table + '.name': name}
        ]
        sql = self.create_django_query_builder(table, 'listid', qfields)
        qres = self._execute_django_query(sql)

        return qres

    def save_screener(self, payload):
        """
    Create screener entry for the specified user
    :param payload:
    :return:
    """
        values = []
        table = "user_profile_screener"
        fields = self._table_columns[table].copy()
        fields = [f for f in fields if f not in ('updated_at', 'created_at', 'listid')]
        qfield = table + '.' + 'listid'

        try:  # validate payload
            # validate filters
            # add 'fields', 'operators', and 'values' to the payload
            # and transform the result into 'fields': ['field1; field2'] etc.
            payload.update({y + 's': '; '.join([str(x[y]) for x in payload['filters']])
                            for y in payload['filters'][0].keys()})

            # remove unnecessary 'filters' from payload keys list
            payload_fields = list(payload.keys())
            payload_fields.remove('filters')
            # diff will contain attributes that are not in the db schema
            diff = set(payload_fields).difference(fields)
            if len(diff) == 0 or (len(diff) == 1 and list(diff)[0] == 'email'):
                # valid payload
                payload['name'] = payload['name'].strip()
                userid = self.get_user_id(payload['email'])
                name = payload['name']
                if len(name) != 0:  # check if name has been provided
                    fields = []
                    # get fields and values from the same place
                    [fields.append(x) if x != 'email' else fields.append('userid')
                     for x in payload_fields]
                    [values.append(payload[x]) if x != 'email' else values.append(userid)
                     for x in payload_fields]
                    # check for existing screeners
                    qres = self._check_screener_name(table, userid=userid, name=name)
                    if qres and len(qres) == 1:  # UPDATE existing screener
                        self._logger.debug(" Screener exists in the database; updating it...")
                        msg = 'UPDATED'
                        listid = qres[0]['listid']
                        sql = self.create_django_update_builder(table, fields, values,
                                                                qfield, listid)
                    else:  # CREATE new screener
                        # creating a new list with a unique email + name combination
                        self._logger.debug(" Screener does not exist; creating it...")
                        msg = 'CREATED'
                        sql = self.create_django_insert_builder(table, fields, values)

                    self._logger.debug('fields: ' + str(fields) + '\nvalues: ' + str(values))
                    self._execute_django_dml(sql)
                    # retrieving listid for the newly-created list
                    qres = self._check_screener_name(table, userid=userid, name=name)
                    listid = str(qres[0]['listid'])
                    res = {"success": True, "message": msg, "listid": listid}
                else:  # TODO: suggest a default name
                    msg = 'No name has been provided; no list has been created.'
                    res = {"success": False, "error": msg}
            else:
                diff.discard('listid')
                res = {'success': False,
                       'error': "Invalid attributes: {}.".format(diff)}
        except Exception as e:
            res = {'success': False,
                   'error': 'Encountered exception: ' + str(e)}

        return res

    def delete_screener(self, email, list_name):
        """
    Delete the screener for the specified user
    :param email:
    :param list_name:
    :return:
    """
        userid = self.get_user_id(email)
        res = {'success': False, 'error': ''}
        msg = None
        table = "user_profile_screener"
        qfield = [
            {table + '.' + 'userid__eq': userid},
            {table + '.' + 'name__eq': list_name}
        ]  # table's constraint: UNIQUE KEY (userid, name)
        try:
            query = self.create_django_query_builder(table, 'listid', qfield)
            qres = self._execute_django_query(query)
            if qres and len(qres) == 1:  # delete list
                list_id = qres[0]['listid']
                sql = self.create_django_delete_builder(table, 'listid', list_id)
                msg = "Deleted list {} ({}).".format(list_id, list_name)
                self._execute_django_dml(sql)
                res['success'] = True
            else:
                logging.debug(" List does not exist; creating it...")
                msg = "List does not exist."
        except Exception as e:
            res['error'] = str(e)

        if msg and not res['success']: res['error'] = msg

        return res

    def page_prefs_json(self, profile):
        """
    Get page prefs as a JSON string
    :param profile:
    :return:
    """
        prefs = {}
        for attr in self._page_prefs:
            prefs[attr] = profile.get(attr, {})

        return json.dumps(prefs)

    def get_page_prefs(self, profile):
        """
    Retrieve the page preferences for the specified user
    :param profile:
    :param userid:
    :return:
    """

        if profile.get("page_prefs"):
            prefs = profile["page_prefs"]
        else:
            prefs = {}

        for attr in self._page_prefs:
            profile[attr] = prefs.get(attr, {})

        return profile

    def td_create_access_token_entry(self, reply, user_guid):
        """
      :param authReply: Insert token into token table
      :return: successfully stored in database
    """
        self._logger.info('Starting insert Postgres Query: ' + str(reply))

        field_names = []
        field_args = []

        try:
            reply = json.loads(reply)

            field_args.append(str(user_guid))
            field_names.append('user_id')

            field_names.append('token')
            field_args.append(reply.get('access_token'))

            field_names.append('reset_token')
            field_args.append(reply.get('refresh_token'))

            field_names.append('guid')
            field_args.append(str(self._sbtcommon.get_uuid()))

            query = self.create_django_insert_builder('user_profile_td_ameritrade_tokens', field_names, field_args)
            self._execute_django_dml(query, raise_exception=True)

            self._logger.info('Token inserted into table')

            return True
        except Exception as e:
            self._logger.error('Inserting token encountered ' +
                               'exception: ' + str(e))
        return False

    def td_update_access_token_entry(self, reply, user_id, reset_token):
        """
      :param authReply: Update token into token table
      :return: successfully updated in database
    """
        self._logger.info('Starting update in Postgres : ' + str(reply))

        field_names = []
        field_args = []

        try:
            reply = json.loads(reply)

            field_args.append(str(user_id))
            field_names.append('user_id')

            field_names.append('token')
            field_args.append(reply.get('access_token'))

            field_names.append('reset_token')
            field_args.append(reset_token)

            entry = self.check_for_token(user_id)
            if entry:
                field_names.append('guid')
                field_args.append(str(entry[0].get('guid')))  # Unexpected Type Warning
            else:
                raise Exception('During update system was not able to ' +
                                ' find entry matching user ' + user_id)
            query = self.create_django_update_builder('user_profile_td_ameritrade_tokens', field_names,
                                                      field_args, 'guid',
                                                      entry[0].get('guid'))  # Unexpected Type Warning
            self._execute_django_dml(query, raise_exception=True)

            self._logger.info('Token updated in table')

            return True
        except Exception as e:
            self._logger.error('Updating token encountered ' +
                               'exception: ' + str(e))
        return False

    def check_for_token(self, user_id):
        """
      :param id: check token by id
      :return: stored in database
    """
        self._logger.info('Starting to check for token entry by id: ' + str(user_id))

        try:
            if id:
                query = self.create_django_query_builder('user_profile_td_ameritrade_tokens',
                                                         and_conditions=[{'user_id': user_id}])
                res = self._execute_django_query(query)
                self._logger.info('Checking for token in DB responded with ' \
                                  + json.dumps(res))
                if res:
                    return res
                else:
                    return {}
            else:
                raise Exception('ID provided when looking up token.')
        except Exception as e:
            self._logger.error('Inserting token encountered ' +
                               'exception: ' + str(e))
            return {'error': str(e)}

    def add_user_profile_log(self, action, **kargs):
        table = 'user_profile_action'
        fields = ['guid', 'action', 'description', 'user_id',
                  'ip_address', 'created']

        final_fields = []
        final_values = []
        for f in fields:
            if f == 'action':
                final_fields.append('action')
                final_values.append(action)
            elif f in kargs and kargs[f]:
                final_fields.append(f)
                final_values.append(kargs[f])

        if table and final_fields:
            builder = self.create_django_insert_builder(table, final_fields,
                                                        final_values)
            self._execute_django_dml(builder)

    def sb_user_registration(self, **kargs):
        snaid = kargs.get('snaid', '')

        kargs['first_name'] = 'UNKNOWN'
        kargs['last_name'] = 'UNKNOWN'

        address_data = self._authentication_accessor.get_address_data(snaid)

        if address_data:
            f_name = address_data.get('firstName', None)
            l_name = address_data.get('lastName', None)

            if f_name:
                kargs['first_name'] = f_name

            if l_name:
                kargs['last_name'] = l_name

        if kargs.get('affiliate_id', '-1') == \
                self._authentication_accessor.get_stansberry_affiliate():
            kargs['user_profile_type'] = UserProfileType.STANSBERRY_USER.value
        else:
            kargs['user_profile_type'] = UserProfileType.FREE_USER.value

        kargs['status'] = Status.ACTIVE.value
        profile = None
        success = False
        try:
            success = self.user_registration(**kargs)
        except Exception as ex:
            self._logger.error('Failed to register SB user : ' +
                               kargs['user_name'] + ' Exception : ' + str(ex))

        if success:
            profile = self.get_profile_by_user_name(kargs['user_name'],
                                                    clean_profile=False,
                                                    include_prefs=False)

        return profile

    def send_registration_email(self, user):
        send_email("free_user_registration.html", user["email"],
                   "Thank You for Registering for Stansberry Investor!",
                   **user)

    def free_user_registration(self, **kargs):
        kargs['user_profile_type'] = UserProfileType.FREE_USER.value

        eletter = {}

        e_snaid = None
        try:
            user_name = kargs.get('user_name', None)
            eletter = self._authentication_accessor.create_new_user(user_name,
                                                                    kargs.get('first_name', None),
                                                                    kargs.get('last_name', None))

            e_snaid = eletter.get('snaid', None)
            if not e_snaid:
                raise RegistrationException("No SNAID returned.")

            #confirm subscription check which is indicated auth record for a snaid
            for i in range(10):
                subs = self._authentication_accessor.get_subscriptions(e_snaid)
                if subs:
                    break

            if not self._authentication_accessor.change_password(user_name, kargs.get('passwd')):
                raise RegistrationException("Could not set password for new account")

            self.send_registration_email(kargs)

        except IamException as iame:
            raise RegistrationException(str(iame))

        if e_snaid and not kargs.get('snaid', None):
            kargs['snaid'] = e_snaid

        kargs['status'] = Status.PENDING.value
        kargs['affiliate_id'] = \
            self._authentication_accessor.get_investor_affiliate()

        return self.user_registration(**kargs)

    def user_registration(self, **kargs):
        self._validate_registration_information(**kargs)

        user_profile_type = kargs.get('user_profile_type', None)
        affiliate_id = kargs.get('affiliate_id', None)
        status = kargs.get('status', Status.PENDING.value)
        password = UserProfileUtility.get_encoded_value(kargs.get('passwd', None))
        snaid = kargs.get('snaid', None)
        guid = str(self._sbtcommon.get_uuid())
        created_dt = datetime.datetime.now(datetime.timezone.utc)

        profile = dict(self._get_registered_user_template())
        profile['guid'] = guid
        profile['name'] = kargs['first_name'] + ' ' + \
                          kargs['last_name']
        profile['first_name'] = kargs['first_name']
        profile['last_name'] = kargs['last_name']
        profile['user_name'] = kargs['user_name'].lower()
        profile['email'] = kargs['email'].lower()
        profile['user_profile_type_id'] = user_profile_type
        profile['snaid'] = snaid.upper()
        profile['status'] = status
        profile['chat_id'] = guid
        profile['passwd'] = password
        profile['created'] = str(created_dt)
        if affiliate_id:
            profile['affiliate_id'] = affiliate_id

        if status == Status.PENDING.value:
            profile['access_token'] = str(SbtGlobalCommon.get_uuid())
            profile['access_token_timestamp'] = \
                str(SbtGlobalCommon.dateutil.add_days(created_dt, 3))

        created = self.add_profile(profile)

        action = {}
        action['user_id'] = guid
        action['description'] = 'Registered User : ' + kargs['user_name']
        if 'ip_address' in kargs:
            action['ip_address'] = kargs['ip_address']

        if created:
            self.add_user_profile_log(UserProfileAction.REGISTRATION.value,
                                      **action)

        if not created and self.profile_exists(profile['email']):
            self.add_user_profile_log(UserProfileAction.FAILED_REGISTRATION.value,
                                      **action)
            self.deleteprofile(profile['email'])

        return created

    def _validate_registration_information(self, **kargs):
        if not kargs:
            raise RegistrationException("No user information provided")

        if not self._registered_user_template:
            raise RegistrationException("No user registration template available")

        if not kargs.get('user_name', None) or \
                not kargs.get('email', None) or \
                not kargs.get('first_name', None) or \
                not kargs.get('last_name', None) or \
                not kargs.get('passwd', None) or \
                not kargs.get('snaid', None) or \
                not kargs.get('user_profile_type', None):
            raise RegistrationException("Missing required field : " + str(kargs))

        user_profile_type = kargs.get('user_profile_type', None)

        if user_profile_type == UserProfileType.FREE_USER.value:
            email = kargs.get('email', 'email')

            if not self.is_valid_email(email):
                raise RegistrationException("Invalid email address.")

            if email != kargs.get('user_name', 'user_name'):
                raise RegistrationException("Email address and user name must match.")

        if self.profile_exists(kargs.get('email', None)):
            raise RegistrationException("User already exists in system.")

    def is_valid_email(self, email):

        try:
            validate_email(email)
            return True
        except ValidationError:
            return False

    @timing
    def make_user_profile(self, users=None):
        """
    Creates a default profile for the specified users from configuration template
    :param users: List of users and attributes to be constructed
    :return: True if all user profiles create false otherwise
    """
        rval = True
        msg = ''

        if not users:
            rval = False
            msg = 'Received empty make user request'
            self.logger.info(msg)
            return rval, msg

        for atts in users:
            template = self._get_template(self._tempfile)

            if atts and 'name' in atts and 'snaid' in atts and 'email' in atts:
                msg += atts['email'] + ' '

                template['name'] = atts['name'].lower()
                template['snaid'] = atts['snaid'].upper()
                template['email'] = atts['email']
                template['created'] = str(datetime.datetime.now().isoformat())

                if 'passwd' in atts: template['passwd'] = atts['passwd']

                sl = atts['email'] if '@' not in atts['email'] else (atts['email'].split('@'))[0]

                template['chat_id'] = sl
                template['sungard_login'] = sl
                template['tradestop_user'] = ''
                template['tradestop_pwd'] = ''

                ok, err = self._create_user_profile(template)

                if not ok:
                    rval = False
                    err = 'Make user ' + atts['email'] + ' failed. ' + err
                    msg = msg + '\n' + err
                    self.logger.info(err)

            template.clear()

        return rval, msg

    def _get_chat_id(self, guid):
        third_party = 'user_profile_third_party'

        and_conditions = [
            {'user_id__eq': guid},
            {'vendor__eq': 'openfire'},
            {'user_attr_name__eq': 'chat_id'},
            {'status': 1}]
        d_query = self.create_django_query_builder(
            third_party,
            return_columns=None,
            and_conditions=and_conditions,
            or_conditions=None)

        data = self._execute_django_query(d_query)

        chat_id = None
        if data and len(data) == 1:
            chat_id = data[0].get('user_attr_value', None)

        return chat_id

    def _insert_role_tp_history(self, profile, password, salt):
        if not profile or 'guid' not in profile or not password or \
                not salt:
            return

        role_xref = 'user_profile_role_xref'
        third_party = 'user_profile_third_party'
        password_history = 'user_profile_password_history'
        guid = profile.get('guid', None)
        role = UserProfileRole.FREE_USER.value

        if profile.get('user_profile_type_id') == \
                UserProfileType.STANSBERRY_USER.value:
            role = UserProfileRole.ALLIANCE.value

        fields = ['user_id', 'role_id']
        values = [guid, role]

        builder = self.create_django_insert_builder(role_xref,
                                                    fields,
                                                    values)

        self._execute_django_dml(builder)

        fields = ['user_id', 'status', 'vendor',
                  'user_attr_name', 'user_attr_value']
        values = [guid, Status.ACTIVE.value, 'openfire',
                  'chat_id', profile.get('chat_id', guid)]

        builder = self.create_django_insert_builder(third_party,
                                                    fields,
                                                    values)

        self._execute_django_dml(builder)

        fields = ['user_id', 'passwd', 'salt', 'created']
        values = [guid, password,
                  salt, profile['created']]

        builder = self.create_django_insert_builder(password_history,
                                                    fields,
                                                    values)

        self._execute_django_dml(builder)

    def _populate_entitlements(self, profile):
        user_id = profile['guid']
        snaid = profile.get('snaid', None)

        entitlements = {}

        sql = "select rx.user_id as user_id, entty.name as entitlement_type, " + \
              "ent.name as entitlement, per.name as permission " + \
              "from user_profile_role_xref rx " + \
              "inner join user_profile_role_entitlement_xref rex " + \
              "ON rx.role_id = rex.role_id " + \
              "inner join user_profile_permission per " + \
              "ON rex.permission_id = per.guid " + \
              "inner join user_profile_entitlement ent " + \
              "ON rex.entitlement_id = ent.guid " + \
              "inner join user_profile_entitlement_type entty " + \
              "ON ent.entitlement_type_id = entty.guid " + \
              "where rx.user_id = %s " + \
              "order by entitlement_type, entitlement"

        role_ents = self._execute_query(sql, [user_id])

        if role_ents:
            for r in role_ents:
                ent_type = r['entitlement_type'].lower()
                if ent_type not in entitlements:
                    entitlements[ent_type] = {}
                map_list = r['entitlement'].split('.')
                SbtGlobalCommon.collectionsutil.set_in_dict(entitlements[ent_type],
                                                            map_list,
                                                            r.get('permission', 'None'))

        sql = "select uent.user_id as user_id, entty.name as entitlement_type, " + \
              "ent.name as entitlement, per.name as permission " + \
              "from user_profile_entitlement_xref uent " + \
              "inner join user_profile_permission per " + \
              "ON uent.permission_id = per.guid " + \
              "inner join user_profile_entitlement ent " + \
              "ON uent.entitlement_id = ent.guid " + \
              "inner join user_profile_entitlement_type entty " + \
              "ON ent.entitlement_type_id = entty.guid " + \
              "where uent.user_id = %s " + \
              "order by entitlement_type, entitlement"

        user_ents = self._execute_query(sql, [user_id])

        if user_ents:
            for r in user_ents:
                ent_type = r['entitlement_type'].lower()
                if ent_type not in entitlements:
                    entitlements[ent_type] = {}
                map_list = r['entitlement'].split('.')
                SbtGlobalCommon.collectionsutil.set_in_dict(entitlements[ent_type],
                                                            map_list,
                                                            r.get('permission', 'None'))

        if snaid:
            pub = self._authentication_accessor.get_subscriptions(snaid)
            if 'publication' not in entitlements:
                entitlements['publication'] = {}
            entitlements['publication'] = pub

        profile['entitlements'] = entitlements

    def _create_user_profile(self, profile):
        """
    Adds the specified profile to the user profile data store if it does not exists
    :param profile:
    :return:
    """
        self.logger.info('Create user profile.')

        created = False
        msg = ''

        if not profile:
            msg = 'Unable to construct empty profile'
        elif 'email' not in profile:
            msg = 'Field \'email\' required for user creation'
        elif 'passwd' not in profile:
            msg = 'Field \'passwd\' required for user creation'
        elif self.user_exists(profile['email']):
            msg = 'User ' + profile['email'] + ' already exists...'
        else:

            created = self.add_profile(profile)

            if not created and self.profile_exists(profile['email']):
                msg = 'Rolling back user ' + profile['email'] + ' creation...'
                self.deleteprofile(profile['email'])
            elif not created:
                msg = 'Failed to create user account for ' + profile['email']

        return created, msg

    def _get_registered_user_template(self):
        self._logger.info('Get Registered User Template')

        try:
            if not self._registered_user_template:
                f = open(self._registered_user_template_file, 'r')
                t = f.read()
                f.close()
                self._registered_user_template = json.loads(t)
        except Exception as e:
            self._logger.error('Encountered exception ' + str(e) + ' loading template')

        return self._registered_user_template

    def _get_user_impersonation(self, current_user_name):
        """
      Determines if current user should impersonate someone else.

      Args :

        current_user_name (str) : User name

      Returns :

        str : User being impersonated

    """

        today = datetime.datetime.utcnow().strftime('%Y-%m-%d')

        # Requires admin access.
        sql = "SELECT i.* FROM user_profile_impersonation i " + \
              "INNER JOIN user_profile u ON i.user_id = u.guid " + \
              "INNER JOIN user_profile_role_xref r " + \
              "ON i.user_id = r.user_id AND r.role_id = " + \
              "'a2c4316f-8f77-4603-89f9-e367bcf01145'" + \
              "WHERE u.user_name = %s ORDER BY i.created DESC"

        imp = self._execute_query(sql, [current_user_name])

        impersonate_user = None

        if imp:
            current = imp[0]
            # Database entries are only good for a day.
            if current['created'].strftime('%Y-%m-%d') == today:
                impersonate_user = current['impersonate_user_name']

        return impersonate_user

    def _is_admin(self, user_name):
        """
      Determines whether a user has the admin role.

      Args :

        user_name (str) : User name

      Returns :

        boolean
    """

        admin = False

        sql = "SELECT r.* FROM user_profile_role_xref r " + \
              "INNER JOIN user_profile u ON r.user_id = u.guid " + \
              "WHERE u.user_name = %s " + \
              "AND role_id = 'a2c4316f-8f77-4603-89f9-e367bcf01145'"

        admin_data = self._execute_query(sql, [user_name])

        if admin_data:
            admin = True

        return admin

    def _clean_profile(self, profile):
        if not profile:
            return

        name = profile.get('name', '')
        if name and name.isupper():
            parts = name.split(' ')
            formatted_name = ''
            for p in parts:
                formatted_name = formatted_name + ' ' + p.capitalize()
            profile['name'] = formatted_name.strip()

        first_name = profile.get('first_name', '')
        if first_name and first_name.isupper():
            profile['first_name'] = first_name.capitalize()

        last_name = profile.get('last_name', '')
        if last_name and last_name.isupper():
            profile['last_name'] = last_name.capitalize()

        profile.pop('passwd', None)
        profile.pop('salt', None)
        profile.pop('sungard_login', None)
        profile.pop('sungard_pwd', None)
        profile.pop('sungard_group', None)
        profile.pop('tradestop_user', None)
        profile.pop('tradestop_pwd', None)
        profile.pop('symsel', None)
        profile.pop('pagesel', None)
        profile.pop('dark_popout', None)
        profile.pop('status', None)
        profile.pop('failed_login_count', None)
        profile.pop('access_token', None)
        profile.pop('access_token_timestamp', None)
        profile.pop('last_failed_login_attempt', None)
        user_profile_type_id = profile.get('user_profile_type_id', None)
        profile['user_profile_type'] = 'UNKNOWN'
        if user_profile_type_id == UserProfileType.FREE_USER.value:
            profile['user_profile_type'] = 'FREE_USER'
        elif user_profile_type_id == UserProfileType.STANSBERRY_USER.value:
            profile['user_profile_type'] = 'STANSBERRY_USER'
        profile.pop('user_profile_type_id', None)
        profile.pop('modified', None)
        profile.pop('created', None)

        return profile

    def _is_valid_profile(self, profile):
        return profile and \
               (profile.get('status', Status.DELETED.value) == Status.ACTIVE.value or \
                profile.get('status', Status.DELETED.value) == Status.PENDING.value)

    def _is_password(self, profile, pwd64):
        exp = profile.get('passwd', 'N/A')
        salt = profile.get('salt', 'N/A')
        pwd = self._sbtcommon.securityutil.base64_to_string(pwd64) + salt
        md5 = hashlib.md5()
        md5.update(pwd.encode())
        act = md5.hexdigest()
        return act == exp

    def _get_iam_authenticated_user_profile(self, user_name,
                                            password,
                                            profile,
                                            new_profile=False):

        self._logger.info('Authenticate and update iam authentication ' +
                          'data for ' +
                          user_name)

        ret_profile = None

        if profile:
            ret_profile = dict(profile)

        authenticated, snaid, affiliate_id = \
            self._authentication_accessor.authenticate(
                user_name,
                password)

        if not authenticated:
            return authenticated, ret_profile

        if new_profile:
            e_guid = self.get_guid_with_snaid(snaid)
            if e_guid:
                self.update_username_email(e_guid, user_name, user_name)
                ret_profile = self.get_profile_by_user_name(user_name,
                                                            clean_profile=False,
                                                            include_prefs=False)

        if not ret_profile and new_profile:
            self._logger.info('IAM user : Create profile for user ' +
                              user_name)

            user = {'snaid': snaid,
                    'user_name': user_name,
                    'email': user_name, 'passwd': password}
            if affiliate_id:
                user['affiliate_id'] = affiliate_id

            ret_profile = self.sb_user_registration(**user)
        else:
            self.update_credentials(ret_profile['guid'], password)

            if ret_profile.get('affiliate_id', '') != affiliate_id:
                self.update_affiliate_id(ret_profile['guid'], affiliate_id)
                ret_profile['affiliate_id'] = affiliate_id

        return authenticated, ret_profile

    def _update_authenticated_user_profile(self, user_name,
                                           password, ip_address,
                                           profile):
        self._logger.info('Update terminal authentication data for ' +
                          user_name)

        if not profile.get('snaid', None):
            try:
                eletter = self._authentication_accessor.create_new_user(
                    profile['user_name'],
                    profile['first_name'],
                    profile['last_name'],
                    apply_white_list=False)

                e_snaid = eletter.get('snaid', None)

                if e_snaid:
                    self.update_snaid(profile['guid'], e_snaid)
                    profile['snaid'] = e_snaid

            except Exception as e:
                self._logger.error('Unable to register account with ' +
                                   ' IAM.' + str(e))

        if profile['status'] == Status.PENDING.value and \
                profile.get('access_token', None) and \
                profile.get('snaid', None) and \
                self._authentication_accessor.change_password(user_name, password):
            self.activate(profile['access_token'],
                          ip_address=ip_address,
                          apply_access_token_timeout=False)
            profile['status'] = Status.ACTIVE.value
            profile['access_token'] = None
            profile['access_token_timestamp'] = None

        if not profile.get('affiliate_id', None):
            authenticated, snaid, a_id = \
                self._authentication_accessor.authenticate(user_name, password)
            self._logger.info('Authenticate snaid ' + str(snaid))

            if authenticated and a_id:
                self.update_affiliate_id(profile['guid'], a_id)
                profile['affiliate_id'] = a_id

    def _is_white_listed(self, email):
        white_listed = False

        if email and self._white_list:
            string_email = None

            if self._sbtcommon.securityutil.is_base64(email):
                string_email = self._sbtcommon.securityutil.base64_to_string(email)
            else:
                string_email = email

            email_parts = string_email.split('@')

            if (string_email in self._white_list.get('users', [])) or \
                    (len(email_parts) > 1 and \
                     email_parts[1] in self._white_list.get('domains', [])):
                white_listed = True
        else:
            white_listed = True

        return white_listed

    def _synchronize_watch_list(self, userid, widget):
        if not userid or not widget or \
                widget.get('type', 'N/A') != 'market-watch':
            return

        for l in widget.get('wlist', []):
            watch_symbols_string = l.get('symbols', '')
            if not watch_symbols_string:
                continue

            watch_symbols = watch_symbols_string.split(',')
            self._barchart_accessor.update_watch_symbols(watch_symbols)

    def _get_authenticated_user_data(self, profile,
                                     log_kargs,
                                     impersonate_user_name=None):

        login_action = UserProfileAction.LOGIN.value
        user_name = profile['user_name']

        is_admin = self._is_admin(user_name)

        # Until this can be made more dynamic on the front-end
        # the back-end system will read this from a table.
        if is_admin and not impersonate_user_name:
            impersonate_user_name = self._get_user_impersonation(
                user_name)

        self._logger.info('Profile : Authenticated user ' +
                          user_name)
        log_kargs['description'] = 'Successful Login by : ' + \
                                   user_name
        if profile.get('failed_login_count', 0) > 0:
            self.update_failed_login_fields(profile, reset=True)

        if impersonate_user_name and \
                impersonate_user_name != user_name:
            if is_admin:
                imp_owner = {'user_name': user_name,
                             'snaid': profile.get('snaid', None)}
                t_profile = self.get_profile_by_user_name(impersonate_user_name,
                                                          clean_profile=False,
                                                          include_prefs=False)
                if t_profile:
                    profile = t_profile
                    profile['impersonated_by'] = imp_owner
                    login_action = UserProfileAction.IMPERSONATION.value
                    log_kargs['description'] = user_name + ' is impersonating ' + \
                                               profile['user_name']
            else:
                self._logger.error('Failed impersonation attempt by : ' + user_name)

        profile = self.get_page_prefs(profile)
        self._populate_entitlements(profile)
        self._clean_profile(profile)
        profile = json.dumps(profile, cls=SimpleJsonDateTimeEncoder)
        ret_profile = json.loads(profile)

        return ret_profile, login_action

    def get_contact_info(self, user_guid):
        response = {"user_id": user_guid, "contact_info": []}

        result = self._execute_query("SELECT * FROM user_profile_contact_info WHERE user_id=%s", [user_guid])
        if result:
            for row in result:
                response["contact_info"].append({
                    "guid": row["guid"],
                    "type": row["ci_type"],
                    "endpoint": row["ci_endpoint"],
                    "confirmed": row["confirmed"].timestamp() if row["confirmed"] else None,
                    "enabled": row["enabled"],
                })

        return response

    def set_contact_info(self, user_guid, contact_info=None):
        if contact_info is None:
            contact_info = []

        conn = psycopg2.connect(self._connection_string)
        cur = conn.cursor()

        try:
            cur.execute("DELETE FROM user_profile_contact_info WHERE user_id=%s", [user_guid])

            for row in contact_info:
                cur.execute("INSERT INTO user_profile_contact_info(user_id, ci_type, ci_endpoint) VALUES(%s, %s, %s)",
                            [user_guid, row["type"], row.get("endpoint", "")])

            conn.commit()

        except Exception as e:
            self._logger.exception("Could not update contact info.")
            conn.rollback()
            raise e

        finally:
            cur.close()
            conn.close()

    def update_contact_info(self, user_guid, row):
        conn = psycopg2.connect(self._connection_string)
        cur = conn.cursor()

        try:
            cur.execute(
                "UPDATE user_profile_contact_info SET enabled=%s, modified=now() WHERE user_id=%s AND ci_type=%s",
                [row.get("enabled", False), user_guid, row["type"]])
            conn.commit()

        except Exception as e:
            self._logger.exception("Could not update contact info.")
            conn.rollback()
            raise e

        finally:
            cur.close()
            conn.close()

    def set_new_contact_info(self, user_guid, row):
        conn = psycopg2.connect(self._connection_string)
        cur = conn.cursor()

        confirm_code = "".join([random.choice(string.digits) for i in range(6)])
        row_id = None

        try:
            cur.execute("DELETE FROM user_profile_contact_info WHERE user_id=%s AND ci_type=%s",
                        [user_guid, row["type"]])
            cur.execute("""
                    INSERT INTO user_profile_contact_info(user_id, ci_type, ci_endpoint, enabled, confirm_code)
                    VALUES(%s, %s, %s, %s, %s)
                    RETURNING guid""",
                        [user_guid, row["type"], row.get("endpoint", ""), row.get("enabled", False), confirm_code])
            row_id = cur.fetchone()[0]
            conn.commit()

        except Exception as e:
            self._logger.exception("Could not update contact info.")
            conn.rollback()
            raise e

        finally:
            cur.close()
            conn.close()
            return {"row_id": row_id, "confirm_code": confirm_code}

    def confirm_contact_info(self, row_guid, user_guid, confirm_code):
        conn = psycopg2.connect(self._connection_string)
        cur = conn.cursor()

        cur.execute("SELECT confirm_code FROM user_profile_contact_info WHERE guid=%s AND user_id=%s",
                    [row_guid, user_guid])
        result = cur.fetchone()
        if not result:
            return {"success": False, "error": "Contact info not found"}

        if result[0] != confirm_code:
            return {"success": False, "error": "Invalid confirmation code"}

        cur.execute("UPDATE user_profile_contact_info SET confirmed=now() WHERE guid=%s", [row_guid])
        conn.commit()

        return {"success": True}

    def delete_contact_info_row(self, row_guid):
        conn = psycopg2.connect(self._connection_string)
        cur = conn.cursor()

        cur.execute("DELETE FROM user_profile_contact_info WHERE guid=%s", [row_guid])
        conn.commit()
