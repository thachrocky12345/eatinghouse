from dd_accessor import DynamoAccessor
from elasticsearch_dsl import Q
from stansberry_article import Article
from elasticsearch_manager import ElasticsearchManager
from intrinio_accessor import IntrinioAccessor

class ArticleAccessor(DynamoAccessor):
  _table_name = "articles"
  _table_authors = "authors"
  _table_publication_codes = "SBT_PUBLICATION_CODE"

  def __init__(self, eshost=None):
    self._es = ElasticsearchManager(None, eshost)
    self._iaccessor = IntrinioAccessor()
    super().__init__()

  def scan_authors (self):
    """
      Returns a list of all authors.

      Returns :
        (list) : List Authors (dict)
    """
    authors = self._scan_table(self._table_authors, None)
    for author in authors :
      author.pop("wordpressId", None)
      author.pop("_id", None)
    return authors


  def scan_author (self, code):
    """
      Returns a single author base on the author code.

      Args :
        code(str) : Author Code

      Returns :
        (dict) : Author Data
    """
    ret_data = {}
    filters = list()
    filters.append(self._create_filter_expression('code', "eq", code))
    filter_exp = self._build_filter_expression(filters)
    results = self._scan_table(self._table_authors, filter_exp)
    if self._sbtcommon.collectionsutil.is_not_empty(results) :
      ret_data = results[0]
      ret_data.pop("wordpressId", None)
      ret_data.pop("_id", None)

    return ret_data

  def scan_publication_codes (self):
    """
      Returns all publication codes.

      Returns :
        (list) : Publication Code Dictionary
    """
    return self._scan_table(self._table_publication_codes, None)

  def query_publication_code (self, code):
    """
      Returns a single publication code.

      Args :
        code(str) : Publication Code

      Returns :
        (dict) : Publication Code
    """
    ret_value = {}

    if self._sbtcommon.stringutil.is_not_empty(code) :
      temp_ret_value = self._unique_item(self._table_publication_codes,
                                         'code', code.upper())

      if self._sbtcommon.collectionsutil.is_not_empty(temp_ret_value) :
        ret_value = temp_ret_value

    return ret_value

  def query_news (self, symbol, start_date):
    """
      Return news articles.

      Args :
        symbol(str)       : Stock ticker symbol
        start_date(str)   : returns all news on or after this date

      Returns :
        list : News articles

    """
    return self._iaccessor.query_news(symbol, start_date)

  def query_articles(self, symbol, start_date):
    match_query = Q("match", tickers=symbol)
    search = self._es.initial_search(query=match_query,
                                     sort_field="-modifiedAt",
                                     doc_type=Article())
    search = self._es.add_filter(search=search, filter_name='range',
                                 filter_dict={'modifiedAt':
                                              {"gte": start_date,
                                               "format": "basic_date"}})
    return self._es.send_response(search, Article.response)

  def query_latest_articles(self, count, category=None):

    if category:
      query = Q('bool',
                filter=[Q('term', **{'defaultCategory.keyword': category})])
      search = self._es.initial_search(query=query, sort_field="-modifiedAt",
                                       doc_type=Article())
    else:
      search = self._es.initial_search(sort_field="-modifiedAt",
                                       doc_type=Article())

    search = self._es.pagination(search=search, size=count)
    return self._es.send_response(search, Article.response)

  def query_articles_by_paragraph(self, symbol, start_date):
    nested_query = Q("nested", path="paragraphs",
                     query=Q("term", **{'paragraphs.tickers.keyword': symbol}),
                     inner_hits={})
    search = self._es.initial_search(query=nested_query,
                                     sort_field="-modifiedAt")
    search = self._es.add_filter(search, 'range', {
      'modifiedAt': {"gte": start_date, "format": "basic_date"}})
    return self._es.send_response(search, Article.paragraphs_response)

  def query_articles_by_publisher(self, symbol, publisher, start_date):
    query = Q('bool',
              must=[Q('term', **{'tickers.keyword': symbol})],
              filter=[Q('term', **{
                'defaultPublication.publicationCode.keyword': publisher}),
                      Q("range",
                        modifiedAt={"gte": start_date, "format": "basic_date"})]
              )
    search = self._es.initial_search(query=query, sort_field="-modifiedAt",
                                     doc_type=Article())
    return self._es.send_response(search, Article.response)

  def query_articles_by_category(self, symbol, category, start_date):
    query = Q('bool',
              must=[Q('term', **{'tickers.keyword': symbol})],
              filter=[Q('term', **{
                'defaultCategory.keyword': category}),
                      Q("range",
                        modifiedAt={"gte": start_date, "format": "basic_date"})]
              )
    search = self._es.initial_search(query=query, sort_field="-modifiedAt",
                                     doc_type=Article())
    return self._es.send_response(search, Article.response)

  def query_articles_company_descriptions(self, symbol):
    prefix = '.*: '
    suffix = '\\).*'
    category = 'company-overview'
    query = Q('bool',
              must=[Q('regexp', **{'title.keyword': prefix + symbol + suffix})],
              filter=[Q('term', **{'defaultCategory.keyword': category})]
              )
    search = self._es.initial_search(query=query, doc_type=Article())
    return self._es.send_response(search, Article.process_description_articles)

  def query_articles_company_bullets(self, symbol):
    prefix = '.*(\\('
    suffix = '\\)).*'
    category = 'company-bullets'
    # q      = '(' + symbol + ') AND company-bullets'
    # f      = [ 'title', 'defaultCategory' ]
    # query  = Q('query_string', query=q, fields=f)
    query = Q('bool',
            must=[Q('regexp', **{'title.keyword': prefix + symbol + suffix})],
             filter=[Q('term', **{'defaultCategory.keyword': category})]
             )
    search = self._es.initial_search(query=query, doc_type=Article())
    return self._es.send_response(search, Article.process_bullet_articles)

  def save_article(self, item):
    """
    Insert JSON formatted data into a specified DynamoDB table
    :param item: the JSON formatted data to be inserted
    :return: the dict returned after insertion
    """
    return self._save(self._table_name, item)

  def delete_article(self, wordpress_id):
    """
    Delete JSON formatted data from a specified DynamoDB table
    :param wordpress_id: the id of the record to be deleted
    :return: the dict returned after deletion
    """
    return self._delete(self._table_name, 'wordpressId', wordpress_id)
