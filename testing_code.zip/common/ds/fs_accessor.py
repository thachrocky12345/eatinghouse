import datetime
import traceback

import pandas as pd
import simplejson as json

from mongo_accessor import MongoAccessor
from sbt_common import SimpleJsonDateTimeEncoder
from snp_accessor import SNPAccessor
from dd_accessor import DynamoAccessor
from mp_accessor import TimeseriesLoader
from mp_accessor import MappingAccessor
from mp_accessor import Vendors
from mp_accessor import TableMapping
from quandl_accessor import QuandlAccessor
from intrinio_accessor import IntrinioAccessor
from sbt_common import SbtCommon
from sbt_common import SbtGlobalCommon
from redis_manager import RedisManager
from data_mapper import SbtDataMapper
from data_mapper import IntrinioDataMapper
from enum import Enum
from functools import lru_cache
from sbt_model_accessor import ModelAccessor
from barchart_accessor import BarchartAccessor
from suggestion import Suggestion

class FinancialAccessorCache :
    _cache_serial_key = ".201907221333."
    _cache_app_code = 'sbt'
    _elastic_cache_validity = 60 * 60 * 24  
    
    def __init__ (self, class_name) :
        self._logger = SbtGlobalCommon.get_global_logger()    
        
        self._logger.info('Set SNPCache for "' + class_name + "'")
        
        self._elastic_cache_manager = RedisManager()  
        
        if self._elastic_cache_manager and \
        not self._elastic_cache_manager.ping_cache() :
            self._elastic_cache_manager = None
        
        self._env = SbtGlobalCommon.get_sbt_config_env()      
        self._cache_base_key = self._env + '.' + self._cache_app_code + \
                                self._cache_serial_key + \
                                class_name + '.'
                                
        self._delete_all_cached_keys()
  
    def is_enabled (self):
        return self._elastic_cache_manager != None
  
    def get_cache_method_parameter_key (self, params):
        c_param = ''
        
        if params :
            for v in params :
                if c_param :
                    c_param = c_param + ','
        
                if v :
                    c_param = c_param + str(v)
                else :
                    c_param = c_param + 'NA'
              
        return c_param
  
    def get_cached_value (self, method_name, param_string):
        value = None
        
        if not self._elastic_cache_manager :
            self._logger.warn('Method _get_cached_value : ' + 
                              'Elastic cache manager not set.')
            return value
    
        key = self._get_elastic_cache_key(method_name, param_string)
    
        if not key :
            self._logger.warn('Key cannot be generated for set cached')
            return value
    
        self._logger.info('Get value for "' + key + ' from elastic cache.')
        string_value = self._elastic_cache_manager.get_string_value(key)
        if string_value :
            try :
                value = json.loads(string_value, use_decimal=True)
            except Exception as e:
                self._logger.error('Encountered exception ' + str(e) +
                                   ' getting cached value for : ' +
                                   key + ' json : ' + string_value)
    
        return value
  
    def set_cached_value (self, method_name, param_string, value):
        if not self._elastic_cache_manager :
            self._logger.warn('Method _set_cached_value : ' +
                              'Elastic cache manager not set.')
            return
          
        if not value:
            self._logger.warn('No value provided for set cached')
            return
    
        key = self._get_elastic_cache_key(method_name, param_string)
    
        if not key :
            self._logger.warn('Key cannot be generated for set cached')
            return
    
        seconds = self._elastic_cache_validity
    
        self._logger.info('Set cache for ' + key
                         + ' elastic cache (expires in ' +
                         str(seconds) + ').')
    
        try :
            value_string = json.dumps(value, cls=SimpleJsonDateTimeEncoder)
            self._elastic_cache_manager.set_value(key, value_string,
                                                  ex=seconds)
        except Exception as e :
            self._logger.error('Encountered exception ' + str(e) +
                               ' setting cached value for : ' +
                               key + ' json : ' + str(value)) 
  
    def _delete_all_cached_keys (self):
        if self._elastic_cache_manager :
            keys = self._elastic_cache_manager.get_cache_keys(
              self._cache_base_key + '*')
            for key in keys :
                if isinstance(key, bytes):
                    str_key = key.decode('utf-8')
                else :
                    str_key = key        
                self._logger.warn('Deleting cache key ' + str_key)
                self._elastic_cache_manager.delete_key(str_key)
        else :
            self._logger.warn('Cannot delete cache keys.')
  
    def _get_elastic_cache_key (self, method_name, param_string):
        if not method_name :
            self._logger.error('No method name or param string provided for ' +
                              'get elastic cache key.')
            return None
    
        if not param_string :
            param_string = 'NO_PARAMS'
    
        key = self._cache_base_key + method_name + '.' + param_string
        self._logger.info('Elastic Cache Key = "' + key + '"')
        return key

class FinancialVendors(Enum):
    """
      Enumeration of supported vendors
    """
    INTRINIO = 'intrinio'
    QUANDL = 'quandl'
    STANDARD_AND_POORS = 'snp'


class FinancialAccessor:
    """
      Class used to access financial data within the system.
      It adds a facade in front of the other data services.
    """

    _stock_price_pull_date = '2013-01-01'

    def __init__(self, vendor):
        """
          Constructor

          Args :
            vendor (str) : Primary data vendor
        """
        self._sbtcommon = SbtCommon()
        self._logger = self._sbtcommon.get_global_logger()
        self._snp_accessor = SNPAccessor()
        self._qaccessor = QuandlAccessor()
        self._iaccessor = IntrinioAccessor()
        self._sbt_data_mapper = SbtDataMapper()
        self._intrinio_data_mapper = IntrinioDataMapper()
        self._primary_data_source = vendor
        self._dd_accessor = DynamoAccessor()
        self._mp_accessor = MappingAccessor()
        self._model_accessor = ModelAccessor()
        self._barchart_accessor = BarchartAccessor()
        self._model_names = ['MOMENTUM', 'CAPITAL_EFFICIENCY', 'MD_SCORE',
                             'MD_SCORE_FIN']
        self._model_names_lookup = {'MOMENTUM': 'momentum',
                                    'CAPITAL_EFFICIENCY': "capitalefficiency",
                                    'MD_SCORE': "mdscore",
                                    'MD_SCORE_FIN': 'mdscorefin',
                                    "MM_MOMENTUM": 'mm_momentum',
                                    'O3_OSCILLATOR': 'o3_oscillator',
                                    'DIVIDEND': 'dividend',
                                    'COMPOSITE': 'composite'}
        self._models_cache = []
        self._models_cache_pull_date = None
        self._financial_accessor_cache = FinancialAccessorCache(self.__class__.__name__) 
        # self._get_model_rankings()
        self._porters_list_portfolio = MongoAccessor("porters_list_portfolio")

    def lookup_symbol(self, symbol, exchange=None):
        ret_data = []

        if exchange or '~' in symbol or ':' in symbol:
            data = self._mp_accessor.unique_symbol_exchange_mapping(symbol,
                                                                    exchange=exchange)
            if data:
                ret_data.append(data)
        else:
            ret_data = self._mp_accessor.query_symbol_exchange_mappings(symbol)

        return ret_data

    def is_valid_symbol(self, symbol, exchange=None, return_snapshot=False):
        """
          Returns a dictionary with metadata indicating whether a
          symbol is loaded in the database.

          Args :
            symbol(str)     : Stock ticker symbol
            exchange(str)   : Exchange code

          Returns :
            dict : Validation response
            :param return_snapshot:

        """
        # flag to avoid calling ES multiple times
        is_full_mapping = False

        ret_value = {}
        ret_value['valid'] = False
        if not symbol:
            return ret_value

        usymbol = symbol.upper()

        ret_value['symbol'] = usymbol

        if '~' in symbol:
            usymbol, exchange = symbol.split('~')[:2]
        elif ':' in symbol:
            usymbol, exchange = symbol.split(':')[:2]
        elif '-' in symbol:
            usymbol, exchange = symbol.split('-')[:2]
        elif self._barchart_accessor.is_index(symbol) \
                or self._barchart_accessor.is_commodity(symbol):
            mapping = self._barchart_accessor.get_index_commodity_mapping(symbol)
            usymbol = mapping.get('symbol')
            exchange = mapping.get('exchange')

        if exchange == 'N/A':
            exchange = None

        uexchange = None
        if exchange:
            uexchange = exchange.upper()
            # quick fix for portfolios that use a
            # different exchange symbol for NasdaQ
            if uexchange in ['NASDAQ']:
                uexchange = 'NSDQ'
        elif exchange is None:
            # if no exchange is provided, then search for
            # a match for the symbol and boost US-based exchanges
            result = Suggestion.get_unique_item(usymbol).get('result')
            # TODO: what to do when there's no exchange found for the symbol?
            if len(result) == 0:
                # if nothing is found for the symbol, return valid = False
                return {'valid': False, 'symbol': usymbol, 'exchange': None}
            uexchange = result.get('exchange') if len(result) else None
            is_full_mapping = True

        symbol_exchange_mapping = {"symbol": usymbol, "exchange": uexchange} if not is_full_mapping else result
        #     self._mp_accessor.unique_stock_symbol_exchange_mapping(usymbol,
        #                                                            exchange=uexchange)

        # if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping \
        #         and self._is_primary_data_snp():
        return self._get_snp_is_valid(symbol_exchange_mapping,
                                      return_snapshot=return_snapshot,
                                      is_full_mapping=is_full_mapping)

        # company = self._get_company_for_symbol(usymbol,
        #                                        exchange=uexchange)
        # if self._sbtcommon.collectionsutil.is_not_empty(company):
        #     ret_value['valid'] = True
        #     ret_value['guid'] = company['guid']
        #     ret_value['exchange'] = [company['mapping']['exchange']]
        #     ret_value['company_name'] = company['mapping']['entity_name']
        #     ret_value['company_type'] = company['template']
        #     if 'sb_portfolio_mapping' in company['mapping'].keys() and \
        #             self._sbtcommon.collectionsutil.is_not_empty(
        #                 company['mapping'][
        #                     'sb_portfolio_mapping']):
        #         ret_value['sb_portfolio'] = True
        #     else:
        #         ret_value['sb_portfolio'] = False
        #
        #     ret_value['supports_sb_content'] = True
        #
        #     if 'latest_filing_date' in company.keys() and \
        #             self._sbtcommon.stringutil.is_not_empty(
        #                 company['latest_filing_date']) and \
        #             len(company['latest_filing_date']) == 10 and \
        #             company['latest_filing_date'] != '0000-00-00':
        #         ret_value['latest_filing_date'] = company['latest_filing_date']
        #     else:
        #         ret_value['latest_filing_date'] = ''
        #
        #     self._set_model_values_for_is_valid_symbol(
        #         company, ret_value)
        #
        # return ret_value

    def query_index(self, symbol):
        """
          Returns dictionary containing information related to the index.

          Args :
            symbol(str)     : index ticker symbol

          Returns :
            dict : index information

        """
        return self._iaccessor.query_index(symbol)

    def query_company_sec_filings(self, symbol):
        """
          Returns dictionary containing the SEC filings and related metadata
          for the specified company.

          Args :
            symbol(str)       : Stock ticker symbol

          Returns :
            dict : Sec filings and metadata

        """
        if not symbol:
            raise Exception('Required parameter is missing for ' +
                            'query_company_sec_filings')

        symbol_exchange_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(
                symbol.upper())

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            return self._snp_accessor.query_company_sec_filings(
                symbol_exchange_mapping)
        else:
            return self._iaccessor.query_company_sec_filings(
                self._get_base_symbol(symbol))

    def query_financial_timeseries(self, symbol, fiscal_period,
                                   exchange=None):
        """
          Returns daily stock prices for a specific symbol.

          Args :
            symbol(str)     : Stock ticker symbol
            timeframe(str)  : Valid Values (1d,1m,1y,5y,10y,Max)
            exchange(str)   : Exchange Code

          Returns :
            list : Stock Data by day
        """
        if not symbol or not fiscal_period:
            raise Exception('Required parameter is missing for ' +
                            'query_financial_timeseries')

        response = None

        symbol_exchange_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(
                symbol.upper(),
                exchange=exchange)

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            response = self._snp_accessor.query_financial_timeseries(
                symbol_exchange_mapping, fiscal_period)

        return response

    def query_stock_price(self, symbol, timeframe,
                          standardized_format=False, timestamp=None,
                          exchange=None):
        """
          Returns daily stock prices for a specific symbol.

          Args :
            symbol(str)     : Stock ticker symbol
            timeframe(str)  : Valid Values (1d,1m,1y,5y,10y,Max)

          Returns :
            list : Stock Data by day
        """

        response = None

        symbol_exchange_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(
                symbol.upper(),
                exchange=exchange)

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            exchange_code = self._mp_accessor.get_exchanges().get(
                symbol_exchange_mapping['exchange'], {}).get(
                'vendor_mapping', {}).get(
                self._primary_data_source, None)

            if exchange_code:
                symbol_exchange_mapping['vendor_exchange_code'] = \
                exchange_code[0]

            response = self._snp_accessor.query_stock_price(
                symbol_exchange_mapping,
                timeframe,
                standardized_format,
                timestamp)
        else:
            if standardized_format:
                response = self._query_standardized_stock_price(
                    self._get_base_symbol(symbol), timeframe, timestamp)
            else:
                response = self._iaccessor.query_stock_price(
                    self._get_base_symbol(symbol), timeframe)

        return response

    def query_history_data(self, symbol, column, typ, sort,
                           exchange=None):
        """
          Returns a list of financial data for the specified symbol
          and column and typ

          Args :
            symbol (str) : Ticker Symbol
            column (str) : Column data
            typ(str)     : Fiscal Period (a - annual, q - quarterly)
            sort(str)    : Sort Order (asc or desc)
            exchange     : Exchange Code (Optional)

          Returns :
            list : Column values
        """
        if not column or not symbol:
            raise Exception('Required parameters are missing for ' +
                            'query_history_data')

        symbol_exchange_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(symbol,
                                                                   exchange=exchange)

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            return self._snp_accessor.query_history_data(
                symbol_exchange_mapping,
                column, typ, sort)
        else:
            return self._iaccessor.query_history_data(
                self._get_base_symbol(symbol),
                column, typ, sort)

    def query_dynamodb(self, symbol, year):
        """
          Returns a list of all financial data elements for the specified ticker
          and year

          Args :
            symbol (str) : Ticker Symbol
            year (str)   : Year you are interested in seeing data for.


          Returns :
            list : Company and Company Financial Information
        """
        if self._is_primary_data_intrinio():
            ret_dict = self._intrinio_data_mapper.finance_converter('a',
                                                                    self._iaccessor.query_dynamodb(
                                                                        self._get_base_symbol(
                                                                            symbol),
                                                                        year),
                                                                    strip_metadata=False)
            # Converts Intrinio response so it is exactly the same as QUANDL
            ret_list = []
            if len(ret_dict) > 0:
                ret_list.append(ret_dict[int(year)])

            self._intrinio_data_mapper.company_converter(ret_list)

            return ret_list
        else:
            return self._qaccessor.query_dynamodb(symbol, year)

    def query_financial_by_category(self, category, symbol, year, typ):
        """
          Returns a dictionary financial data related to the specified category,
          symbol, year and type

           Args :
            category(str)  : Financial Category (CASH, CALCULATION, BALANCE, INCOME)
            symbol (str)   : Ticker Symbol
            year (str)     : Year you are interested in seeing data for.
            typ (str)      : Fiscal Period (a - annual, q - quarterly)

          Returns :
            dict : Company Financial Information
        """
        if self._is_primary_data_intrinio():
            # Converts Intrinio response so it is exactly the same as QUANDL
            return self._intrinio_data_mapper.finance_converter(typ,
                                                                self._iaccessor.query_financial_by_category(
                                                                    category,
                                                                    self._get_base_symbol(
                                                                        symbol),
                                                                    year, typ))
        else:
            return self._qaccessor.query_financial_by_category(category,
                                                               self._get_base_symbol(
                                                                   symbol),
                                                               year, typ)

    def query_financial_by_category_from(self, category, symbol,
                                         startyear, typ):
        """
          Returns a dictionary financial data related to the specified category,
          symbol, startyear and type

          Args :
            category(str)  :Financial Category (CASH, CALCULATION, BALANCE, INCOME)
            symbol (str)   :Ticker Symbol
            startyear(str) :Start Year
            to (str)       :End Year
            typ (str)      :Fiscal Period (a - annual, q - quarterly)

          Returns :
            dict : Company Financial Information
        """
        if self._is_primary_data_intrinio():
            # Converts Intrinio response so it is exactly the same as QUANDL
            return self._intrinio_data_mapper.finance_converter(typ,
                                                                self._iaccessor.query_financial_by_category_from(
                                                                    category,
                                                                    self._get_base_symbol(
                                                                        symbol),
                                                                    startyear,
                                                                    typ),
                                                                group_by_year=True)
        else:
            return self._qaccessor.query_financial_by_category_from(category,
                                                                    self._get_base_symbol(
                                                                        symbol),
                                                                    startyear,
                                                                    typ)

    def query_category_group_by_range(self, category,
                                      symbol, frm, to, typ):
        """
          Returns a dictionary financial data related to the specified category,
          symbol, from date, to date and type

           Args :
            category(str)  : Financial Category (CASH, CALCULATION, BALANCE, INCOME)
            symbol (str)   : Ticker Symbol
            frm (str)      : Start Year
            to (str)       : End Year
            typ (str)      : Fiscal Period (a - annual, q - quarterly)

          Returns :
            dict : Company Financial Information
        """
        ret_data = {}

        if not category or not symbol or not frm or not typ:
            raise Exception('Required parameters are missing for ' +
                            'query_financial_by_category_range')

        sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(
            symbol.upper())

        if sem and 'snp_id' in sem and self._is_primary_data_snp():
            ret_data = self._snp_accessor.query_category_group_by_range(
                category,
                sem,
                frm,
                to,
                typ)

        return ret_data

    def query_category_group_by_range_with_metadata(self, category,
                                                    symbol, frm, to, typ):
        """
          Returns a dictionary financial data related to the specified category,
          symbol, from date, to date and type

           Args :
            category(str)  : Financial Category (CASH, CALCULATION, BALANCE, INCOME)
            symbol (str)   : Ticker Symbol
            frm (str)      : Start Year
            to (str)       : End Year
            typ (str)      : Fiscal Period (a - annual, q - quarterly)

          Returns :
            dict : Company Financial Information
        """
        ret_data = {}

        if not category or not symbol or not frm or not typ:
            raise Exception('Required parameters are missing for ' +
                            'query_financial_by_category_range')

        sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(
            symbol.upper())

        if sem and 'snp_id' in sem and self._is_primary_data_snp():
            ret_data = \
                self._snp_accessor.query_category_group_by_range_with_metadata(
                    category,
                    sem,
                    frm,
                    to,
                    typ)

        return ret_data

    @lru_cache(maxsize=2000, typed=False)
    def query_financial_by_category_range(self, category,
                                          symbol, frm, to, typ,
                                          source='intrinio'):
        """
          Returns a dictionary financial data related to the specified category,
          symbol, from date, to date and type

           Args :
            category(str)  : Financial Category (CASH, CALCULATION, BALANCE, INCOME)
            symbol (str)   : Ticker Symbol
            frm (str)      : Start Year
            to (str)       : End Year
            typ (str)      : Fiscal Period (a - annual, q - quarterly)

          Returns :
            dict : Company Financial Information
        """
        ret_data = {}

        if not category or not symbol or not frm or not typ:
            raise Exception('Required parameters are missing for ' +
                            'query_financial_by_category_range')

        sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(
            symbol.upper())

        if sem and 'snp_id' in sem and self._is_primary_data_snp():
            ret_data = self._snp_accessor.query_financial_by_category_range(
                category,
                sem,
                frm,
                to,
                typ)

        if ret_data:
            return ret_data

        if source == 'intrinio' and self._is_primary_data_intrinio():
            # Converts Intrinio response so it is exactly the same as QUANDL
            ret_data = self._intrinio_data_mapper.finance_converter(typ,
                                                                    self._iaccessor.query_financial_by_category_range(
                                                                        category,
                                                                        self._get_base_symbol(
                                                                            symbol),
                                                                        frm,
                                                                        to,
                                                                        typ),
                                                                    group_by_year=True)
        else:
            ret_data = self._qaccessor.query_financial_by_category_range(
                category,
                self._get_base_symbol(symbol), frm, to, typ)

        return ret_data

    @lru_cache(maxsize=2000, typed=False)
    def query_financial_by_category_range_with_metadata(self,
                                                        category, symbol, frm,
                                                        to, typ,
                                                        source='intrinio'):
        """
          Returns a dictionary financial data related to the specified category,
          symbol, from date, to date and type

           Args :
            category(str)  : Financial Category (CASH, CALCULATION, BALANCE, INCOME)
            symbol (str)   : Ticker Symbol
            frm (str)      : Start Year
            to (str)       : End Year
            typ (str)      : Fiscal Period (a - annual, q - quarterly)

          Returns :
            dict : Company Financial Information
        """
        ret_data = {}

        if not category or not symbol or not frm or not typ:
            raise Exception('Required parameters are missing for ' +
                            'query_financial_by_category_range')

        sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(
            symbol.upper())

        if sem and 'snp_id' in sem and self._is_primary_data_snp():
            ret_data = \
                self._snp_accessor.query_financial_by_category_range_with_metadata(
                    category,
                    sem,
                    frm,
                    to,
                    typ)

        if ret_data:
            return ret_data

        if source == 'intrinio' and self._is_primary_data_intrinio():
            # Converts Intrinio response so it is exactly the same as QUANDL
            ret_data = self._intrinio_data_mapper.finance_converter(typ,
                                                                    self._iaccessor.query_financial_by_category_range(
                                                                        category,
                                                                        self._get_base_symbol(
                                                                            symbol),
                                                                        frm,
                                                                        to,
                                                                        typ),
                                                                    group_by_year=True)
        else:
            ret_data = self._qaccessor.query_financial_by_category_range(
                category,
                self._get_base_symbol(symbol), frm, to, typ)

        return {'metadata': {}, 'fundamentals': ret_data}

    def query_category_group(self, category, symbol):
        if not category or not symbol:
            raise Exception('Required fields are missing.')

        symbol_exchange_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(
                symbol.upper())

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            return self._snp_accessor.query_category_group(category,
                                                           symbol_exchange_mapping)
        elif self._is_primary_data_intrinio():
            return self._iaccessor.query_category_group(category,
                                                        self._get_base_symbol(
                                                            symbol))

    def query_category_groups(self, symbol=None):
        """
          Returns a dictionary of the financial data data grouped under
          specific headers.

          Returns :
            dict : Financial Groups
        """
        symbol_exchange_mapping = None
        if symbol:
            symbol_exchange_mapping = \
                self._mp_accessor.unique_stock_symbol_exchange_mapping(
                    symbol.upper())

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            return self._snp_accessor.query_category_groups(
                symbol_exchange_mapping)
        if self._is_primary_data_intrinio():
            return self._iaccessor.query_category_groups()
        else:
            return self._qaccessor.query_category_groups()

    def query_insider_ownership(self, symbol):
        """
          Retrieve insider ownership for the specified symbol

          Args :
            symbol (str) : Ticker Symbol

          Returns :
            list : Company insider ownership
        """
        return self._iaccessor.query_insider_ownership(
            self._get_base_symbol(symbol))

    def query_insider_transactions(self, symbol):
        """
          Retrieve insider transactions for the specified symbol

          Args :
            symbol (str) : Ticker Symbol

          Returns :
            list : Company insider transactions
        """
        return self._iaccessor.query_insider_transactions(
            self._get_base_symbol(symbol))

    def query_insider_metrics(self, symbol, metricstype):
        """
          Returns a list of insider metrics for the specified symbol and type

          Args :
            symbol (str)   : Ticker Symbol
            metricstype(int)  : Metrics Type (1, 2, 4)
        """
        return self._qaccessor.query_insider_metrics(
            self._get_base_symbol(symbol),
            metricstype)

    def query_institutional_holdings(self, symbol):
        """
          Returns a list of institutional holdings for the specified symbol

          Args :
            symbol (str)   : Ticker Symbol
        """
        if self._is_primary_data_intrinio():
            return self._iaccessor.query_institutional_holdings(
                self._get_base_symbol(symbol))
        else:
            return self._qaccessor.query_institutional_holdings(
                self._get_base_symbol(symbol))

    def query_company(self, symbol):
        """
          Returns a list of company data.

          Args :
            symbol (str) : Ticker Symbol

          Returns :
            list : Company Information
        """
        if not symbol:
            raise Exception('Required parameter is missing for ' +
                            'query_company')

        ret = []

        symbol_exchange_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(
                symbol.upper())

        company = self._query_company(symbol_exchange_mapping)

        if company : 
            if symbol_exchange_mapping.get('exchange_country', 'NA') == 'USA':
                quote = self._barchart_accessor.get_stock_quote(
                    [symbol])
                if quote:
                    high = quote[0].get('fiftyTwoWkHigh',
                                        company.get('fifty_two_week_high', 0))
                    low = quote[0].get('fiftyTwoWkLow',
                                       company.get('fifty_two_week_low', 0))
                    company['fifty_two_week_high'] = high
                    company['fifty_two_week_low'] = low
                    company['52_week_high'] = high
                    company['52_week_low'] = low
                              
            ret.append(company)
        
        return ret

    def query_debt_summary(self, symbol):
        symbol_exchange_mapping = None
        if symbol:
            symbol_exchange_mapping = \
                self._mp_accessor.unique_stock_symbol_exchange_mapping(
                    symbol.upper())

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            return self._snp_accessor.query_debt_summary(
                symbol_exchange_mapping)
        else:
            return []

    def query_capital_structure_debt_detail(self, symbol):
        symbol_exchange_mapping = None
        if symbol:
            symbol_exchange_mapping = \
                self._mp_accessor.unique_stock_symbol_exchange_mapping(
                    symbol.upper())

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            return self._snp_accessor.query_capital_structure_debt_detail(
                symbol_exchange_mapping)
        else:
            return []

    def query_capital_structure_debt_yearly_summary(self, symbol):
        symbol_exchange_mapping = None
        if symbol:
            symbol_exchange_mapping = \
                self._mp_accessor.unique_stock_symbol_exchange_mapping(
                    symbol.upper())

        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            return self._snp_accessor.query_capital_structure_debt_yearly_summary(
                symbol_exchange_mapping)
        else:
            return {}

    def query_metadata(self, category, symbol):
        """
         Retrieve a list of metadata related to the specified category and symbol

          Args :
            category(str)  : Financial Category (CASH, CALCULATION, BALANCE, INCOME)
            symbol (str)   : Ticker Symbol

          Returns :
            list : Financial Information Metadata
        """
        if self._is_primary_data_intrinio():
            # Converts Intrinio response so it is exactly the same as QUANDL
            return self._intrinio_data_mapper.metadata_converter(
                self._iaccessor.query_metadata(category,
                                               self._get_base_symbol(symbol)))
        else:
            return self._qaccessor.query_metadata(category)

    def get_figi_code(self, symbol, exchange):
        code = None

        if not symbol or not exchange:
            return code

        symbol_exchange_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(
                symbol.upper(),
                exchange.upper())

        return self._snp_accessor.get_figi_code(symbol_exchange_mapping)

    def consolidate_and_check_groupings(self, category, groupings):
        self._snp_accessor.consolidate_and_check_groupings(category, groupings)

    def returns_formatted_grouping(self, category, symbol, exchange=None):
        ret_value = False

        if not symbol or not category or \
                category.upper() not in ['INCOME', 'BALANCE', 'CASH']:
            return ret_value

        usymbol = symbol.upper()
        uexchange = None
        if exchange:
            uexchange = exchange.upper()

        if self._is_primary_data_snp():
            symbol_exchange_mapping = \
                self._mp_accessor.unique_stock_symbol_exchange_mapping(usymbol,
                                                                       exchange=uexchange)

            if symbol_exchange_mapping and \
                    symbol_exchange_mapping.get('snp_type', -1) in [1, 2, 3, 4,
                                                                    5, 7, 8]:
                ret_value = True

        return ret_value

    def query_etf(self, symbol):
        ret = {}

        if not symbol:
            return ret

        sem = self._mp_accessor.unique_symbol_exchange_mapping(symbol)

        if sem:
            guid = sem.get('sbt_company_id', sem['guid'])
            ret = self._get_cached_value('query_etf', guid)
          
            if not ret :
              # hit Intrinio API for data
              ret = self._iaccessor.query_etf(sem)
              if ret :
                  self._populate_etf_description(sem, ret)      
                  self._set_cached_value('query_etf', guid, ret)

        return ret

    def query_etf_holdings(self, symbol):
        ret = []

        if not symbol:
            return ret

        sem = self._mp_accessor.unique_symbol_exchange_mapping(symbol)

        if sem:
            ret = self._iaccessor.query_etf_holdings(sem)

        return ret

    def query_company_exchanges(self, company_id):
        ret = {}
        sem = Suggestion.get_items_by_company_id(company_id)

        if sem.get('success'):
            exchanges = []
            [exchanges.append({
                'symbol': e.get('symbol'),
                'exchange': e.get('exchange'),
                'exchange_name': e.get('exchange_name'),
                'exchange_country': e.get('exchange_country'),
                'exchange_currency': e.get('exchange_currency', 'N/A'),
                'guid': e.get('trading_item_id'),
                'global_id': e.get('global_id', ''),
                'primary': e.get('is_primary_exchange')
            }) for e in sem['result']]

            ret = {
                'company_id': sem.get('result')[0].get('company_id'),
                'name': sem.get('result')[0].get('entity_name'),
                'exchanges': exchanges
            }

        return ret

    def cache_clear(self):
        self._logger.info('Clearing Financial Accessor Cache')
        self._logger.info(self.query_financial_by_category_range.cache_info())
        self.query_financial_by_category_range.cache_clear()

    def _is_primary_data_snp(self):
        """
          Returns true if the primary data source in Intrinio

          Returns :
            bool : True if Intrinio is the primary data source
        """
        return self._primary_data_source == 'snp'

    def _is_primary_data_intrinio(self):
        """
          Returns true if the primary data source in Intrinio

          Returns :
            bool : True if Intrinio is the primary data source
        """
        return self._primary_data_source == 'intrinio' or \
               self._is_primary_data_snp()

    def _populate_etf_description (self, symbol_exchange_mapping, ret):        
        ret['top_holding_market_cap'] = 0
        ret['top_holding_revenue'] = 0
        # ret['fifty_two_week_low'] = 0.00
        # ret['fifty_two_week_high'] = 0.00
        # ret['dividendyield'] = 0.00
        #
        # co_data = self._query_company(symbol_exchange_mapping)
        # if co_data :
        #     ret['fifty_two_week_low'] = co_data.get('fifty_two_week_low', 0.00)
        #     ret['fifty_two_week_high'] = co_data.get('fifty_two_week_high', 0.00)
        #     ret['dividendyield'] = co_data.get('dividendyield', 0.00)

        holdings = self.query_etf_holdings(symbol_exchange_mapping['symbol'])

        snapshot = self.get_snapshot(symbol_exchange_mapping['snp_trading_item_id'])
        ret['snapshot'] = snapshot
        # adding info about dividends
        # ret['dividend_amount'] = snapshot.get('dividend_amount', 0)
        # ret['adjustment_factor'] = snapshot.get('adjustment_factor', 0)
        # ret['split_adjusted_dividend_amount'] = snapshot.get(
        #     'split_adjusted_dividend_amount', 0)
        # ret['dividend_exdate'] = snapshot.get('dividend_exdate', 0)
        # ret['dividend_paydate'] = snapshot.get('dividend_paydate', 0)
        # ret['dividend_record'] = snapshot.get('dividend_record', 0)
        # ret['annualized_dividend'] = snapshot.get('annualized_dividend', 0)
        # ret['dividend_currency'] = snapshot.get('dividend_currency', 0)
        # ret['dividend_yield_percentage'] = snapshot.get(
        #     'dividend_yield_percentage', 0)
        # ret['last_close_price'] = snapshot.get(
        #     'last_close_price', 0)
        # ret['last_close_pricedate'] = snapshot.get(
        #     'last_close_pricedate', 0)
      
        ret['top_ten_holdings'] = []
        if holdings :
            ret['top_ten_holdings'] = holdings
            top = holdings[0]
            t_symbol = top.get('ticker', None)
            if t_symbol :
                t_sem = self._mp_accessor.unique_symbol_exchange_mapping(t_symbol)
                if t_sem :
                  t_company = self.get_snapshot(t_sem.get('snp_trading_item_id'))
                  if t_company :
                      ret['top_holding_market_cap'] = t_company.get('market_cap',0)
                      ret['top_holding_revenue'] = t_company.get('total_revenue',0)

      
    def _query_standardized_stock_price(self, symbol, timeframe,
                                        timestamp=None):
        """
          Returns daily stock prices for a specific symbol.

          Args :
            symbol(str)     : Stock ticker symbol
            timeframe(str)  : Valid Values (1d,1m,1y,5y,10y,Max)

          Returns :
            dict : Stock Data dictionary

        """

        response = None

        sym_mapping = \
            self._mp_accessor.unique_stock_symbol_exchange_mapping(symbol)
        if self._sbtcommon.collectionsutil.is_empty(sym_mapping):
            return response

        tm_guid = '6bbd065d-0b13-49ef-a85d-cf0f26eccd62'
        if 'index' in sym_mapping.keys() and sym_mapping['index']:
            tm_guid = '1f2fe84b-c3a8-4f36-a06d-598170264a6a'

        table_mapping = self._mp_accessor.get_table_mapping(tm_guid)

        table_name = self._get_validated_vendor_table_name(table_mapping)
        if self._sbtcommon.stringutil.is_empty(table_name):
            return response

        co_id = sym_mapping.get('sbt_company_id',
                                sym_mapping.get('guid', None))

        prices = self._dd_accessor._query_table(table_name,
                                                'guid',
                                                co_id)
        if self._sbtcommon.collectionsutil.is_empty(prices):
            self._generate_initial_stock_price_data(sym_mapping,
                                                    table_mapping)

            prices = self._dd_accessor._query_table(table_name,
                                                    'guid',
                                                    co_id)

        compare_date = None
        if timestamp is not None:
            compare_date = \
                datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d')
        else:
            compare_date = self._get_stockprice_timeframe_start_date(timeframe)

        filtered_price_list = []

        if self._sbtcommon.collectionsutil.is_not_empty(prices):
            filtered_prices = filter(lambda x: x['date'] >= compare_date,
                                     prices)
            filtered_price_list = sorted(filtered_prices,
                                         key=lambda k: k['date'])

        if timestamp is None and timeframe.upper() == '1D' and \
                len(filtered_price_list) > 0:
            last_day = filtered_price_list[(len(filtered_price_list) - 1)]
            filtered_price_list = []
            filtered_price_list.append(last_day)

        metadata = {}
        metadata['category_name'] = table_mapping.get_format_name()
        metadata['mappings'] = table_mapping.get_value_attributes_metadata()
        response = self._sbt_data_mapper.get_formatted_financial_data(
            sym_mapping,
            metadata,
            filtered_price_list)

        return response

    def _get_stockprice_timeframe_start_date(self, timeframe):
        """
          Returns start date based on the timeframe that is provided.

          Args :
            timeframe(str)  : Valid Values (1d,1m,1y,5y,10y,Max)

          Returns :
            str : String date value YYYY-MM-DD
        """
        kwargs = {}
        kwargs['days'] = -1

        start_date = self._sbtcommon.dateutil.get_relative_date(months=-1,
                                                                date_format='%Y-%m-%d',
                                                                **kwargs)

        if timeframe.upper() == '1Y':
            start_date = self._sbtcommon.dateutil.get_relative_date(months=-12,
                                                                    date_format='%Y-%m-%d',
                                                                    **kwargs)
        elif timeframe.upper() == '5Y':
            start_date = self._sbtcommon.dateutil.get_relative_date(months=-60,
                                                                    date_format='%Y-%m-%d',
                                                                    **kwargs)
        elif timeframe.upper() == '10Y':
            start_date = self._sbtcommon.dateutil.get_relative_date(
                months=-120,
                date_format='%Y-%m-%d',
                **kwargs)
        elif timeframe.upper() == 'MAX':
            start_date = self._sbtcommon.dateutil.get_relative_date(
                months=-240,
                date_format='%Y-%m-%d',
                **kwargs)

        return start_date

    def _generate_initial_stock_price_data(self,
                                           symbol_mapping,
                                           table_mapping):

        l_vendor = self._primary_data_source.lower()
        conf = table_mapping.get_vendor_mappings()[l_vendor]
        params = []
        params.append({
            "action": "static",
            "input": "ticker",
            "type": "string",
            "value": symbol_mapping['symbol']
        })
        params.append({
            "action": "static",
            "input": "start_date",
            "type": "string",
            "value": self._stock_price_pull_date
        })
        conf['extraction']['custom']['parameters'] = params
        _ts_loader = TimeseriesLoader(table_mapping, [symbol_mapping],
                                      override_vendor_mapping=conf,
                                      vendor=l_vendor)
        _ts_loader.load_data()

    def _get_validated_vendor_table_name(self, table_mapping):
        """
          Returns a validated vendor table name

          Args :
            table_mapping(TableMapping) : TableMapping

          Returns :
            str : Vendor Table Name
        """
        table_name = None

        temp_table_name = table_mapping.get_table_name(
            'intrinio')

        if self._dd_accessor._table_exists(temp_table_name):
            table_name = temp_table_name

        return table_name

    def _get_base_symbol(self, symbol):
        """
          Returns the base company symbol.  Some companies can have
          multiple symbols that map to the same entity.  This methods
          resolve the symbol that is entered to the base symbol

          Args :
            symbol(str) : Symbol

          Returns :
            str : Symbol
        """
        base_symbol = symbol

        company = self._get_company_for_symbol(symbol)
        if self._sbtcommon.collectionsutil.is_not_empty(company):
            base_symbol = company['ticker']

        return base_symbol

    def _get_model(self, symbol_exchange_mapping):
        return self._model_accessor.query_all_company_models(
            symbol_exchange_mapping)

    def get_exchange_mapping(self, exchange_symbol):
        if exchange_symbol is not None:
            if exchange_symbol.startswith('OTC'):
                exchange_mapping = 'OTC'
            else:
                exchange_mapping = \
                    self.EXCHANGE_MAPPING.get(exchange_symbol, exchange_symbol)
        else:
            self._logger.error(" EXCHANGE IS NONE.")
            exchange_mapping = exchange_symbol

        return exchange_mapping

    # TODO: implement cache here
    def _get_snp_is_valid(self, symbol_exchange_mapping,
                          return_snapshot=False, is_full_mapping=False):

        ret_value = {}
        ret_value['valid'] = False

        if len(symbol_exchange_mapping) == 0:
            return ret_value
        symbol = symbol_exchange_mapping.get('symbol')
        exchange = symbol_exchange_mapping.get('exchange')

        ret_value['symbol'] = symbol
        ret_value['exchange'] = [exchange]

        if not is_full_mapping:
            # 1 - hit ES for SYM+EXC
            res = Suggestion.get_unique_item(
                symbol=symbol_exchange_mapping['symbol'],
                exchange=symbol_exchange_mapping['exchange']
            )
            if len(res['result']):
                symbol_exchange_mapping = res['result']
                # update exchange in case we're using an exchange mapping
                ret_value['exchange'] = [symbol_exchange_mapping.get('exchange')]
            else:
                # if no result is found in ES, return valid = False
                return ret_value

        # dealing with periods in the symbol
        symbol = symbol_exchange_mapping['symbol']
        symbol = symbol.replace('.', '') \
            if '.' in symbol \
               and len(symbol.replace('.', '')) == 5 \
               and symbol_exchange_mapping['exchange'] == "OTC" \
            else symbol

        # 2 - extract company_id and trading_item_id from result
        company_id = symbol_exchange_mapping.get('company_id')
        trading_item_id = symbol_exchange_mapping.get('trading_item_id')

        # 3 - get portfolio list
        # TODO: move this into ES
        pf_list = [x for x in self._porters_list_portfolio.find(
            {"symbol": symbol, "exchange": exchange}
        )]
        sb_portfolio_mapping = pf_list[0]['publications'] if len(pf_list) else []
        ret_value['sb_portfolio'] = True if len(sb_portfolio_mapping) else False

        # 4 - check if supports SB content (USA exchange or in a SB portfolio)
        ret_value['supports_sb_content'] = True \
            if symbol_exchange_mapping.get('exchange_country') == 'USA' \
                    or ret_value.get('sb_portfolio') \
            else False
        # TODO: move the call to the snapshot into the IF block
        # 5 - call snapshot for trading_item_id
        if return_snapshot:
            snapshot = self.get_snapshot(trading_item_id)
            # only return data that's necessary for snapshot
            ret_val = {
                "snapshot": snapshot,
                "supports_sb_content": ret_value['supports_sb_content']
            }
            return ret_val

        # 6 - get all exchanges that the company trades on
        all_exchanges = Suggestion.get_items_by_company_id(company_id)

        if not symbol_exchange_mapping:
            return ret_value

        exchange_type = symbol_exchange_mapping.get('exchange_type', 'N/A')

        ret_value['original_symbol'] = symbol_exchange_mapping['symbol']

        ret_value['valid'] = True
        ret_value['guid'] = symbol_exchange_mapping['trading_item_id']
        ret_value['sbt_company_id'] = symbol_exchange_mapping.get('company_id')
        ret_value['exchange_type'] = [exchange_type]

        other_exchanges = [x for x in all_exchanges if x != exchange]
        if len(other_exchanges):
            ret_value['exchange'].extend(
                ret_value.get('associated_exchanges', []))

        ret_value['company_name'] = symbol_exchange_mapping['entity_name']
        # TODO: remove this attribute
        # ret_value['company_type'] = 'N/A'

        ret_value['supports_streaming'] = \
            symbol_exchange_mapping.get('support_streaming', False)
        # TODO: remove this attribute
        # ret_value['latest_filing_date'] = snapshot.get('latest_filing_date')

        # TODO: fix this value in Elasticsearch to use Intrinio data
        #  (currently using S&P's classification for ETFs)
        ret_value['is_etf'] = symbol_exchange_mapping.get('is_etf')

        # if 'snp_latest_filing_date' in symbol_exchange_mapping and \
        #         symbol_exchange_mapping[
        #             'snp_latest_filing_date'] != '0000-00-00' and \
        #         symbol_exchange_mapping['snp_latest_filing_date'] != 'N/A':
        #     ret_value['latest_filing_date'] = \
        #         symbol_exchange_mapping['snp_latest_filing_date']

        # get info about models
        # TODO: get this into ES
        models = self._get_model(symbol_exchange_mapping)
        # list with the names of the available models for the company
        available_model_names = [list(m.keys())[0] for m in models]

        # ret_value['indicators'] = {
        #     "momentum": False,
        #     "capitalefficiency": False,
        #     "mdscore": False,
        #     "mdscorefin": False,
        #     "mm_momentum": False,
        #     "o3_oscillator": False
        # }

        # if models:
        #     for m in models:
        #         if 'model_id' in m:
        #             if m['model_id'] in self._model_names_lookup and \
        #                     self._model_names_lookup[m['model_id']] in ret_value[
        #                 'indicators']:
        #                 ret_value['indicators'][
        #                     self._model_names_lookup[m['model_id']]] = True

        # create indicators attribute
        ret_value['indicators'] = {
            self._model_names_lookup[x]: True
                if self._model_names_lookup[x] in available_model_names
                else False
            for x in self._model_names_lookup
        }

        ret_value['company_id'] = symbol_exchange_mapping.get('company_id')
        ret_value['trading_item_id'] = symbol_exchange_mapping.get('trading_item_id')

        return ret_value

    def _get_model_rankings(self):
        current = datetime.datetime.now()

        if not self._models_cache_pull_date or \
                (current - self._models_cache_pull_date).total_seconds() > 10:
            self._logger.info('Load model cache')
            for name in self._model_names:
                rankings = self._model_accessor.query_model_ranking(name)
                if rankings:
                    self._models_cache.append(rankings)
            self._models_cache_pull_date = current

        return self._models_cache

    def _set_model_values_for_is_valid_symbol(self, company,
                                              valid_symbol):
        """
          Set model values within the is_valid_symbol.

          Args :
            company (dict) : Contains company info
            valid_symbol (dict) : Is valid response data

          Return :
            None
        """

        model_names = ['MOMENTUM', 'CAPITAL_EFFICIENCY', 'MD_SCORE',
                       'MD_SCORE_FIN', 'MM_MOMENTUM', 'DIVIDEND']
        models = []
        for name in model_names:
            models.append(self._model_accessor.query_model_ranking(name))

        # This is within a try catch so an error is not thrown to the
        # front end, but instead is logged.
        try:
            # valid_symbol['indicators'] = {
            #     "momentum": bool(len([True for x in models[0][0]['rankings']
            #                           if x['guid'] == company['guid']])),
            #     "capitalefficiency": bool(
            #         len([True for x in models[1][0]['rankings']
            #              if x['guid'] == company['guid']])),
            #     "mdscore": bool(len([True for x in models[2][0]['rankings']
            #                          if x['guid'] == company['guid']])),
            #     "mdscorefin": bool(len([True for x in models[3][0]['rankings']
            #                             if x['guid'] == company['guid']]))
            # }

            # check existence of results for company
            has_mom_res = False
            has_mmmom_res = bool("SELECT COUNT(*) " \
                             "FROM development_sbt_models_mmmomentum " \
                             "WHERE guid='{}'".format(company['guid']))
            has_div_res = bool("SELECT COUNT(*) " \
                                 "FROM development_sbt_models_dividend_rankings " \
                                 "WHERE guid='{}'".format(company['guid']))
            has_capeff_res = bool("SELECT COUNT(*) " \
                             "FROM development_sbt_models_capeff " \
                             "WHERE guid='{}'".format(company['guid']))
            has_mdscore_res = bool("SELECT COUNT(*) " \
                              "FROM development_sbt_models_mdscore_valuation "\
                              "WHERE guid='{}'".format(company['guid']))
            has_mdscorefin_res = bool("SELECT COUNT(*) " \
                             "FROM development_sbt_models_mdscore_financial " \
                             "WHERE guid='{}'".format(company['guid']))
            has_composite_res = bool("SELECT COUNT(*) " \
                                      "FROM development_sbt_models_composite " \
                                      "WHERE guid='{}'".format(
                company['guid']))
            valid_symbol['indicators'] = {
                "momentum": has_mom_res,
                "capitalefficiency": has_capeff_res,
                "mdscore": has_mdscore_res,
                "mdscorefin": has_mdscorefin_res,
                "mm_momentum": has_mmmom_res,
                "dividend": has_div_res,
                "composite": has_composite_res
            }
        except Exception as exc:
            # Set default values.
            valid_symbol['indicators'] = {
                "momentum": False,
                "capitalefficiency": False,
                "mdscore": False,
                "mdscorefin": False,
                "mm_momentum": False,
                "dividend": False,
                "composite": False
            }
            self._logger.error('Failed to set model values : ' + str(exc) +
                               ' Trace : ' + traceback.format_exc())

    def _get_company_for_symbol(self, symbol, exchange=None):
        """
          Returns company object associated with symbol

          Args :
            symbol(str) : Symbol
            exchange(str) : Exchange

          Returns :
            dict : Company Data
        """
        company = None
        sem = self._mp_accessor.unique_stock_symbol_exchange_mapping(symbol,
                                                                     exchange=exchange)
        if self._sbtcommon.collectionsutil.is_not_empty(sem):
            table_mapping = self._mp_accessor.get_table_mappings_by_name_and_code(
                '_US_COMPANY')
            table_name = self._get_validated_vendor_table_name(table_mapping)
            company = None
            if self._sbtcommon.stringutil.is_not_empty(table_name):
                co_id = sem.get('sbt_company_id',
                                sem.get('guid', None))
                company = self._dd_accessor._unique_item(table_name, 'guid',
                                                         co_id,
                                                         index_name='GUIDidx')
                if company is not None:
                    company['mapping'] = sem

        return company

    def _query_company (self, symbol_exchange_mapping):
        if not symbol_exchange_mapping :
          return {}
      
        symbol = symbol_exchange_mapping['symbol']
        
        if symbol_exchange_mapping and 'snp_id' in symbol_exchange_mapping and \
                self._is_primary_data_snp():
            company = self._snp_accessor.query_company(symbol_exchange_mapping)
            return company
  
        companies = []
  
        b_symbol = self._get_base_symbol(symbol)
  
        if self._is_primary_data_intrinio():
            companies = self._iaccessor.query_company(b_symbol)
            current_fiscal_quarter_calc = self._iaccessor.query_lastest_quarter(
                'CALCULATION', b_symbol)
            current_fiscal_year_calc = self._iaccessor.query_lastest_fiscal_year(
                'CALCULATION', b_symbol)
            current_fiscal_year_income = self._iaccessor.query_lastest_fiscal_year(
                'INCOME', b_symbol)
            current_fiscal_quarter_income = self._iaccessor.query_lastest_quarter(
                'INCOME', b_symbol)
            self._intrinio_data_mapper.company_converter(companies,
                                                         current_fiscal_year_income,
                                                         current_fiscal_quarter_income,
                                                         current_fiscal_year_calc,
                                                         current_fiscal_quarter_calc)
        else:
            companies = self._qaccessor.query_comp_description(b_symbol)          
        
        if companies :
          return companies[0]  

    def _get_cache_method_parameter_key (self, params):
        return self._financial_accessor_cache.get_cache_method_parameter_key(params)
     
    def _get_cached_value (self, method_name, param_string):
        return self._financial_accessor_cache.get_cached_value(method_name, param_string)

    def _set_cached_value (self, method_name, param_string, value):
        self._financial_accessor_cache.set_cached_value(method_name, param_string, value)

    def get_snapshot(self, symbol):
        res = self._snp_accessor.get_snapshot(symbol)
        return res
