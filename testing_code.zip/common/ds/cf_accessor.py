from dd_accessor import DynamoAccessor
from boto3.dynamodb.conditions import Key
import simplejson


class CFTCAccessor(DynamoAccessor):

  def __init__(self):
    super().__init__()

  def query_futures(self, code, date=None, table_name='CFTC'):
    if date:
      key_condition = Key('guid').eq(code) & \
                      Key('date').gte(date)
    else:
      key_condition = Key('guid').eq(code)
    return self.range_query_table(key_condition, table_name)

  def range_query_table(self, key_condition, table_name):
    response = []
    table = self._get_table(table_name)
    response_dict = table.query(KeyConditionExpression=key_condition)

    if response_dict is not None and 'Items' in response_dict.keys():
      response = response_dict['Items']

    return response

  def save_item(self, item, data_type, table_name='CFTC'):
    self._logger.info("Saving item: " +
                      simplejson.dumps(item, use_decimal=True))
    table = self._get_table(table_name)
    key = {
      'date': item['date']
    }
    guid_table = self._get_table('SBT_SYMBOL_EXCHANGE_MAPPING')
    guid_item = guid_table.get_item(Key={"symbol":
                                         item['cftc_contract_market_code'],
                                         "exchange": item['cftc_market_code']
                                    .strip()})
    item['guid'] = guid_item['Item']['guid']
    key['guid'] = guid_item['Item']['guid']
    del item['cftc_market_code']
    del item['cftc_contract_market_code']
    if 'Item' in table.get_item(Key=key):
      self._logger.info("Updating Item: " + simplejson.dumps(key))
      table.update_item(
        Key=key,
        UpdateExpression='SET #field.#type = :new',
        ExpressionAttributeNames={'#type': data_type, '#field': 'data'},
        ExpressionAttributeValues={':new': item['data'][data_type]}
      )
      return
    table.put_item(Item=item)
