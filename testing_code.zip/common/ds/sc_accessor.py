import collections
import datetime
import enum
import logging
import re
import time
from functools import reduce
from numbers import Number
from operator import or_, and_

import numpy as np
import pandas as pd
import requests
import simplejson
from bs4 import BeautifulSoup as bs
from pypika import PostgreSQLQuery as query
from pypika import CustomFunction
from pypika.terms import BasicCriterion
from pypika import Table
from pypika import Tables, Field
from sqlalchemy.types import BOOLEAN
from sqlalchemy.types import NUMERIC
from sqlalchemy.types import VARCHAR

from dd_accessor import DynamoAccessor
from pg_accessor import PostgresAccessor
from sbt_common import SbtGlobalCommon
from snp_accessor import SNPAccessor

# dict of tables used in SQL referencing
_ref_tb = {
    "company": "screener_test_company",
    "sic": "screener_test_sic",
    "meta": "screener_test_metadata",
    "description": "screener_test_description"
}

# dict of tables used for data sourcing
prefix = 'screener_test'
# list of subsets
suffix = ['balance', 'calc', 'cashflow', 'income']
_data_tb = {
    "indu": [prefix + '_indu_' + x for x in suffix],
    "fin": [prefix + '_fin_' + x for x in suffix]
}

# tables to be used for Market Cap calculations
_mc_tb = {
    "indu": [prefix + '_indu_calc'],
    "fin": [prefix + '_fin_calc']
}

# table with model calculations
_model_tb = "screener_test_sbt_model"

del prefix, suffix


class Comp(enum.Enum):
    match = "@@"


plainto_tsquery = CustomFunction('plainto_tsquery', ['text'])


class ScreenerAccessor(PostgresAccessor):

    def __init__(self):
        self.screener_table = 'screener'
        # PG DB
        self.pgconfig = SbtGlobalCommon.get_sbt_config()['postgres'][
            'datafactory']
        super().__init__(self.pgconfig)
        # engine connection to PG
        if not self._engine:
            self._logger.info('Engine is NONE')

        self._logger = SbtGlobalCommon.get_logger(logging.DEBUG, ' SCREENER')

        # string to be used when querying for data
        # (e.g.: SELECT ... FROM self._joined_tables WHERE ...)
        # (TODO: create a view?)
        self._joined_tables = {k: _data_tb[k][0] + "".join(
            [" JOIN " + x + " USING (ticker)" for x in
             _data_tb[k][1:] + [_ref_tb["company"]] + [_model_tb]
             ]
        ) for k in _data_tb}

        # table names
        self._SCREENER_COMPANY_TABLE_NAME = "new_screener_company"
        self._SCREENER_DATA_TABLE_NAME = "new_screener_data"
        self._SCREENER_FINANCIAL_PARAMETERS = "new_screener_financial_parameters"
        self._SCREENER_STAGING_TABLE_NAME = "new_screener_staging"
        self._SCREENER_DESCRIPTIONS_TABLE_NAME = "new_screener_data_description"

        # base query used to retrieve GICS data (sector, group, industry etc.)
        self._GICS_BASE_QUERY = """
                SELECT {id}, {desc}, COUNT(*)
                FROM {table_name}
                GROUP BY {id}, {desc}
                ORDER BY {desc} ASC"""

        self._field_mapping = self._get_field_mapping()
        # get descriptions, units & tag list
        self._descriptions = self._get_descriptions()
        # this is how you select None values in a pandas df
        self._tag_list = \
            [self._dromedary_case_split(x) for x in
             list(self._descriptions.query(
                 "data_unittypename != data_unittypename"
             )['data_itemid'])]
        # populate screener
        self._populate_data = self.populate()

    def _dromedary_case_split(self, string):
        # split a camelCase string into its component words
        list_of_words = [word.lower() for word in re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)', string)]

        return "_".join(list_of_words)

    def _get_descriptions(self):
        engine = self._engine
        df = pd.read_sql_table(self._SCREENER_DESCRIPTIONS_TABLE_NAME,
                               engine, index_col=None)
        return df

    def _get_field_mapping(self):
        engine = self._engine
        # read the description table (column, name, unit, description, category)
        df = pd.read_sql_table(self._SCREENER_FINANCIAL_PARAMETERS,
                               engine, index_col=None)
        df.rename(columns={
            "snp_data_item_id": "data_itemid",
            "sbt_data_item_id": "id",
            "snp_data_item_name": "name",
            "snp_data_item_description": "description"
        }, inplace=True)

        return df

    def _handle_percentage(self, filters=[], to_percentage=True,
                           get_list=False):
        '''
        Transform between decimal and percentage.
        :param filter_list: a list with all the filters that are being used
        :param to_percentage: default is to convert from percentage input to decimal
        :return:
        '''
        # deal with percentage <-> real number
        # get mapping of all available filters (name, call, unit, description)
        populate = self._populate_data
        temp = []
        [[temp.append(item) for item in x] for x in
         populate['CUSTOM'].values()]
        # get all filters with unit = percentage
        percentage = [x['call'] for x in temp if x['unit'] == 'percentage']
        if get_list:
            # return the list of filters that have unit='percentage'
            return percentage
        else:
            # transform payload filters
            # get custom filters from payload
            custom_filters = [x['field'] for x in filters
                              if
                              x['field'] != 'mcap' and x['field'] != 'sector']
            # get all filters from payload that needs to be transformed
            custom_filters_percentage = [x for x in custom_filters if
                                         x in percentage]
            # transform from percentage format to real number if to_percentage=True
            # otherwise, transform from decimal to percentage format
            [[x.update(value=str(float(x['value']) / 100)) for x in filters if
              x['field'] == y] for y in
             custom_filters_percentage] if to_percentage \
                else [
                [x.update(value=str(float(x['value']) * 100)) for x in filters
                 if x['field'] == y] for y in custom_filters_percentage]

            return filters

    def _is_number(self, s):
        # test if a string s is a number or not
        # (https://bit.ly/2xPOJNA)
        try:
            float(s)
            return True
        except ValueError:
            pass

        try:
            import unicodedata
            unicodedata.numeric(s)
            return True
        except (TypeError, ValueError):
            pass

        return False

    def _build_criteria_from_filters(self, filters, field=None):
        prefix = 'data_itemid'
        criteria = []
        if field:
            for x in filters:
                if x['field'] == field:
                    if type(x['value']) != tuple:
                        if x['field'].count('sectorid') or x['field'].count('industry'):
                            # sector
                            criterion = getattr(Field(x['field']),
                                                x['operator'])(x['value'])
                        else:
                            if field.isdigit():
                                # data_itemid### (financial)
                                criterion = \
                                    getattr(Field(prefix + x['field']),
                                            x['operator'])(
                                        pd.to_numeric(x['value'], errors='ignore'))
                            else:
                                # data_itemidXXX (tags)
                                criterion = \
                                    getattr(Field(prefix + '_'.join(x['field'].lower().split())),
                                            x['operator'])(
                                        pd.to_numeric(x['value'],
                                                      errors='ignore'))
                    else:
                        # mcap
                        criterion = \
                            getattr(Field(prefix + x['field']), x['operator']) \
                                (pd.to_numeric(x['value'][0], errors='ignore'),
                                 pd.to_numeric(x['value'][1], errors='ignore'))

                    criteria.append(criterion)

        else:
            # tags
            [x.update(field='_'.join(x['field'].lower().split()))
             for i, x in enumerate(filters)
             if '_'.join(x['field'].lower().split()) in self._tag_list]
            criteria = [
                BasicCriterion(Comp.match,
                               Field('data_itemid{}'.format(x['field'])),
                               plainto_tsquery(x['value'])
                               ) if type(x['value']) != tuple else
                getattr(Field(x['field']), x['operator'])(
                    pd.to_numeric(x['value'][0], errors='ignore'),
                    pd.to_numeric(x['value'][1], errors='ignore')
                ) for x in filters if x['field'] in self._tag_list
            ]

        return criteria

    def _validate_filter(self):
        _BASE_SQL = "SELECT DISTINCT COLUMN_NAME " \
                    "FROM INFORMATION_SCHEMA.COLUMNS " \
                    "WHERE TABLE_NAME='{0}'"

        # get the sector list and count for each table in self._all_tables
        SQL_DICT = {k: [_BASE_SQL.format(t) for t in tables]
                    for k, tables in _data_tb.items()}

        # concatenate base SQL queries
        sql_union = [" UNION ".join(SQL_DICT[x]) for x in SQL_DICT]
        # intersection of all datasets
        sql_intersect = "(" + ") INTERSECT (".join(sql_union) + ")"

        # group by sectors and return the sum for each group
        sql_query = 'SELECT DISTINCT "column" FROM {0} ' \
                    'WHERE "column" IN (' + sql_intersect + ");"

        sql_query = sql_query.format(_ref_tb["description"])

        df = self._new_screener_query_executer(sql_query)
        valid_filters_list = [x[0] for x in df.values]
        valid_filters_list.append('sector')
        valid_filters_list.append('sic')
        valid_filters_list.append('rank')
        valid_filters_list.append('rank_mds')
        valid_filters_list.append('rank_ce')
        valid_filters_list.append('rank_mom')

        return valid_filters_list

    def _get_list_of_custom_filters(self):
        """
        Create the list of available custom filters.
        :param payload:
        :return:
        """
        # _BASE_SQL = "SELECT DISTINCT COLUMN_NAME " \
        #             "FROM INFORMATION_SCHEMA.COLUMNS " \
        #             "WHERE TABLE_NAME='{0}'"
        #
        # # get the sector list and count for each table in self._all_tables
        # # SQL_LIST = []
        # # [SQL_LIST.append(_BASE_SQL.format(table.table_name)) for table in self._all_tables
        # #  if table.table_name not in [_ref_tb['sic'], _ref_tb['company']]]
        # SQL_DICT = {k: [_BASE_SQL.format(t) for t in tables]
        #             for k, tables in _data_tb.items()}
        #
        # # concatenate base SQL queries
        # # sql_union = " UNION ".join(SQL_LIST) \
        # #   if len(self._all_tables) > 1 else SQL_LIST[0]
        # sql_union = [" UNION ".join(SQL_DICT[x]) for x in SQL_DICT]
        # # intersection of all datasets
        # sql_intersect = "(" + ") INTERSECT (".join(sql_union) + ")"
        #
        # # group by sectors and return the sum for each group
        # sql_query = 'SELECT DISTINCT ' \
        #             '"column", {0}."name", units, description ' \
        #             'FROM {0} JOIN {1} ' \
        #             'USING("column") WHERE "column" IN (' \
        #             "SELECT column_name FROM (" + \
        #             sql_intersect + \
        #             ") AS X" \
        #             ");"
        #
        # sql_query = sql_query.format(_ref_tb["meta"], _ref_tb["description"])

        sql_query = """
            select distinct * from {finpar}
                join {desc} on {finpar}.snp_data_item_id = {desc}.data_itemid
                """.format(
            finpar=self._SCREENER_FINANCIAL_PARAMETERS,
            desc=self._SCREENER_DESCRIPTIONS_TABLE_NAME
        )

        df = self._new_screener_query_executer(sql_query)
        # list of tuples
        custom_items_list = [tuple(x) for x in df.values]

        res = {
            x[1].upper():
                [{
                    "name": x[2],
                    "call": x[0],
                    "unit": x[-2],
                    "description": x[3]
                }]
            for x in custom_items_list
        }

        # create a list with all the valid custom items
        self._valid_filters = [str(x[0]['call']) for x in res.values()]

        return res

    def _get_list_of_industries(self, sector):
        """
        Create the list of available industries for a given sector.
        :param payload:
        :return:
        """

        _BASE_SQL = "SELECT sic, description FROM screener_sic WHERE sic IN (" \
                    "SELECT DISTINCT sic FROM screener " \
                    "JOIN screener_company USING(ticker) " \
                    "WHERE sector='{}')".format(sector)

        res = self._new_screener_query_executer(_BASE_SQL)

        indu_list = [{y: int(x)} for x, y in res.values]

        return indu_list

    def _new_screener_query_builder(self, payload):
        '''
        Query the database for items that match the specified filters.
        :param pl: a screener request object (see "Screener POST method request
          schema" on the SBT Screener page in Confluence: http://bit.ly/2EZNdqN).
        :return: the result of a query with the specified filters.
        '''

        pl = payload.copy()

        tb_company = Table(_ref_tb["company"])
        tb_model = Table(_model_tb)

        # following Investopedia's definition: https://bit.ly/2VkuBfP
        capsizes = {
            'small': [2e3, 'lt'],
            'mid': [(2e3, 10e3), 'between'],
            'large': [(10e3, 200e3), 'between'],
            'mega': [200e3, 'gte']
        }

        # get all filters
        filters = [x for x in pl['filters']]
        # get the fields to filter on
        all_fields = [x['field'] for x in filters]

        # # deal with percentage -> real number
        filters = self._handle_percentage(filters=filters)

        # by sector filters
        if 'sector' in all_fields:
            [item.update(
                field='company_sectorid',
                value=' '.join(item['value'].title().split('-')),
                operator=item['operator']
            ) for item in [x for x in filters if x['field'] == 'sector']]

        # by market cap filters
        if 'mcap' in all_fields:
            # updating mcap filters with actual fields, values, and operators
            [item.update(
                field='100010',
                value=capsizes[item['value']][0],
                operator=capsizes[item['value']][1]
            ) for item in [x for x in filters if x['field'] == 'mcap']]

        # by industry filters
        if 'indu' in all_fields:
            [item.update(
                field='company_industry',
                value=' '.join(item['value'].title().split('-')),
                operator=item['operator']
            ) for item in [x for x in filters if x['field'] == 'indu']]

        # by CE & MDS filters
        if 'rank' in all_fields:
            # updating model filters with actual fields, values, and operators
            # this will rename 'rank' to 'rank_mds'
            [item.update(
                field='rank_mds',
                value=item['value'],
                operator=item['operator']
            ) for item in [x for x in filters
                           if x['field'] == 'rank']]
            # TODO: do this programmatically
            temp = [{"field": 'rank_ce',
                     "value": x['value'],
                     "operator": x['operator']}
                    for x in filters if x['field'] == 'rank_mds'][0]
            filters.append(temp)
            temp = [{"field": 'rank_mom',
                     "value": x['value'],
                     "operator": x['operator']}
                    for x in filters if x['field'] == 'rank_mds'][0]
            filters.append(temp)

        # update list of fields
        all_fields = [x['field'] for x in filters]

        # list of unique fields (groups)
        tags = {}
        unique_fields = set([
            x if '_'.join(x.lower().split()) not in self._tag_list
            else tags.update({x: '_'.join(x.lower().split())}) for x in all_fields]
        )

        # grouping by field
        grouped_fields = [self._build_criteria_from_filters(filters, field)
                          for field in unique_fields]

        # create Table objects
        sc_data_table, sc_company_table, sc_staging_table = Tables(
            self._SCREENER_DATA_TABLE_NAME,
            self._SCREENER_COMPANY_TABLE_NAME,
            self._SCREENER_STAGING_TABLE_NAME
        )

        # fields to be returned:
        # - selected by the user
        fields = list(set([Field('data_itemid{}'.format(x['field']))
                           for x in filters if
                           x['field'] in self._valid_filters
                           or x['field'] in self._tag_list]))
        # add industry if selected
        fields.extend([Field('company_industry_desc')]) \
            if all_fields.count('company_industry') else None
        # - default fields to be always displayed regardless of the type of
        # screener
        fields.append(Field('company_tickersymbol',
                            table=self._SCREENER_COMPANY_TABLE_NAME))
        fields.append(Field('company_name',
                            table=self._SCREENER_COMPANY_TABLE_NAME))
        fields.append(Field('company_sectordesc',
                            table=self._SCREENER_COMPANY_TABLE_NAME)) \
            if 'sector' not in set(all_fields) else None

        # base query to select * from tables
        base_query = query.from_(
            sc_company_table
        ).join(
            sc_data_table
        ).on(
            sc_company_table.company_tradingitemid == \
            sc_data_table.data_tradingitemid
        ).select([x.name for x in fields])

        # adding 'where' filtering to query builder
        # - first: OR conditions
        combine_groups = [reduce(or_, group) for group in grouped_fields]
        # - second: AND conditions
        combine_all = reduce(and_, combine_groups)
        base_query._wheres = combine_all

        base_query = base_query.get_sql()
        # remove trash
        sql_query = re.sub('ARRAY', '', base_query)
        # remove left brackets
        sql_query = re.sub("\['", '"', sql_query)
        # remove right brackets
        sql_query = re.sub("'\]", '"', sql_query)
        # remove single quotes from column names
        sql_query = re.sub("','", '","', sql_query)

        return sql_query

    def _new_screener_query_executer(self, sql_query):
        engine = self._engine
        df = pd.read_sql_query(sql_query, engine, coerce_float=True)
        # return a pandas dataframe
        return df

    def populate(self):
        #
        # STATIC DATA
        #

        # CUSTOM FILTER ITEMS AVAILABLE FROM THE TABLES INFO SCHEMA
        custom_items_dict = self._get_list_of_custom_filters()

        # MARKET CAP ITEMS
        mcap_items_dict = self.get_market_cap_count()

        # SECTOR ITEMS
        sector_items_dict = self.get_sector_count()

        # GROUPS ITEMS
        # groups_items_dict = self.get_groups_count()

        # INDUSTRY ITEMS
        indu_items_dict = self.get_industry_count()

        # SUB-INDUSTRY ITEMS
        # subindustry_items_dict = self.get_subindustry_count()

        # TOP COMPANIES
        # top_companies = self.get_top_companies()

        # TAGS
        tags = self.get_tags_count()

        # CROSS REFERENCE BETWEEN SECTOR AND INDUSTRY
        sector_indu_dict = {k: [indu[0] for indu in indu_items_dict.values()
                                if indu[0]['call'].startswith(v[0]['call'])]
                            for k, v in sector_items_dict.items()
                            }

        # MODEL ITEMS (TODO: implement this to run programmatically)
        names = ["Stansberry's Investment Advisory",
                 'Retirement Millionaire', 'True Wealth', 'All']
        calls = ['rank_ce', 'rank_mds', 'rank_mom', 'rank']
        models_items_dict = {k: [{'name': k, 'call': v, 'count': '1'}]
                             for k, v in zip(names, calls)}

        # return list of items with name, column, unit, adn description
        res = {
            "CUSTOM": custom_items_dict,
            "MCAP": mcap_items_dict,
            "SECTOR": sector_items_dict,
            "INDUSTRY": indu_items_dict,
            "SECTOR_INDUSTRY_MAP": sector_indu_dict,
            "MODELS": models_items_dict,
            "TAGS": tags,
        }
        return res

    def new_screener_count(self, payload):
        '''
        Get the total number of items to be returned by a query using the selected
          filters.
        :param payload: a screener request object (see "Screener POST method request
          schema" on the SBT Screener page in Confluence: http://bit.ly/2EZNdqN).
        :return: the number of items to be returned by a query with the specified
          filters.
        '''

        sql_query = self._new_screener_query_builder(payload)
        sql_count = 'SELECT COUNT(*) FROM (' + sql_query + ') AS x;'
        count = self._new_screener_query_executer(sql_count)

        return int(count.values)

    def new_screener(self, payload):
        pl = payload.copy()
        sql_query = self._new_screener_query_builder(pl)
        df = self._new_screener_query_executer(sql_query)
        # mapping all the filters to their actual names
        field_mapping = self._field_mapping
        # if 'sic' in df.keys():
        #     df['sic'] = [field_mapping.loc[
        #                      field_mapping['column'] == str(int(x)), 'name'
        #                  ].values[0] for x in df['sic']]
        # convert from pd.df to dict
        data_dict = {x: list(df[x].values) for x in df.to_dict()}
        # attributes to be added in the response
        desired_attr = [x for x in data_dict.keys() if
                        len(x.split('data_itemid')) == 1 or self._is_number(
                            x.split('data_itemid')[1])]
        # only keep what's desired
        data_dict = {k: v for k, v in data_dict.items() if k in desired_attr}
        # returning percentage-formatted values
        percentage = self._handle_percentage(get_list=True)
        for x in df.to_dict():
            if x in percentage:
                data_dict[x] = list(df[x].values * 100)

        # formatting for tag values only (e.g. 'buy-and-hold' => 'Buy and hold')
        # formatting datatype correctly
        data_dict = {
            k: [' '.join(str(x).split('-')).capitalize() for x in v]
            if (len(k.split('data_itemid')) > 1 and k.split('data_itemid')[1] and not k.split('data_itemid')[1].isdigit())
            else [pd.to_numeric(v1) if self._is_number(v1) else v1 for v1 in v]
            for k, v in data_dict.items()
        }

        str_json = simplejson.dumps(data_dict, default=lambda x: str(x))
        # # loads up string into JSON format for the browser
        data_json = simplejson.loads(str_json, use_decimal=True)

        # create labels from the description for each data_itemid
        # (financial & tags)
        labels = {
            k:
                self._descriptions.query(
                    "data_itemid == '{}'".format(k.split('data_itemid')[1])
                )['data_itemname'].values[0]
                if k.split('data_itemid')[1].isdigit()
                else ' '.join(k.split('data_itemid')[1].split('_')).capitalize()
            for k in data_dict.keys() if k.count('data_itemid')
        }
        units = {
            k:
                self._descriptions.query(
                    "data_itemid == '{}'".format(k.split('data_itemid')[1])
                )['data_unittypename'].values[0]
                if k.split('data_itemid')[1].isdigit() else 'N/A'
            for k in data_dict.keys() if k.count('data_itemid')
        }

        labels['company_name'] = 'Company Name'
        labels['company_tickersymbol'] = 'Symbol'
        labels['company_sectordesc'] = 'Sector'
        units['company_name'] = 'N/A'
        units['company_tickersymbol'] = 'N/A'
        units['company_sectordesc'] = 'N/A'
        # optional (display only if 'Industry' has been selected)
        if 'company_industry_desc' in df.keys():
            labels['company_industry_desc'] = 'Industry'
            units['company_industry_desc'] = 'N/A'

        return {
            "results": data_json,
            "labels": [labels],
            "units": [units]
        }

    def get_market_cap_count(self):
        # following Investopedia's definition: https://bit.ly/2VkuBfP
        sql_query = """
        SELECT
            CASE
                WHEN data_itemid100010 = 0 THEN 'ZEROMCAP'
                WHEN (data_itemid100010 < 2e3 and data_itemid100010 <> 0) THEN 'SMALL'
                WHEN (data_itemid100010 >= 2e3 AND data_itemid100010 <= 1e4) THEN 'MID'
                WHEN (data_itemid100010 > 1e4 AND data_itemid100010 < 2e5) THEN 'LARGE'
                WHEN data_itemid100010 >= 2e5 THEN 'MEGA'
            END AS caps,
            COUNT(*)
        FROM {} as nstt
        -- marketcap => 100010
        WHERE data_itemid100010 is not null
        GROUP BY caps
        """.format(self._SCREENER_DATA_TABLE_NAME)

        df = self._new_screener_query_executer(sql_query)
        # returning a dict of market cap and count
        mcap_items = {k: int(v) for k, v in df.values}

        # removing key that corresponds to items with no data about MC
        mcap_items.pop('ZEROMCAP', None)
        res = [(k, [{'name': k.title(), 'call': k.lower(), 'count': v}])
               for k, v in zip(mcap_items.keys(), mcap_items.values())]

        # keeping the order
        res = collections.OrderedDict([res[2], res[1], res[0], res[3]])

        return res

    def get_sector_count(self):
        sql_query = \
            self._GICS_BASE_QUERY.format(
                id='company_sectorid',
                desc='company_sectordesc',
                table_name=self._SCREENER_COMPANY_TABLE_NAME
            )

        df = self._new_screener_query_executer(sql_query)
        # format response
        res = {y: [{'name': y, 'call': x, 'count': z}] for x, y, z in
               df.values}

        return res

    def get_industry_count(self):
        sql_query = \
            self._GICS_BASE_QUERY.format(
                id='company_industry',
                desc='company_industry_desc',
                table_name=self._SCREENER_COMPANY_TABLE_NAME
            )

        df = self._new_screener_query_executer(sql_query)
        # format response
        res = {y: [{'name': y, 'call': x, 'count': z}] for x, y, z in
               df.values}

        return res

    def get_top_companies(self, full_list=None):
        # sql_query = "SELECT rank_ce,rank_mds,rank_mom," \
        #             "screener_test_indu_balance.ticker,screener_test_company.name," \
        #             "screener_test_company.sector," \
        #             "screener_test_indu_calc.marketcap " \
        #             "FROM screener_test_indu_balance " \
        #             "JOIN screener_test_indu_calc USING (ticker) " \
        #             "JOIN screener_test_indu_cashflow USING (ticker) " \
        #             "JOIN screener_test_indu_income USING (ticker) " \
        #             "JOIN screener_test_company USING (ticker) " \
        #             "JOIN screener_test_sbt_model USING (ticker) " \
        #             "WHERE rank_ce IS NOT NULL AND rank_mds IS NOT NULL AND rank_mom IS NOT NULL " \
        #             "AND marketcap<>0 " \
        #             "UNION " \
        #             "SELECT rank_ce,rank_mds,rank_mom," \
        #             "screener_test_fin_balance.ticker,screener_test_company.name," \
        #             "screener_test_company.sector," \
        #             "screener_test_fin_calc.marketcap " \
        #             "FROM screener_test_fin_balance " \
        #             "JOIN screener_test_fin_calc USING (ticker) " \
        #             "JOIN screener_test_fin_cashflow USING (ticker) " \
        #             "JOIN screener_test_fin_income USING (ticker) " \
        #             "JOIN screener_test_company USING (ticker) " \
        #             "JOIN screener_test_sbt_model USING (ticker) " \
        #             "WHERE rank_ce IS NOT NULL AND rank_mds IS NOT NULL AND rank_mom IS NOT NULL " \
        #             "AND marketcap<>0"

        sql_query = """
                select ce.composite_pk_id id, ce.rank capeff, 
                val.score val , fin.score fin, mom.score mom--,
        --	(ce.rank+100*(val.score+fin.score)+mom.score)/4 composite_avg
        from development_sbt_models_capeff ce
            inner join development_sbt_models_mdscore_valuation val
                using ("composite_pk_id")
            inner join development_sbt_models_mdscore_financial fin
                using ("composite_pk_id")
            inner join development_sbt_models_mmmomentum mom
                using ("composite_pk_id")
        where
            ce.rank is not null
            and val.score is not null
            and fin.score is not null
            and mom.score is not null
        """

        df = self._new_screener_query_executer(sql_query)
        # capeff's rank
        df['capeff'] = df.capeff
        # valuation's percentile rank
        df['val'] = 100 * df.val
        # financial's percentile rank
        df['fin'] = 100 * df.fin
        # mmmomentum's score
        df['mom'] = df.mom

        df['average_rank'] = (df.capeff + df.val + df.fin + df.mom) / 4.
        df['percentile_rank'] = 100 * df.average_rank.rank(pct=True)
        df['rank'] = df.percentile_rank.rank(ascending=False)

        # return only the top 10 companies if full_list == None
        df = df.sort_values(
            by='rank') if full_list is not None else df.sort_values(
            by='rank').iloc[:10]

        res = simplejson.loads(df.to_json(orient='records'))

        return res

    def get_tags_count(self):
        def flatten(container):
            # flatten out a nested list
            # (see https://bit.ly/3baTi2A)
            for i in container:
                if isinstance(i, (list, tuple)):
                    for j in flatten(i):
                        yield j
                else:
                    yield i

        # get tag column names
        sql_get_tag_names = """
            SELECT column_name
            FROM information_schema.columns cols
            WHERE table_schema = 'public' and cols.data_type = 'text'
                AND table_name  = '{}';
        """.format(self._SCREENER_DATA_TABLE_NAME)
        df_tag_name = self._new_screener_query_executer(sql_get_tag_names)
        tag_cols_list = [x[0] for x in df_tag_name.values
                         if not x[0].count('tradingitemid')]

        sql_query = ["""
            select nsd.{tag_col}, count(*)
            from {table_name} nsd
            where nsd.{tag_col} is not null
            group by {tag_col} 
        """.format(table_name=self._SCREENER_DATA_TABLE_NAME, tag_col=col)
                     for col in tag_cols_list]

        res = {}
        for i, col in enumerate(tag_cols_list):
            df = self._new_screener_query_executer(sql_query[i])
            if col == 'data_itemidspecial_tags':
                # returning a dict of tags and count for the special tags
                items = set(', '.join(
                    [x[0].replace('[', '').replace(']', '').replace("'", '')
                     for x in df.values.tolist()]).split(', '))
                tag_items = {
                    ' '.join(col.split('data_itemid')[1].split('_')).capitalize(): [
                            {'call': item,
                             'count': int(self._new_screener_query_executer(
                                 """
                                    select sum(item_count) as total
                                    from (SELECT data_itemidspecial_tags, count(*) item_count
                                    FROM {table_name} nsd
                                    where data_itemidspecial_tags @@ plainto_tsquery('{item}')
                                    group by data_itemidspecial_tags) as a;
                                """.format(table_name=self._SCREENER_DATA_TABLE_NAME,
                                           item=item)).values.tolist()[0][0]),
                             'name': ' '.join(item.split('-')).capitalize()
                             } for item in items
                        ]
                }
            else:
                # returning a dict of tags and count per tag
                tag_items = {
                    ' '.join(k.split('data_itemid')[1].split('_')).capitalize(): [
                        {
                            'call': el,
                            'count': str(df['count'][i]),
                            'name': ' '.join(el.split('-')).capitalize()
                        } for i, el in enumerate(list(v.values))
                    ] for k, v in df.items() if k != 'count'
                }

            res.update(tag_items)

        return res


class ScreenerPopulateTable(DynamoAccessor, PostgresAccessor):

    def __init__(self):
        self.pgconfig = SbtGlobalCommon.get_sbt_config()['postgres'][
            'datafactory']
        super().__init__(self.pgconfig)
        self._configure()

    def _configure(self):
        # engine connection to PG
        self._engine = PostgresAccessor(self.pgconfig)._engine

    def _screener_populate_table(self, table_name_from, table_name_to):
        tic = time.time()
        # filter to be used
        filter = 'fiscal_id contains TTM OR fiscal_id contains FY'
        result = self._scan_table_with_filter_str(table_name_from, filter)
        #
        # [[(result[i][item], type(result[i][item])) for item in
        #   result[i]] for i in range(len(result))]
        tac = time.time()
        print('dt = {:0.2f} s'.format(tac - tic))
        df = pd.DataFrame(result)
        # select only the most recent data
        data_ltm = self._uniquify_table(df=df)
        # query table for most recent data
        result_ltm = [self._unique_item(
            table_name_from,
            key_name='ticker', key_value=ticker,
            range_name='fiscal_id', range_value=fiscal_id
        ) for ticker, fiscal_id in zip(data_ltm.keys(), data_ltm.values())]
        df2 = pd.DataFrame(result_ltm)
        # write to PG database
        self._write_from_df_to_pg(table_name_to, df2)

    def _uniquify_table(self, df=None, table_name=None):
        engine = self._engine
        df = pd.read_sql_table(table_name, con=engine) if df is None else df
        # select all invalid tickers and corresponding fiscal_id
        data_dict = {x: [y for y in df['fiscal_id'][df['ticker'] == x]]
                     for x in set(x for x in df['ticker'])}

        # latest fiscal_id for tickers with invalid dates
        # fiscal_id_list = {k: [''.join(re.split('Q|TTM|F', x))
        #           for x in data_dict[k]] for k in data_dict}
        # latest_fiscal_id_index = {k: [''.join(re.split('Q|TTM|F', x))
        #          for x in data_dict[k]].index(max([''.join(re.split('Q|TTM|F', x))
        #          for x in data_dict[k]])) for k in data_dict}
        latest_fiscal_id_values = {
            k: data_dict[k][[''.join(re.split('Q|TTM|F', x))
                             for x in data_dict[k]].index(
                max([''.join(re.split('Q|TTM|F', x))
                     for x in data_dict[k]]))] for k in data_dict}

        # print(data_latest_fiscal_id)
        return latest_fiscal_id_values

    def _read_from_dynamo_into_df(self, table_name_from, filter=None):
        # READ FROM DYNAMODB
        # returns a pandas DataFrame
        # construct a filter expression if a string with conditions is provided
        # (e.g.: 'mic contains XNYS OR composite_figi_ticker begins_with A')
        filter_expression = self._scan_table_with_filter_str(filter) \
            if filter is None else filter
        # scan the table
        result = self._scan_table_with_filter_str(table_name_from,
                                                  filter_expression)
        # returns a pandas DataFrame
        df = pd.DataFrame(result)
        return df

    def _write_from_df_to_pg(self, table_name, data_frame):
        # WRITE TO PG
        # read data in
        # drop list of dicts
        # df = data_frame.drop('securities', axis=1) \
        #   if 'company' in table_name else data_frame
        df = data_frame
        # get connection engine
        engine = PostgresAccessor(self.pgconfig)._engine
        # write to PG database
        print("Writing to PG now...")
        tic = time.time()
        # deal with the datatype
        dtypes = {x: self._handle_datatype(x, df[x])
                  for x in df}
        # drop literal string (weird data from Intrinio)
        df = df.replace('na', np.nan)
        df.to_sql(table_name, engine,
                  if_exists='replace', index=False,
                  dtype=dtypes
                  )
        tac = time.time()
        # POST PROCESSING: create PK and FK
        try:
            with engine.connect() as con:
                if 'ticker' in df.columns.values.tolist():
                    # set PK on ticker
                    con.execute('ALTER TABLE {0} ADD CONSTRAINT {0}_pk '
                                'PRIMARY KEY (ticker);'
                                .format(table_name))
                    if 'sic' in df.columns.values.tolist():
                        # COMPANY table - set FK on SIC code referencing SIC table
                        con.execute('ALTER TABLE {0} '
                                    'ADD CONSTRAINT {0}_screener_test_sic_fk '
                                    'FOREIGN KEY (sic) '
                                    'REFERENCES screener_test_sic(sic);'
                                    .format(table_name))
                    else:
                        # regular table - set FK on ticker referencing COMPANY table
                        con.execute('ALTER TABLE {0} '
                                    'ADD CONSTRAINT {0}_screener_test_company_fk '
                                    'FOREIGN KEY (ticker) '
                                    'REFERENCES screener_test_company(ticker);'
                                    .format(table_name))
                elif 'sic' in df.columns.values.tolist():
                    # SIC table - set PK and UK on the SIC code
                    con.execute('ALTER TABLE {0} ADD CONSTRAINT {0}_pk '
                                'PRIMARY KEY (sic);'
                                .format(table_name))
                    con.execute('ALTER TABLE {0} ADD CONSTRAINT {0}_pk '
                                'UNIQUE (sic);'
                                .format(table_name))
        except Exception as e:
            pass
        print("Done writing to PG in {:0.2f} s.".format(tac - tic))

    def _handle_datatype(self, col_name, series):
        # a series corresponds to a column, which means the items
        # should have the same datatype, implying a single dtype
        # for the series
        if col_name == 'etf':
            print('STOP')
        try:
            # total number of elements
            series_len = len(series)
            # total number of elements that are Numbers
            number_elem_len = len([x for x in series if
                                   (isinstance(x, Number) & (
                                           x is not np.nan))])
            # total number of elements that are null
            null_elem_len = series.isnull().sum()
            if (null_elem_len >= series_len / 2):
                # not null elements
                not_null_elem = series[series.notnull()]
                # total number of not null elements
                not_null_elem_len = len(not_null_elem)
                # coerce series to numeric; all non numeric elements will be set to NaN
                temp = pd.to_numeric(not_null_elem, errors='coerce')
                if np.count_nonzero(~np.isnan(temp)) > 0:
                    # some of the elements could be successfully coerced into numeric
                    # bool is a subclass of int (number)
                    bool_elem_len = len(
                        [x for x in temp if isinstance(x, bool)])
                    dtype = BOOLEAN if (
                            bool_elem_len >= not_null_elem_len / 2) else NUMERIC
                else:
                    # all the elements were converted to NaN
                    dtype = VARCHAR
            elif (number_elem_len >= series_len / 2):
                # bool is a subclass of int (number)
                bool_elem_len = len([x for x in series if isinstance(x, bool)])
                dtype = BOOLEAN if (
                        bool_elem_len >= series_len / 2) else NUMERIC
            else:
                dtype = BOOLEAN if ({x for x in series}.pop() == True or
                                    {x for x in
                                     series}.pop() == False) else VARCHAR
        except TypeError as e:
            # cannot work with lists, dicts, etc.
            dtype = None
            print("Error: {}".format(e))
        print('COL NAME: {} ({})'.format(col_name, dtype))
        return dtype


class Screnner(PostgresAccessor):

    def __init__(self):
        # PG DB
        self.pgconfig = \
            SbtGlobalCommon.get_sbt_config()['postgres']['snpsource']
        super().__init__(self.pgconfig)
        self._SNP_SOURCE_ENGINE = self._engine

        self.pgconfig = \
            SbtGlobalCommon.get_sbt_config()['postgres'][
                'snpcompanyfinancials']
        super().__init__(self.pgconfig)
        self._SBT_COMPANY_FINANCIALS_ENGINE = self._engine

        self.pgconfig = \
            SbtGlobalCommon.get_sbt_config()['postgres']['datafactory']
        super().__init__(self.pgconfig)
        self._DATAFACTORY = self._engine

        # create an instance of the SNPAccessor
        self.snp_accessor = SNPAccessor()
        # get the list of supported exchanges
        self._supported_exchanges = self.snp_accessor._get_exchanges()
        # convert result into a list of exchange IDs
        self._supported_exchanges_ids = []
        [self._supported_exchanges_ids.extend(
            [int(x) for x in v['vendor_id']['snp']]) for k, v in
            self._supported_exchanges.items() if
            'vendor_id' in v and 'snp' in v['vendor_id'] and len(
                v['vendor_id']['snp'])]

    def _create_financial_parameters_table_for_screener(self):
        """
        This method reads all the financial parameters used in the Terminal
        from the *snp_data_item* table and creates a separate table for the
        Screener.
        :return: None
        """
        sql_query = "SELECT * " \
                    "FROM snp_data_item " \
                    "WHERE sbt_data_item_id != 'unknown'"

        df = pd.read_sql_query(sql_query, self._SBT_COMPANY_FINANCIALS_ENGINE)

        df.to_sql('screener_financial_parameters', self._DATAFACTORY,
                  index=False,
                  if_exists='replace'
                  )

        print("DONE READING snp_data_item TABLE.")

    def _get_financial_parameters(self):
        """
        This method reads the content of the financial parameters to be used in
        the Screener and returns its S&P's data item ID.
        :return: List of S&P's data item ID.
        """
        sql_query = "SELECT snp_data_item_id " \
                    "FROM screener_financial_parameters"

        df = pd.read_sql_query(sql_query, self._DATAFACTORY)

        rval = list(df.snp_data_item_id)

        return rval

    def _get_all_symbol_exchange_combinations(self):
        """
        This method reads the full content of the sbt_symbol_exchange_mapping
        table and returns a list of the composite_pk_id (unique identifiers).
        :return: Dictionary of all supported ticker:exchange.
        """
        sql_query = "SELECT * FROM dev_snp_company"

        df = pd.read_sql_query(sql_query, self._SBT_COMPANY_FINANCIALS_ENGINE)

        print("DONE.")

        rval = df.to_dict(orient='records')

        return rval

    def _get_data_by_id(self, composite_pk_id_dict=None,
                        financial_parameters_list=None
                        ):

        def build_sql_query(snp_id, fin_param):
            sql_query = """
                    select
                        c.companyName,
                        c.companyId,
                        ti.tickerSymbol,
                        e.exchangeSymbol,
                        pt.periodTypeName,
                        fp.calendarQuarter,
                        fp.calendarYear,
                        fd.dataItemId,
                        di.dataItemName,
                        fd.dataItemValue,
                        tid.identifiervalue
                    from
                        ciqCompany c
                        join ciqSecurity s using ("companyid")
                        join ciqTradingItem ti using ("securityid")
                        join ciqExchange e using ("exchangeid")
                        join ciqtradingitemidentifier tid using ("tradingitemid")
                        join ciqcrossrefidentifiertype crossrefid using ("identifiertypeid")
                        join ciqLatestInstanceFinPeriod fp using ("companyid")
                        join ciqPeriodType pt using ("periodtypeid")
                        join ciqFinancialData fd using ("financialperiodid")
                        join ciqDataItem di using ("dataitemid")
                    where
                        fd.dataItemId in ({})
                        --LTM
                        and fp.periodTypeId = 4 
                        -- Supported exchanges
                        and e.exchangeid in ({})
                        -- Security's primary exchange in the USA
                        and s.primaryflag = 1
                        and e.countryid = 213
                        -- Company's ID
                        and c.companyid = {}
                        -- Global identifier
                        and tid.identifiertypeid = 8406
                        --Current Period
                        and fp.latestPeriodFlag = 1
                        order by di.dataItemName
                    """.format(", ".join(
                [str(x)
                 for x in fin_param]
            ),
                ", ".join(
                    [str(x)
                     for x in self._supported_exchanges_ids]
                ),
                snp_id
            )

            return sql_query

        queries = []
        [queries.append(
            build_sql_query(x['vendor_assigned_id'],
                            financial_parameters_list
                            )
        ) for x in composite_pk_id_dict]

        batch_size = 100
        save_counter = 1
        time_list = []
        df = pd.DataFrame()
        for i, q in enumerate(queries):
            print("RUNNING QUERY #{}...".format(i + 1))
            df = df.append(pd.read_sql_query(q, self._SNP_SOURCE_ENGINE),
                           ignore_index=True
                           )
            print(" DONE.")
            if not ((i + 1) % batch_size):
                print("SAVING THE LAST {} RESULTS...".format(batch_size))
                t0 = datetime.datetime.now()
                df.to_sql('new_screener_test_table',
                          self._DATAFACTORY,
                          if_exists='append'
                          )
                t1 = datetime.datetime.now()

                dt = (t1 - t0)
                save_counter += 1

                time_list.append(dt)
                # number of batches remaining
                n = (len(queries) - save_counter * batch_size) / batch_size
                # current ETA
                eta = n * dt
                # average ETA
                avg_eta = n * sum(time_list,
                                  datetime.timedelta()) / len(time_list)
                print(" DONE.")
                print("{} ETA: {}".format(datetime.datetime.now(), eta))
                print("{} <ETA>: {}".format(datetime.datetime.now(), avg_eta))
                df = pd.DataFrame()

        if len(df) > 0:
            # saving the rest of the data
            df.to_sql('new_screener_test_table',
                      self._DATAFACTORY,
                      if_exists='append'
                      )

        print("TABLE CREATED.")

    def create_tables(self):
        financial_parameters_list = self._get_financial_parameters()
        composite_pk_id_dict = self._get_all_symbol_exchange_combinations()

        self._get_data_by_id(composite_pk_id_dict,
                             financial_parameters_list
                             )

        print("DONE.")


def _create_screener_table(dev=True):
    """
    Creates a table in Postgres with data imported from a DynamoDB table.
    :return: None
    """
    screener = ScreenerPopulateTable()
    # mapping PG_table_name (to_tbl) : DD_table_name (from_tbl)
    # tables = {"PG_table_name_to_be_create" : "DD_table_name_to_read_data_from"}
    if dev:
        # create test table for development
        tables = {
            "screener_test_indu_calc": "INTRINIO_US_INDU_CALCULATIONS",
            "screener_test_indu_income": "INTRINIO_US_INDU_INCOME",
            "screener_test_indu_balance": "INTRINIO_US_INDU_BALANCE_SHEET",
            "screener_test_indu_cashflow": "INTRINIO_US_INDU_CASH_FLOW",
            "screener_test_fin_calc": "INTRINIO_US_FIN_CALCULATIONS",
            "screener_test_fin_income": "INTRINIO_US_FIN_INCOME",
            "screener_test_fin_balance": "INTRINIO_US_FIN_BALANCE_SHEET",
            "screener_test_fin_cashflow": "INTRINIO_US_FIN_CASH_FLOW",
        }
    else:
        # replace existent tables
        tables = {
            "SCREENER_INDU_CALC": "INTRINIO_US_INDU_CALCULATIONS",
            "SCREENER_INDU_INCOME": "INTRINIO_US_INDU_INCOME",
            "SCREENER_INDU_BALANCE": "INTRINIO_US_INDU_BALANCE_SHEET",
            "SCREENER_INDU_CASHFLOW": "INTRINIO_US_INDU_CASH_FLOW",
            "SCREENER_FIN_CALC": "INTRINIO_US_FIN_CALCULATIONS",
            "SCREENER_FIN_INCOME": "INTRINIO_US_FIN_INCOME",
            "SCREENER_FIN_BALANCE": "INTRINIO_US_FIN_BALANCE_SHEET",
            "SCREENER_FIN_CASHFLOW": "INTRINIO_US_FIN_CASH_FLOW",
        }
    # create screener tables
    [screener._screener_populate_table(from_tbl, to_tbl)
     for to_tbl, from_tbl in tables.items()]
    print("Creation of Screener tables finished (dev={}).".format(dev))


def _create_sbt_model_table(dev=True):
    # this table should be the same as its DD counterpart
    screener = ScreenerPopulateTable()
    # Dynamo table to get the data from
    table_from = "SBT_MODEL"
    # PG table name to be created
    table_to = "screener_test_sbt_model" if dev else "SCREENER_MODEL"

    # define filters and conditions
    filter = 'category ne rose OR category ne maria'
    # read data from DD
    df = screener._read_from_dynamo_into_df(table_from, filter)

    # REMOVE MOMENTUM DATA (TODO: include MOMENTUM data)
    # df = df[df['model_id'] != 'MOMENTUM']

    # keep only the useful attributes
    # df.drop(['calculated_data', 'raw_data'], axis='columns', inplace=True)
    df = df[['symbol', 'model_id', 'rank']]
    # rename 'symbol' to 'ticker'
    df.rename(columns={"symbol": "ticker"}, index=str, inplace=True)

    # # data that has both CE & MDS
    # new_df = pd.concat(g for _, g in df.groupby('ticker') if len(g) > 1)
    #
    # create temporary dfs
    df_ce = df[df['model_id'] == 'CAPITAL_EFFICIENCY']
    df_mds = df[df['model_id'] == 'MD_SCORE']
    df_mom = df[df['model_id'] == 'MOMENTUM']
    # merge both temp dfs
    temp_df = pd.merge(left=df_mds, right=df_ce, on=['ticker'], how='outer')
    merged_df = pd.merge(left=temp_df, right=df_mom, on=['ticker'],
                         how='outer')
    # drop unnecessary columns
    df = merged_df[['ticker', 'rank_x', 'rank_y', 'rank']]
    # rename cols
    df.rename(
        columns={"rank_x": "mds", "rank_y": "rank_ce", "rank": "rank_mom"},
        index=str, inplace=True)
    # map MD Score to (fractional) ranking (high:1, low:N)
    df['rank_mds'] = df['mds'].rank(ascending=False)
    df.drop(["mds"], axis=1, inplace=True)

    # write data to PG
    screener._write_from_df_to_pg(table_to, df)
    print(
        "Creation of Screener SBT MODEL table finished (dev={}).".format(dev))


def _create_metadata_table(dev=True):
    # this table should be the same as its DD counterpart
    screener = ScreenerPopulateTable()
    # Dynamo table to get the data from
    table_from = "INTRINIO_DATA_DICTIONARY_METADATA"
    # PG table name to be created
    table_to = "screener_test_metadata" if dev else "SCREENER_METADATA"

    # define filters and conditions
    filter = 'category ne rose OR category ne maria'
    # read data from DD
    df = screener._read_from_dynamo_into_df(table_from, filter)
    # write data to PG
    screener._write_from_df_to_pg(table_to, df)
    print("Creation of Screener metadata table finished (dev={}).".format(dev))


def _create_company_table(dev=True):
    # this table should be the same as its DD counterpart
    screener = ScreenerPopulateTable()
    # Dynamo table to get the data from
    table_from = "INTRINIO_US_COMPANY"
    # PG table name to be created
    table_to = "screener_test_company" if dev else "SCREENER_COMPANY"

    # define filters and conditions (just used to retrieve everything)
    filter = 'category ne rose OR category ne maria'
    # read data from DD
    df = screener._read_from_dynamo_into_df(table_from, filter)
    # write data to PG
    screener._write_from_df_to_pg(table_to, df)
    print("Creation of Screener company table finished (dev={}).".format(dev))


def _create_description_table(dev=True):
    # deal with DB
    pgconfig = SbtGlobalCommon.get_sbt_config()['postgres']['datafactory']
    engine = PostgresAccessor(pgconfig)._engine
    # get metadata from screener_metadata
    meta_table = "screener_test_metadata" if dev else "SCREENER_METADATA"
    df_meta = pd.read_sql_table(meta_table, engine, index_col=None)
    # consider only the "column" col for removing duplicate
    df_meta.drop_duplicates(subset="column", inplace=True)
    json_dict = {}
    # this loop will fetch description from Intrinio's webpage for each item
    tic = time.time()
    for index, item in \
            enumerate(zip(df_meta['name'], df_meta['column'],
                          df_meta['units'], df_meta['category'])):
        name, col, unit, categ = item[0], item[1], item[2], item[3]
        url = 'https://intrinio.com/data-tag/' + col
        try:
            hdr = {
                'User-Agent': 'we dont want to wait for more requests /u/teamT'}
            req = requests.get(url, headers=hdr)
            dt = 0
            while req.status_code == 429:
                print(
                    " Oops... Too fast! Will try again in {} s...".format(dt))
                print(" (sleeping now... dt={} s)".format(time.time() - tic))
                time.sleep(dt)
                dt += 1
                req = requests.get(url, headers=hdr)
        except Exception as e:
            print(e)

        soup = bs(req.content, 'html.parser')
        divs = soup.find_all('div', class_='label')
        is_description_present = bool(len(
            [x for x in soup.find_all('div', class_='label')
             if x.text == 'Description']
        ))

        # if categ == "CALCULATION":
        if is_description_present:
            desc = [x.previous_sibling.previous_sibling.text for x in divs
                    if x.text == 'Description'][0]
            json_dict[index] = [col, name, unit, desc, categ]
        else:
            json_dict[index] = [col, name, unit, '', categ]
        # else:
        #   json_dict_skipped[index] = [col, name, unit]
        #   print(" #{} IS NOT CALCULATION (returned code {}): {}, {}, {}"
        #         .format(index, req.status_code, name, col, unit))
        print("Request status code for index #{} ({}): {}"
              .format(index, url, req.status_code))
    tac = time.time()

    print('=> dt to retrieve description: {} seconds'.format(tac - tic))
    # convert dict to dataframe and transpose it
    df_t = pd.DataFrame(json_dict).T
    # give each column its name
    df_t.columns = ['column', 'name', 'unit', 'description', 'category']

    # adding info about the models
    # TODO: implement method to do this programmatically
    df_t = df_t.append(pd.Series([
        'rank_mds',
        'MD Score rank',
        'N/A',
        '',
        'CALCULATION'
    ], index=df_t.columns), ignore_index=True)
    df_t = df_t.append(pd.Series([
        'rank_ce',
        'Capital Efficiency rank',
        'N/A',
        '',
        'CALCULATION'
    ], index=df_t.columns), ignore_index=True)
    df_t = df_t.append(pd.Series([
        'rank_mom',
        'Momentum rank',
        'N/A',
        '',
        'CALCULATION'
    ], index=df_t.columns), ignore_index=True)

    # write to PG database
    # deal with DB
    # get dict from sbt_config.json
    # engine = PostgresAccessor(pgconfig)._engine
    table_name = "screener_test_description" if dev else "SCREENER_DESCRIPTION"
    df_t.to_sql(table_name, engine, if_exists='replace', index=False)
    print("Creation of Screener description table finished (dev={}).".format(
        dev))


def _create_sic_table(dev=True):
    # this table should be the same as its DD counterpart
    screener = ScreenerPopulateTable()
    # Dynamo table to get the data from
    table_from = "SBT_STANDARD_INDUSTRIAL_CLASSIFICATION"
    # PG table name to be created
    table_to = "screener_test_sic" if dev else "SCREENER_SIC"

    # define filters and conditions
    filter = 'category ne rose OR category ne maria'
    # read data from DD
    df = screener._read_from_dynamo_into_df(table_from, filter)
    # remove unnecessary attribute
    df.drop(['ad_office'], axis='columns', inplace=True)
    # write data to PG
    screener._write_from_df_to_pg(table_to, df)
    print("Creation of Screener sic table finished (dev={}).".format(dev))


def _test_screener():
    screener = ScreenerAccessor()

    # top_companies = screener.get_top_companies(full_list=True)
    # print(top_companies)
    #
    # # populate endpoint
    # list_of_keys = screener.populate()
    # print(list_of_keys)
    #
    # # MCAP count
    # mcaps_count = screener.get_market_cap_count()
    # print(mcaps_count)
    #
    # # SECTOR count
    # sectors_count = screener.get_sector_count()
    # print(sectors_count)
    #
    # # INDUSTRY count
    # industry_count = screener.get_industry_count()
    # print(industry_count)
    #
    # # TAGS count
    # tags_count = screener.get_tags_count()
    # print(tags_count)
    #
    # print("Done")
    #
    # # SCREENING
    # payload0 = {
    #     "filters": [
    #         {
    #             "field": "sector",
    #             "value": "40",
    #             "operator": "eq"
    #         }
    #     ]
    # }
    # data = screener.new_screener(payload0)
    # print(payload0)
    # print(data.keys())
    # print(data.values())
    #
    # response = screener.new_screener_count(payload0)
    # print('TOTAL: ' + str(response))
    #
    # del payload0
    #
    # payload0 = {
    #     "filters": [
    #         {
    #             "field": "100003",
    #             "value": "10",
    #             "operator": "gte"
    #         },
    #         {
    #             "field": "sector",
    #             "value": "technology",
    #             "operator": "eq"
    #         },
    #         {
    #             "field": "3058",
    #             "value": "0.01",
    #             "operator": "gte"
    #         },
    #         {
    #             "field": "mcap",
    #             "value": "small",
    #             "operator": "eq"
    #         },
    #         {
    #             "field": "mcap",
    #             "value": "mega",
    #             "operator": "eq"
    #         },
    #         {
    #             "field": "sector",
    #             "value": "15",
    #             "operator": "eq"
    #         },
    #         {
    #             "field": "sector",
    #             "value": "35",
    #             "operator": "eq"
    #         },
    #         {
    #             "field": "sector",
    #             "value": "25",
    #             "operator": "eq"
    #         },
    #         {
    #             "field": "mcap",
    #             "value": "large",
    #             "operator": "eq"
    #         },
    #         # {
    #         #     "field": "rank",
    #         #     "value": 300,
    #         #     "operator": "lte"
    #         # }
    #     ]
    # }
    # response = screener.new_screener_count(payload0)
    # print('TOTAL: ' + str(response))
    #
    # # TESTING THE TAG REQUESTS
    # del payload0
    payload0 = {
        "filters": [
            {
                "field": "Special tags",
                "operator": "eq",
                "value": "retirement"
            }
        ]
    }
    response = screener.new_screener_count(payload0)
    print('TOTAL: ' + str(response))


if __name__ == "__main__":
    _is_this_dev = True

    # # dev = True for development
    # # dev = False for replacement of the existent tables
    #
    # _create_metadata_table(dev=_is_this_dev)
    #
    # _create_company_table(dev=_is_this_dev)
    #
    # _create_description_table(dev=_is_this_dev)
    #
    # # for the SIC table, SIC = 0 must be added
    # _create_sic_table(dev=_is_this_dev)
    #
    # # for CE & MDS
    # _create_sbt_model_table(dev=_is_this_dev)
    #
    # # keep this for last as it needs to reference the tables above
    # _create_screener_table(dev=_is_this_dev)

    _test_screener()

    # screener = Screnner()
    # screener.create_tables()

    print("Stop")
