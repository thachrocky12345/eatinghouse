import datetime
import logging

from sbt_common import SbtGlobalCommon
from sbt_model import ModelId
from sbt_model import Model

g_logger = SbtGlobalCommon.get_global_logger()


def timeit(f):
  def timed(*args, **kw):
    tic = datetime.datetime.now()
    result = f(*args, **kw)
    tac = datetime.datetime.now()
    g_logger.info(" {}: DONE IN {}".format(f.__name__, tac - tic))
    return result
  return timed


class ModelLoader(object):
  
  def __init__(self):
    """
      Constructor
    """
    self._sbtcommon = SbtGlobalCommon
    self._logger = self._sbtcommon.get_global_logger()
  
  def pop (self):
    model = Model(ModelId.CAPITAL_EFFICIENCY.value)
    ma = model.get_model_accessor()
    
    companies = ma._scan_table('SBT_SYMBOL_EXCHANGE_MAPPING', None)
    
    dataload = []
    for company in companies :
      if 'central_index_key' in company.keys() :
        dl = {}
        dl['guid'] = company['guid']
        dl['symbol'] = company['symbol']
        dl['model_id'] = model._model_id
        dl['load_timestamp'] = '00-00-0000 00:00:00 GMT'
        dataload.append(dl)

    ma.save_model_dataload(dataload)

  @timeit
  def load_ce_model (self):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format( datetime.datetime.utcnow() )
    tickers = []
    
    model_id = ModelId.CAPITAL_EFFICIENCY.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1    
    for mapping in pending :
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500 :
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)        
        tickers = []
        counter = 1
      else :
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank()

  @timeit
  def load_momentum_model (self):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format( datetime.datetime.utcnow() )
    tickers = []
    
    model_id = ModelId.MOMENTUM.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)
    
    counter = 1    
    for mapping in pending :
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500 :
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else :
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank()

  @timeit
  def load_md_val_model(self):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank()

  @timeit
  def load_md_fin_model(self):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE_FIN.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank()

  @timeit
  def load_md_ear_model(self):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE_EAR.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank()

  @timeit
  def load_md_avg_model(self):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE_AVG.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank()

  @timeit
  def load_md_all(self):
    self.load_md_val_model()
    self.load_md_fin_model()
    self.load_md_ear_model()
    self.load_md_avg_model()

  @timeit
  def load_all_models(self):
    self.load_ce_model()
    self.load_momentum_model()
    self.load_md_all()


class MdLoader(object):

  def __init__(self):
    """
      Constructor
    """
    self._sbtcommon =SbtGlobalCommon
    self._logger = self._sbtcommon.get_global_logger()
    # list to contain the GUID and corresponding
    # symbol and exchange for the companies
    self.company_info = {}

  def _setup_model(self, model_id=None, symbol_list=None, reset_all=False):
    # this method will setup up SBT_MODEL_DATALOAD by zeroing
    # the "load_timestamp" attribute for:
    # (1) a given list of symbols (symbol_list=[symbols]) or
    # (2) for all symbols under a specific model (reset_all=True)
    model = Model(model_id)
    ma = model.get_model_accessor()

    if reset_all:
      ma.reset_all_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(getattr(ModelId, model_id).value)
      self._logger.critical("A TOTAL OF {} SYMBOLS HAVE BEEN RESET FOR {}.".format(
              len(pending), model_id))
    elif symbol_list and model_id:
      # retrieve data needed for SBT_MODEL_DATALOAD
      guids = [[x['guid'] for x in ma.query_symbol_exchage_mapping_for_symbol(symbol=symbol)]
               for symbol in symbol_list]
      symbols = [[x['symbol'] for x in ma.query_symbol_exchage_mapping_for_symbol(symbol=symbol)]
               for symbol in symbol_list]
      exchanges = [[x['exchange'] for x in ma.query_symbol_exchage_mapping_for_symbol(symbol=symbol)]
               for symbol in symbol_list]
      latest_filing_dates = [[x['snp_latest_filing_date'] for x in
                ma.query_symbol_exchage_mapping_for_symbol(symbol=symbol)]
               for symbol in symbol_list]
      # flattened version of the lists above
      # (accounts for duplicate symbols due to different exchanges)
      self.company_info['guids'] = guids = [item for sublist in guids for item in sublist]
      self.company_info['symbols'] = symbols = [item for sublist in symbols for item in sublist]
      self.company_info['exchanges'] = exchanges = [item for sublist in exchanges for item in sublist]
      latest_filing_dates = [item for sublist in latest_filing_dates for item in sublist]

      attributes = ["load_timestamp", "symbol", "exchange", "latest_filing_date"]
      reset_load_timestamp = "00-00-0000 00:00:00 GMT"

      [ma._update(ma._model_dataload_table,
                 attributes_to_update=attributes,
                 attribute_values=[
                   reset_load_timestamp, symbols[i],
                   exchanges[i], latest_filing_dates[i]
                 ],
                 expression_attribute_names={
                   "#{}".format(attr): attr for attr in attributes
                 },
                 key={"guid": guid, "model_id": model_id})
       for i, guid in enumerate(guids)]

      self._logger.info("{} table has been setup for {}")
    else:
      self._logger.info("MODEL NOT SET.")

  def _load_md_val_model(self, symbol_list=None):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank(company_info=self.company_info if symbol_list else None)

    print("DONE.")

  def _load_md_fin_model(self, symbol_list=None):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE_FIN.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank(company_info=self.company_info if symbol_list else None)

    print("DONE.")

  def _load_md_ear_model(self, symbol_list=None):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE_EAR.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank(company_info=self.company_info if symbol_list else None)

    print("DONE.")

  def _load_md_avg_model(self, symbol_list=None):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model_id = ModelId.MD_SCORE_AVG.value
    model = Model(model_id)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(model_id)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(model_id)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank(company_info=self.company_info if symbol_list else None)

  @timeit
  def load_md_all(self):
    # subset of symbols to run the model calculations over
    # symbol_list = ['GS',
    #            'IBM',
    #            'TRV',
    #            'AXP',
    #            'WMT',
    #            'DIS',
    #            'VZ',
    #            'JPM',
    #            'GE',
    #            'AAPL',
    #            'PG',
    #            'CSCO',
    #            'PFE',
    #            'CAT',
    #            'INTC',
    #            'XOM',
    #            'BA',
    #            'UTX',
    #            'UNH',
    #            'HD',
    #            'JNJ',
    #            'MRK',
    #            'CVX',
    #            'DWDP',
    #            'MCD',
    #            'MMM',
    #            'KO',
    #            'MSFT',
    #            'NKE',
    #            'V']
    # symbol_list = ['AAPL', 'AXP', 'BA',
    #                'INTC', 'JNJ', 'JPM',
    #                'VZ', 'WMT', 'XOM']
    symbol_list = None
    # if reset_all=True, all symbols will be reset, regardless of symbol_list.
    reset_all = True

    # tic = datetime.datetime.now()
    # model_id = ModelId.MD_SCORE.value
    # self._setup_model(model_id=model_id,
    #                   symbol_list=symbol_list,
    #                   reset_all=reset_all)
    # self._load_md_val_model(symbol_list=symbol_list)
    # tac = datetime.datetime.now()
    # self._logger.critical(" MD SCORE VAL MODEL COMPLETED IN {}".format(tac - tic))

    tic = datetime.datetime.now()
    model_id = ModelId.MD_SCORE_FIN.value
    self._setup_model(model_id=model_id,
                      symbol_list=symbol_list,
                      reset_all=reset_all)
    self._load_md_fin_model(symbol_list=symbol_list)
    tac = datetime.datetime.now()
    self._logger.critical(" MD SCORE FIN MODEL COMPLETED IN {}".format(tac - tic))
    #
    # model_id = ModelId.MD_SCORE_EAR.value
    # self._setup_model(model_id=model_id, symbol_list=symbol_list)
    # self._load_md_ear_model(symbol_list=symbol_list)
    #
    # model_id = ModelId.MD_SCORE_AVG.value
    # self._setup_model(model_id=model_id, symbol_list=symbol_list)
    # self._load_md_avg_model(symbol_list=symbol_list)


class CeLoader(object):
  """
  This class is a self-contained version of ModelLoader.load_ce_model intended
    to be used with a limited number of symbols or for updating CAPITAL
    EFFICIENCY over the whole dataset.
  """

  def __init__(self):
    """
      Constructor
    """
    logging.getLogger('botocore').setLevel(logging.CRITICAL)
    self._sbtcommon = SbtGlobalCommon
    self._logger = self._sbtcommon.get_global_logger()
    self._logger.setLevel('CRITICAL')

  def _setup_model(self, model_id=None, symbol_list=None, reset_all=False):
    # this method will setup up SBT_MODEL_DATALOAD by zeroing
    # the "load_timestamp" attribute for:
    # (1) a given list of symbols (symbol_list=[symbols]) or
    # (2) for all symbols under a specific model (reset_all=True)
    model = Model(model_id)
    ma = model.get_model_accessor()

    if reset_all:
      ma.reset_all_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(
        ModelId.CAPITAL_EFFICIENCY.value)
      self._logger.critical("A TOTAL OF {} SYMBOLS HAVE BEEN RESET FOR {} .".format(
              len(pending), model_id))
    elif symbol_list and model_id:
      guids = [ma.query_symbol_exchage_mapping_for_symbol(symbol=symbol)[0]['guid']
               for symbol in symbol_list]

      attribute = "load_timestamp"
      attribute_value = "00-00-0000 00:00:00 GMT"
      expression_attribute_names = {"#{}".format(attribute): attribute}

      [ma._update(ma._model_dataload_table,
                 attributes_to_update=[attribute],
                 attribute_values=[attribute_value],
                 key={"guid": guid, "model_id": model_id},
                 expression_attribute_names=expression_attribute_names)
       for guid in guids]

      # self._logger.info("{} table has been setup for {}")
    else:
      self._logger.info("MODEL NOT SET.")

  def _load_ce_model(self, symbol_list=None):
    # this method is the same as ModelLoader.load_ce_model above except it can
    # take a list of symbols to be updated.
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model = Model(ModelId.CAPITAL_EFFICIENCY.value)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(ModelId.CAPITAL_EFFICIENCY.value)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(ModelId.CAPITAL_EFFICIENCY.value)
      pending = ma.query_pending_model_datalaod(ModelId.CAPITAL_EFFICIENCY.value)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank(company_info=symbol_list)

  @timeit
  def load_ce_all(self):
    # subset of symbols to run the model calculations over
    # symbol_list = ['FB', 'AAPL', 'MSFT', 'IBM', 'TSLA', 'XHR']
    symbol_list = None
    # if reset_all=True, all symbols will be reset, regardless of symbol_list.
    reset_all = True
    tic = datetime.datetime.now()
    model_id = ModelId.CAPITAL_EFFICIENCY.value
    self._setup_model(model_id=model_id,
                      symbol_list=symbol_list,
                      reset_all=reset_all)
    self._load_ce_model(symbol_list=symbol_list)
    tac = datetime.datetime.now()
    self._logger.critical(" CE MODEL COMPLETED IN {}".format(tac-tic))


class MomentumLoader(object):
  def __init__(self):
    """
      Constructor
    """
    self._sbtcommon =SbtGlobalCommon
    self._logger = self._sbtcommon.get_global_logger()

  def _setup_model(self, model_id=None, symbol_list=None, reset_all=False):
    # this method will setup up SBT_MODEL_DATALOAD by zeroing
    # the "load_timestamp" attribute for:
    # (1) a given list of symbols (symbol_list=[symbols]) or
    # (2) for all symbols under a specific model (reset_all=True)
    model = Model(model_id)
    ma = model.get_model_accessor()

    if reset_all:
      ma.reset_all_to_pending_model_datalaod(model_id)
      pending = ma.query_pending_model_datalaod(
              ModelId.MOMENTUM.value)
      self._logger.critical(
              "A TOTAL OF {} SYMBOLS HAVE BEEN RESET FOR {} .".format(
                      len(pending), model_id))
    elif symbol_list and model_id:
      guids = [
        ma.query_symbol_exchage_mapping_for_symbol(symbol=symbol)[0]['guid']
        for symbol in symbol_list]

      attribute = "load_timestamp"
      attribute_value = "00-00-0000 00:00:00 GMT"
      expression_attribute_names = {"#{}".format(attribute): attribute}

      [ma._update(ma._model_dataload_table,
                  attributes_to_update=[attribute],
                  attribute_values=[attribute_value],
                  key={"guid": guid, "model_id": model_id},
                  expression_attribute_names=expression_attribute_names)
       for guid in guids]

      # self._logger.info("{} table has been setup for {}")
    else:
      self._logger.info("MODEL NOT SET.")

  def _load_mom_model(self, symbol_list=None):
    timestamp = '{:%m-%d-%Y %H:%M:%S GMT}'.format(datetime.datetime.utcnow())
    tickers = []

    model = Model(ModelId.MOMENTUM.value)
    ma = model.get_model_accessor()

    pending = ma.query_pending_model_datalaod(ModelId.MOMENTUM.value)

    if self._sbtcommon.collectionsutil.is_empty(pending):
      ma.reset_to_pending_model_datalaod(ModelId.MOMENTUM.value)
      pending = ma.query_pending_model_datalaod(ModelId.MOMENTUM.value)

    counter = 1
    for mapping in pending:
      mapping['load_timestamp'] = timestamp
      tickers.append(mapping)

      if counter == 500:
        model.process_companies(tickers)
        ma.save_model_dataload(tickers)
        tickers = []
        counter = 1
      else:
        counter = counter + 1

    if len(tickers) > 0 and counter > 1:
      model.process_companies(tickers)
      ma.save_model_dataload(tickers)

    model.rank(company_info=symbol_list)

  @timeit
  def load_mom_all(self):
    # subset of symbols to run the model calculations over
    # symbol_list = ['FB', 'AAPL', 'MSFT', 'IBM', 'TSLA', 'XHR']
    symbol_list = None
    # if reset_all=True, all symbols will be reset, regardless of symbol_list.
    reset_all = True
    tic = datetime.datetime.now()
    model_id = ModelId.MOMENTUM.value
    self._setup_model(model_id=model_id,
                      symbol_list=symbol_list,
                      reset_all=reset_all)
    self._load_mom_model(symbol_list=symbol_list)
    tac = datetime.datetime.now()
    self._logger.critical(" MOMENTUM MODEL COMPLETED IN {}".format(tac-tic))


class ReRanker(object):

  def __init__(self):
    logging.getLogger('botocore').setLevel(logging.CRITICAL)
    self._sbtcommon = SbtGlobalCommon
    self._logger = self._sbtcommon.get_global_logger()
    self._logger.setLevel('CRITICAL')

  def do_it(self, model_name):
    try:
      if model_name == 'CAPITAL_EFFICIENCY':
        model_id = ModelId.CAPITAL_EFFICIENCY.value
      elif model_name == 'MD_SCORE':
        model_id = ModelId.MD_SCORE.value
      elif model_name == 'MD_SCORE_FIN':
        model_id = ModelId.MD_SCORE_FIN.value
      elif model_name == 'MD_SCORE_EAR':
        model_id = ModelId.MD_SCORE_EAR.value
      elif model_name == 'MOMENTUM':
        model_id = ModelId.MOMENTUM.value
      else:
        raise ValueError(' UNKNOWN MODEL NAME: {}'.format(model_name))

      model = Model(model_id)
      model.rank()
    except ValueError as err:
      self._logger.critical(err.args)
      self._logger.critical(' EXITING.')


if __name__ == '__main__':

  # RESET EVERYTHING
  # (RESET DATALOAD TO ZERO FOR A SPECIFIC MODEL)
  # model_id = 'CAPITAL_EFFICIENCY'
  # model = Model(model_id)
  # ma = model.get_model_accessor()
  # ma.reset_all_to_pending_model_datalaod(model_id)

  # MD SCORE
  # loader = ModelLoader()
  loader = MdLoader()
  loader.load_md_all()

  # CAPITAL EFFICIENCY
  # loader = ModelLoader()
  # loader = CeLoader()
  # loader.load_ce_all()

  # MOMENTUM
  # loader = ModelLoader()
  # loader = MomentumLoader()
  # loader.load_mom_all()

  # CAPITAL EFFICIENCY RANKING
  # ce_reranker = ReRanker('CAPITAL_EFFICIENCY')
  # ce_reranker.do_it()

  # MD SCORE RANKING
  # md_reranker = ReRanker('MD_SCORE')
  # tic = datetime.datetime.now()
  # md_reranker.do_it()
  # tac = datetime.datetime.now()
  # print("Dt = {}".format(tac-tic))

  print("DONE.")
