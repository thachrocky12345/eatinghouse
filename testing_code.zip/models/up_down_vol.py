import pandas as pd
from barchart_accessor import BarchartAccessor
import numpy as np

class UpDownVol:
    def __init__(self):
        self.barchart_accessor = BarchartAccessor()

    def get_prices(self, symbol):
        adj_close_data = self.barchart_accessor.get_history(None, "daily", 0, "19000101", None,
                                                            symbol)
        adj_close_df = pd.DataFrame([float(x['close']) for x in adj_close_data],
                                    [x['tradingDay'] for x in adj_close_data])
        adj_close_df = adj_close_df[~adj_close_df.index.duplicated(keep='last')]

        adj_close_df['volume'] = [x['volume'] for x in adj_close_data]
        adj_close_df.rename(columns={0: "close"}, inplace=True)
        return adj_close_df

    def sem(self, arr):
        mean = np.average(arr)
        std = np.std(arr)
        sm = 0
        count = 0
        for i in arr:
            if i < mean:
                sm += (mean - i) ** 2
                count += 1
        semi = np.sqrt(sm/count)
        semi = arr[arr < mean].std()
        # print("Std", std)
        # print("Semi", semi)
        return semi


    def calc(self, symbol):
        prices = self.get_prices(symbol)
        prices.index = pd.to_datetime(prices.index)
        prices['daily_returns'] = prices['close'].pct_change(1)
        monthly = prices['close'].resample('BM', how=lambda x: x[-1])
        monthly_ret = monthly.pct_change()
        prices['monthly_returns'] = monthly.pct_change()

        yearly = prices['close'].resample('BY', how=lambda x: x[-1])
        yearly_ret = yearly.pct_change()
        prices['yearly_returns'] = yearly.pct_change()

        semi_daily = pd.Series(prices['daily_returns'].rolling(252*3).apply(self.sem), name='semi')
        stand_daily = pd.Series(prices['daily_returns'].rolling(252*3).std(), name='stand')
        # % of the total volatility coming from negative returns
        ratio_daily = pd.Series(semi_daily/stand_daily, name='ratio')
        comb_daily = pd.concat([semi_daily, stand_daily, ratio_daily, prices['daily_returns']], axis=1)

        semi_monthly = pd.Series(monthly_ret.rolling(36).apply(self.sem), name='semi')
        stand_monthly = pd.Series(monthly_ret.rolling(36).std(), name='stand')
        # % of the total volatility coming from negative returns
        ratio_monthly = pd.Series(semi_monthly / stand_monthly, name='ratio')
        comb_monthly = pd.concat([semi_monthly, stand_monthly, ratio_monthly, monthly_ret], axis=1)

        semi_yearly = pd.Series(yearly_ret.rolling(3).apply(self.sem), name='semi')
        stand_yearly = pd.Series(yearly_ret.rolling(3).std(), name='stand')
        # % of the total volatility coming from negative returns
        ratio_yearly = pd.Series(semi_yearly / stand_yearly, name='ratio')
        comb_yearly = pd.concat([semi_yearly, stand_yearly, ratio_yearly, yearly_ret], axis=1)

        print()

if __name__ == '__main__':
    vol = UpDownVol()
    vol.calc('AAPL')
