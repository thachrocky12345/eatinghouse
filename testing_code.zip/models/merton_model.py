import logging

import numpy as np
from scipy.stats import norm
from scipy.optimize import minimize
import math
import os
import sys
import json
import sqlalchemy
import pandas as pd
from sympy import symbols, Eq, solve
import datetime
from dateutil.relativedelta import relativedelta
from sqlalchemy import JSON, FLOAT, VARCHAR, text

# global list of environments to update
ENVS_TO_UPDATE = ['dev', 'qa', 'prod']


class MertonModel:
    def __init__(self, back_test=False, start_date=None, skip_load=False):
        # configure logging
        self._logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self._logger.info("Logging Configured...")

        # read the entire config file
        with open(os.path.join(sys.path[0], 'sbt_conf.json')) as config:
            config = json.load(config)

        # self.ENV = 'dev'
        self._snp_pg = config['dev']['postgres']['snpsource']
        self._snp_engine = self._create_pg_engine(self._snp_pg)

        self._pg_df = config['dev']['postgres']['datafactory']
        self._pg_df_engine = self._create_pg_engine(self._pg_df)

        self._pg_df_qa = config['qa']['postgres']['datafactory']
        self._pg_df_qa_engine = self._create_pg_engine(self._pg_df_qa)

        self._pg_df_prod = config['prod']['postgres']['datafactory']
        self._pg_df_prod_engine = self._create_pg_engine(self._pg_df_prod)

        # env to db mapping
        self.db_to_update = {'DEV': self._pg_df_engine,
                             'QA': self._pg_df_qa_engine,
                             'PROD': self._pg_df_prod_engine}

        self.EXCHANGE_MAPPING = {
            'NasdaqGS': 'NSDQ',
            'NasdaqGM': 'NSDQ',
            'NasdaqCM': 'NSDQCM',
            'ARCA': 'NYSEARCA'
        }
        if not skip_load:
            if back_test:
                self._start_date = datetime.datetime.strptime(start_date, '%Y-%m-%d')
                self._end_date = self._start_date + relativedelta(years=1)
                self.rf_rate = pd.read_sql("SELECT * FROM timeseries_external_data WHERE composite_pk_id = 'DGS5:FRED'",
                                           self._pg_df_engine)
                self.rf_rate = self.rf_rate[self.rf_rate['timestamp'] == (self._end_date + relativedelta(days=1)).strftime(
                    "%Y-%m-%d") + " 00:00:00"]['value'].iloc[0]

                sql = """
                                   SELECT s.tickersymbol,
                       s.companyname,
                       s.companyid,
                       s.currentliabilities,
                       s.ltdebt,
                       s.ltliabilities,
                       s.sharesout,
                       s.exchangesymbol,
                       s.gicsgroup,
                       s.tradingitemid,
                       s.filingdate,
                       s.mktcap
                FROM (SELECT t1.tickersymbol,
                             t1.companyname,
                             t1.companyid,
                             t1.exchangesymbol,
                             t1.gicsgroup,
                             t1.tradingitemid,
                             t1.filingdate,
                             sum(
                                     CASE
                                         WHEN (t1.dataitemid = 1009) THEN t1.dataitemvalue
                                         ELSE NULL::numeric
                                         END) AS currentliabilities,
                             sum(
                                     CASE
                                         WHEN (t1.dataitemid = 1014) THEN t1.dataitemvalue
                                         ELSE NULL::numeric
                                         END) AS ltliabilities,
                             sum(
                                     CASE
                                         WHEN (t1.dataitemid = 1072) THEN t1.dataitemvalue
                                         ELSE NULL::numeric
                                         END) AS sharesout,
                             sum(
                                     CASE
                                         WHEN (t1.dataitemid = 1193) THEN t1.dataitemvalue
                                         ELSE NULL::numeric
                                         END) AS ltdebt,
                             sum(
                                     CASE
                                         WHEN (t1.dataitemid = 100010) THEN t1.dataitemvalue
                                         ELSE NULL::numeric
                                         END) AS mktcap
                      FROM (SELECT mv.companyname,
                                   mv.companyid,
                                   mv.tickersymbol,
                                   fd.dataitemid,
                                   fd.dataitemvalue,
                                   mv.exchangesymbol,
                                   mv.gicsgroup,
                                   mv.tradingitemid,
                                   mmd.filingdate
                            FROM (((((v2mv_sbt_company mv
                                JOIN merton_model_backtest({}) mmd ON mmd.companyid = mv.companyid
                                JOIN ciqfinancialdata fd ON fd.financialperiodid = mmd.financialperiodid)))
                                ))
                            WHERE ((fd.dataitemid = ANY (ARRAY [1072, 1009, 1193, 1014, 100010])) AND (
                            mv.is_primary_exchange = true))) t1
                      GROUP BY t1.companyname, t1.tickersymbol, t1.companyid, t1.exchangesymbol, t1.gicsgroup, 
                      t1.filingdate,
                               t1.tradingitemid) s;
                                    """.format(self._end_date.year)
                self._data = pd.read_sql(sql, self._snp_engine)
                sql = """
                            SELECT companyid, (SELECT v.pricingdate
                                                        FROM v_price_timeseries v
                                                        WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate
                                                        = '{}'
                                                        ORDER BY v.pricingdate
                                                        LIMIT 1)
                                                                        AS volatility_sample_start,
                                                       (SELECT v.pricingdate
                                                        FROM v_price_timeseries v
                                                        WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate
                                                        = '{}'
                                                        ORDER BY v.pricingdate DESC
                                                        LIMIT 1)
                                                                        AS volatility_sample_end,
                                      (SELECT stddev_samp(t.adjret) * sqrt(252) FROM (SELECT pricingdate, ((v.divadjprice 
                                      - lag(v.divadjprice, '-1'::integer) OVER (ORDER BY v.pricingdate DESC)) /
                 lag(v.divadjprice,'-1'::integer) OVER (ORDER BY v.pricingdate DESC)) as adjret FROM v_price_timeseries v
                WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate >= '{}' AND v.pricingdate <= '{}') t) as 
                volatility
                                                       FROM v2mv_sbt_company psc where psc.exchangesymbol = ANY (ARRAY [
                                                       'NYSE', 'AMEX', 'ARCA', 'NasdaqGS',
                'NasdaqGM',
                                                                                    'NasdaqCM', 'NasdaqCS'])
                                                                                    AND psc.is_primary_exchange = TRUE;
                            """.format(self._start_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                                       self._end_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                                       self._start_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                                       self._end_date.strftime('%Y-%m-%d') + " 00:00:00.000000")
                self._vol_data = pd.read_sql(sql, self._snp_engine)
                self.mergeddata = pd.merge(left=self._data, right=self._vol_data, left_on='companyid', right_on='companyid')
                self.results = pd.DataFrame(columns=['tickersymbol', 'exchangesymbol', 'dd', 'pd', 'tradingitemid'])
            else:
                self.rf_rate = pd.read_sql("SELECT * FROM timeseries_external_data WHERE composite_pk_id = 'DGS5:FRED'",
                                           self._pg_df_engine).sort_values('timestamp').iloc[-1]['value']
                self._data = pd.read_sql('SELECT * FROM v_mertondata', self._snp_engine)
                sql = """
                SELECT companyid, (SELECT v.pricingdate
                                                FROM v_snapshot_volatility v
                                                WHERE (v.tradingitemid = psc.tradingitemid)
                                                ORDER BY v.pricingdate
                                                LIMIT 1)                                                                  
                                                     AS volatility_sample_start,
                                               (SELECT v.pricingdate
                                                FROM v_snapshot_volatility v
                                                WHERE (v.tradingitemid = psc.tradingitemid)
                                                ORDER BY v.pricingdate DESC
                                                LIMIT 1)                                                                  
                                                     AS volatility_sample_end,
                                               (SELECT count((v.priceclose * v.adjustmentfactor))
                                                       OVER (ORDER BY v.pricingdate) AS count
                                                FROM v_snapshot_volatility v
                                                WHERE (v.tradingitemid = psc.tradingitemid)
                                                ORDER BY v.pricingdate DESC
                                                LIMIT 1)                                                                  
                                                     AS volatility_sample_days,
                                               (SELECT (((((((t1.res * 0.5) + (t2.res * 0.3)) + (t3.res * 0.2)))::double 
                                               precision *
                                                          sqrt((252)::double precision)) * (2)::double precision) /
                                                        (3)::double precision) AS volatility
                                                FROM (((SELECT 1     AS id,
                                                               x.std AS res
                                                        FROM (SELECT t.pricingdate,
                                                                     stddev_samp(t.adj_return)
                                                                     OVER (ORDER BY t.pricingdate ROWS BETWEEN 756 
                                                                     PRECEDING AND CURRENT ROW) AS std
                                                              FROM (SELECT v.pricingdate,
                                                                           ((v.adj_price_close -
                                                                             lag(v.adj_price_close, '-1'::integer)
                                                                             OVER (ORDER BY v.pricingdate DESC)) /
                                                                            lag(v.adj_price_close, '-1'::integer)
                                                                            OVER (ORDER BY v.pricingdate DESC)) AS 
                                                                            adj_return
                                                                    FROM v_snapshot_volatility v
                                                                    WHERE (v.tradingitemid = psc.tradingitemid)) t) x
                                                        ORDER BY x.pricingdate DESC
                                                        LIMIT 1) t1
                                                    JOIN (SELECT 1         AS id,
                                                                 x.std_252 AS res
                                                          FROM (SELECT t.pricingdate,
                                                                       stddev_samp(t.adj_return)
                                                                       OVER (ORDER BY t.pricingdate ROWS BETWEEN 756 
                                                                       PRECEDING AND CURRENT ROW) AS std_252
                                                                FROM (SELECT v.pricingdate,
                                                                             ((v.adj_price_close -
                                                                               lag(v.adj_price_close, '-1'::integer)
                                                                               OVER (ORDER BY v.pricingdate DESC)) /
                                                                              lag(v.adj_price_close, '-1'::integer)
                                                                              OVER (ORDER BY v.pricingdate DESC)) AS 
                                                                              adj_return
                                                                      FROM v_snapshot_volatility v
                                                                      WHERE (v.tradingitemid = psc.tradingitemid)) t) x
                                                          ORDER BY x.pricingdate
                                                              OFFSET 252
                                                          LIMIT 1) t2 ON ((t2.id = t1.id)))
                                                         JOIN (SELECT 1         AS id,
                                                                      x.std_504 AS res
                                                               FROM (SELECT t.pricingdate,
                                                                            stddev_samp(t.adj_return)
                                                                            OVER (ORDER BY t.pricingdate ROWS BETWEEN 756 
                                                                            PRECEDING AND CURRENT ROW) AS std_504
                                                                     FROM (SELECT v.pricingdate,
                                                                                  ((v.adj_price_close -
                                                                                    lag(v.adj_price_close, '-1'::integer)
                                                                                    OVER (ORDER BY v.pricingdate DESC)) /
                                                                                   lag(v.adj_price_close, '-1'::integer)
                                                                                   OVER (ORDER BY v.pricingdate DESC)) AS 
                                                                                   adj_return
                                                                           FROM v_snapshot_volatility v
                                                                           WHERE (v.tradingitemid = psc.tradingitemid)) t) x
                                                               ORDER BY x.pricingdate
                                                                   OFFSET 504
                                                               LIMIT 1) t3
                                                              ON ((t3.id = t1.id))))                                      
                                                                   AS volatility
        FROM v2mv_sbt_company psc where psc.exchangesymbol = ANY (ARRAY ['NYSE', 'AMEX', 'ARCA', 'NasdaqGS', 'NasdaqGM', 
                                                                            'NasdaqCM', 'NasdaqCS']) 
                                                                            AND psc.is_primary_exchange = TRUE;
                """
                self._vol_data = pd.read_sql(sql, self._snp_engine)
                self.mergeddata = pd.merge(left=self._data, right=self._vol_data, left_on='companyid', right_on='companyid')
                self.results = pd.DataFrame(columns=['tickersymbol', 'exchangesymbol', 'dd', 'pd', 'tradingitemid'])
            # self._logger.info()

    def update_data(self, start_date):
        self._start_date = start_date - relativedelta(years=1)
        self._end_date = start_date
        self.rf_rate = pd.read_sql("SELECT * FROM timeseries_external_data WHERE composite_pk_id = 'DGS5:FRED'",
                                   self._pg_df_engine)
        try:
            self.rf_rate = self.rf_rate[self.rf_rate['timestamp'] == (self._end_date + relativedelta(days=1)).strftime(
                "%Y-%m-%d") + " 00:00:00"]['value'].iloc[0]
        except IndexError:
            try:
                self.rf_rate = self.rf_rate[self.rf_rate['timestamp'] == (self._end_date + relativedelta(days=2)).strftime(
                    "%Y-%m-%d") + " 00:00:00"]['value'].iloc[0]
            except IndexError:
                self.rf_rate = \
                self.rf_rate[self.rf_rate['timestamp'] == (self._end_date + relativedelta(days=3)).strftime(
                    "%Y-%m-%d") + " 00:00:00"]['value'].iloc[0]

        sql = """
                   SELECT s.tickersymbol,
       s.companyname,
       s.companyid,
       s.currentliabilities,
       s.ltdebt,
       s.ltliabilities,
       s.sharesout,
       s.exchangesymbol,
       s.gicsgroup,
       s.tradingitemid,
       s.filingdate,
       s.mktcap
FROM (SELECT t1.tickersymbol,
             t1.companyname,
             t1.companyid,
             t1.exchangesymbol,
             t1.gicsgroup,
             t1.tradingitemid,
             t1.filingdate,
             sum(
                     CASE
                         WHEN (t1.dataitemid = 1009) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS currentliabilities,
             sum(
                     CASE
                         WHEN (t1.dataitemid = 1014) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS ltliabilities,
             sum(
                     CASE
                         WHEN (t1.dataitemid = 1072) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS sharesout,
             sum(
                     CASE
                         WHEN (t1.dataitemid = 1193) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS ltdebt,
             sum(
                     CASE
                         WHEN (t1.dataitemid = 100010) THEN t1.dataitemvalue
                         ELSE NULL::numeric
                         END) AS mktcap
      FROM (SELECT mv.companyname,
                   mv.companyid,
                   mv.tickersymbol,
                   fd.dataitemid,
                   fd.dataitemvalue,
                   mv.exchangesymbol,
                   mv.gicsgroup,
                   mv.tradingitemid,
                   mmd.filingdate
            FROM (((((v2mv_sbt_company mv
                JOIN merton_model_backtest({}) mmd ON mmd.companyid = mv.companyid
                JOIN ciqfinancialdata fd ON fd.financialperiodid = mmd.financialperiodid)))
                ))
            WHERE ((fd.dataitemid = ANY (ARRAY [1072, 1009, 1193, 1014, 100010])) AND (mv.is_primary_exchange = true))) t1
      GROUP BY t1.companyname, t1.tickersymbol, t1.companyid, t1.exchangesymbol, t1.gicsgroup, t1.filingdate,
               t1.tradingitemid) s;
                    """.format(self._end_date.year)
        self._data = pd.read_sql(sql, self._snp_engine)
        sql = """
                    SELECT companyid, (SELECT v.pricingdate
                                                FROM v_price_timeseries v
                                                WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate
                                                = '{}'
                                                ORDER BY v.pricingdate
                                                LIMIT 1)
                                                                AS volatility_sample_start,
                                               (SELECT v.pricingdate
                                                FROM v_price_timeseries v
                                                WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate
                                                = '{}'
                                                ORDER BY v.pricingdate DESC
                                                LIMIT 1)
                                                                AS volatility_sample_end,
        				      (SELECT stddev_samp(t.adjret) * sqrt(252) FROM (SELECT pricingdate, ((v.divadjprice - 
        				      lag(v.divadjprice, '-1'::integer) OVER (ORDER BY v.pricingdate DESC)) /
         lag(v.divadjprice,'-1'::integer) OVER (ORDER BY v.pricingdate DESC)) as adjret FROM v_price_timeseries v
        WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate >= '{}' AND v.pricingdate <= '{}') t) as 
        volatility
                                               FROM v2mv_sbt_company psc where psc.exchangesymbol = ANY (ARRAY [
                                               'NYSE', 'AMEX', 'ARCA', 'NasdaqGS',
        'NasdaqGM',
                                                                            'NasdaqCM', 'NasdaqCS'])
                                                                            AND psc.is_primary_exchange = TRUE;
                    """.format(self._start_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                               self._end_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                               self._start_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                               self._end_date.strftime('%Y-%m-%d') + " 00:00:00.000000")
        self._vol_data = pd.read_sql(sql, self._snp_engine)
        self.mergeddata = pd.merge(left=self._data, right=self._vol_data, left_on='companyid', right_on='companyid')
        self.results = pd.DataFrame(columns=['tickersymbol', 'exchangesymbol', 'dd', 'pd', 'tradingitemid'])

    def quarterly_check(self, start_date):
        _start_date = start_date - relativedelta(years=1)
        _end_date = start_date
        self.rf_rate = pd.read_sql("SELECT * FROM timeseries_external_data WHERE composite_pk_id = 'DGS5:FRED' "
                                   "AND timestamp <= '{}'".format(_end_date), self._pg_df_engine)
        self.rf_rate = self.rf_rate.sort_values('timestamp')['value'].iloc[-1]
        # try:
        #     self.rf_rate = self.rf_rate[self.rf_rate['timestamp'] == (_end_date + relativedelta(days=1)).strftime(
        #         "%Y-%m-%d") + " 00:00:00"]['value'].iloc[0]
        # except IndexError:
        #     try:
        #         self.rf_rate = \
        #         self.rf_rate[self.rf_rate['timestamp'] == (_end_date + relativedelta(days=2)).strftime(
        #             "%Y-%m-%d") + " 00:00:00"]['value'].iloc[0]
        #     except IndexError:
        #         self.rf_rate = \
        #             self.rf_rate[self.rf_rate['timestamp'] == (_end_date + relativedelta(days=3)).strftime(
        #                 "%Y-%m-%d") + " 00:00:00"]['value'].iloc[0]

        sql = """
                           SELECT s.tickersymbol,
               s.companyname,
               s.companyid,
               s.currentliabilities,
               s.ltdebt,
               s.ltliabilities,
               s.sharesout,
               s.exchangesymbol,
               s.gicsgroup,
               s.tradingitemid,
               s.filingdate,
               s.mktcap
        FROM (SELECT t1.tickersymbol,
                     t1.companyname,
                     t1.companyid,
                     t1.exchangesymbol,
                     t1.gicsgroup,
                     t1.tradingitemid,
                     t1.filingdate,
                     sum(
                             CASE
                                 WHEN (t1.dataitemid = 1009) THEN t1.dataitemvalue
                                 ELSE NULL::numeric
                                 END) AS currentliabilities,
                     sum(
                             CASE
                                 WHEN (t1.dataitemid = 1014) THEN t1.dataitemvalue
                                 ELSE NULL::numeric
                                 END) AS ltliabilities,
                     sum(
                             CASE
                                 WHEN (t1.dataitemid = 1072) THEN t1.dataitemvalue
                                 ELSE NULL::numeric
                                 END) AS sharesout,
                     sum(
                             CASE
                                 WHEN (t1.dataitemid = 1193) THEN t1.dataitemvalue
                                 ELSE NULL::numeric
                                 END) AS ltdebt,
                     sum(
                             CASE
                                 WHEN (t1.dataitemid = 100010) THEN t1.dataitemvalue
                                 ELSE NULL::numeric
                                 END) AS mktcap
              FROM (SELECT mv.companyname,
                           mv.companyid,
                           mv.tickersymbol,
                           fd.dataitemid,
                           fd.dataitemvalue,
                           mv.exchangesymbol,
                           mv.gicsgroup,
                           mv.tradingitemid,
                           mmd.filingdate
                    FROM (((((v2mv_sbt_company mv
                        JOIN merton_model_backtest({}) mmd ON mmd.companyid = mv.companyid
                        JOIN ciqfinancialdata fd ON fd.financialperiodid = mmd.financialperiodid)))
                        ))
                    WHERE ((fd.dataitemid = ANY (ARRAY [1072, 1009, 1193, 1014, 100010])) AND (mv.is_primary_exchange 
                    = true))) t1
              GROUP BY t1.companyname, t1.tickersymbol, t1.companyid, t1.exchangesymbol, t1.gicsgroup, t1.filingdate,
                       t1.tradingitemid) s;
                            """.format(_end_date.year)
        self._data = pd.read_sql(sql, self._snp_engine)
        sql = """
                            SELECT companyid, (SELECT v.pricingdate
                                                        FROM v_price_timeseries v
                                                        WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate
                                                        = '{}'
                                                        ORDER BY v.pricingdate
                                                        LIMIT 1)
                                                                        AS volatility_sample_start,
                                                       (SELECT v.pricingdate
                                                        FROM v_price_timeseries v
                                                        WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate
                                                        = '{}'
                                                        ORDER BY v.pricingdate DESC
                                                        LIMIT 1)
                                                                        AS volatility_sample_end,
                				      (SELECT stddev_samp(t.adjret) * sqrt(252) FROM (SELECT pricingdate, 
                				      ((v.divadjprice - 
                				      lag(v.divadjprice, '-1'::integer) OVER (ORDER BY v.pricingdate DESC)) /
                 lag(v.divadjprice,'-1'::integer) OVER (ORDER BY v.pricingdate DESC)) as adjret FROM 
                 v_price_timeseries v
                WHERE (v.tradingitemid = psc.tradingitemid) AND v.pricingdate >= '{}' AND v.pricingdate <= '{}') t) as 
                volatility
                                                       FROM v2mv_sbt_company psc where psc.exchangesymbol = ANY (ARRAY [
                                                       'NYSE', 'AMEX', 'ARCA', 'NasdaqGS',
                'NasdaqGM',
                                                                                    'NasdaqCM', 'NasdaqCS'])
                                                                                    AND psc.is_primary_exchange = TRUE;
                            """.format(_start_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                                       _end_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                                       _start_date.strftime('%Y-%m-%d') + " 00:00:00.000000",
                                       _end_date.strftime('%Y-%m-%d') + " 00:00:00.000000")
        self._vol_data = pd.read_sql(sql, self._snp_engine)
        self.mergeddata = pd.merge(left=self._data, right=self._vol_data, left_on='companyid', right_on='companyid')
        self.results = pd.DataFrame(columns=['tickersymbol', 'exchangesymbol', 'dd', 'pd', 'tradingitemid'])

    @staticmethod
    def _create_pg_engine(config):
        host = config['host']
        credentials = config['credentials']
        user = config['user']
        dbname = config['database']
        # dialect+driver://username:password@host:port/database
        return sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=user, password=credentials,
                host=host, db=dbname
            )
        )

    def run(self):
        # self._data = self._data[self._data['exchangesymbol'].isin(['NYSE', 'AMEX', 'NasdaqGS', 'NasdaqGM', 'NasdaqCM',
        #                                                            'NasdaqCS'])]
        for i, row in enumerate(self.mergeddata.iterrows()):
            row = row[1]
            self._logger.info(str(row['tickersymbol']) + ":" + str(row['exchangesymbol']))
            try:
                V_equity = row['mktcap']
            except KeyError:
                V_equity = row['marketcap']
            default_point = row['currentliabilities'] + row['ltliabilities'] / 2
            rf_rate = self.rf_rate / 100
            sigma_equity = row['volatility']
            T = 1

            # One dimension estimation
            def equation(x):
                d1 = (np.log(x[0] / default_point) + (rf_rate + x[1] ** 2 / 2) * T) / (x[1] * np.sqrt(T))
                d2 = d1 - x[1] * np.sqrt(T)
                res1 = x[0] * norm.cdf(d1) - np.exp(-rf_rate * T) * default_point * norm.cdf(d2) - V_equity
                res2 = x[0] * norm.cdf(d1) * x[1] - V_equity * sigma_equity
                return res1 ** 2 + res2 ** 2

            result = minimize(equation, [V_equity, sigma_equity])

            d1 = (np.log(V_equity / default_point) + (rf_rate + sigma_equity ** 2 / 2) * T) / (
                sigma_equity * np.sqrt(T))
            d2 = d1 - sigma_equity * np.sqrt(T)
            Va, siga = symbols('Va, siga')
            eq1 = Eq((Va / V_equity) * norm.cdf(d1) * sigma_equity - siga, 0)
            eq2 = Eq(Va * norm.cdf(d1) - np.exp(-rf_rate * T) * default_point * norm.cdf(d2) - V_equity, 0)
            sol_dict = solve((eq1, eq2), (Va, siga))
            # self._logger.info(sol_dict)

            # self._logger.info(f'x = {sol_dict[Va]}')
            # self._logger.info(f'y = {sol_dict[siga]}')

            V_asset = list(result['x'])[0]
            sigma_asset = list(result['x'])[1]
            # self._logger.info('\nThe asset of the firm is %10.3f' % V_asset)
            # self._logger.info('\nThe volatility of the firm asset is %10.5f' % sigma_asset)
            if row['gicsgroup'] == 'Banks':
                pacr = .08
            else:
                pacr = 0

            lambd = 1 / (1 - pacr)
            if sol_dict:
                dd = (np.log(float(sol_dict[Va]) / (lambd * default_point)) + (
                    rf_rate - .5 * math.pow(float(sol_dict[siga]), 2)) * T) / (
                         float(sol_dict[siga]) * np.sqrt(T))
            else:
                dd = (np.log(V_asset / (lambd * default_point)) + (rf_rate - .5 * math.pow(sigma_asset, 2)) * T) / (
                    sigma_asset * np.sqrt(T))
            # self._logger.info(dd)
            prob_default = norm.cdf(-dd)
            self.results.loc[i] = {'tickersymbol': row['tickersymbol'], 'exchangesymbol': row['exchangesymbol'],
                                   'tradingitemid': row['tradingitemid'], 'dd': dd, 'pd': prob_default}
        self.results = self.results.sort_values('dd')
        # self._logger.info()
        # return self.results

    def get_start(self, tradingitemid):
        try:
            sql_start = """
                        SELECT * FROM v_price_timeseries WHERE pricingdate >= '{}' AND tradingitemid = '{}';
                        """
            return pd.read_sql(sql_start.format(self._end_date - datetime.timedelta(1), tradingitemid),
                               self._snp_engine).sort_values('pricingdate')['divadjprice'].iloc[0]
        except IndexError:
            sql_start = """
                        SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}';
                        """
            return pd.read_sql(sql_start.format(tradingitemid),
                               self._snp_engine).sort_values('pricingdate')['divadjprice'].iloc[0]

    def get_end(self, tradingitemid, end_date = None):
        if end_date is None:
            sql_end = """
                        SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}' AND pricingdate >= '{}';
                        """
            try:
                return pd.read_sql(sql_end.format(tradingitemid, self._end_date + relativedelta(years=5)),
                                   self._snp_engine).sort_values('pricingdate')['divadjprice'].iloc[0]
            except:
                self._logger.info("not enough stock price data", tradingitemid)
                sql_end = """SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}' AND pricingdate >= '{}';"""
                return pd.read_sql(sql_end.format(tradingitemid, self._end_date),
                            self._snp_engine).sort_values('pricingdate')['divadjprice'].iloc[-1]
        else:
            sql_end = """
                        SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}' AND pricingdate >= '{}';
                        """
            try:
                return pd.read_sql(sql_end.format(tradingitemid, end_date),
                                   self._snp_engine).sort_values('pricingdate')['divadjprice'].iloc[0]
            except:
                self._logger.info("not enough stock price data", tradingitemid)
                sql_end = """SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}' AND pricingdate >= '{}';"""
                return pd.read_sql(sql_end.format(tradingitemid, end_date),
                                   self._snp_engine).sort_values('pricingdate')['divadjprice'].iloc[-1]

    def backtest(self):
        spy_tradingitemid = 6179710
        spy_start = self.get_start(spy_tradingitemid)
        spy_end = self.get_end(spy_tradingitemid)
        portfolio_start_bal = 100000
        spy_shares = portfolio_start_bal / spy_start
        spy_end_bal = spy_shares * spy_end

        # years = datetime.datetime.now().year - self._end_date.year
        # if years == 0:
        #     years = 1
        portfolio_end_bal = 0
        while self._end_date.year <= datetime.datetime.now().year:
            # if i % 5 == 0 or self._end_date.year == datetime.datetime.now().year:
            self.run()
            self.results = self.results.loc[~np.isnan(self.results['dd'])]
            buy = self.results.iloc[-41:-1]
            short = self.results.iloc[0:20]

            quarterly_updates = {}
            # for i in range(5*4):
            #     self.quarterly_check(self._end_date + relativedelta(months=3*i))
            #     self.run()
            #     self.results = self.results.loc[~np.isnan(self.results['dd'])]
            #     q_buy = self.results.iloc[-41:-1]['tickersymbol']
            #     for stock in buy.iterrows():
            #         stock = stock[1]
            #         if stock['tickersymbol'] not in q_buy.to_list():
            #             quarterly_updates[stock['tickersymbol']] = self._end_date + relativedelta(months=3*i)

            # some companies (example FHB) have financial data back far enough but IPO/spinoff didnt occur until much later
            # need to account for that and skip those stocks when backtesting
            buy_to_skip = []
            for stock in buy.iterrows():
                stock = stock[1]
                sql_end = """SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}' AND pricingdate <= '{}'; """
                if len(pd.read_sql(sql_end.format(stock['tradingitemid'], self._end_date), self._snp_engine)) == 0:
                    buy_to_skip.append(stock['tickersymbol'])
                # sql_end = """SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}' AND pricingdate = '{}'; """
                # if len(pd.read_sql(sql_end.format(stock['tradingitemid'], self._end_date + relativedelta(years=5) + relativedelta(days=1)), self._snp_engine)) == 0:
                #     buy_to_skip.append(stock['tickersymbol'])

            portfolio_per_stock = portfolio_start_bal / (len(buy)-len(buy_to_skip))
            for stock in buy.iterrows():
                stock = stock[1]
                if stock['tickersymbol'] not in buy_to_skip:
                    stock_trading_id = stock['tradingitemid']
                    stock_start = self.get_start(stock_trading_id)
                    try:
                        end_date = quarterly_updates[stock['tickersymbol']]
                        stock_end = self.get_end(stock_trading_id, end_date)
                        self._logger.info(stock['tickersymbol'] + ' sold early when it fell out of top 40 on ', end_date)
                    except KeyError:
                        stock_end = self.get_end(stock_trading_id)
                    stock_shares = portfolio_per_stock / stock_start
                    stock_end = stock_shares * stock_end
                    self._logger.info(stock['tickersymbol'], stock['exchangesymbol'], stock_end, stock['dd'])
                    portfolio_end_bal = portfolio_end_bal + stock_end
            self._logger.info("Merton:",str(self._end_date) + " - " + str(self._end_date + relativedelta(years=5)), portfolio_end_bal)
            spy_period_end = spy_shares * self.get_end(spy_tradingitemid)
            self._logger.info("SPY:",str(self._end_date) + " - " + str(self._end_date + relativedelta(years=5)), spy_period_end)
            portfolio_start_bal = portfolio_end_bal
            if (self._end_date + relativedelta(years=5)).year > datetime.datetime.now().year:
                break
            else:
                self.update_data(self._end_date + relativedelta(years=5))
                # short_to_skip = []
                # for stock in short.iterrows():
                #     stock = stock[1]
                #     sql_end = """
                #                                 SELECT * FROM v_price_timeseries WHERE tradingitemid = '{}' AND pricingdate
                #                                 <= '{}';
                #                                 """
                #     if len(pd.read_sql(sql_end.format(stock['tradingitemid'], self._end_date), self._snp_engine)) == 0:
                #         short_to_skip.append(stock['tickersymbol'])

                # short_portfolio_end_bal = 0
                # portfolio_per_stock = portfolio_start_bal / (len(short) - len(short_to_skip))
                # for stock in short.iterrows():
                #     stock = stock[1]
                #     if stock['tickersymbol'] not in short_to_skip:
                #         stock_trading_id = stock['tradingitemid']
                #         stock_start = self.get_start(stock_trading_id)
                #         stock_end = self.get_end(stock_trading_id)
                #         stock_shares = portfolio_per_stock / stock_start
                #         stock_end = stock_shares * stock_end
                #         self._logger.info(stock['tickersymbol'], stock_end)
                #         short_portfolio_end_bal = short_portfolio_end_bal + stock_end
                #
                # portfolio_end_bal = portfolio_end_bal + (portfolio_start_bal - short_portfolio_end_bal)
        self._logger.info(portfolio_end_bal)
        self._logger.info(spy_end_bal)
        upside = (portfolio_end_bal - spy_end_bal) / spy_end_bal
        self._logger.info(upside)

    def create_model_stats_table(self, model_id=None, data=None):
        self._logger.info(
            'MERTON: CREATING STATS TABLE IN PG...')
        RESULT_TABLENAME_PREFIX = "development_sbt_models"
        tic = datetime.datetime.now()
        model_id = "".join(model_id.lower().split("_"))
        # # # rating stats table
        TABLE_NAME = "{}_{}_rating_stats".format(RESULT_TABLENAME_PREFIX,
                                                 model_id
                                                 )
        # get the min/max for the model's rank (:= total number of points),
        # which is the most important result for CE
        df_stats = data.groupby(by='rating') \
            .agg({"score": [min, max, "count"]})
        # rename columns
        df_stats.columns = ['minRank', 'maxRank', 'total']
        # save rating stats
        for env in ENVS_TO_UPDATE:
            df_stats.to_sql(TABLE_NAME,
                            self.db_to_update.get(env.upper()),
                            if_exists='replace',
                            index_label='rating'
                            )
        # # rank stats table
        TABLE_NAME = "{}_{}_score_stats".format(RESULT_TABLENAME_PREFIX,
                                                model_id
                                                )
        model_stat_df = data.agg({'score': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minscore', 'maxscore', 'total']
        # stats per model (total within each rank bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(norm.cdf(-data['score']), [-1000, -999, 0, .25, .50, .75, 1])
        )['score'].count()).T
        # rename columns
        # model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        model_stat_score_bin_df.columns = ['b0', 'b5', 'b4', 'b3', 'b2', 'b1']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save rank stats
        for env in ENVS_TO_UPDATE:
            model_score_stat_df.to_sql(TABLE_NAME,
                                       self.db_to_update.get(env.upper()),
                                       if_exists='replace'
                                       )
        self._logger.info(
            'MERTON: MERTON TABLE CREATED IN Dt = {}'.format(
                datetime.datetime.now() - tic)
        )


    def data_load(self):
        self.run()
        self.results = self.results.loc[~np.isnan(self.results['dd'])]
        self.results.loc[self.results['pd'] >= 0, 'rating'] = 'AAA'
        self.results.loc[self.results['pd'] == 1, 'rating'] = 'D'
        self.results.loc[(self.results['pd'] >= 0.99) & (self.results['pd'] < 1), 'rating'] = 'C'
        self.results.loc[(self.results['pd'] >= 0.98) & (self.results['pd'] < .99), 'rating'] = 'CC'
        self.results.loc[(self.results['pd'] >= 0.95) & (self.results['pd'] < .98), 'rating'] = 'CCC'
        self.results.loc[(self.results['pd'] >= 0.9) & (self.results['pd'] < .95), 'rating'] = 'B-'
        self.results.loc[(self.results['pd'] >= 0.85) & (self.results['pd'] < .9), 'rating'] = 'B'
        self.results.loc[(self.results['pd'] >= 0.8) & (self.results['pd'] < .85), 'rating'] = 'B+'
        self.results.loc[(self.results['pd'] >= 0.6) & (self.results['pd'] < .8), 'rating'] = 'BB-'
        self.results.loc[(self.results['pd'] >= 0.4) & (self.results['pd'] < .6), 'rating'] = 'BB'
        self.results.loc[(self.results['pd'] >= 0.3) & (self.results['pd'] < .4), 'rating'] = 'BB+'
        self.results.loc[(self.results['pd'] >= 0.2) & (self.results['pd'] < .3), 'rating'] = 'BBB-'
        self.results.loc[(self.results['pd'] >= 0.1) & (self.results['pd'] < .2), 'rating'] = 'BBB'
        self.results.loc[(self.results['pd'] >= 0.05) & (self.results['pd'] < .1), 'rating'] = 'BBB+'
        self.results.loc[(self.results['pd'] >= 0.01) & (self.results['pd'] < .05), 'rating'] = 'A-'
        self.results.loc[(self.results['pd'] >= 0.001) & (self.results['pd'] < .01), 'rating'] = 'A'
        self.results.loc[(self.results['pd'] >= 0.0001) & (self.results['pd'] < .001), 'rating'] = 'A+'
        self.results.loc[(self.results['pd'] >= 0.00001) & (self.results['pd'] < .0001), 'rating'] = 'AA-'
        self.results.loc[(self.results['pd'] >= 0.000001) & (self.results['pd'] < .00001), 'rating'] = 'AA'
        self.results.loc[(self.results['pd'] > 0) & (self.results['pd'] < .000001), 'rating'] = 'AA+'
        self.results.loc[self.results['exchangesymbol'].isin(['NasdaqGS', 'NasdaqGM']), 'exchangesymbol'] = 'NSDQ'
        self.results.loc[self.results['exchangesymbol'] == 'NasdaqCM', 'exchangesymbol'] = 'NSDQCM'
        self.results.loc[self.results['exchangesymbol'] == 'ARCA', 'exchangesymbol'] = 'NYSEARCA'
        self.results['score'] = self.results['dd']
        self.results['composite_pk_id'] = self.results['tickersymbol'] + ':' + self.results['exchangesymbol']
        self.results = self.results.sort_values('dd')
        self.results.reset_index(inplace=True, drop=True)
        self.results['rank'] = self.results.index/(len(self.results.index)-1)
        self.results['model'] = ""
        count = 0
        for row in self.results.iterrows():
            row = row[1]
            self.results.at[count, 'model'] = {
                'model': {
                    "composite_pk_id": row["composite_pk_id"],
                    'date_calculated': datetime.datetime.now().strftime('%Y-%m-%d'),
                    "guid": str(row["tradingitemid"]),
                    'score': row['dd'],
                    'value': row['dd'],
                    'rank': row['rank'],
                    'rating': row['rating'],
                    'raw_data': {},
                    'calculated_data': {},
                }
            }
            count = count + 1
        to_db = self.results[['composite_pk_id', 'model', 'rank', 'rating', 'score']]
        to_db = to_db.sort_values('rank', ascending=False)
        self._logger.info(" DONE.")

        tic = datetime.datetime.now()
        for env in ENVS_TO_UPDATE:
            to_db.to_sql(
                'development_sbt_models_merton',
                self.db_to_update.get(env.upper()),
                if_exists='replace',
                index=False,
                dtype={
                    'model': JSON,
                    'score': FLOAT,
                    'rank': FLOAT,
                    'rating': VARCHAR,
                    'composite_pk_id': VARCHAR
                })
            tac = datetime.datetime.now()

            self._logger.info(" {}: DATA SAVED IN Dt={}.".format(
                env.upper(), tac - tic)
            )

        # create stats table
        self.create_model_stats_table('MERTON', to_db)


if __name__ == '__main__':
    # m = MertonModel(skip_load=True)
    # data = pd.read_sql('SELECT * FROM development_sbt_models_merton', m._pg_df_engine)
    # m.create_model_stats_table(model_id="MERTON", data=data)
    m = MertonModel()
    m.data_load()

    # m = MertonModel(back_test=True, start_date='2005-01-03')
    # m.backtest()
