import datetime
import math
import model_accessor
import numbers
import json
from collections import OrderedDict
from enum import Enum
from builtins import list
from fs_accessor import FinancialAccessor
from fs_accessor import FinancialVendors
from intrinio_api import IntrinioApi
from sbt_common import SbtCommon
from sbt_common import DecimalStringEncoder

class FinancialDataType(Enum):
  """
      FinancialDataType is an enumeration used to help centralize
      the various financial data estypes into one class/enum.
  """
  ANNUAL_REVENUE = 'annual_revenue'
  QUARTERLY_REVENUE = 'quarterly_revenue'
  QUARTERLY_NET_INCOME = 'quarterly_net_income'
  ANNUAL_NET_INCOME = 'annual_net_income'
  QUARTERLY_ASSETS = 'quarterly_assets'
  ANNUAL_ASSETS = 'annual_assets'
  QUARTERLY_FCF = 'quarterly_fcf'
  ANNUAL_FCF = 'annual_fcf'
  QUARTERLY_CAPITAL = 'quarterly_capital'
  ANNUAL_CAPITAL = 'annual_capital'
  RETURNED_CAPITAL = 'returned_capital'    
  FIVE_YEAR_REVENUE_GROWTH = 'five_year_revenue_growth'
  TWENTY_QUARTER_ASSET_AVERAGE = 'twenty_quarter_asset_average'
  TWENTY_QUARTER_FCF_REVENUE_AVERAGE = 'fcf_revenue_average'
  FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE = 'sh_return_revenue_average'
  CAPITAL_EFFICICENCY_RANK_SCORE = 'capital_effieciency_rank_score'
  CAPITAL_EFFICICENCY_SCORE_RANK = 'capital_effieciency_score_rank'

class FinancialData () :
  """
    The FinancialData class contains all the properties and methods specific to
    a single financial data element within the model package.
  """
  def __init__(self, name, value, timeframe, description='', 
               calculated=False, rank = None):
    """
      Constructor method used to initialize the class
    """
    self.name = name
    self.value = value
    self.timeframe = timeframe
    self.description = description
    self.calculated = calculated
    self.rank = rank

  def get_timeframe(self):
    """
        Helper method to return the timeframe associated with this 
        specific financial data instance
    """
    return self.timeframe

  def get_name(self):
    """
        Helper method to return the name associated with this specific 
        financial data instance
    """
    return self.name

  def get_value(self):
    """
        Helper method to return the value associated with this specific 
        financial data instance
    """
    return self.value

  def get_rank (self):
    """
        Helper method to return the rank associated with this specific 
        financial data instance
    """
    return self.rank

  def set_rank (self, rank):
    """
        Helper method to set the rank associated with this specific 
        financial data instance
    """
    self.rank = rank


class CompanyRepository :
  sbt_zfmanager = 'SBT_ZFMANAGER'
  sbt_zfmanager_intrinio = 'SBT_ZFMANAGER_INTRINIO'  
  sbt_intrionio = 'SBT_INTRINIO'  
  
  def __init__(self):
    self._sbtcommon = SbtCommon()
    self._logger = self._sbtcommon.get_global_logger()
    self.datasource = self.sbt_zfmanager_intrinio
  
  def populated_company (self, company):  
    self._populate_annual_revenue(company)
    self._populate_quarterly_revenue(company)
    self._populate_quarterly_net_income(company)
    self._populate_quarterly_assets(company)
    self._populate_free_cash_flow(company)
    self._populate_capital(company)
    
  def get_populated_company (self, ticker):
    company = Company(ticker,dict())
    
    self.populated_company(company)
    
    return company

  def create_company_dictionary (self, company):
    selected_company = {}
    if company is not None :
      selected_company['ticker'] = company.get_ticker()
      selected_company['financial_data'] = []
      selected_company['value'] = company.value
      selected_company['rank'] = company.rank
      financial_data = []
      for v in list(company.get_financial_data().values()) :
        if isinstance(v,list) :
          for fd in v :
            financial_data.append(fd.__dict__)
        else :
          financial_data.append(v.__dict__)
  
  
      selected_company['financial_data'] = financial_data

    return selected_company
    
  def _populate_capital (self, company):
    data_list = list()

    if self.datasource == self.sbt_zfmanager :
      fundamentals = self._get_sbt_fundamentals(company.get_ticker(), 
                                                'BALANCE', 'a')
  
      for year in range(2011, 2017) :
        date = str(year)
        year_data = fundamentals[date]
        ret_data = year_data[date]
  
        capital = self._get_sbt_fundamentals_returned_capital(ret_data)
  
        if capital > 0 :
          data_list.append(FinancialData(
            FinancialDataType.RETURNED_CAPITAL.value, capital, date[:4], 
            description='Returned Capital'))

    elif self.datasource == self.sbt_zfmanager_intrinio :
      json_data = self._get_sbt_fundamentals_intrionio (company.get_ticker(), 
                                                        'returnedcapital', 
                                                        'a')
      for ret_data in json_data :
        data_list.append(FinancialData(
                               FinancialDataType.RETURNED_CAPITAL.value, 
                               float(ret_data['value']), 
                               str(ret_data['fiscal_year']), 
                               description='Returned Capital'))
    
    else :
      json_data = self._get_sbt_intrionio (company.get_ticker(), 
                                           'totalcapital', 'FY')

      for ret_data in json_data :
        date = ret_data['date']
        data_list.append(FinancialData(
          FinancialDataType.RETURNED_CAPITAL.value, ret_data['value'], 
          date[:4], description='Returned Capital'))

    if len(data_list) > 0 :
      company.get_financial_data()[
        FinancialDataType.RETURNED_CAPITAL.value] = data_list

  def _populate_free_cash_flow (self, company):
    data_list = list()

    if self.datasource == self.sbt_zfmanager :
      fundamentals = self._get_sbt_fundamentals(company.get_ticker(), 'CASH', 
                                                'q')

      for year in range(2011, 2017) :
        self._populate_sbt_fundamentals_quarterly_fcf(year, fundamentals, 
                                                      data_list)

    elif self.datasource == self.sbt_zfmanager_intrinio :
      json_data = self._get_sbt_fundamentals_intrionio (company.get_ticker(), 
                                                        'freecashflow', 
                                                        'q')
      for ret_data in json_data :
        fiscal_period = ret_data['fiscal_period']        
        if len(fiscal_period) == 2 :
          data_list.append(FinancialData(FinancialDataType.QUARTERLY_FCF.value, 
                                 float(ret_data['value']), 
                                 fiscal_period + str(ret_data['fiscal_year']), 
                                 description='Free Cash Flow'))

    else :
      json_data = self._get_sbt_intrionio (company.get_ticker(), 
                                           'freecashflow', 'QTR')

      for ret_data in json_data :
        date = ret_data['date']
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_FCF.value, float(ret_data['value']), 
          self._get_quarter (date[5:7]) + date[:4], 
          description='Free Cash Flow'))

    if len(data_list) > 0 :
      company.get_financial_data()[
        FinancialDataType.QUARTERLY_FCF.value] = data_list


  def _populate_quarterly_assets (self, company):
    data_list = list()

    if self.datasource == self.sbt_zfmanager :
      fundamentals = self._get_sbt_fundamentals(company.get_ticker(), 
                                                'BALANCE', 'q')

      for year in range(2011, 2017) :
        self._populate_sbt_fundamentals_quarterly_assets(year, 
                                                         fundamentals, 
                                                         data_list)

    elif self.datasource == self.sbt_zfmanager_intrinio :
      json_data = self._get_sbt_fundamentals_intrionio (company.get_ticker(), 
                                                        'totalassets', 
                                                        'q')
      for ret_data in json_data :
        fiscal_period = ret_data['fiscal_period']
        if len(fiscal_period) == 2 :
          data_list.append(FinancialData(
                                 FinancialDataType.QUARTERLY_ASSETS.value, 
                                 float(ret_data['value']), 
                                 fiscal_period + str(ret_data['fiscal_year']), 
                                 description='Assets'))

    else :
      json_data = self._get_sbt_intrionio (company.get_ticker(), 
                                           'totalassets', 'q')

      for ret_data in json_data :
        date = ret_data['date']
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_ASSETS.value, ret_data['value'], 
          self._get_quarter (date[5:7]) + date[:4], description='Assets'))

    if len(data_list) > 0 :
      company.get_financial_data()[
        FinancialDataType.QUARTERLY_ASSETS.value] = data_list

  def _populate_quarterly_net_income (self, company):
    data_list = list()

    if self.datasource == self.sbt_zfmanager :
      fundamentals = self._get_sbt_fundamentals(company.get_ticker(), 
                                                'INCOME', 'q')

      for year in range(2011, 2017) :
        self._populate_sbt_fundamentals_quarterly_net_income(year, 
                                                             fundamentals, 
                                                             data_list)

    elif self.datasource == self.sbt_zfmanager_intrinio :
      json_data = self._get_sbt_fundamentals_intrionio (company.get_ticker(), 
                                                      'netincome', 'q')
      for ret_data in json_data :
        fiscal_period = ret_data['fiscal_period']
        if len(fiscal_period) == 2 :
          data_list.append(FinancialData(
                                 FinancialDataType.QUARTERLY_NET_INCOME.value, 
                                 float(ret_data['value']), 
                                 fiscal_period + str(ret_data['fiscal_year']), 
                                 description='Net Income'))

    else :
      json_data = self._get_sbt_intrionio (company.get_ticker(), 
                                           'netincome', 'QTR')

      for ret_data in json_data :
        date = ret_data['date']
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_NET_INCOME.value, ret_data['value'], 
          self._get_quarter (date[5:7]) + date[:4], description='Net Income'))

    if len(data_list) > 0 :
      company.get_financial_data()[
        FinancialDataType.QUARTERLY_NET_INCOME.value] = data_list

  def _populate_quarterly_revenue (self, company):
    data_list = list()

    if self.datasource == self.sbt_zfmanager :
      fundamentals = self._get_sbt_fundamentals(company.get_ticker(), 
                                                'INCOME', 'q')

      for year in range(2011, 2017) :
        self._populate_sbt_fundamentals_quarterly_revenue(year, 
                                                          fundamentals, 
                                                          data_list)

    elif self.datasource == self.sbt_zfmanager_intrinio :
      json_data = self._get_sbt_fundamentals_intrionio (company.get_ticker(), 
                                                        'totalrevenue', 'q')
      for ret_data in json_data :
        fiscal_period = ret_data['fiscal_period']
        if len(fiscal_period) == 2 :
          data_list.append(FinancialData(
                                  FinancialDataType.QUARTERLY_REVENUE.value, 
                                 float(ret_data['value']), 
                                 fiscal_period + str(ret_data['fiscal_year']), 
                                 description='Revenue'))  
    else :
      json_data = self._get_sbt_intrionio (company.get_ticker(), 
                                           'totalrevenue', 'QTR')

      for ret_data in json_data :
        date = ret_data['date']
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_REVENUE.value, ret_data['value'], 
          self._get_quarter (date[5:7]) + date[:4], description='Revenue'))

    if len(data_list) > 0 :
      company.get_financial_data()[
        FinancialDataType.QUARTERLY_REVENUE.value] = data_list

  def _populate_annual_revenue (self, company):
    data_list = list()

    if self.datasource == self.sbt_zfmanager :
      fundamentals = self._get_sbt_fundamentals(company.get_ticker(), 
                                                'INCOME', 'a')

      for year in range(2011, 2017) :
        date = str(year)
        year_data = fundamentals[date]
        ret_data = year_data[date]

        tot_rev = self._get_sbt_fundamentals_total_revenue(ret_data)
        if tot_rev is not None :
          data_list.append(FinancialData(
            FinancialDataType.ANNUAL_REVENUE.value, tot_rev, date[:4], 
            description='Revenue'))

    elif self.datasource == self.sbt_zfmanager_intrinio :
      json_data = self._get_sbt_fundamentals_intrionio (company.get_ticker(), 
                                                        'totalrevenue', 
                                                        'a')
      for ret_data in json_data :
        data_list.append(FinancialData(FinancialDataType.ANNUAL_REVENUE.value, 
                               float(ret_data['value']), 
                               str(ret_data['fiscal_year']), 
                               description='Revenue'))  
          
    else :
      json_data = self._get_sbt_intrionio (company.get_ticker(), 
                                           'totalrevenue', 'FY')

      for ret_data in json_data :
        date = ret_data['date']
        data_list.append(FinancialData(
          FinancialDataType.ANNUAL_REVENUE.value, ret_data['value'], date[:4], 
          description='Revenue'))

    if len(data_list) > 0 :
      company.get_financial_data()[
        FinancialDataType.ANNUAL_REVENUE.value] = data_list

  def _populate_sbt_fundamentals_quarterly_fcf (self, 
                                                year, 
                                                fundamentals, 
                                                data_list) :
    for quarter in range(1,5) :
      str_quarter = '0' + str(quarter)
      year_data = fundamentals[str(year)]
      ret_data = year_data[str(year) + str_quarter]

      if 'end_cash' in ret_data.keys() :
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_FCF.value, 
          float(ret_data['end_cash']), 'Q' + str(quarter) + str(year), 
          description='Free Cash Flow'))    

  def _populate_sbt_fundamentals_quarterly_assets (self, 
                                                   year, 
                                                   fundamentals, 
                                                   data_list) :
    for quarter in range(1,5) :
      str_quarter = '0' + str(quarter)
      year_data = fundamentals[str(year)]
      ret_data = year_data[str(year) + str_quarter]

      if 'tot_asset' in ret_data.keys() :
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_ASSETS.value, 
          float(ret_data['tot_asset']), 'Q' + str(quarter) + str(year), 
          description='Assets'))    

  def _populate_sbt_fundamentals_quarterly_net_income (self, 
                                                       year, 
                                                       fundamentals, 
                                                       data_list) :
    for quarter in range(1,5) :
      str_quarter = '0' + str(quarter)
      year_data = fundamentals[str(year)]
      ret_data = year_data[str(year) + str_quarter]

      if 'net_income_parent_comp' in ret_data.keys() :
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_NET_INCOME.value, 
          float(ret_data['net_income_parent_comp']), 
          'Q' + str(quarter) + str(year), description='Net Income'))    

  def _populate_sbt_fundamentals_quarterly_revenue (self, 
                                                    year, 
                                                    fundamentals, 
                                                    data_list):
    for quarter in range(1,5) :
      str_quarter = '0' + str(quarter)
      year_data = fundamentals[str(year)]
      ret_data = year_data[str(year) + str_quarter]
      tot_rev = self._get_sbt_fundamentals_total_revenue(ret_data)
      if tot_rev is not None :
        data_list.append(FinancialData(
          FinancialDataType.QUARTERLY_REVENUE.value, tot_rev, 
          'Q' + str(quarter) + str(year), description='Revenue'))     

  def _get_sbt_fundamentals_returned_capital (self, data):
    capital = 0
    if 'tot_asset' in data.keys() and \
    'tot_curr_liab' in data.keys() :
      tot_liab = float(0)
      if data['tot_curr_liab'] is None :
        self._logger.warn('Total Current Liability was None')
      else :
        tot_liab = float(data['tot_curr_liab'])
      capital = float(data['tot_asset']) - tot_liab    

    return capital

  def _get_sbt_fundamentals_total_revenue (self, data):
    tot_rev = None
                
    if 'tot_revnu' in data.keys() :
      tot_rev = float(0)
      if data['tot_revnu'] is None :
        self._logger.warn('Total Revenue was None')
      else :
        tot_rev = float(data['tot_revnu'])
        
    return tot_rev

  def _get_sbt_intrionio (self, ticker, item, timeframe): 
    data = []
    intrinio = IntrinioApi()
    hdata = intrinio.get_historical_data (ticker, item, timeframe) 
    if 'data' in hdata.keys() :
      data = hdata['data']
    return data
  
  def _get_sbt_fundamentals_intrionio (self, ticker, item, timeframe): 
    conv_data = []
    fa = FinancialAccessor(FinancialVendors.INTRINIO)
    data = fa.query_history_data(ticker, item, timeframe, 'asc')
    json_str = json.dumps(data, cls=DecimalStringEncoder)
    json_data = json.loads(json_str)
    if 'data' in json_data.keys() :
      conv_data = json_data['data']
    return conv_data

  def _get_sbt_fundamentals (self, ticker, item, timeframe):
    fa = FinancialAccessor(FinancialVendors.INTRINIO)
    return fa.query_financial_by_category_range(item, ticker, '2011', '2017', timeframe)   

  def _get_quarter (self, month):
    qtr = 'Q1'

    if month == '06' or month == '07' :
      qtr = 'Q2'
    elif month == '09' or month == '10' :
      qtr = 'Q3'
    elif month == '12' :
      qtr = 'Q4'

    return qtr
  
class Company:
  """
      The Company class contains all the properties and methods specific to
      a company within the model package.
  """

  def __init__(self, ticker, finanncial_data):
    """
        Constructor method used to initialize the class
    """    
    self.finanncial_data = finanncial_data
    self.ticker = ticker
    self.model_built = False
    self.value = None
    self.rank = None

  def get_financial_data(self):
    """
        Helper method to return the financial data associated with this 
        specific company instance
    """
    return self.finanncial_data

  def get_ticker (self):
    """
        Helper method to return the ticker associated with this 
        specific company instance
    """
    return self.ticker

  def add_financial_data (self, name, value, timeframe, description= '', 
                          calculated=False, rank = None) :
    """
        Add a financial data element to the company instance
    """
    self.finanncial_data[name] = FinancialData(name, value, timeframe, 
                                               description, calculated, 
                                               rank)

  def get_sum (self, name, start_year, end_year, quarterly):
    """
        Calculates the sum of all the financial data elements of a 
        specific type over a specified time frame
    """
    sumdata = 0

    timeframes = []
    for x in range(start_year, end_year+1) :
      if (quarterly) :
        for y in range(1, 5) :
          timeframes.append('Q' + str(y) + str(x))
      else :
        timeframes.append(str(x))

    if name in self.finanncial_data and \
    isinstance(self.finanncial_data[name], list)  :
      for fd in self.finanncial_data[name] :
        if fd.get_timeframe() in timeframes \
        and isinstance(fd.get_value(), numbers.Number):
          sumdata += fd.get_value()

    return sumdata

"""
    ModelType is an enumeration used to help centralize
    the various financial data estypes into one class/enum.
"""
class ModelType(Enum):
  CAPITAL_EFFICIENCY_SCORE_RANK = 1

class Model(object):
  """
      The Model super class should be inherited by all models.
  """

  def factory(typ):
    """
        Static method used to create instances of a specific model.
    """
    if ModelType.CAPITAL_EFFICIENCY_SCORE_RANK == typ :
      return CaptialEfficiencyScoreRank()
    assert 0, "Bad model creation: " + typ

  factory = staticmethod(factory)

class CaptialEfficiencyScoreRank (Model):
  """
      The CaptialEfficiencyScoreRank contains all the logic related to the
      capital efficiency model within the model package.
  """
  sbt_zfmanager = 'SBT_ZFMANAGER'
  sbt_intrionio = 'SBT_INTRINIO'
  model_type_id = 1

  def __init__(self):
    """
        Constructor method used to initialize the class
    """
    self._sbtcommon = SbtCommon()
    self._logger = self._sbtcommon.get_global_logger()    
    self._config = self._sbtcommon.get_sbt_config()
    
    if 'model_format' in  self._config['models']['cost_efficiency'].keys() :
      self.model_format = self._config['models']['cost_efficiency'] \
                          ['model_format']
    else :
      self.model_format = None
    self.company_repositoy = CompanyRepository()
    self.datasource = self.sbt_zfmanager
    self.fundamentals_results = {}
    self.model_loaded = False
    self.db_model = model_accessor.ModelAccessor()
    self.companies = []

  def calculate (self):
    self._get_five_year_revenue_growth()
    self._get_five_year_revenue_growth_rank()
    self._get_asset_average_last_twenty_quarters()
    self._get_asset_average_last_twenty_quarters_rank()
    self._get_fcf_revenue_average_last_twenty_quarters()
    self._get_fcf_revenue_average_last_twenty_quarters_rank()
    self._get_sh_return_revenue_average_last_five_years()
    self._get_sh_return_revenue_average_last_five_years_rank()
    self._get_capital_effienciency()
    #self._get_capital_effienciency_rank()
    self.model_loaded = True
      
  def generate(self):
    """
        Generates the the capital efficiency model
    """    
    #self._populate_companies()
    if len(self.companies) > 0 :
      for company in self.companies :
        self.company_repositoy.populated_company(company)

      self.calculate()

  def get_model_rankings (self):
    """
      Returns a listing of the model rankings.
  
      Returns :
        list : Model Rankings     

    """    
    info = []
    
    def_model = self.db_model.get_default_model_information(1)
    if len(def_model) == 1 :
      info = self.db_model.get_model_rankings(def_model[0]['id']) 
  
    return info

  def load_model(self, tickers):
    model_id = None
    def_model = self.db_model.get_default_model_information(self.model_type_id)
    if len(def_model) == 1 :
      model_id = def_model[0]['id']
    
    if model_id is None :
      return
    
    counter = 0
    for ticker in tickers :
      uticker = ticker.upper()
      json = self.db_model.get_model_template(self.model_type_id, uticker)      
      if 'companies' in json.keys() and uticker in json['companies'].keys() :
        if len(json['companies'][uticker]) == 0 or \
        len(json['companies'][uticker]['financial_data']) == 0:
          company = self.company_repositoy.get_populated_company(uticker)
          self.companies.append(company)
          self.calculate()
          counter = counter + 1
        
      if counter > 49 :    
        self._save_loaded_models(model_id)
        counter = 0
    
    self._save_loaded_models(model_id)

 
  def _save_loaded_models (self, model_id):
    for company in self.companies :      
      if company.model_built :
        model_dict = self._create_model_dictionary_for_company(company)
        if len(model_dict['companies']['financial_data']) > 0 :
          self.db_model.save_model(model_id, company.ticker, 
                           model_dict['companies']['value'], 
                           model_dict['companies']['rank'], 
                           model_dict['companies']['financial_data'])

    rankings = OrderedDict()
    rankings['sh_return_revenue_average'] = 'DESC'
    rankings['fcf_revenue_average'] = 'DESC'
    rankings['twenty_quarter_asset_average'] = 'DESC'
    rankings['five_year_revenue_growth'] = 'DESC'

    self.db_model.rank_model_company_data(model_id, 
                                    rankings, 
                                    model_rank_type='AVERAGE')
    self.db_model.rank_model_company(model_id)  
    
    self.companies = []    
              
  def get_json (self, ticker):
    """
        Returns a json representation of the model
    """
    uticker = ticker.upper()
    json = self.db_model.get_model_template(self.model_type_id, uticker)

    if 'companies' in json.keys() and uticker in json['companies'].keys() :
      if len(json['companies'][uticker]) == 0 or \
      len(json['companies'][uticker]['financial_data']) == 0:
        company = self.company_repositoy.get_populated_company(uticker)
        self.companies.append(company)
        self.calculate()
        model_dict = self._create_model_dictionary(uticker)
        if len(model_dict['companies']['financial_data']) > 0 :
          self.db_model.save_model(json['id'], uticker, 
                           model_dict['companies']['value'], 
                           model_dict['companies']['rank'], 
                           model_dict['companies']['financial_data'])

          rankings = OrderedDict()
          rankings['sh_return_revenue_average'] = 'DESC'
          rankings['fcf_revenue_average'] = 'DESC'
          rankings['twenty_quarter_asset_average'] = 'DESC'
          rankings['five_year_revenue_growth'] = 'DESC'

          self.db_model.rank_model_company_data(json['id'], 
                                          rankings, 
                                          model_rank_type='AVERAGE')
          self.db_model.rank_model_company(json['id'])

        json = self.db_model.get_model_template(self.model_type_id, 
                                                uticker)

        self.companies = []

    else :
      raise Exception ('An error occurred retrieving ' + 
                       'model from database.')

    if self.model_format is not None and self.model_format == 1 :
      json = self._convert_to_format_one(uticker, json)

    return json

  def _create_model_dictionary_for_company (self, company):
      model = {}
      model['model_type'] = "Capitial Efficiency"

      selected_company = {}

      if (self.model_loaded) and \
      company is not None and company.model_built:
        selected_company = \
          self.company_repositoy.create_company_dictionary(
            company)
      
      if len(selected_company) == 0 :
          selected_company['ticker'] = company.ticker
          selected_company['financial_data'] = []
          selected_company['model_data_loaded'] = self.model_loaded          
          
      
      model['companies'] = selected_company
              
      return model

  def _create_model_dictionary (self, ticker):
      model = {}
      model['model_type'] = "Capitial Efficiency"

      selected_company = {}

      if (self.model_loaded) and \
      len(self.companies) == 1 and \
      ticker == self.companies[0].get_ticker() and \
      self.companies[0].model_built:
        selected_company = \
          self.company_repositoy.create_company_dictionary(
            self.companies[0])
      
      if len(selected_company) == 0 :
          selected_company['ticker'] = ticker
          selected_company['financial_data'] = []
          selected_company['model_data_loaded'] = self.model_loaded          
          
      
      model['companies'] = selected_company
              
      return model

  """
      Returns all the companies contained within this model.
  """
  def get_companies (self):
    return self.companies

  """
      Returns all companies containing a specified financial data type
  """
  def get_companies_containing (self, financial_data_type):
    return [c for c in self.companies \
            if financial_data_type in c.get_financial_data()]

  def _get_capital_effienciency (self):
    for company in self.companies :
      sh_fd = None
      fcf_fd = None
      asset_fd = None
      rg_fd = None
      if FinancialDataType.FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE.value \
      in company.get_financial_data() :
        sh_fd = company.get_financial_data()[
          FinancialDataType.FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE.value]
      if FinancialDataType.TWENTY_QUARTER_FCF_REVENUE_AVERAGE.value \
      in company.get_financial_data() :
        fcf_fd = company.get_financial_data()[
          FinancialDataType.TWENTY_QUARTER_FCF_REVENUE_AVERAGE.value]
      if FinancialDataType.TWENTY_QUARTER_ASSET_AVERAGE.value \
      in company.get_financial_data() :
        asset_fd = company.get_financial_data()[
          FinancialDataType.TWENTY_QUARTER_ASSET_AVERAGE.value]
      if FinancialDataType.FIVE_YEAR_REVENUE_GROWTH.value \
      in company.get_financial_data() :
        rg_fd = company.get_financial_data()[
          FinancialDataType.FIVE_YEAR_REVENUE_GROWTH.value]

      ce_value = 0
      ce_rank = 0
      if sh_fd and fcf_fd and asset_fd and rg_fd :
        ce_value = (sh_fd.get_value() + fcf_fd.get_value() + 
                    asset_fd.get_value() + rg_fd.get_value()) * .25
        ce_rank = int((sh_fd.get_rank() + fcf_fd.get_rank() + 
                       asset_fd.get_rank() + rg_fd.get_rank()) * .25)
        company.model_built=True
      else :
        self._logger.info(company.ticker + ' is missing data.')
        
      company.value = ce_value
      company.rank = ce_rank

  def _get_capital_effienciency_rank (self):
    growth = self.get_companies_containing(
      FinancialDataType.CAPITAL_EFFICICENCY_RANK_SCORE.value)
    growth.sort(key = lambda c: c.get_financial_data()[
      FinancialDataType.CAPITAL_EFFICICENCY_RANK_SCORE.value
      ].get_value(), reverse=True)

    rank = 1
    for company in growth :
      company.get_financial_data()[
        FinancialDataType.CAPITAL_EFFICICENCY_RANK_SCORE.value
        ].set_rank(rank)
      rank = rank + 1

    growth = self.get_companies_containing(
      FinancialDataType.CAPITAL_EFFICICENCY_SCORE_RANK.value)
    growth.sort(key = lambda c: c.get_financial_data()[
      FinancialDataType.CAPITAL_EFFICICENCY_SCORE_RANK.value].get_value(), 
      reverse=False)

    rank = 1
    for company in growth :
      company.get_financial_data()[
        FinancialDataType.CAPITAL_EFFICICENCY_SCORE_RANK.value
        ].set_rank(rank)
      rank = rank + 1

  def _get_sh_return_revenue_average_last_five_years (self):
    now = datetime.datetime.now()
    first_year = now.year - 1
    last_year = first_year - 4
    for company in self.companies :
      if company.finanncial_data is not None and \
      len(company.finanncial_data) > 0 :
        cap_total = company.get_sum (
          FinancialDataType.RETURNED_CAPITAL.value, 
          last_year, first_year, False)
        cap_total = cap_total*-1
        revenue_total = company.get_sum (
          FinancialDataType.ANNUAL_REVENUE.value, last_year, 
          first_year, False)
        value = 0
        if revenue_total != 0 :
          value = (cap_total/revenue_total) * 100
        
        if value > 0 :  
          company.add_financial_data (
            FinancialDataType.FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE.value, 
            value, "2017", description='SH Return Average (5 Years)', 
            calculated = True)
        else :
          self._logger.info(company.ticker + ' could not calculate SH Return Average.')
        
  def _get_sh_return_revenue_average_last_five_years_rank (self):
    growth = self.get_companies_containing(
      FinancialDataType.FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE.value)
    growth.sort(key = lambda c: c.get_financial_data()[
      FinancialDataType.FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE.value
      ].get_value(), reverse=True)

    rank = 1
    for company in growth :
      company.get_financial_data()[
        FinancialDataType.FIVE_YEAR_SH_RETURN_REVENUE_AVERAGE.value
        ].set_rank(rank)
      rank = rank + 1

  def _get_fcf_revenue_average_last_twenty_quarters (self):
    now = datetime.datetime.now()
    first_year = now.year - 1
    last_year = first_year - 4
    for company in self.companies :
      if company.finanncial_data is not None and \
      len(company.finanncial_data) > 0 :
        cfc_total = company.get_sum (
          FinancialDataType.QUARTERLY_FCF.value, last_year, 
          first_year, True)
        revenue_total = company.get_sum (
          FinancialDataType.QUARTERLY_REVENUE.value, last_year, 
          first_year, True)
        value = 0
        if revenue_total != 0 :
          value = (cfc_total/revenue_total) * 100
        
        if value > 0 :  
          company.add_financial_data (
            FinancialDataType.TWENTY_QUARTER_FCF_REVENUE_AVERAGE.value, 
            value, "2017", 
            description='FCF Revenue Average (20 Quarters)', 
            calculated = True)
        else :
          self._logger.info(company.ticker + ' could not calculate FCF Revenue Average.')

  def _get_fcf_revenue_average_last_twenty_quarters_rank (self):
    growth = self.get_companies_containing(
      FinancialDataType.TWENTY_QUARTER_FCF_REVENUE_AVERAGE.value)
    growth.sort(key = lambda c: c.get_financial_data()[
      FinancialDataType.TWENTY_QUARTER_FCF_REVENUE_AVERAGE.value
      ].get_value(), reverse=True)

    rank = 1
    for company in growth :
      company.get_financial_data()[
        FinancialDataType.TWENTY_QUARTER_FCF_REVENUE_AVERAGE.value
        ].set_rank(rank)
      rank = rank + 1

  def _get_asset_average_last_twenty_quarters (self):
    now = datetime.datetime.now()
    first_year = now.year - 1
    last_year = first_year - 4
    for company in self.companies :
      if company.finanncial_data is not None and \
      len(company.finanncial_data) > 0 :
        asset_total = company.get_sum (
          FinancialDataType.QUARTERLY_ASSETS.value, last_year, 
          first_year, True)
        net_income_total = company.get_sum (
          FinancialDataType.QUARTERLY_NET_INCOME.value, last_year, 
          first_year, True)
        value = 0
        if asset_total != 0 :
          value = (net_income_total/asset_total/4) * 100
          
        if value > 0 :  
          company.add_financial_data (
            FinancialDataType.TWENTY_QUARTER_ASSET_AVERAGE.value, value, 
            "2017", description='Asset Average (20 Quarters)', 
            calculated = True)
        else :
          self._logger.info(company.ticker + ' could not calculate Asset Average.')

  def _get_asset_average_last_twenty_quarters_rank (self):
    growth = self.get_companies_containing(
      FinancialDataType.TWENTY_QUARTER_ASSET_AVERAGE.value)
    growth.sort(key = lambda c: c.get_financial_data()[
      FinancialDataType.TWENTY_QUARTER_ASSET_AVERAGE.value].get_value(), 
      reverse=True)

    rank = 1
    for company in growth :
      company.get_financial_data()[
        FinancialDataType.TWENTY_QUARTER_ASSET_AVERAGE.value].set_rank(
          rank)
      rank = rank + 1


  def _get_five_year_revenue_growth (self):
    now = datetime.datetime.now()
    first_year = now.year - 1
    last_year = first_year - 6
    #TODO : Fix Quandl Data set
    #QUANDL Data set does not go back to 2010 currently adjusting formula for now
    if self.datasource == self.sbt_zfmanager :
        last_year = first_year - 5
    for company in self.companies :
      value = self._calculate_five_year_revenue_growth(first_year, last_year, 
                                                       company.get_financial_data())
      if value is not None :
        company.add_financial_data (
          FinancialDataType.FIVE_YEAR_REVENUE_GROWTH.value, value, 
          "2017", description='Five Year Revenue Growth', 
          calculated = True)
      else :
        self._logger.info(company.ticker + ' could not calculate Five Year Revenue Growth.')

  def _get_five_year_revenue_growth_rank (self):
    growth = self.get_companies_containing(
      FinancialDataType.FIVE_YEAR_REVENUE_GROWTH.value)
    growth.sort(key = lambda c: c.get_financial_data()[
      FinancialDataType.FIVE_YEAR_REVENUE_GROWTH.value].get_value(), 
      reverse=True)

    rank = 1
    for company in growth :
      company.get_financial_data()[
        FinancialDataType.FIVE_YEAR_REVENUE_GROWTH.value].set_rank(rank)
      rank = rank + 1

  def _calculate_five_year_revenue_growth (self, first_year, last_year, financial_data):
    value = None
    
    if financial_data is None or \
    len(financial_data) == 0 or \
    FinancialDataType.ANNUAL_REVENUE.value not in financial_data.keys() :
      return value
    
    first_year_rev = 0
    last_year_rev = 0
    for rev in financial_data[
      FinancialDataType.ANNUAL_REVENUE.value] :
        if rev.get_timeframe() == str(first_year) :
          first_year_rev = float(rev.get_value())
        elif rev.get_timeframe() == str(last_year) :
          last_year_rev = float(rev.get_value())

    if first_year_rev != 0 and last_year_rev != 0 :
      value = \
        ((math.pow((first_year_rev/last_year_rev),1/5))-1)*100
          
    return value
            
  def _convert_to_format_one (self, ticker, current_format):
    self._logger.warn('Converting to format 1')
    results = {}

    results['model_type'] = current_format['description']
    company = {}

    company['ticker'] = ticker

    all_fin_data = []
    data_laoded = False

    if 'financial_data' in current_format['companies'][ticker].keys() :
      all_fin_data = current_format['companies'][ticker]['financial_data']
  
      for fd in all_fin_data :
        fd['shortdescription'] = fd['description']
        fd['type'] = fd['name']
        fd.pop('name')
        fd.pop('description')
  
      ces = FinancialData(
        FinancialDataType.CAPITAL_EFFICICENCY_RANK_SCORE.value, 
        current_format['companies'][ticker]['value'], "2017", 
        description='Capital Efficiency Rank Score', 
        calculated = True, 
        rank=current_format['companies'][ticker]['rank']).__dict__
      ces['shortdescription'] = ces['description']
      ces['type'] = ces['name']
      ces.pop('name')
      ces.pop('description')
  
      cer = FinancialData(
        FinancialDataType.CAPITAL_EFFICICENCY_SCORE_RANK.value, 
        current_format['companies'][ticker]['rank'], "2017", 
        description='Capital Efficiency Score Rank', calculated = True, 
        rank=current_format['companies'][ticker]['rank']).__dict__
      cer['shortdescription'] = cer['description']
      cer['type'] = cer['name']
      cer.pop('name')
      cer.pop('description')
  
      all_fin_data.append(ces)
      all_fin_data.append(cer)
      data_laoded = True

    company['financial_data'] = all_fin_data

    results['company'] = company

    results['model_data_loaded'] = data_laoded

    return results 