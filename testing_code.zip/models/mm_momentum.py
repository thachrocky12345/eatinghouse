import numpy as np
import pandas as pd
# import modin.pandas as pd
# from mp_accessor import MappingAccessor
from dd_accessor import DynamoAccessor
from mp_accessor import MappingAccessor
from services.public.time_series_manager import TimeSeriesManager
from pykalman import KalmanFilter
import datetime as dt
from sbt_common import SbtCommon
from pandas.plotting import register_matplotlib_converters
from pathlib import Path
from barchart_accessor import BarchartAccessor
from decimal import Decimal
import time
import datetime
from scipy import optimize
# from sbt_model_accessor import ModelAccessor
from sbt_common import SbtGlobalCommon
from buy_sell_indicators import BuyIndicators
import logging
# from sklearn.cluster import AgglomerativeClustering
# from sklearn.neighbors import KNeighborsClassifier
# import scipy.cluster.hierarchy as sch
import time
import ciso8601
import sqlalchemy
from pg_accessor import PostgresAccessor
import json
from sqlalchemy.types import JSON, VARCHAR, FLOAT, BIGINT


class MMMomentum(DynamoAccessor):
  def __init__(self, companies=None):
    super().__init__(aws_profile_name=None,
                     aws_region_name=None,
                     aws_end_point_url=None)
    # self.mapping_accessor = MappingAccessor()
    SYMBOL_MAPPING_TABLENAME = 'DEV_SBT_SYMBOL_EXCHANGE_MAPPING'
    self.all_symbols_list = self._scan_table_with_filter_str(
      SYMBOL_MAPPING_TABLENAME, 'symbol ne mairan')
    self.all_symbols = pd.DataFrame(self.all_symbols_list)
    self.symbols_data = self.all_symbols[
      (self.all_symbols.exchange_type == 'STOCK')
      & (self.all_symbols.exchange_country == 'USA')
      & ((self.all_symbols.exchange.str.startswith('NYSE'))
         | (self.all_symbols.exchange.str.startswith('NSDQ'))
         )
      ]
    self.buy_sell = BuyIndicators()
    # logging.getLogger('botocore').setLevel(logging.CRITICAL)
    # logging.getLogger('botocore.credentials').setLevel(logging.CRITICAL)
    # logging.getLogger('sbt_common').setLevel(logging.CRITICAL)
    self._logger = self._sbtcommon.get_global_logger()
    self.dd = DynamoAccessor()
    # self._logger.setLevel("ERROR")
    self.ts = TimeSeriesManager()
    self.kf = KalmanFilter(transition_matrices=[1],
                      observation_matrices=[1],
                      initial_state_mean=0,
                      initial_state_covariance=1,
                      observation_covariance=1,
                      transition_covariance=.01)
    self.config = SbtGlobalCommon.raw_sbt_config
    self.ENV = SbtGlobalCommon.get_sbt_config_env()
    self.pgconfig = {self.ENV: self.config[self.ENV]['postgres']['datafactory']}
    self.pg = PostgresAccessor(self.pgconfig[self.ENV])

    self.barchart_accessor = BarchartAccessor()
    self.mp_accessor = MappingAccessor()

    if companies is not None:
      self.prices = {}
      for company in companies:
        ticker = list(company.keys())[0]
        p = self.get_prices("barchart", list(company.keys())[0])
        self.prices.update({ticker: p})

    self._sbtcommon = SbtCommon()
    # self._logger = self._sbtcommon.get_global_logger() if not log else log
    self._host = self.config[self.ENV]['postgres']['datafactory']['host']
    self._port = self.config[self.ENV]['postgres']['datafactory']['port']
    self._credentials = self.config[self.ENV]['postgres']['datafactory']['credentials']
    self._user = self.config[self.ENV]['postgres']['datafactory']['user']
    self._dbname = self.config[self.ENV]['postgres']['datafactory']['database']
    self._connection_string = "dbname='" + self._dbname + "' user='" + \
                              self._user + "' host='" + self._host + \
                              "' password=" + self._credentials
    # dialect+driver://username:password@host:port/database
    self._engine = sqlalchemy.create_engine(
      'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
              user=self._user, password=self._credentials,
              host=self._host, db=self._dbname))


  def pykalm(self, T, start_point, symbol, exchange):
    home = str(Path.home())
    # ts = TimeSeriesManager()
    # mp_accessor = MappingAccessor()
    # symbol_mappings = mp_accessor.scan_symbol_exchange_mapping()
    sym = self.mp_accessor.query_symbol_exchange_mappings(symbol)
    for symbol in sym:
      if symbol['exchange'] == exchange:
        break
    symbols = []

    adj_close_data = self.ts._get_history_from_snp(symbol['symbol'], symbol['exchange'], symbol['exchange_country'], None,
                                              None)
    adj_close_df = pd.DataFrame([x['close'] for x in adj_close_data], [x['tradingDay'] for x in adj_close_data])
    adj_close_df = adj_close_df[~adj_close_df.index.duplicated(keep='first')]
    adj_close_df['volume'] = [x['volume'] for x in adj_close_data]
    adj_close_df.rename(columns={0: "close"}, inplace=True)
    self._logger.info(symbol['symbol'])
    adj_close_df["rolling_ret"] = adj_close_df['close'].pct_change(15)

    # adj_close_df['log_ret'] = np.log(adj_close_df["close"].shift(1))-np.log(adj_close_df["close"])

    # Construct a Kalman filter
    kf = KalmanFilter(transition_matrices=[1],
                      observation_matrices=[1],
                      initial_state_mean=0,
                      initial_state_covariance=1,
                      observation_covariance=1,
                      transition_covariance=.01)

    price_means, covariances = kf.filter(adj_close_df["close"])
    adj_close_df['price_means'] = price_means
    volume_means, covariances = kf.filter(adj_close_df["volume"])
    adj_close_df['volume_means'] = volume_means
    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]
    # adj_close_df[['volume', 'volume_means']].plot()
    # plt.show()

    delta_t = 5  # will give us weekly increments
    t = T / delta_t
    t = t / 2

    avgs = []
    prev = 0
    reverse_df = adj_close_df[-T:].iloc[::-1]
    for i in range(0, T):
      if i % delta_t == 0 and i != 0:
        avgs.append(np.mean(reverse_df['price_means'].iloc[prev:i]))
        prev = i

    slopes = []
    raw_slopes = []
    weights = []
    for i in range(0, len(avgs) - 1):
      raw_slope = (avgs[i] - avgs[i + 1]) / delta_t  # This may be reversed ?
      raw_slopes.append(raw_slope)
      weighted = np.exp(-i / t)
      weights.append(weighted)
      slopes.append(raw_slope * weighted)
    print("Mean slopes: ", np.mean(slopes))

    delta_slopes = []
    three_time_period_delta = 0
    for i in range(len(slopes) - 1):
      delta_slopes.append(slopes[i - 1] - slopes[i])
      if i == 2:
        three_time_period_delta = slopes[i - 2] - slopes[i]
    print("Delta over 3 most recent observations: ", three_time_period_delta)

    # fig, ax = plt.subplots()
    # ax.plot(list(reversed(slopes)), color='b', label='Weight Adjusted Slopes')
    # ax.plot(list(reversed(raw_slopes)), color='orange', label='Raw Slopes')
    # ax.legend(loc='upper right')
    # plt.title(symbol['symbol'] + ": Slopes vs Raw Slopes")
    # plt.savefig(home + "/Desktop/momentum/graphs/" + symbol['symbol'] + "_slopes")
    # # plt.show()
    # plt.close()
    # # adj_close_df.plot()
    # # Upticks (1) are buy signals while down ticks (-1) are sell signals
    # fig, ax1 = plt.subplots()
    # ax1.plot(adj_close_df['datetimes'].values.tolist()[-T:-1], adj_close_df["close"].values.tolist()[-T:-1], 'b', label="Close Price")
    # ax1.set_xlabel('Date')
    # # Make the y-axis label, ticks and tick labels match the line color.
    # ax1.set_ylabel('Close Price', color='b')
    # ax1.tick_params('y', colors='b')
    #
    # # ax2 = ax1.twinx()
    # ax1.plot(adj_close_df['datetimes'].values.tolist()[-T:-1], adj_close_df['price_means'].values.tolist()[-T:-1], 'g', label="Kalman Filter")
    # # ax2.set_ylabel('K', color='g')
    # # ax2.tick_params('y', colors='g')
    # toggle = 0
    # previous = -1
    # for i in range(1, T+1):
    #   if i % delta_t == 0 and toggle == 0:
    #     ax1.axvspan(adj_close_df['datetimes'].iloc[previous], adj_close_df['datetimes'].iloc[-i], alpha=0.5, facecolor='grey')
    #     toggle = 1
    #     previous = -i
    #     plt.plot(adj_close_df['datetimes'].iloc[int(-i+int(delta_t/2))], avgs[int((i-1) / delta_t)], "ro")
    #   elif i % delta_t == 0 and toggle == 1:
    #     ax1.axvspan(adj_close_df['datetimes'].iloc[previous], adj_close_df['datetimes'].iloc[-i], alpha=0.5, facecolor='#D3D3D3')
    #     toggle = 0
    #     previous = -i
    #     plt.plot(adj_close_df['datetimes'].iloc[int(-i+int(delta_t/2))], avgs[int((i-1) /delta_t)], "ro")
    # ax.legend(loc='upper left')
    # plt.title(symbol['symbol'] + ": Kalman Filter vs Close Price")
    # fig.tight_layout()
    # plt.savefig(home + "/Desktop/momentum/graphs/" + symbol['symbol']+ "_price_kalman")
    # # plt.show()
    # plt.close()

  def kalman_filter(self, df):
    # Construct a Kalman filter

    means, covariances = self.kf.filter(df)

    return means

  def calculate_momentum(self, df, delta_t, T, column='price_means'):
    # df[column + "_raw_slopes"] = np.nan
    # df[column + "_delta_slopes"] = np.nan
    # df[column + "_avgs"] = np.nan

    t = T / delta_t
    t = t / 2
    # for y in range(1, int(len(df) / T) + 1):
    prev = 0
    avgs = []
    raw_slopes = []
    delta_slopes = []

    # day_count = 1
    np_avgs = np.full(len(df), np.nan)
    np_slope = np.full(len(df), np.nan)
    np_delta = np.full(len(df), np.nan)
    for i in range(len(df)):
      loc = i
      if (loc + 1) % delta_t == 0 and (loc) != 0:
        # label = df.index.values[loc]
        avgs.append(np.mean(df[column].iloc[prev:loc+1]))
        np_avgs[loc] = np.mean(df[column].iloc[prev:loc+1])
        prev = loc + 1
        if len(avgs) > 1:
          # loc = df.index.get_loc(index)
          raw_slope = (np_avgs[loc] - np_avgs[loc-delta_t]) / delta_t
          raw_slopes.append(raw_slope)
          np_slope[i] =  raw_slope
        if len(raw_slopes) > 1:
          delta_slope = np_slope[loc] - np_slope[loc-delta_t]
          np_delta[i] = delta_slope
          delta_slopes.append(delta_slope)
        # day_count += 1

    # std_df = df.std()
    # std_delta_slopes = std_df['delta_slopes']
    # print(1.5*std_delta_slopes, 2*std_delta_slopes, 3*std_delta_slopes)

    # slopes = []
    # raw_slopes = []
    # weights = []
    # raw_slopes.append(np.nan)
    # for i in range(1, len(avgs)):
    #   raw_slope = (avgs[i] - avgs[i - 1]) / delta_t
    #   raw_slopes.append(raw_slope)
    #   weighted = np.exp(-i / t)
    #   weights.append(weighted)
    #   slopes.append(raw_slope * weighted)
    #
    # delta_slopes = []
    # delta_slopes.append(np.nan)
    # for i in range(1, len(raw_slopes)):
    #   delta_slopes.append(raw_slopes[i] - raw_slopes[i - 1])
    df[column + "_raw_slopes"] = np_slope
    df[column + "_delta_slopes"] = np_delta
    df[column + "_avgs"] = np_avgs
    return avgs, raw_slopes, delta_slopes, df

  def get_prices(self, source, symbol, exchange=None):
    if source == "barchart":

      adj_close_data = self.barchart_accessor.get_history(None, "daily", 0, "19000101", None,
                                                     symbol)
      adj_close_df = pd.DataFrame([float(x['close']) for x in adj_close_data],
                                  [x['tradingDay'] for x in adj_close_data])
      adj_close_df = adj_close_df[~adj_close_df.index.duplicated(keep='last')]

      adj_close_df['volume'] = [x['volume'] for x in adj_close_data]
      adj_close_df.rename(columns={0: "close"}, inplace=True)

    elif source == "snp":
      # symbol_mappings = mp_accessor.scan_symbol_exchange_mapping()

      sym = self.mp_accessor.query_symbol_exchange_mappings(symbol)
      for symbol in sym:
        if symbol['exchange'] == exchange:
          break
      symbols = []
      adj_close_data = self.ts._get_history_from_snp(symbol['symbol'], symbol['exchange'], symbol['exchange_country'], None,
                                                None)
      adj_close_df = pd.DataFrame([x['close'] for x in adj_close_data], [x['tradingDay'] for x in adj_close_data])
      adj_close_df = adj_close_df[~adj_close_df.index.duplicated(keep='first')]
      adj_close_df.rename(columns={0: "close"}, inplace=True)

    return adj_close_df

  def strategy_1(self, x, symbol, zero_day=None, start_flag=False, end_day=None, delta_t=5, prices=None, sign=None):
    self._logger.info(symbol)

    if prices is None:
      adj_close_df = self.get_prices("barchart", symbol)
    else:
      adj_close_df = prices

    if zero_day is None or start_flag:
      zero_day = adj_close_df.index[0]
    if end_day is None:
      end_day = adj_close_df.index[-1]
    else:
      adj_close_df = adj_close_df[:end_day]

    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    adj_close_df['volume_means'] = self.kalman_filter(adj_close_df['volume'])

    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]

    avgs, raw_slopes, delta_slopes, __ = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df))
    pos_streak = 0
    neg_streak = 0
    pos_streaks = []
    neg_streaks = []
    shares = 0
    short_shares = 0
    capital = 1000
    dif_delt = []
    day_count = 1  # changed from 0 to 1 bc 0 creates off by one day
    position_opened = ''
    most_recent_trade = ""
    most_recent_trade_metrics = {}
    for index, day in adj_close_df.iterrows():
      if day_count % delta_t == 0 and day_count != 0:
        try:
          if raw_slopes[int(day_count / delta_t) - 1] > 0 and pos_streak > 0:
            pos_streak += 1
          elif raw_slopes[int(day_count / delta_t) - 1] > 0 and neg_streak > 0:
            neg_streaks.append(neg_streak)
            neg_streak = 0
            pos_streak = 1
            if index >= zero_day and index <= end_day:
              if shares == 0 and short_shares == 0:
                shares = capital / day['close']
                capital = 0
                position_opened = index
                most_recent_trade = "BUY: " + index
                # print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
              #  Force close a short position when its indicated that it is time to buy
              elif short_shares != 0 and shares == 0:
                capital -= short_shares * day["close"]
                short_shares = 0
                shares = capital / day['close']
                capital = 0
                position_opened = index
                most_recent_trade = "BUY: " + index
                # print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
          elif raw_slopes[int(day_count / delta_t) - 1] < 0 and pos_streak > 0:
            pos_streaks.append(pos_streak)
            neg_streak = 1
            pos_streak = 0
            # TODO: FIX SHORTING ALGO. STATUS: DONE
            if index >= zero_day and index <= end_day:
              if short_shares == 0 and shares == 0:
                short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
                capital += short_shares * day['close']
                position_opened = index
                most_recent_trade = "SHORT: " + index
                # print("Short at " + str(day["close"]) + " on " + str(index))
          elif raw_slopes[int(day_count / delta_t) - 1] < 0 and neg_streak > 0:
            neg_streak += 1
          elif pos_streak == 0 and neg_streak == 0:
            if raw_slopes[int(day_count / delta_t) - 1] > 0:
              pos_streak += 1
              if index >= zero_day and index <= end_day:
                shares = capital / day["close"]
                capital = 0
                position_opened = index
                most_recent_trade = "BUY: " + index
                # print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
            else:
              neg_streak += 1
              # if index >= exchange:
              #   short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
              #   capital += short_shares * day['close']

          # TODO: This needs to be fixed... the -5 creates problems the first couple times around. STATUS: DONE
          # The below change addresses the above issue
          if (int(day_count / delta_t)) >= delta_t * 5 and index != position_opened:
            if (delta_slopes[(int(day_count / delta_t)) - 1] <
                delta_slopes[(int(day_count / delta_t)) - 5]) and (delta_slopes[(int(day_count / delta_t)) - 12] -
                                                                   delta_slopes[(int(
                                                                     day_count / delta_t)) - 5]) < x[0] and capital == 0:
              if index >= zero_day and index <= end_day:
                dif_delt.append(delta_slopes[(int(day_count / delta_t)) - 1] -
                                delta_slopes[(int(day_count / delta_t)) - 5])
                capital = shares * day["close"]
                shares = 0
                most_recent_trade = "SELL TO CLOSE: " + index
                most_recent_trade_metrics.update(
                  {"slopes": raw_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
                most_recent_trade_metrics.update(
                  {"delta_slopes": delta_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
                # print("Sold " + str(day["close"])+ " on " + str(index))
                # print()
            if (delta_slopes[(int(day_count / delta_t)) - 1] >
                delta_slopes[(int(day_count / delta_t)) - 5]) and (delta_slopes[(int(day_count / delta_t)) - 1] -
                                                                   delta_slopes[(int(
                                                                     day_count / delta_t)) - 5]) > x[1] and short_shares != 0:  # Test the <.1 more
              if index >= zero_day and index <= end_day:
                dif_delt.append(delta_slopes[(int(day_count / delta_t)) - 1] -
                                delta_slopes[(int(day_count / delta_t)) - 5])
                capital -= short_shares * day["close"]
                short_shares = 0
                most_recent_trade = "BUY TO CLOSE: " + index
                most_recent_trade_metrics.update(
                  {"slopes": raw_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
                most_recent_trade_metrics.update(
                  {"delta_slopes": delta_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
                # print("Close short at " + str(day["close"])+ " on " + str(index))
        except IndexError:
          pass
      day_count += 1
    ending_pos = ""
    if capital == 0:
      capital = shares * adj_close_df["close"][end_day]
      ending_pos = "long"
      # print("MM Guidance: In Long Position")
    if short_shares != 0:
      capital -= short_shares * adj_close_df["close"][end_day]
      shares = 0
      ending_pos = "short"
      # print("MM Guidance: In Short Position")
    # print("MM Last 5 delta slopes & slopes", delta_slopes[-1], raw_slopes[-2:])

    buy_hold = (1000 / adj_close_df["close"][zero_day]) * adj_close_df["close"][end_day]

    if sign:
      return sign * capital
    else:
      return (capital - buy_hold) / buy_hold * 100, capital, buy_hold, most_recent_trade, most_recent_trade_metrics

  def production_strategy(self, x, symbol, zero_day=None, start_flag=False, end_day=None, delta_t=5, prices=None, sign=None):
    self._logger.info(symbol)

    # start = time.time()
    if prices is None:
      adj_close_df = self.get_prices("barchart", symbol)
      # print(time.time()-start)
    else:
      adj_close_df = prices

    # start = time.time()
    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    # print(time.time() - start)
    # adj_close_df['volume_means'] = self.kalman_filter(adj_close_df['volume'])

    # start = time.time()
    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]
    # print(time.time() - start)

    if zero_day is None or start_flag:
      zero_day = adj_close_df.index[0]
    if end_day is None:
      end_day = adj_close_df.index[-1]
    else:
      adj_close_df = adj_close_df[:end_day]

    # start = time.time()
    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df))
    # print(time.time() - start)

    # adj_close_df['volatility'] = np.nan

    # dd = DynamoAccessor()
    # guid = self.mapping_accessor.query_symbol_exchange_mappings(symbol)[0]['guid']
    # volatility = self.dd._query_table(
    #   'SBT_HISTORICAL_VOLATILITY_BARCHART',
    #   'guid', guid)
    #
    # i = 0
    # for v in volatility:
    #   adj_close_df.at[v['date'], "volatility"] = float(v['values']['value'])
    #   if np.isnan(float(v['values']['value'])):
    #     i += 1

    # o3 = pd.DataFrame(index=adj_close_df.index, columns=['red_zone', 'yellow_zone', 'zone_classification'])
    # o3['zone_classification'] = "None"
    # hv_timeseries = self.mapping_accessor._query_table('SBT_HISTORICAL_VOLATILITY_BARCHART', 'guid', symbol['guid'])
    # hv_lst = [float(volatility[x]['values']['value']) for x in range(len(volatility))]
    # hv_df = pd.DataFrame([x['values']['value'] for x in volatility], [x['date'] for x in volatility])
    # # self._logger.info(symbol['symbol'])
    # if hv_lst and len(adj_close_df.values.tolist()) > 521:
    #   # adj_close_df = adj_close_df.truncate(after=volatility[-1]['date'])
    #   adj_close_lst = adj_close_df["close"].values.tolist()
    #   # averageVQ = np.convolve(hv_lst, np.ones((7560,)) / 7560, mode='valid') # used to be 756
    #   averageVQ = hv_df.rolling(7650).mean()
    #   if np.isnan(averageVQ[0].iloc[-1]):
    #     averageVQ = hv_df.rolling(len(hv_df)).mean()
    #   vq_ratio = (hv_lst[-1] - averageVQ[0].iloc[-1]) / averageVQ[0].iloc[-1]
    #   if len(hv_lst) >= 521:
    #     o3 = self.buy_sell.o3_timeseries(adj_close_lst, hv_lst, adj_close_df)

    # while np.isnan(float(adj_close_df['volatility'][i])):

    # adj_close_df['volatility_means'] = np.nan
    # vol_means = self.kalman_filter(adj_close_df['volatility'][i:]).flatten()
    # xy = 0
    # for index, d in adj_close_df[i:].iterrows():
    #   adj_close_df.at[index, "volatility_means"] = vol_means[xy]
    #   xy += 1

    # avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df),
    #                                                                        column='volatility_means')
    # mp = MappingAccessor()
    guid = self.dd._query_table("SBT_SYMBOL_EXCHANGE_MAPPING", "symbol", symbol)[0]['guid']
    # guid = mp.query_symbol_exchange_mappings(symbol)[0]['guid']
    try:
      vol_df = self.vol_strategy_2([-0.04832031, -0.3765332], symbol, guid,
                                   zero_day=None, start_flag=True, end_day=None, delta_t=delta_t)[-1]
    except Exception as e:
      vol_df = None
      print(e)

    pos_streak = 0
    neg_streak = 0
    pos_streaks = []
    neg_streaks = []
    shares = 1000/adj_close_df["close"][zero_day]
    # print(str(zero_day), "\tBuy\t", adj_close_df["close"][zero_day])
    # print("Bought " + str(shares) + " at " + str(adj_close_df["close"][zero_day]) + " on " + str(zero_day))
    short_shares = 0
    capital = 0
    dif_delt = []
    # day_count = 1  # changed from 0 to 1 bc 0 creates off by one day
    position_opened = ''
    most_recent_trade = "BUY"
    most_recent_trade_date = zero_day
    most_recent_trade_metrics = {}
    time_series = []
    adj_close_df["trade"] = np.nan
    adj_close_df["buy"] = False
    adj_close_df["short"] = False
    adj_close_df["sell_to_close"] = False
    adj_close_df["buy_to_close"] = False
    adj_close_df['pos_streaks'] = np.nan
    adj_close_df['neg_streaks'] = np.nan
    buy_count = 0
    anchor_price = 0
    trade = 0
    buy = True
    # max_price = adj_close_df["close"][zero_day]
    for index, day in adj_close_df.iterrows():
      loc = adj_close_df.index.get_loc(index)
      adj_close_df.at[index, "trade"] = trade
      adj_close_df.at[index, "buy"] = buy
      timestamp = Decimal(str(time.mktime(datetime.datetime.strptime(str(index),
                                                                     "%Y-%m-%d").timetuple())))
      if (loc + 1) % delta_t == 0:

        # Count streaks for disribution purposes
        # if adj_close_df['price_means_raw_slopes'][index] > 0 and pos_streak > 0:
        #   pos_streak += 1
        # elif adj_close_df['price_means_raw_slopes'][index] > 0 and neg_streak > 0:
        #   adj_close_df.at[index, "neg_streaks"] = neg_streak
        #   neg_streaks.append(neg_streak)
        #   neg_streak = 0
        #   pos_streak = 1
        # elif adj_close_df['price_means_raw_slopes'][index] < 0 and pos_streak > 0:
        #   adj_close_df.at[index, "pos_streaks"] = pos_streak
        #   pos_streaks.append(pos_streak)
        #   neg_streak = 1
        #   pos_streak = 0
        # elif adj_close_df['price_means_raw_slopes'][index] < 0 and neg_streak > 0:
        #   neg_streak += 1
        # elif pos_streak == 0 and neg_streak == 0:
        #   if adj_close_df['price_means_raw_slopes'][index] > 0:
        #     pos_streak += 1
        #   else:
        #     neg_streak += 1

        part_df = adj_close_df[:loc]
        # vol_avg = np.mean(part_df['volatility_means'])
        std_df = part_df.std()
        std_delta_slopes = std_df['price_means_delta_slopes']
        # std_vol_delta_slopes = std_df['volatility_means']
        std_pos = std_df['pos_streaks']
        std_neg = std_df['neg_streaks']

        two_sigma = std_delta_slopes*2
        # two_sigma_vol = std_vol_delta_slopes
        accel_significance = "normal"
        vol_significance = "normal"
        # TODO: IS THIS RIGHT??? MAYBE SHOULD BE < mew - two_sigma
        if day["price_means_delta_slopes"] > two_sigma or day["price_means_delta_slopes"] < -two_sigma:
          accel_significance = "significant"
        # if day["volatility_means"] > vol_avg + two_sigma_vol:
        #   vol_significance = "significant"
        # print(1.5 * std_delta_slopes, 2 * std_delta_slopes, 3 * std_delta_slopes)

        # Can't put nan in dynamodb
        # elif not np.isnan(day['raw_slopes']):
        #   time_series.append({'date': str(index), 'slope': Decimal(day['raw_slopes']), 'accel': Decimal(np.nan), 'timestamp': timestamp})
        # elif not np.isnan(day['delta_slopes']):
        #   time_series.append(
        #     {'date': str(index), 'slope': Decimal(np.nan), 'accel': Decimal(day['delta_slopes']), 'timestamp': timestamp})

      if (loc + 1) % delta_t == 0 and (loc + 1) > (delta_t*2):
        if index >= zero_day and index <= end_day:
          if shares != 0 and anchor_price !=0:
            if index >= zero_day and index <= end_day:
              if (day["price_means_avgs"] - anchor_price) / anchor_price <= x[0]:
                buy_count = 0
                capital = shares * day["close"]
                shares = 0
                most_recent_trade = "SELL TO CLOSE"
                most_recent_trade_date = index
                # print("Sold " + str(day["close"]) + " on " + str(index), " \tanchor price was ", anchor_price)
                position_opened = index

                if short_shares == 0 and shares == 0:
                  short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
                  capital += short_shares * day['close']
                  position_opened = index
                  most_recent_trade = "SHORT"
                  most_recent_trade_date = index
                  # print("Short at " + str(day["close"]) + " on " + str(index))
                  # print(day['volatility_means'], day['volatility_means_delta_slopes'],
                  #       day['volatility_means_raw_slopes'], o3['zone_classification'][index])
                  trade = 1
                  buy = False
                  adj_close_df.at[index, "trade"] = trade
                  adj_close_df.at[index, "buy"] = buy
                  # print(index, "\tSell/Short\t", day['close'])
          if np.sign(adj_close_df["price_means_raw_slopes"][index]) < np.sign(adj_close_df["price_means_raw_slopes"][loc-delta_t]):
            buy_count = 0
            if day["price_means_avgs"] > anchor_price:
              if index >= zero_day and index <= end_day:
                anchor_price = day["price_means_avgs"]
          else:
            if index >= zero_day and index <= end_day:
              if shares == 0 and index != position_opened:
                capital -= short_shares * day["close"]
                short_shares = 0
                most_recent_trade = "BUY TO CLOSE"
                most_recent_trade_date = index
                # print("Close short at " + str(day["close"])+ " on " + str(index))

                # print(day['delta_slopes'])

                shares = capital / day['close']
                capital = 0
                position_opened = index
                most_recent_trade = "BUY"
                most_recent_trade_date = index
                trade = 0
                buy = True
                adj_close_df.at[index, "trade"] = 0
                adj_close_df.at[index, "buy"] = True
                # print(index, "\tClose Short/Buy\t", day['close'])
                # print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
                # print(day['volatility_means'], day['volatility_means_delta_slopes'], day['volatility_means_raw_slopes'], o3['zone_classification'][index])
                anchor_price = 0
      if not np.isnan(day['price_means_raw_slopes']) and not np.isnan(day['price_means_delta_slopes']):
        try:
          if vol_df is not None:
            if not np.isnan(vol_df['volatility_means_delta_slopes'][index]):
              if vol_df['buy'][index] == adj_close_df['buy'][index]:
                # print(index, adj_close_df['buy'][index])
                time_series.append(
                  {'date': str(index), 'values': {'price_slope': Decimal(str(day['price_means_raw_slopes'])),
                                                  'price_accel': Decimal(str(day['price_means_delta_slopes'])),
                                                  'binary_direction': Decimal(
                                                    str(np.sign(day['price_means_raw_slopes']))),
                                                  'price_accel_significance': accel_significance,
                                                  'vol_slope': Decimal(
                                                    str(vol_df['volatility_means_raw_slopes'][index])),
                                                  'vol_accel': Decimal(
                                                    str(vol_df['volatility_means_delta_slopes'][index])),
                                                  'strong_trade': True},
                   'timestamp': timestamp})
              else:
                # print(index, vol_df['buy'][index],adj_close_df['buy'][index])
                time_series.append(
                  {'date': str(index), 'values': {'price_slope': Decimal(str(day['price_means_raw_slopes'])),
                                                  'price_accel': Decimal(str(day['price_means_delta_slopes'])),
                                                  'binary_direction': Decimal(
                                                    str(np.sign(day['price_means_raw_slopes']))),
                                                  'price_accel_significance': accel_significance,
                                                  'vol_slope': Decimal(
                                                    str(vol_df['volatility_means_raw_slopes'][index])),
                                                  'vol_accel': Decimal(
                                                    str(vol_df['volatility_means_delta_slopes'][index])),
                                                  'strong_trade': False},
                   'timestamp': timestamp})
            else:
              if vol_df['buy'][index] == adj_close_df['buy'][index]:
                # print(index, adj_close_df['buy'][index])
                time_series.append(
                  {'date': str(index), 'values': {'price_slope': Decimal(str(day['price_means_raw_slopes'])),
                                                  'price_accel': Decimal(str(day['price_means_delta_slopes'])),
                                                  'binary_direction': Decimal(
                                                    str(np.sign(day['price_means_raw_slopes']))),
                                                  'price_accel_significance': accel_significance,
                                                  'strong_trade': True},
                   'timestamp': timestamp})
              else:
                # print(index, vol_df['buy'][index], adj_close_df['buy'][index])
                time_series.append(
                  {'date': str(index), 'values': {'price_slope': Decimal(str(day['price_means_raw_slopes'])),
                                                  'price_accel': Decimal(str(day['price_means_delta_slopes'])),
                                                  'binary_direction': Decimal(
                                                    str(np.sign(day['price_means_raw_slopes']))),
                                                  'price_accel_significance': accel_significance,
                                                  'strong_trade': False},
                   'timestamp': timestamp})
          else:
            time_series.append(
              {'date': str(index), 'values': {'price_slope': Decimal(str(day['price_means_raw_slopes'])),
                                              'price_accel': Decimal(str(day['price_means_delta_slopes'])),
                                              'binary_direction': Decimal(
                                                str(np.sign(day['price_means_raw_slopes']))),
                                              'price_accel_significance': accel_significance,
                                              'strong_trade': False},
               'timestamp': timestamp})
        except KeyError as e:
          print(e)
          # time_series.append(
          #   {'date': str(index), 'values': {'price_slope': Decimal(str(day['price_means_raw_slopes'])),
          #                                   'price_accel': Decimal(str(day['price_means_delta_slopes'])),
          #                                   'binary_direction': Decimal(
          #                                     str(np.sign(day['price_means_raw_slopes']))),
          #                                   'price_accel_significance': accel_significance,
          #                                   'strong_trade': False},
          #    'timestamp': timestamp})

        # Shorting can just be short selling immediately following a sale (fully reverse position)



        # # if int(day_count / delta_t) > 1:
        #   # print(len(delta_slopes), int(day_count / delta_t))
        #   # print(len(raw_slopes), int(day_count / delta_t))
        #   # print(len(adj_close_df)/5)
        #   # time_series.append(
        #   #   {"date": index, "timestamp": timestamp, "slope": raw_slopes[int(day_count / delta_t) - 1], "accel": Decimal(delta_slopes[(int(day_count / delta_t)) - 2])})
        # # else:
        # #   time_series.append({"date": index, "timestamp": timestamp, "slope": raw_slopes[int(day_count / delta_t) - 1], "accel": Decimal("NaN")})
        # try:
        #   if adj_close_df['raw_slopes'][index] > 0 and pos_streak > 0:
        #     pos_streak += 1
        #   elif adj_close_df['raw_slopes'][index] > 0 and neg_streak > 0:
        #     neg_streaks.append(neg_streak)
        #     neg_streak = 0
        #     pos_streak = 1
        #     if index >= zero_day and index <= end_day:
        #       if shares == 0 and short_shares == 0:
        #         shares = capital / day['close']
        #         capital = 0
        #         position_opened = index
        #         most_recent_trade = "BUY"
        #         most_recent_trade_date = index
        #         adj_close_df.at[index, "trade"] = 0
        #         adj_close_df.at[index, "buy"] = True
        #         print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
        #         anchor_price = 0
        #       #  Force close a short position when its indicated that it is time to buy
        #       elif short_shares != 0 and shares == 0:
        #         capital -= short_shares * day["close"]
        #         short_shares = 0
        #         shares = capital / day['close']
        #         capital = 0
        #         position_opened = index
        #         most_recent_trade = "BUY"
        #         most_recent_trade_date = index
        #         adj_close_df.at[index, "trade"] = 0
        #         adj_close_df.at[index, "buy"] = True
        #         print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
        #   elif adj_close_df['raw_slopes'][index] < 0 and pos_streak > 0:
        #     pos_streaks.append(pos_streak)
        #     neg_streak = 1
        #     pos_streak = 0
        #     if anchor_price != 0:
        #       if (day["avgs"]-anchor_price)/anchor_price < x[0]:
        #         if shares != 0:
        #           capital = shares * day["close"]
        #           shares = 0
        #           most_recent_trade = "SELL TO CLOSE"
        #           most_recent_trade_date = index
        #           print("Sold " + str(day["close"]) + " on " + str(index), " \tanchor price was ", anchor_price)
        #
        #     # TODO: FIX SHORTING ALGO. STATUS: DONE
        #     # if index >= zero_day and index <= end_day:
        #     #   if short_shares == 0 and shares == 0:
        #     #     short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
        #     #     capital += short_shares * day['close']
        #     #     position_opened = index
        #     #     most_recent_trade = "SHORT"
        #     #     most_recent_trade_date = index
        #     #     adj_close_df.at[index, "trade"] = 1
        #     #     adj_close_df.at[index, "short"] = True
        #     #     print("Short at " + str(day["close"]) + " on " + str(index))
        #   elif adj_close_df['raw_slopes'][index] < 0 and neg_streak > 0:
        #     neg_streak += 1
        #     # if anchor_price != 0:
        #     #   if (day["avgs"]-anchor_price)/anchor_price < x[0]:
        #     #     if shares != 0:
        #     #       capital = shares * day["close"]
        #     #       shares = 0
        #     #       most_recent_trade = "SELL TO CLOSE"
        #     #       most_recent_trade_date = index
        #     #       print("Sold " + str(day["close"]) + " on " + str(index), " \tanchor price was ", anchor_price)
        #   elif pos_streak == 0 and neg_streak == 0:
        #     if adj_close_df['raw_slopes'][index] > 0:
        #       pos_streak += 1
        #       # if index >= zero_day and index <= end_day:
        #       #   shares = capital / day["close"]
        #       #   capital = 0
        #       #   position_opened = index
        #       #   most_recent_trade = "BUY"
        #       #   most_recent_trade_date = index
        #       #   adj_close_df.at[index, "trade"] = 0
        #       #   adj_close_df.at[index, "buy"] = True
        #       #   print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
        #     else:
        #       neg_streak += 1
        #       # if index >= exchange:
        #       #   short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
        #       #   capital += short_shares * day['close']
        #
        #   # TODO: do delta_slopes need to be -2 instead of -1? UPDATE: I dont think so
        #   # The below change addresses the above issue
        #   # if index != position_opened:
        #   #   if (np.sign(adj_close_df['raw_slopes'][index - (delta_t)]) > np.sign(adj_close_df['raw_slopes'][index]) and (adj_close_df['delta_slopes'][index] -
        #   #                                                          adj_close_df['delta_slopes'][day_count - (4*delta_t)-1]) < x[0] and capital == 0:
        #   #     if index >= zero_day and index <= end_day:
        #   #       dif_delt.append(adj_close_df['delta_slopes'][index] -
        #   #                       adj_close_df['delta_slopes'][day_count - (4*delta_t)-1])
        #   #       capital = shares * day["close"]
        #   #       shares = 0
        #   #       most_recent_trade = "SELL TO CLOSE"
        #   #       most_recent_trade_date = index
        #   #       most_recent_trade_metrics.update(
        #   #         {"slopes": raw_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       most_recent_trade_metrics.update(
        #   #         {"delta_slopes": delta_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       adj_close_df.at[index, "trade"] = 2
        #   #       adj_close_df.at[index, "sell_to_close"] = True
        #   #       print("Sold " + str(day["close"])+ " on " + str(index))
        #   #       lst_sell.append(adj_close_df['delta_slopes'][index] -
        #   #                                                          adj_close_df['delta_slopes'][day_count - (4*delta_t)-1])
        #   #       # print()
        #   #   if (adj_close_df['delta_slopes'][index] >
        #   #       adj_close_df['delta_slopes'][day_count - (4*delta_t)-1]) and (adj_close_df['delta_slopes'][index] - adj_close_df['delta_slopes'][day_count - (4*delta_t)-1]) > x[1] and short_shares != 0:  # Test the <.1 more
        #   #     if index >= zero_day and index <= end_day:
        #   #       dif_delt.append(adj_close_df['delta_slopes'][index] -
        #   #                       adj_close_df['delta_slopes'][day_count - (4*delta_t)-1])
        #   #       capital -= short_shares * day["close"]
        #   #       short_shares = 0
        #   #       most_recent_trade = "BUY TO CLOSE"
        #   #       most_recent_trade_date = index
        #   #       most_recent_trade_metrics.update(
        #   #         {"slopes": raw_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       most_recent_trade_metrics.update(
        #   #         {"delta_slopes": delta_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       adj_close_df.at[index, "trade"] = 3
        #   #       adj_close_df.at[index, "buy_to_close"] = True
        #   #       print("Close short at " + str(day["close"])+ " on " + str(index))
        # except IndexError as e:
        #   print(e)
      # day_count += 1
    # self.graph(adj_close_df, symbol)
    ending_pos = ""
    if capital == 0:
      capital = shares * adj_close_df["close"][end_day]
      ending_pos = "long"
      # print("MM Guidance: In Long Position")
    if short_shares != 0:
      capital -= short_shares * adj_close_df["close"][end_day]
      shares = 0
      ending_pos = "short"
      # print("MM Guidance: In Short Position")
    # print("MM Last 5 delta slopes & slopes", delta_slopes[-1], raw_slopes[-2:])

    buy_hold = (1000 / adj_close_df["close"][zero_day]) * adj_close_df["close"][end_day]
    # print(np.median(lst_sell))

    # print(std_pos, np.mean(adj_close_df['pos_streaks']), std_neg, np.mean(adj_close_df['neg_streaks']))
    v = -1
    if time_series:
      if most_recent_trade == "BUY":
        v = 100
      elif most_recent_trade == "SELL":
        v = 0
      if time_series[-1]['values']['strong_trade']:
        most_recent_trade = "STRONG" + most_recent_trade
    else:
      v = -1
    ret_object = {"symbol": symbol, "timeseries": time_series,
                  "last_recommendation": {"date": str(most_recent_trade_date), "action": most_recent_trade}, 'value': v}


    if sign:
      return sign * capital
    else:
      return (capital - buy_hold) / buy_hold * 100, capital, buy_hold, ret_object

  def acceleration_test_September(self, x, symbol, exchange, zero_day=None, start_flag=False, end_day=None, delta_t=5, prices=None, sign=None):
    # self._logger.info(symbol)

    # start = time.time()
    if prices is None:
      adj_close_df = self.get_prices("barchart", symbol)
      # print(time.time()-start)
    else:
      adj_close_df = prices

    # start = time.time()
    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    # print(time.time() - start)
    # adj_close_df['volume_means'] = self.kalman_filter(adj_close_df['volume'])

    # start = time.time()
    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]
    # print(time.time() - start)

    if zero_day is None or start_flag:
      zero_day = adj_close_df.index[0]
    if end_day is None:
      end_day = adj_close_df.index[-1]
    else:
      adj_close_df = adj_close_df[:end_day]

    # start = time.time()
    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df))
    # print(time.time() - start)

    # adj_close_df['volatility'] = np.nan

    # dd = DynamoAccessor()
    # guid = self.mapping_accessor.query_symbol_exchange_mappings(symbol)[0]['guid']
    # volatility = self.dd._query_table(
    #   'SBT_HISTORICAL_VOLATILITY_BARCHART',
    #   'guid', guid)
    #
    # i = 0
    # for v in volatility:
    #   adj_close_df.at[v['date'], "volatility"] = float(v['values']['value'])
    #   if np.isnan(float(v['values']['value'])):
    #     i += 1

    # o3 = pd.DataFrame(index=adj_close_df.index, columns=['red_zone', 'yellow_zone', 'zone_classification'])
    # o3['zone_classification'] = "None"
    # hv_timeseries = self.mapping_accessor._query_table('SBT_HISTORICAL_VOLATILITY_BARCHART', 'guid', symbol['guid'])
    # hv_lst = [float(volatility[x]['values']['value']) for x in range(len(volatility))]
    # hv_df = pd.DataFrame([x['values']['value'] for x in volatility], [x['date'] for x in volatility])
    # # self._logger.info(symbol['symbol'])
    # if hv_lst and len(adj_close_df.values.tolist()) > 521:
    #   # adj_close_df = adj_close_df.truncate(after=volatility[-1]['date'])
    #   adj_close_lst = adj_close_df["close"].values.tolist()
    #   # averageVQ = np.convolve(hv_lst, np.ones((7560,)) / 7560, mode='valid') # used to be 756
    #   averageVQ = hv_df.rolling(7650).mean()
    #   if np.isnan(averageVQ[0].iloc[-1]):
    #     averageVQ = hv_df.rolling(len(hv_df)).mean()
    #   vq_ratio = (hv_lst[-1] - averageVQ[0].iloc[-1]) / averageVQ[0].iloc[-1]
    #   if len(hv_lst) >= 521:
    #     o3 = self.buy_sell.o3_timeseries(adj_close_lst, hv_lst, adj_close_df)

    # while np.isnan(float(adj_close_df['volatility'][i])):

    # adj_close_df['volatility_means'] = np.nan
    # vol_means = self.kalman_filter(adj_close_df['volatility'][i:]).flatten()
    # xy = 0
    # for index, d in adj_close_df[i:].iterrows():
    #   adj_close_df.at[index, "volatility_means"] = vol_means[xy]
    #   xy += 1

    # avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df),
    #                                                                        column='volatility_means')
    # mp = MappingAccessor()
    # guid = mp.query_symbol_exchange_mappings(symbol)[0]['guid']

    symbol_info = self.dd._query_table("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", "symbol", symbol, 'exchange', exchange)[0]
    guid = symbol_info['guid']
    # print(time.time() - start)
    # try:
      # vol_df = self.vol_strategy_2([-0.04832031, -0.3765332], symbol, guid,
      #                              zero_day=None, start_flag=True, end_day=None, delta_t=delta_t)[-1]
    # except Exception as e:
    #   vol_df = None
    #   print(e)
    vol_df = None

    pos_streak = 0
    neg_streak = 0
    pos_streaks = []
    neg_streaks = []
    shares = 1000 / adj_close_df["close"][zero_day]
    # print(str(zero_day), "\tBuy\t", adj_close_df["close"][zero_day])
    # print("Bought " + str(shares) + " at " + str(adj_close_df["close"][zero_day]) + " on " + str(zero_day))
    short_shares = 0
    capital = 0
    dif_delt = []
    # day_count = 1  # changed from 0 to 1 bc 0 creates off by one day
    position_opened = ''
    most_recent_trade = "BUY"
    most_recent_trade_date = zero_day
    most_recent_trade_metrics = {}
    time_series = []
    # adj_close_df["trade"] = np.nan
    # adj_close_df["buy"] = False
    # adj_close_df["short"] = False
    # adj_close_df["sell_to_close"] = False
    # adj_close_df["buy_to_close"] = False
    # adj_close_df['pos_streaks'] = np.nan
    # adj_close_df['neg_streaks'] = np.nan
    # buy_arr = np.full(len(adj_close_df), False)
    buy_count = 0
    anchor_price = -1
    trade = 0
    buy = True
    # max_price = adj_close_df["close"][zero_day]
    # start = time.time()
    for i, (tup) in enumerate(zip(adj_close_df['close'], adj_close_df.index, adj_close_df['price_means_delta_slopes'], adj_close_df['price_means_raw_slopes'], adj_close_df['price_means_avgs'])):
      # print(tup)
      start = time.time()
      loc = i
      # adj_close_df.at[tup[1], "trade"] = trade
      # buy_arr[i] = buy  # Double check that this does what the below line does
      # adj_close_df.at[tup[1], "buy"] = buy
            # print(time.time()-start)
      if (loc + 1) % delta_t == 0:
        # start = time.time()
        # timestamp = Decimal(str(time.mktime(datetime.datetime.strptime(str(tup[1]),
        #                                                                "%Y-%m-%d").timetuple())))
        # print("Datetime", time.time() - start)
        # start = time.time()
        timestamp = Decimal(str(time.mktime(ciso8601.parse_datetime(str(tup[1])).timetuple())))
        # print("ciso", time.time() - start)
        # Count streaks for disribution purposes
        # if adj_close_df['price_means_raw_slopes'][index] > 0 and pos_streak > 0:
        #   pos_streak += 1
        # elif adj_close_df['price_means_raw_slopes'][index] > 0 and neg_streak > 0:
        #   adj_close_df.at[index, "neg_streaks"] = neg_streak
        #   neg_streaks.append(neg_streak)
        #   neg_streak = 0
        #   pos_streak = 1
        # elif adj_close_df['price_means_raw_slopes'][index] < 0 and pos_streak > 0:
        #   adj_close_df.at[index, "pos_streaks"] = pos_streak
        #   pos_streaks.append(pos_streak)
        #   neg_streak = 1
        #   pos_streak = 0
        # elif adj_close_df['price_means_raw_slopes'][index] < 0 and neg_streak > 0:
        #   neg_streak += 1
        # elif pos_streak == 0 and neg_streak == 0:
        #   if adj_close_df['price_means_raw_slopes'][index] > 0:
        #     pos_streak += 1
        #   else:
        #     neg_streak += 1
        # start = time.time()
        part_df = adj_close_df[:loc]
        # std_df = part_df.std()
        # std_delta_slopes = std_df['price_means_delta_slopes']
        std_delta_slopes = part_df['price_means_delta_slopes'].std()
        # std_pos = std_df['pos_streaks']
        # std_neg = std_df['neg_streaks']

        two_sigma = std_delta_slopes * 2
        # two_sigma_vol = std_vol_delta_slopes
        accel_significance = "normal"
        # vol_significance = "normal"
        # TODO: IS THIS RIGHT??? MAYBE SHOULD BE < mew - two_sigma
        if tup[2] > two_sigma or tup[2] < -two_sigma:
          accel_significance = "significant"
        # if day["volatility_means"] > vol_avg + two_sigma_vol:
        #   vol_significance = "significant"
        # print(1.5 * std_delta_slopes, 2 * std_delta_slopes, 3 * std_delta_slopes)

        # Can't put nan in dynamodb
        # elif not np.isnan(day['raw_slopes']):
        #   time_series.append({'date': str(index), 'slope': Decimal(day['raw_slopes']), 'accel': Decimal(np.nan), 'timestamp': timestamp})
        # elif not np.isnan(day['delta_slopes']):
        #   time_series.append(
        #     {'date': str(index), 'slope': Decimal(np.nan), 'accel': Decimal(day['delta_slopes']), 'timestamp': timestamp})
        # print(time.time()-start)
        if (loc + 1) > (delta_t * 2) and len(part_df) > 350:
          if tup[1] >= zero_day and tup[1] <= end_day:
            if shares == 0 and tup[1] != position_opened:
              if tup[1] >= zero_day and tup[1] <= end_day:
                if (tup[4] - anchor_price) / anchor_price >= x[0]:
                  capital -= short_shares * tup[0]
                  short_shares = 0
                  most_recent_trade = "BUY TO CLOSE"
                  most_recent_trade_date = tup[1]
                  # print("Close short at " + str(day["close"])+ " on " + str(index))

                  # print(day['delta_slopes'])

                  shares = capital / tup[0]
                  capital = 0
                  position_opened = tup[1]
                  most_recent_trade = "BUY"
                  most_recent_trade_date = tup[1]
                  trade = 0
                  buy = True
                  # adj_close_df.at[tup[1], "trade"] = 0
                  # buy_arr[i] = True
                  # adj_close_df.at[tup[1], "buy"] = True
                  # print(index, "\tClose Short/Buy\t", day['close'])
                  # print(shares)
                  # print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
                  # print(day['volatility_means'], day['volatility_means_delta_slopes'], day['volatility_means_raw_slopes'], o3['zone_classification'][index])

              # if np.sign(adj_close_df["price_means_raw_slopes"][index]) < np.sign(adj_close_df["price_means_raw_slopes"][loc-delta_t]):
              buy_count = 0
            if tup[4] < anchor_price:
              if tup[1] >= zero_day and tup[1] <= end_day:
                anchor_price = tup[4]

            # Note: -3 produces best results. -2.5 increases frequency of trades slightly, while also decreasing the return
            elif tup[2] < -3 * std_delta_slopes and np.sign(tup[3]) < 0:
              if tup[1] >= zero_day and tup[1] <= end_day:
                if shares != 0 and anchor_price != 0:
                  buy_count = 0
                  capital = shares * tup[0]
                  shares = 0
                  most_recent_trade = "SELL TO CLOSE"
                  most_recent_trade_date = tup[1]
                  # print("Sold " + str(day["close"]) + " on " + str(index), " \tanchor price was ", anchor_price)
                  position_opened = tup[1]

                  if short_shares == 0 and shares == 0:
                    short_shares = (capital / 2) / tup[0]  # only allow half of capital to be shorted
                    capital += short_shares * tup[0]
                    position_opened = tup[1]
                    most_recent_trade = "SHORT"
                    most_recent_trade_date = tup[1]
                    # print("Short at " + str(day["close"]) + " on " + str(index))
                    # print(day['volatility_means'], day['volatility_means_delta_slopes'],
                    #       day['volatility_means_raw_slopes'], o3['zone_classification'][index])
                    trade = 1
                    buy = False
                    # adj_close_df.at[tup[1], "trade"] = trade
                    # buy_arr[i] = buy
                    # adj_close_df.at[tup[1], "buy"] = buy
                    # print(index, "\tSell/Short\t", day['close'])
                    # print(capital)
                  anchor_price = 10000

          if not np.isnan(tup[3]) and not np.isnan(tup[2]):
            try:
              # if vol_df is not None:
              #   if not np.isnan(vol_df['volatility_means_delta_slopes'][tup[1]]):
              #     if vol_df['buy'][tup[1]] == adj_close_df['buy'][tup[1]]:
              #       # print(index, adj_close_df['buy'][index])
              #       time_series.append(
              #         {'date': str(tup[1]), 'guid': guid, 'values': {'price_slope': Decimal(str(tup[3])),
              #                                         'price_accel': Decimal(str(tup[2])),
              #                                         'binary_direction': Decimal(
              #                                           str(np.sign(tup[3]))),
              #                                         'price_accel_significance': accel_significance,
              #                                         'vol_slope': Decimal(
              #                                           str(vol_df['volatility_means_raw_slopes'][tup[1]])),
              #                                         'vol_accel': Decimal(
              #                                           str(vol_df['volatility_means_delta_slopes'][tup[1]])),
              #                                         'strong_trade': True},
              #          'timestamp': timestamp})
              #     else:
              #       # print(index, vol_df['buy'][index],adj_close_df['buy'][index])
              #       time_series.append(
              #         {'date': str(tup[1]), 'guid': guid, 'values': {'price_slope': Decimal(str(tup[3])),
              #                                         'price_accel': Decimal(str(tup[2])),
              #                                         'binary_direction': Decimal(
              #                                           str(np.sign(tup[3]))),
              #                                         'price_accel_significance': accel_significance,
              #                                         'vol_slope': Decimal(
              #                                           str(vol_df['volatility_means_raw_slopes'][tup[1]])),
              #                                         'vol_accel': Decimal(
              #                                           str(vol_df['volatility_means_delta_slopes'][tup[1]])),
              #                                         'strong_trade': False},
              #          'timestamp': timestamp})
              #   else:
              #     if vol_df['buy'][tup[1]] == adj_close_df['buy'][tup[1]]:
              #       # print(index, adj_close_df['buy'][index])
              #       time_series.append(
              #         {'date': str(tup[1]), 'guid': guid, 'values': {'price_slope': Decimal(str(tup[3])),
              #                                         'price_accel': Decimal(str(tup[2])),
              #                                         'binary_direction': Decimal(
              #                                           str(np.sign(tup[3]))),
              #                                         'price_accel_significance': accel_significance,
              #                                         'strong_trade': True},
              #          'timestamp': timestamp})
              #     else:
              #       # print(index, vol_df['buy'][index], adj_close_df['buy'][index])
              #       time_series.append(
              #         {'date': str(tup[1]), 'guid': guid, 'values': {'price_slope': Decimal(str(tup[3])),
              #                                         'price_accel': Decimal(str(tup[2])),
              #                                         'binary_direction': Decimal(
              #                                           str(np.sign(tup[3]))),
              #                                         'price_accel_significance': accel_significance,
              #                                         'strong_trade': False},
              #          'timestamp': timestamp})
              # else:
              trade = None
              if most_recent_trade_date == tup[1]:
                trade = most_recent_trade
              time_series.append(
                {'date': str(tup[1]), 'guid': guid, 'values': {'price_slope': float(tup[3]),
                                                'price_accel': float(tup[2]),
                                                'binary_direction': float(np.sign(tup[3])),
                                                'price_accel_significance': accel_significance,
                                                'strong_trade': False, 'trade': trade},
                 'timestamp': float(timestamp)})
            except KeyError as e:
              print(e)
              # time_series.append(
              #   {'date': str(index), 'values': {'price_slope': Decimal(str(day['price_means_raw_slopes'])),
              #                                   'price_accel': Decimal(str(day['price_means_delta_slopes'])),
              #                                   'binary_direction': Decimal(
              #                                     str(np.sign(day['price_means_raw_slopes']))),
              #                                   'price_accel_significance': accel_significance,
              #                                   'strong_trade': False},
              #    'timestamp': timestamp})

        # Shorting can just be short selling immediately following a sale (fully reverse position)

        # # if int(day_count / delta_t) > 1:
        #   # print(len(delta_slopes), int(day_count / delta_t))
        #   # print(len(raw_slopes), int(day_count / delta_t))
        #   # print(len(adj_close_df)/5)
        #   # time_series.append(
        #   #   {"date": index, "timestamp": timestamp, "slope": raw_slopes[int(day_count / delta_t) - 1], "accel": Decimal(delta_slopes[(int(day_count / delta_t)) - 2])})
        # # else:
        # #   time_series.append({"date": index, "timestamp": timestamp, "slope": raw_slopes[int(day_count / delta_t) - 1], "accel": Decimal("NaN")})
        # try:
        #   if adj_close_df['raw_slopes'][index] > 0 and pos_streak > 0:
        #     pos_streak += 1
        #   elif adj_close_df['raw_slopes'][index] > 0 and neg_streak > 0:
        #     neg_streaks.append(neg_streak)
        #     neg_streak = 0
        #     pos_streak = 1
        #     if index >= zero_day and index <= end_day:
        #       if shares == 0 and short_shares == 0:
        #         shares = capital / day['close']
        #         capital = 0
        #         position_opened = index
        #         most_recent_trade = "BUY"
        #         most_recent_trade_date = index
        #         adj_close_df.at[index, "trade"] = 0
        #         adj_close_df.at[index, "buy"] = True
        #         print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
        #         anchor_price = 0
        #       #  Force close a short position when its indicated that it is time to buy
        #       elif short_shares != 0 and shares == 0:
        #         capital -= short_shares * day["close"]
        #         short_shares = 0
        #         shares = capital / day['close']
        #         capital = 0
        #         position_opened = index
        #         most_recent_trade = "BUY"
        #         most_recent_trade_date = index
        #         adj_close_df.at[index, "trade"] = 0
        #         adj_close_df.at[index, "buy"] = True
        #         print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
        #   elif adj_close_df['raw_slopes'][index] < 0 and pos_streak > 0:
        #     pos_streaks.append(pos_streak)
        #     neg_streak = 1
        #     pos_streak = 0
        #     if anchor_price != 0:
        #       if (day["avgs"]-anchor_price)/anchor_price < x[0]:
        #         if shares != 0:
        #           capital = shares * day["close"]
        #           shares = 0
        #           most_recent_trade = "SELL TO CLOSE"
        #           most_recent_trade_date = index
        #           print("Sold " + str(day["close"]) + " on " + str(index), " \tanchor price was ", anchor_price)
        #
        #     # TODO: FIX SHORTING ALGO. STATUS: DONE
        #     # if index >= zero_day and index <= end_day:
        #     #   if short_shares == 0 and shares == 0:
        #     #     short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
        #     #     capital += short_shares * day['close']
        #     #     position_opened = index
        #     #     most_recent_trade = "SHORT"
        #     #     most_recent_trade_date = index
        #     #     adj_close_df.at[index, "trade"] = 1
        #     #     adj_close_df.at[index, "short"] = True
        #     #     print("Short at " + str(day["close"]) + " on " + str(index))
        #   elif adj_close_df['raw_slopes'][index] < 0 and neg_streak > 0:
        #     neg_streak += 1
        #     # if anchor_price != 0:
        #     #   if (day["avgs"]-anchor_price)/anchor_price < x[0]:
        #     #     if shares != 0:
        #     #       capital = shares * day["close"]
        #     #       shares = 0
        #     #       most_recent_trade = "SELL TO CLOSE"
        #     #       most_recent_trade_date = index
        #     #       print("Sold " + str(day["close"]) + " on " + str(index), " \tanchor price was ", anchor_price)
        #   elif pos_streak == 0 and neg_streak == 0:
        #     if adj_close_df['raw_slopes'][index] > 0:
        #       pos_streak += 1
        #       # if index >= zero_day and index <= end_day:
        #       #   shares = capital / day["close"]
        #       #   capital = 0
        #       #   position_opened = index
        #       #   most_recent_trade = "BUY"
        #       #   most_recent_trade_date = index
        #       #   adj_close_df.at[index, "trade"] = 0
        #       #   adj_close_df.at[index, "buy"] = True
        #       #   print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
        #     else:
        #       neg_streak += 1
        #       # if index >= exchange:
        #       #   short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
        #       #   capital += short_shares * day['close']
        #
        #   # TODO: do delta_slopes need to be -2 instead of -1? UPDATE: I dont think so
        #   # The below change addresses the above issue
        #   # if index != position_opened:
        #   #   if (np.sign(adj_close_df['raw_slopes'][index - (delta_t)]) > np.sign(adj_close_df['raw_slopes'][index]) and (adj_close_df['delta_slopes'][index] -
        #   #                                                          adj_close_df['delta_slopes'][day_count - (4*delta_t)-1]) < x[0] and capital == 0:
        #   #     if index >= zero_day and index <= end_day:
        #   #       dif_delt.append(adj_close_df['delta_slopes'][index] -
        #   #                       adj_close_df['delta_slopes'][day_count - (4*delta_t)-1])
        #   #       capital = shares * day["close"]
        #   #       shares = 0
        #   #       most_recent_trade = "SELL TO CLOSE"
        #   #       most_recent_trade_date = index
        #   #       most_recent_trade_metrics.update(
        #   #         {"slopes": raw_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       most_recent_trade_metrics.update(
        #   #         {"delta_slopes": delta_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       adj_close_df.at[index, "trade"] = 2
        #   #       adj_close_df.at[index, "sell_to_close"] = True
        #   #       print("Sold " + str(day["close"])+ " on " + str(index))
        #   #       lst_sell.append(adj_close_df['delta_slopes'][index] -
        #   #                                                          adj_close_df['delta_slopes'][day_count - (4*delta_t)-1])
        #   #       # print()
        #   #   if (adj_close_df['delta_slopes'][index] >
        #   #       adj_close_df['delta_slopes'][day_count - (4*delta_t)-1]) and (adj_close_df['delta_slopes'][index] - adj_close_df['delta_slopes'][day_count - (4*delta_t)-1]) > x[1] and short_shares != 0:  # Test the <.1 more
        #   #     if index >= zero_day and index <= end_day:
        #   #       dif_delt.append(adj_close_df['delta_slopes'][index] -
        #   #                       adj_close_df['delta_slopes'][day_count - (4*delta_t)-1])
        #   #       capital -= short_shares * day["close"]
        #   #       short_shares = 0
        #   #       most_recent_trade = "BUY TO CLOSE"
        #   #       most_recent_trade_date = index
        #   #       most_recent_trade_metrics.update(
        #   #         {"slopes": raw_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       most_recent_trade_metrics.update(
        #   #         {"delta_slopes": delta_slopes[(int(day_count / delta_t)) - 5: (int(day_count / delta_t)) - 1]})
        #   #       adj_close_df.at[index, "trade"] = 3
        #   #       adj_close_df.at[index, "buy_to_close"] = True
        #   #       print("Close short at " + str(day["close"])+ " on " + str(index))
        # except IndexError as e:
        #   print(e)
      # print(time.time()-start)
      # day_count += 1
    # self.graph(adj_close_df, symbol)
    # print(time.time()-start)
    ending_pos = ""
    if capital == 0:
      capital = shares * adj_close_df["close"][end_day]
      ending_pos = "long"
      # print("MM Guidance: In Long Position")
    if short_shares != 0:
      capital -= short_shares * adj_close_df["close"][end_day]
      shares = 0
      ending_pos = "short"
      # print("MM Guidance: In Short Position")
    # print("MM Last 5 delta slopes & slopes", delta_slopes[-1], raw_slopes[-2:])

    buy_hold = (1000 / adj_close_df["close"][zero_day]) * adj_close_df["close"][end_day]
    # print(np.median(lst_sell))

    # print(std_pos, np.mean(adj_close_df['pos_streaks']), std_neg, np.mean(adj_close_df['neg_streaks']))
    v = -1
    if time_series:
      if most_recent_trade == "BUY":
        v = 100
      elif most_recent_trade == "SHORT":
        v = 0
      if time_series[-1]['values']['strong_trade']:
        most_recent_trade = "STRONG" + most_recent_trade
    else:
      v = -1
    ret_object = {"symbol": symbol, 'model_id': 'MM_MOMENTUM',
                  "last_recommendation": {"date": str(most_recent_trade_date), "action": most_recent_trade}, 'value': v,
                  "timeseries": time_series}
    # print(len(adj_close_df))

    if sign:
      return sign * capital
    else:
      return (capital - buy_hold) / buy_hold * 100, capital, buy_hold, ret_object, time_series, symbol_info

  def vol_strategy(self, x, symbol, guid, zero_day=None, start_flag=False, end_day=None, delta_t=5, prices=None, sign=None):
    self._logger.info(symbol)

    if prices is None:
      adj_close_df = self.get_prices("barchart", symbol)
    else:
      adj_close_df = prices

    adj_close_df['volatility'] = np.nan


    volatility = self.dd._query_table(
      'SBT_HISTORICAL_VOLATILITY_BARCHART',
      'guid', guid)

    for v in volatility:
      adj_close_df.at[v['date'], "volatility"] = v['values']['value']

    hv_lst = [float(volatility[x]['values']['value']) for x in range(len(volatility))]
    hv_df = pd.DataFrame([float(x['values']['value']) for x in volatility], [x['date'] for x in volatility])
    # self._logger.info(symbol['symbol'])
    if hv_lst and len(adj_close_df.values.tolist()) > 521:
      # adj_close_df = adj_close_df.truncate(after=volatility[-1]['date'])
      adj_close_lst = adj_close_df["close"].values.tolist()
      # averageVQ = np.convolve(hv_lst, np.ones((7560,)) / 7560, mode='valid') # used to be 756
      averageVQ = hv_df.rolling(7650).mean()
      if np.isnan(averageVQ[0].iloc[-1]):
        averageVQ = hv_df.rolling(len(hv_df)).mean()
      vq_ratio = (hv_lst[-1] - averageVQ[0].iloc[-1]) / averageVQ[0].iloc[-1]
      if len(hv_lst) >= 521:
        o3 = self.buy_sell.o3_timeseries(adj_close_lst, hv_lst, adj_close_df)

    adj_close_df['zone_classification'] = o3['zone_classification']

    # if volatility:
    #   sorted_volatility = sorted(volatility,
    #                              key=lambda k: k['date'],
    #                              reverse=True)


    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    adj_close_df['volume_means'] = self.kalman_filter(adj_close_df['volume'])
    i = 0
    while np.isnan(adj_close_df['volatility'][i]):
      i += 1
    adj_close_df['volatility_means'] = np.nan
    adj_close_df['volatility_means'][i:] = self.kalman_filter(adj_close_df['volatility'][i:]).flatten()  # TODO: FIX THIS

    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]

    if zero_day is None or start_flag:
      zero_day = adj_close_df.index[0]
    if end_day is None:
      end_day = adj_close_df.index[-1]
    else:
      adj_close_df = adj_close_df[:end_day]

    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df))

    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df), column='volatility_means')
    print()

    shares = 1000 / adj_close_df["close"][zero_day]
    print("Bought " + str(shares) + " at " + str(adj_close_df["close"][zero_day]) + " on " + str(zero_day))
    short_shares = 0
    capital = 0
    dif_delt = []
    delt_count = 0
    position_opened = 0
    most_recent_trade = "BUY"
    most_recent_trade_date = zero_day
    most_recent_trade_metrics = {}
    last_slopes_day = None
    time_series = []
    # avg = np.mean(adj_close_df['delta_slopes'])
    for index, d in adj_close_df.iterrows():
      loc = adj_close_df.index.get_loc(index)
      if index >= zero_day and index <= end_day:

          if (loc + 1) % delta_t == 0:
            last_slopes_day = d
          #   Decide to close a short position or not
          if shares == 0 and loc >= position_opened+(delta_t):
            if (adj_close_df['zone_classification'][index] == 'yellow' and (adj_close_df['volatility_means_delta_slopes'][index] <= .00001 and adj_close_df['volatility_means_delta_slopes'][index] >= -.00001)) or adj_close_df['zone_classification'][index] == 'red':
              capital -= short_shares * d["close"]
              short_shares = 0
              most_recent_trade = "BUY TO CLOSE"
              most_recent_trade_date = index
              print("Close short at " + str(d["close"])+ " on " + str(index))

              # print(day['delta_slopes'])

              shares = capital / d['close']
              capital = 0
              position_opened = loc
              most_recent_trade = "BUY"
              most_recent_trade_date = index
              adj_close_df.at[index, "trade"] = 0
              adj_close_df.at[index, "buy"] = True
              print("Bought " + str(shares) + " at " + str(d["close"]) + " on " + str(index))
              anchor_price = 0
            elif adj_close_df['zone_classification'][index] == 'green' and adj_close_df['zone_classification'][
              loc - 1] == 'green' and adj_close_df['zone_classification'][loc - 2] == 'green' and \
                adj_close_df['zone_classification'][loc - 3] == 'green' and adj_close_df['zone_classification'][
              loc - 4] == 'green':
              capital -= short_shares * d["close"]
              short_shares = 0
              most_recent_trade = "BUY TO CLOSE"
              most_recent_trade_date = index
              print("Close short at " + str(d["close"]) + " on " + str(index),
                    adj_close_df['volatility_means_delta_slopes'][index],
                    adj_close_df['price_means_delta_slopes'][index])

              # print(day['delta_slopes'])

              shares = capital / d['close']
              capital = 0
              position_opened = loc
              most_recent_trade = "BUY"
              most_recent_trade_date = index
              adj_close_df.at[index, "trade"] = 0
              adj_close_df.at[index, "buy"] = True
              print("Bought " + str(shares) + " at " + str(d["close"]) + " on " + str(index))
              anchor_price = 0

          if shares != 0 and loc >= position_opened+(delta_t):
            if adj_close_df['zone_classification'][index] == 'yellow' and adj_close_df['zone_classification'][
             loc - 1] == 'yellow' and adj_close_df['zone_classification'][loc - 2] == 'yellow' and \
               adj_close_df['zone_classification'][loc - 3] == 'green' and adj_close_df['zone_classification'][
             loc - 4] == 'green' and adj_close_df['zone_classification'][loc - 5] == 'green' and \
               adj_close_df['zone_classification'][loc - 6] == 'green' and adj_close_df['zone_classification'][
             loc - 7] == 'green' and\
                last_slopes_day['volatility_means_delta_slopes'] < .00009 and last_slopes_day['volatility_means_delta_slopes'] > -.00009 and last_slopes_day['volatility_means_raw_slopes'] < .00009 and last_slopes_day['volatility_means_raw_slopes'] > -.00009:
              capital = shares * d["close"]
              shares = 0
              most_recent_trade = "SELL TO CLOSE"
              most_recent_trade_date = index
              print("Sold " + str(d["close"]) + " on " + str(index), adj_close_df['volatility_means_delta_slopes'][index], adj_close_df['price_means_delta_slopes'][index])
              position_opened = index

              if short_shares == 0 and shares == 0:
                short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
                capital += short_shares * d['close']
                position_opened = loc
                most_recent_trade = "SHORT"
                most_recent_trade_date = index
                print("Short at " + str(d["close"]) + " on " + str(index))
      # if not np.isnan(d['delta_slopes']):
      #   delt_count += 1
      # if delt_count > 3:  # Gives kalman filter time to adjust
      #   if d['delta_slopes'] > x[0]:
      #     print(index, d['delta_slopes'], d["raw_slopes"], d['close'])
      #     # if index >= zero_day and index <= end_day:
      #     #   if shares == 0 and index != position_opened:
      #     #     capital -= short_shares * d["close"]
      #     #     short_shares = 0
      #     #     most_recent_trade = "BUY TO CLOSE"
      #     #     most_recent_trade_date = index
      #     #     print("Close short at " + str(d["close"])+ " on " + str(index))
      #     #
      #     #     # print(day['delta_slopes'])
      #     #
      #     #     shares = capital / d['close']
      #     #     capital = 0
      #     #     position_opened = index
      #     #     most_recent_trade = "BUY"
      #     #     most_recent_trade_date = index
      #     #     adj_close_df.at[index, "trade"] = 0
      #     #     adj_close_df.at[index, "buy"] = True
      #     #     print("Bought " + str(shares) + " at " + str(d["close"]) + " on " + str(index))
      #     #     anchor_price = 0
      #   elif d['delta_slopes'] < x[1]:
      #     print(index, d['delta_slopes'], d["raw_slopes"], d['close'])
      #     # if shares != 0:
      #     #   if index >= zero_day and index <= end_day:
      #     #       buy_count = 0
      #     #       capital = shares * d["close"]
      #     #       shares = 0
      #     #       most_recent_trade = "SELL TO CLOSE"
      #     #       most_recent_trade_date = index
      #     #       print("Sold " + str(d["close"]) + " on " + str(index))
      #     #       position_opened = index
      #     #
      #     #       if short_shares == 0 and shares == 0:
      #     #         short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
      #     #         capital += short_shares * d['close']
      #     #         position_opened = index
      #     #         most_recent_trade = "SHORT"
      #     #         most_recent_trade_date = index
      #     #         print("Short at " + str(d["close"]) + " on " + str(index))
    if capital == 0:
      capital = shares * adj_close_df["close"][end_day]
      ending_pos = "long"
      # print("MM Guidance: In Long Position")
    if short_shares != 0:
      capital -= short_shares * adj_close_df["close"][end_day]
      shares = 0
      ending_pos = "short"
      # print("MM Guidance: In Short Position")
    # print("MM Last 5 delta slopes & slopes", delta_slopes[-1], raw_slopes[-2:])

    buy_hold = (1000 / adj_close_df["close"][zero_day]) * adj_close_df["close"][end_day]
    # print(np.median(lst_sell))

    ret_object = {"symbol": symbol,"timeseries": time_series, "last_recommendation": {"date": str(most_recent_trade_date), "action": most_recent_trade}}



    if sign:
      return sign * capital
    else:
      return (capital - buy_hold) / buy_hold * 100, capital, buy_hold, ret_object

  def vol_strategy_2(self, x, symbol, guid, zero_day=None, start_flag=False, end_day=None, delta_t=5, prices=None, sign=None):
    self._logger.info(symbol)

    if prices is None:
      adj_close_df = self.get_prices("barchart", symbol)
    else:
      adj_close_df = prices

    adj_close_df['volatility'] = np.nan


    volatility = self.dd._query_table(
      'SBT_HISTORICAL_VOLATILITY_BARCHART',
      'guid', guid)

    for v in volatility:
      adj_close_df.at[v['date'], "volatility"] = v['values']['value']

    hv_lst = [float(volatility[x]['values']['value']) for x in range(len(volatility))]
    hv_df = pd.DataFrame([x['values']['value'] for x in volatility], [x['date'] for x in volatility])
    # self._logger.info(symbol['symbol'])
    if hv_lst and len(adj_close_df.values.tolist()) > 521:
      # adj_close_df = adj_close_df.truncate(after=volatility[-1]['date'])
      adj_close_lst = adj_close_df["close"].values.tolist()
      # averageVQ = np.convolve(hv_lst, np.ones((7560,)) / 7560, mode='valid') # used to be 756
      averageVQ = hv_df.rolling(7650).mean()
      if float(averageVQ[0].iloc[-1]):
        averageVQ = hv_df.rolling(len(hv_df)).mean()
      vq_ratio = (hv_lst[-1] - averageVQ[0].iloc[-1]) / averageVQ[0].iloc[-1]
      if len(hv_lst) >= 521:
        o3 = self.buy_sell.o3_timeseries(adj_close_lst, hv_lst, adj_close_df)

    adj_close_df['zone_classification'] = o3['zone_classification']

    # if volatility:
    #   sorted_volatility = sorted(volatility,
    #                              key=lambda k: k['date'],
    #                              reverse=True)


    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    adj_close_df['volume_means'] = self.kalman_filter(adj_close_df['volume'])
    i = 0
    while np.isnan(adj_close_df['volatility'][i]):
      i += 1
    adj_close_df['volatility_means'] = np.nan
    adj_close_df['volatility_means'][i:] = self.kalman_filter(adj_close_df['volatility'][i:]).flatten()  # TODO: FIX THIS

    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]

    if zero_day is None or start_flag:
      zero_day = adj_close_df.index[0]
    if end_day is None:
      end_day = adj_close_df.index[-1]
    else:
      adj_close_df = adj_close_df[:end_day]

    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df))

    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df), column='volatility_means')
    # print()

    # X = adj_close_df.iloc[:, [3, 8, 9, 11, 12]].values
    # for el in range(len(X)):
    #   if X[el][0] == 'green':
    #     X[el][0] = 0
    #   elif X[el][0] == 'yellow':
    #     X[el][0] = 1
    #   elif X[el][0] == 'red':
    #     X[el][0] = 2
    #   elif np.isnan(X[el][0]):
    #     X[el][0] = 10000
    #   if np.isnan(X[el][4]):
    #     X[el][1] = 10000
    #     X[el][2] = 10000
    #     X[el][3] = 10000
    #     X[el][4] = 10000
    #
    # # dendrogram = sch.dendrogram(sch.linkage(X, method='ward'))
    # model = AgglomerativeClustering(n_clusters=15, affinity='euclidean', linkage='ward')
    # model.fit(X)
    #
    # adj_close_df['cluster'] = model.labels_

    shares = 1000 / adj_close_df["close"][zero_day]
    # print("Bought " + str(shares) + " at " + str(adj_close_df["close"][zero_day]) + " on " + str(zero_day))
    # print(str(zero_day), "\tBuy\t", adj_close_df["close"][zero_day])

    # shares = 0
    short_shares = 0
    capital = 0
    dif_delt = []
    delt_count = 0
    position_opened = 0
    most_recent_trade = "BUY"
    most_recent_trade_date = zero_day
    most_recent_trade_metrics = {}
    last_slopes_day = None
    anchor_price = 0
    time_series = []
    red_streak = False
    red_trade = False
    trade = 0
    buy = True
    # avg = np.mean(adj_close_df['delta_slopes'])
    for index, d in adj_close_df.iterrows():
      loc = adj_close_df.index.get_loc(index)
      adj_close_df.at[index, "trade"] = trade
      adj_close_df.at[index, "buy"] = buy
      # if (d['cluster'] == 12) and d['zone_classification'] == 'red' and shares == 0:
      #   if short_shares != 0:
      #     capital -= short_shares * d["close"]
      #     short_shares = 0
      #     most_recent_trade = "BUY TO CLOSE"
      #     most_recent_trade_date = index
      #     print("Close short at on " + str(index), d['close'])
      #
      #
      #   # print("Buy", d['close'])
      #   shares = capital / d['close']
      #   capital = 0
      #   position_opened = loc
      #   most_recent_trade = "BUY"
      #   most_recent_trade_date = index
      #   adj_close_df.at[index, "trade"] = 0
      #   adj_close_df.at[index, "buy"] = True
      #   print("Bought on " + str(index), d['close'])
      #   print(shares)
      #   # print("long yellow streak", index)
      # elif (d['cluster'] == 5) and d['zone_classification'] == 'red' and short_shares == 0:
      #   # print("Short", d['close'])
      #   if shares != 0:
      #     capital = shares * d["close"]
      #     shares = 0
      #     most_recent_trade = "SELL TO CLOSE"
      #     most_recent_trade_date = index
      #     print("Sold " + str(d["close"]) + " on " + str(index), d['close'])
      #     position_opened = index
      #
      #
      #   short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
      #   capital += short_shares * d['close']
      #   position_opened = loc
      #   most_recent_trade = "SHORT"
      #   most_recent_trade_date = index
      #   print("Short on " + str(index), d['close'])
      #   # print("SHORT", index)

      if index >= zero_day and index <= end_day:
        loc = adj_close_df.index.get_loc(index)
        if index >= zero_day and index <= end_day:
          if adj_close_df['zone_classification'][index] == 'red' and not red_streak:
            red_streak = True
            if 'green' == adj_close_df['zone_classification'][loc - 2] and 'yellow' == \
                adj_close_df['zone_classification'][loc - 1] and short_shares == 0 and shares == 0:
              short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
              capital += short_shares * d['close']
              position_opened = loc
              most_recent_trade = "SHORT"
              most_recent_trade_date = index
              trade = 1
              buy = False
              adj_close_df.at[index, "trade"] = trade
              adj_close_df.at[index, "buy"] = buy
              # print(index, "\tShort\t", d['close'])
              # print("Short on " + str(index))
              # print("SHORT", index)
            elif 'green' in list(adj_close_df['zone_classification'][loc - 30:loc - 1]) and 'red' in list(
                adj_close_df['zone_classification'][loc - 15:loc - 1]) and short_shares == 0 and shares == 0:
              short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
              capital += short_shares * d['close']
              position_opened = loc
              most_recent_trade = "SHORT"
              most_recent_trade_date = index
              trade = 1
              buy = False
              adj_close_df.at[index, "trade"] = trade
              adj_close_df.at[index, "buy"] = buy
              # print(index, "\tShort\t", d['close'])
              # print("Short on " + str(index))
              # print("red to yellow back to red with green in sight = SHORT", index)
            elif 'green' not in list(adj_close_df['zone_classification'][loc - 30:loc - 1]) and 'red' in list(
                adj_close_df['zone_classification'][loc - 15:loc - 1]) and shares == 0 and short_shares == 0:
              shares = capital / d['close']
              capital = 0
              position_opened = loc
              most_recent_trade = "BUY"
              most_recent_trade_date = index
              adj_close_df.at[index, "trade"] = 0
              adj_close_df.at[index, "buy"] = True
              trade = 0
              buy = True
              adj_close_df.at[index, "trade"] = trade
              adj_close_df.at[index, "buy"] = buy
              # print(index, "\tBuy\t", d['close'])
              # print("Bought on " + str(index))
              # print("red to yellow back to red with no green in sight = BUY", index)
            elif 'green' not in list(adj_close_df['zone_classification'][loc - 30:loc - 1]) and np.nan not in list(
                adj_close_df['zone_classification'][loc - 30:loc - 1]) and shares == 0 and short_shares == 0:
              shares = capital / d['close']
              capital = 0
              position_opened = loc
              most_recent_trade = "BUY"
              most_recent_trade_date = index
              adj_close_df.at[index, "trade"] = 0
              adj_close_df.at[index, "buy"] = True
              trade = 0
              buy = True
              adj_close_df.at[index, "trade"] = trade
              adj_close_df.at[index, "buy"] = buy
              # print(index, "\tBuy\t", d['close'])
              # print("Bought on " + str(index))
              # print("long yellow streak", index)
            elif 'green' in list(adj_close_df['zone_classification'][loc - 13:loc - 3]) and all(x == 'yellow' for x in
                                                                                                adj_close_df[
                                                                                                  'zone_classification'][
                                                                                                loc - 3:loc - 1]) and shares == 0 and short_shares == 0:
              shares = capital / d['close']
              capital = 0
              position_opened = loc
              most_recent_trade = "BUY"
              most_recent_trade_date = index
              adj_close_df.at[index, "trade"] = 0
              adj_close_df.at[index, "buy"] = True
              trade = 0
              buy = True
              adj_close_df.at[index, "trade"] = trade
              adj_close_df.at[index, "buy"] = buy
              # print(index, "\tBuy\t", d['close'])
              # print("Bought on " + str(index))
          # this is new not in algo before
          # elif most_recent_trade == "BUY" and adj_close_df['zone_classification'][index] == 'red' and (
          #     adj_close_df['close'][index] - adj_close_df['close'][most_recent_trade_date]) / adj_close_df['close'][
          #   most_recent_trade_date] < -.15 and shares == 0 and short_shares == 0:
          #   red_streak = False
          #   capital = shares * d["close"]
          #   shares = 0
          #   most_recent_trade = "SELL TO CLOSE"
          #   most_recent_trade_date = index
          #   print("Sold " + str(d["close"]) + " on " + str(index))
          #   print("Capital:", capital)
          #   position_opened = index
          #
          #   short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
          #   capital += short_shares * d['close']
          #   position_opened = loc
          #   most_recent_trade = "SHORT"
          #   most_recent_trade_date = index
          #   print("Short on " + str(index))
          elif adj_close_df['zone_classification'][index] == 'red' and red_streak and short_shares != 0 and -.000009 < \
              adj_close_df['volatility_means_delta_slopes'][index] < 0 and 0 < \
              adj_close_df['volatility_means_raw_slopes'][index] < .0001:
            red_streak = False
            capital -= short_shares * d["close"]
            short_shares = 0
            most_recent_trade = "BUY TO CLOSE"
            most_recent_trade_date = index
            trade = 2
            buy = None
            adj_close_df.at[index, "trade"] = trade
            adj_close_df.at[index, "buy"] = buy
            # print(index, "\tClose Short\t", d['close'])
            # print("Close short at on " + str(index))
            # print("Capital:", capital)
          # elif adj_close_df['zone_classification'][index] != 'red' and shares != 0:
          #   red_streak = False
          #   capital = shares * d["close"]
          #   shares = 0
          #   most_recent_trade = "SELL TO CLOSE"
          #   most_recent_trade_date = index
          #   print("Sold " + str(d["close"]) + " on " + str(index))
          #   print("Capital:", capital)
          #   position_opened = index
          elif adj_close_df['zone_classification'][index] == 'green' and shares != 0 and -.000009 < \
              adj_close_df['volatility_means_delta_slopes'][index] < 0 and 0 < \
              adj_close_df['volatility_means_raw_slopes'][index] < .0001:
            red_streak = False
            capital = shares * d["close"]
            shares = 0
            most_recent_trade = "SELL TO CLOSE"
            most_recent_trade_date = index
            trade = 2
            buy = None
            adj_close_df.at[index, "trade"] = trade
            adj_close_df.at[index, "buy"] = buy
            # print(index, "\tSell\t", d['close'])
            # print("Sold " + str(d["close"]) + " on " + str(index))
            # print("Capital:", capital)
            position_opened = index
          elif adj_close_df['zone_classification'][index] != 'red' and short_shares != 0:
            red_streak = False
            capital -= short_shares * d["close"]
            short_shares = 0
            most_recent_trade = "BUY TO CLOSE"
            most_recent_trade_date = index
            trade = 2
            buy = None
            adj_close_df.at[index, "trade"] = trade
            adj_close_df.at[index, "buy"] = buy
            # print(index, "\tClose Short\t", d['close'])
            # print("Close short at on " + str(index))
            # print("Capital:", capital)
          elif adj_close_df['zone_classification'][index] != 'red':
            red_streak = False
    # self.graph(adj_close_df, symbol)
    # home = str(Path.home())
    # adj_close_df.to_csv(home + "/Desktop/cluster_algo_graphs/" + symbol + ".csv")
    if capital == 0:
      capital = shares * adj_close_df["close"][end_day]
      ending_pos = "long"
      # print("MM Guidance: In Long Position")
    if short_shares != 0:
      capital -= short_shares * adj_close_df["close"][end_day]
      shares = 0
      ending_pos = "short"
    # print("MM Last 5 delta slopes & slopes", delta_slopes[-1], raw_slopes[-2:])

    buy_hold = (1000 / adj_close_df["close"][zero_day]) * adj_close_df["close"][end_day]
    # print(np.median(lst_sell))

    ret_object = {"symbol": symbol,"timeseries": time_series, "last_recommendation": {"date": str(most_recent_trade_date), "action": most_recent_trade}}



    if sign:
      return sign * capital
    else:
      return (capital - buy_hold) / buy_hold * 100, capital, buy_hold, ret_object, adj_close_df

  def graph(self, adj_close_df, symbol):
    import matplotlib.pyplot as plt
    register_matplotlib_converters()
    adj_close_df['close'].plot(color='black')
    plt.title(symbol)
    prev_t = True
    prev_td = 0
    for index, d in adj_close_df.iterrows():
      loc = adj_close_df.index.get_loc(index)
      if (d['buy'] == True or d['buy'] is None) and (prev_t == False or prev_t == None):
        plt.axvspan(prev_td, loc, facecolor='red', alpha=1)
        prev_td = loc
        prev_t = d['buy']
      elif (d['buy'] == False or d['buy'] is None) and (prev_t == True or prev_t == None):
        plt.axvspan(prev_td, loc, facecolor='green', alpha=.7)
        prev_td = loc
        prev_t = d['buy']
      elif loc == len(adj_close_df) - 1 and d['buy'] == False:
        plt.axvspan(prev_td, loc, facecolor='red', alpha=1)
      elif loc == len(adj_close_df) - 1 and d['buy'] == True:
        plt.axvspan(prev_td, loc, facecolor='green', alpha=.7)
      else:
        prev_t = d['buy']
    plt.show()
    home = str(Path.home())
    fig = plt.gcf()
    fig.set_size_inches((15, 11), forward=False)
    # fig.save(figName, dpi=500)
    plt.savefig(home + "/Desktop/cluster_algo_graphs/" + symbol, dpi=500)
    plt.close()

  def commodity_vol_strat(self, x, symbol, guid, cluster_key, zero_day=None, start_flag=False, end_day=None, delta_t=5, prices=None, sign=None):
    # print(symbol)

    if prices is None:
      fred_data_lst = self.ts.get_fred_data(symbol)
      adj_close_df = pd.DataFrame([float(x['values']['value']) for x in fred_data_lst],
                                  [x['date'] for x in fred_data_lst])
      adj_close_df.rename(columns={0: "close"}, inplace=True)
    else:
      adj_close_df = prices

    adj_close_df['volatility'] = np.nan


    volatility = self.dd._query_table(
      'SBT_HISTORICAL_VOLATILITY_BARCHART',
      'guid', guid)

    for v in volatility:
      adj_close_df.at[v['date'], "volatility"] = float(v['values']['value'])

    prev = np.nan
    for index, d in adj_close_df.iterrows():
      if np.isnan(d['volatility']) and not np.isnan(prev):
        adj_close_df.at[index, "volatility"] = prev
      else:
        prev = d['volatility']

    hv_lst = [float(volatility[x]['values']['value']) for x in range(len(volatility))]
    hv_df = pd.DataFrame([float(x['values']['value']) for x in volatility], [x['date'] for x in volatility])
    # self._logger.info(symbol['symbol'])
    if hv_lst and len(adj_close_df.values.tolist()) > 521:
      # adj_close_df = adj_close_df.truncate(after=volatility[-1]['date'])
      adj_close_lst = adj_close_df["close"].values.tolist()
      # averageVQ = np.convolve(hv_lst, np.ones((7560,)) / 7560, mode='valid') # used to be 756
      averageVQ = hv_df.rolling(7650).mean()
      if float(averageVQ[0].iloc[-1]):
        averageVQ = hv_df.rolling(len(hv_df)).mean()
      vq_ratio = (hv_lst[-1] - averageVQ[0].iloc[-1]) / averageVQ[0].iloc[-1]
      if len(hv_lst) >= 521:
        o3 = self.buy_sell.o3_timeseries(adj_close_lst, hv_lst, adj_close_df)

    adj_close_df['zone_classification'] = o3['zone_classification']

    # if volatility:
    #   sorted_volatility = sorted(volatility,
    #                              key=lambda k: k['date'],
    #                              reverse=True)


    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    i = 0
    while np.isnan(adj_close_df['volatility'][i]):
      i += 1
    adj_close_df['volatility_means'] = np.nan
    adj_close_df['volatility_means'][i:] = self.kalman_filter(adj_close_df['volatility'][i:]).flatten()  # TODO: FIX THIS

    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]

    freeze_day = zero_day

    if zero_day is None or start_flag:
      zero_day = adj_close_df.index[0]
    if end_day is None:
      end_day = adj_close_df.index[-1]
    else:
      adj_close_df = adj_close_df[:end_day]

    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df))

    avgs, raw_slopes, delta_slopes, adj_close_df = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df), column='volatility_means')


    if len(freeze_day) > 0:
      adj_close_df_training = adj_close_df[:freeze_day]
      X = adj_close_df_training.iloc[:, [2, 6, 7, 9, 10]].values
    else:
      X = adj_close_df.iloc[:, [2, 6, 7, 9, 10]].values

    for el in range(len(X)):
      if X[el][0] == 'green':
        X[el][0] = 0
      elif X[el][0] == 'yellow':
        X[el][0] = 1
      elif X[el][0] == 'red':
        X[el][0] = 2
      elif np.isnan(float(X[el][0])):
        X[el][0] = 10000
      if np.isnan(X[el][4]):
        X[el][1] = 10000
        X[el][2] = 10000
        X[el][3] = 10000
        X[el][4] = 10000
    # Test to determine optimal K

    # from sklearn.cluster import KMeans
    # import matplotlib.pyplot as plt
    # from yellowbrick.cluster import KElbowVisualizer

    # Instantiate the clustering model and visualizer
    # model = KMeans()
    # visualizer = KElbowVisualizer(model, k=(4, 100))
    # print(symbol)
    # visualizer.fit(X)  # Fit the data to the visualizer
    # visualizer.poof()  # Draw/show/poof the data
    # # dendrogram = sch.dendrogram(sch.linkage(X, method='ward'))
    model = AgglomerativeClustering(n_clusters=cluster_key[symbol]["CLUSTERS"], affinity='euclidean', linkage='ward')
    model.fit(X)

    if len(freeze_day) > 0:
      adj_close_df_training['cluster'] = model.labels_
      labels = model.labels_.tolist()
      neigh = KNeighborsClassifier(n_neighbors=3)
      neigh.fit(X, adj_close_df_training["cluster"])
      loc = adj_close_df.index.get_loc(freeze_day)
      for index, d in adj_close_df[loc+1:].iterrows():
        z = 0
        if d["zone_classification"] == 'red':
          z = 2
        elif d['zone_classification'] == "yellow":
          z = 1
        elif d['zone_classification'] == 'green':
          z = 0
        pr = d["price_means_raw_slopes"]
        if np.isnan(pr):
          pr = 10000
        pds = d["price_means_delta_slopes"]
        if np.isnan(pds):
          pds = 10000
        vr = d["volatility_means_raw_slopes"]
        if np.isnan(vr):
          vr = 10000
        vd = d["volatility_means_delta_slopes"]
        if np.isnan(vd):
          vd = 10000
        prediction = neigh.predict(np.asarray([z, pr, pds, vr, vd]).reshape(1, -1))
        labels.append(prediction)
        # print(d['datetimes'], prediction)
      # print(len(labels), len(adj_close_df))
      adj_close_df['cluster'] = labels
    else:
      adj_close_df['cluster'] = model.labels_
    shares = 1000 / adj_close_df["close"][zero_day]
    # print("Bought " + str(shares) + " at " + str(adj_close_df["close"][zero_day]) + " on " + str(zero_day))
    print(str(zero_day), "\tBuy\t", adj_close_df["close"][zero_day])
    # shares = 0
    short_shares = 0
    capital = 0
    dif_delt = []
    delt_count = 0
    position_opened = 0
    most_recent_trade = "BUY"
    most_recent_trade_date = zero_day
    most_recent_trade_metrics = {}
    last_slopes_day = None
    anchor_price = 0
    time_series = []
    red_streak = False
    red_trade = False
    trade = 0
    buy = True
    # avg = np.mean(adj_close_df['delta_slopes'])
    for index, d in adj_close_df.iterrows():
      loc = adj_close_df.index.get_loc(index)
      adj_close_df.at[index, "trade"] = trade
      adj_close_df.at[index, "buy"] = buy
      if len(cluster_key[symbol]["BUY"]) == 2:
        if (d['cluster'] == cluster_key[symbol]["BUY"][0] or d['cluster'] == cluster_key[symbol]["BUY"][1]) and d['zone_classification'] == 'red' and shares == 0:
          if short_shares != 0:
            capital -= short_shares * d["close"]
            short_shares = 0
            most_recent_trade = "BUY TO CLOSE"
            most_recent_trade_date = index
            # print("Close short at on " + str(index), d['close'])

          # print("Buy", d['close'])
          shares = capital / d['close']
          capital = 0
          position_opened = loc
          most_recent_trade = "BUY"
          most_recent_trade_date = index
          trade = 0
          buy = True
          adj_close_df.at[index, "trade"] = 0
          adj_close_df.at[index, "buy"] = True
          # print("Bought on " + str(index), d['close'])
          print(index, "\tClose Short/Buy\t", d['close'])
          # print(shares)
          # print("long yellow streak", index)
        elif (d['cluster'] == cluster_key[symbol]["SHORT"][0]) and d['zone_classification'] == 'red' and short_shares == 0:
          # print("Short", d['close'])
          if shares != 0:
            capital = shares * d["close"]
            shares = 0
            most_recent_trade = "SELL TO CLOSE"
            most_recent_trade_date = index
            # print("Sold " + str(d["close"]) + " on " + str(index), d['close'])
            position_opened = index

          short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
          capital += short_shares * d['close']
          position_opened = loc
          most_recent_trade = "SHORT"
          most_recent_trade_date = index
          trade = 1
          buy = False
          adj_close_df.at[index, "trade"] = 1
          adj_close_df.at[index, "buy"] = False
          # print("Short on " + str(index), d['close'])
          print(index, "\tSell/Short\t", d['close'])
          # print("SHORT", index)
      else:
        if (d['cluster'] == cluster_key[symbol]["BUY"][0]) and d['zone_classification'] == 'red' and shares == 0:
          if short_shares != 0:
            capital -= short_shares * d["close"]
            short_shares = 0
            most_recent_trade = "BUY TO CLOSE"
            most_recent_trade_date = index
            # print("Close short at on " + str(index), d['close'])


          # print("Buy", d['close'])
          shares = capital / d['close']
          capital = 0
          position_opened = loc
          most_recent_trade = "BUY"
          most_recent_trade_date = index
          trade = 0
          buy = True
          adj_close_df.at[index, "trade"] = 0
          adj_close_df.at[index, "buy"] = True
          # print("Bought on " + str(index), d['close'])
          print(index, "\tClose Short/Buy\t", d['close'])
          # print(shares)
          # print("long yellow streak", index)
        elif (d['cluster'] == cluster_key[symbol]["SHORT"][0]) and d['zone_classification'] == 'red' and short_shares == 0:
          # print("Short", d['close'])
          if shares != 0:
            capital = shares * d["close"]
            shares = 0
            most_recent_trade = "SELL TO CLOSE"
            most_recent_trade_date = index
            # print("Sold " + str(d["close"]) + " on " + str(index), d['close'])
            position_opened = index


          short_shares = (capital / 2) / d['close']  # only allow half of capital to be shorted
          capital += short_shares * d['close']
          position_opened = loc
          most_recent_trade = "SHORT"
          most_recent_trade_date = index
          trade = 1
          buy = False
          adj_close_df.at[index, "trade"] = 1
          adj_close_df.at[index, "buy"] = False
          # print("Short on " + str(index), d['close'])
          print(index, "\tSell/Short\t", d['close'])
          # print("SHORT", index)

    # self.graph(adj_close_df, symbol)
    # home = str(Path.home())
    # adj_close_df.to_csv(home + "/Desktop/cluster_algo_graphs/" + symbol + ".csv")
    # print(shares)
    if capital == 0:
      capital = shares * adj_close_df["close"][end_day]
      ending_pos = "long"
      # print("MM Guidance: In Long Position")
    if short_shares != 0:
      capital -= short_shares * adj_close_df["close"][end_day]
      shares = 0
      ending_pos = "short"
    # print("MM Last 5 delta slopes & slopes", delta_slopes[-1], raw_slopes[-2:])

    buy_hold = (1000 / adj_close_df["close"][zero_day]) * adj_close_df["close"][end_day]
    # print(np.median(lst_sell))

    ret_object = {"symbol": symbol,"timeseries": time_series, "last_recommendation": {"date": str(most_recent_trade_date), "action": most_recent_trade}}

    if sign:
      return sign * capital
    else:
      return (capital - buy_hold) / buy_hold * 100, capital, buy_hold, ret_object

  def strategy_2_15d_optimized(self, T, start_point, symbol, zero_day=None, start_flag=False, end_day=None, delta_t=5):
    self._logger.info(symbol)

    adj_close_df = self.get_prices("barchart", symbol)

    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    adj_close_df['volume_means'] = self.kalman_filter(adj_close_df['volume'])

    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]

    if zero_day is None or start_flag:
      zero_day = adj_close_df.index[0]
    if end_day is None:
      end_day = adj_close_df.index[-1]

    avgs, raw_slopes, delta_slopes = self.calculate_momentum(adj_close_df, delta_t, len(adj_close_df))

    pos_streak = 0
    neg_streak = 0
    pos_streaks = []
    neg_streaks = []
    shares = 0
    short_shares = 0
    capital = 1000
    dif_delt = []
    day_count = 0
    position_opened = ''
    for index, day in adj_close_df.iterrows():
      if day_count % delta_t == 0 and day_count != 0:
        try:
          if raw_slopes[int(day_count / delta_t) - 1] > 0 and pos_streak > 0:
            pos_streak += 1
          elif raw_slopes[int(day_count / delta_t) - 1] > 0 and neg_streak > 0:
            neg_streaks.append(neg_streak)
            neg_streak = 0
            pos_streak = 1
            if index >= zero_day and index <= end_day:
              if shares == 0 and short_shares == 0:
                shares = capital / day['close']
                capital = 0
                position_opened = index
              #  Force close a short position when its indicated that it is time to buy
              elif short_shares != 0 and shares == 0:
                capital -= short_shares * day["close"]
                short_shares = 0
                shares = capital / day['close']
                capital = 0
                position_opened = index
                # print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
          elif raw_slopes[int(day_count / delta_t) - 1] < 0 and pos_streak > 0:
            pos_streaks.append(pos_streak)
            neg_streak = 1
            pos_streak = 0
            # TODO: FIX SHORTING ALGO
            if index >= zero_day and index <= end_day:
              if short_shares == 0 and shares == 0:
                short_shares = (capital / 2) / day['close']  # only allow half of capital to be shorted
                capital += short_shares * day['close']
                position_opened = index
                # print("Short at " + str(day["close"]) + " on " + str(index))
          elif raw_slopes[int(day_count / delta_t) - 1] < 0 and neg_streak > 0:
            neg_streak += 1
          elif pos_streak == 0 and neg_streak == 0:
            if raw_slopes[int(day_count / delta_t) - 1] > 0:
              pos_streak += 1
              if index >= zero_day and index <= end_day:
                shares = capital / day["close"]
                capital = 0
                position_opened = index
                # print("Bought " + str(shares) + " at " + str(day["close"]) + " on " + str(index))
            else:
              neg_streak += 1
          # TODO: This needs to be fixed... the -5 creates problems the first couple times around
          # The below change addresses the above issue
          if (int(day_count / delta_t)) >= delta_t * delta_t and index != position_opened:
            if (delta_slopes[(int(day_count / delta_t)) - 1] <
                delta_slopes[(int(day_count / delta_t)) - delta_t]) and (delta_slopes[(int(day_count / delta_t)) - 1] -
                                                                         delta_slopes[(int(
                                                                           day_count / delta_t)) - delta_t]) < -0.3 and capital == 0:
              if index >= zero_day and index <= end_day:
                dif_delt.append(delta_slopes[(int(day_count / delta_t)) - 1] -
                                delta_slopes[(int(day_count / delta_t)) - delta_t])
                capital = shares * day["close"]
                shares = 0
                # print("Sold " + str(day["close"])+ " on " + str(index))
                # print()
            if (delta_slopes[(int(day_count / delta_t)) - 1] >
                delta_slopes[(int(day_count / delta_t)) - delta_t]) and (delta_slopes[(int(day_count / delta_t)) - 1] -
                                                                         delta_slopes[(int(
                                                                           day_count / delta_t)) - delta_t]) > 0.3 and short_shares != 0:  # Test the <.1 more
              if index >= zero_day and index <= end_day:
                dif_delt.append(delta_slopes[(int(day_count / delta_t)) - 1] -
                                delta_slopes[(int(day_count / delta_t)) - delta_t])
                capital -= short_shares * day["close"]
                short_shares = 0
                # print("Close short at " + str(day["close"])+ " on " + str(index))
        except IndexError:
          pass
      day_count += 1
    if capital == 0:
      capital = shares * adj_close_df["close"][end_day]
    if short_shares != 0:
      capital -= short_shares * adj_close_df["close"][end_day]
      shares = 0

    buy_hold = (1000 / adj_close_df["close"][zero_day]) * adj_close_df["close"][end_day]

    return (capital - buy_hold) / buy_hold * 100, capital, buy_hold

  def credit_spread_strat(self, symbol=None, zero_day=None, start_flag=False, end_day=None, delta_t=15):
    ts = TimeSeriesManager()
    company = ts.create_stock_exchange_search_dict(
      ts.get_symbol_mapping("BAA10Y", exchange="FRED"), "D")
    company['guid'] = company["id"]
    company['entity_name'] = company["text"]
    data = ts.get_data(company)
    credit_spread_df = pd.DataFrame([float(x['values']['value']) for x in data['data']['results']],
                                    [x['date'] for x in data['data']['results']])
    credit_spread_df = credit_spread_df[~credit_spread_df.index.duplicated(keep='last')]
    self._logger.info(symbol)

    spy_df = self.get_prices("barchart", "SPY")
    trade_df = self.get_prices("barchart", symbol)
    credit_spread_df = credit_spread_df[spy_df.index[0]:]
    spy_df = spy_df[:credit_spread_df.index[-1]]

    credit_spread_df['price_means'] = self.kalman_filter(credit_spread_df[0])
    credit_spread_df['price_means_v2'] = self.kalman_filter(credit_spread_df['price_means'])
    credit_spread_df['price_means_v3'] = self.kalman_filter(credit_spread_df['price_means_v2'])
    credit_spread_df['price_means_v4'] = self.kalman_filter(credit_spread_df['price_means_v3'])
    credit_spread_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in
                                     credit_spread_df.index.values]

    if zero_day is None or start_flag:
      zero_day = trade_df.index[0]
    if end_day is None:
      end_day = trade_df.index[-1]

    spy_avgs, spy_raw_slopes, spy_delta_slopes = self.calculate_momentum(spy_df, delta_t, len(credit_spread_df), "close")
    credit_avgs, credit_raw_slopes, credit_delta_slopes = self.calculate_momentum(credit_spread_df, delta_t, len(credit_spread_df),
                                                                                  "price_means_v4")

    shares = 1000 / trade_df["close"][zero_day]
    # print("OPEN", zero_day, trade_df["close"][zero_day], shares)
    short_shares = 0
    capital = 0
    day_count = 0

    # fig, ax1 = plt.subplots()
    # ax1.plot(credit_spread_df['price_means'].values)
    # # Make the y-axis label, ticks and tick labels match the line color.
    # ax1.tick_params('y', colors='b')
    #
    # ax2 = ax1.twinx()
    # ax2.plot(spy_df['close'].values, 'g', label="Kalman Filter")

    for index, day in spy_df.iterrows():
      if day_count % delta_t == 0 and day_count != 0:
        try:
          if credit_delta_slopes[int(day_count / delta_t) - 2] > 0.006 and np.mean(
              spy_raw_slopes[int(day_count / delta_t) - 4:int(day_count / delta_t) - 1]) > -.15:
            if index >= zero_day and index <= end_day:
              if short_shares == 0 and shares == 0:
                print("SHORT", index, trade_df['close'][index])
                short_shares = (capital / 2) / trade_df['close'][index]  # only allow half of capital to be shorted
                capital += short_shares * trade_df['close'][index]
                position_opened = index
              elif short_shares == 0 and shares != 0:
                print("Close, SHORT", index, trade_df['close'][index])
                capital = shares * trade_df['close'][index]
                shares = 0
                short_shares = (capital / 2) / trade_df['close'][index]  # only allow half of capital to be shorted
                capital += short_shares * trade_df['close'][index]
                position_opened = index
          elif credit_delta_slopes[int(day_count / delta_t) - 2] > 0.006 and np.mean(
              spy_raw_slopes[int(day_count / delta_t) - 4:int(day_count / delta_t) - 1]) < -.15:
            if index >= zero_day and index <= end_day:
              if shares == 0 and short_shares == 0:
                print("BUY", index, trade_df['close'][index])
                shares = capital / trade_df['close'][index]
                capital = 0
                position_opened = index
                #  Force close a short position when its indicated that it is time to buy
              elif short_shares != 0 and shares == 0:
                capital -= short_shares * trade_df['close'][index]
                print("BUY", index, trade_df['close'][index])
                short_shares = 0
                shares = capital / trade_df['close'][index]
                capital = 0
                position_opened = index
          elif credit_delta_slopes[int(day_count / delta_t) - 2] < -.006 and np.mean(
              spy_raw_slopes[int(day_count / delta_t) - 4:int(day_count / delta_t) - 1]) > 0:
            if index >= zero_day and index <= end_day:
              if shares == 0 and short_shares == 0:
                print("BUY", index, trade_df['close'][index])
                shares = capital / trade_df['close'][index]
                capital = 0
                position_opened = index
                #  Force close a short position when its indicated that it is time to buy
              elif short_shares != 0 and shares == 0:
                print("BUY", index, trade_df['close'][index])
                capital -= short_shares * trade_df['close'][index]
                short_shares = 0
                shares = capital / trade_df['close'][index]
                capital = 0
                position_opened = index

          # if delta_slopes[int(day_count / delta_t)-2] < -.006 and np.mean(p_raw_slopes[int(day_count / delta_t)-4:int(day_count / delta_t)-1]) > 0:
          #   print("BUY AT: ", index, delta_slopes[int(day_count / delta_t)-2], np.mean(p_raw_slopes[int(day_count / delta_t)-4:int(day_count / delta_t)-1]))
        except IndexError:
          pass
        except KeyError:  # handles times when a company didn't exist when the S&P generated a buy or sell
          pass
      day_count += 1
    if capital == 0:
      capital = shares * trade_df["close"][end_day]
    if short_shares != 0:
      capital -= short_shares * trade_df["close"][end_day]
      shares = 0
    buy_hold = (1000 / trade_df["close"][zero_day]) * trade_df["close"][end_day]

    return (capital - buy_hold) / buy_hold * 100, capital, buy_hold

    # pos_streak = 0
    # neg_streak = 0
    # pos_streaks = []
    # neg_streaks = []
    # count_confirm = 0
    # count_deviant = 0
    # for i, s in enumerate(delta_slopes):
    #   if s > 0 and pos_streak > 0:
    #     pos_streak += 1
    #   elif s > 0 and neg_streak > 0:
    #     neg_streaks.append(neg_streak)
    #     neg_streak = 0
    #     pos_streak = 1
    #   elif s < 0 and pos_streak > 0:
    #     pos_streaks.append(pos_streak)
    #     neg_streak = 1
    #     pos_streak = 0
    #   elif s < 0 and neg_streak > 0:
    #     neg_streak += 1
    #   elif pos_streak == 0 and neg_streak == 0:
    #     if s > 0:
    #       pos_streak += 1
    #     else:
    #       neg_streak += 1
    # print(count_confirm, count_deviant)
    # home = str(Path.home())
    # plt.hist(pos_streaks, bins=50, alpha=0.7, rwidth=0.5)
    # plt.title(symbol['symbol'] + ": Pos Histogram")
    # plt.savefig(home + "/Desktop/momentum/histograms/" + symbol['symbol'] + "_pos_hist")
    # plt.close()
    # plt.hist(neg_streaks, bins=50, alpha=0.7, rwidth=0.5)
    # plt.title(symbol['symbol'] + ": Neg Histogram")
    # plt.savefig(home + "/Desktop/momentum/histograms/" + symbol['symbol'] + "_neg_hist")
    # plt.close()

  def optimize_params(self, x):
    x = np.append(x, 0)
    # companies = [{"MSFT": "2010-11-11"}, {"FSMEX": "2008-09-03"}, {"BRK.B": "2009-04-01"}, {"MTCH": "2017-12-12"},
    #              {"CBRE": "2016-02-09"}, {"AMZN": "2017-05-09"}, {"IR": "2018-04-12"}, {"GOOGL": "2016-12-13"},
    #              {"PEY": "2016-04-12"}, {"JPM": "2017-04-11"}, {"PBP": "2013-12-11"}, {"LMT": "2017-07-11"},
    #              {"MSI": "2018-12-13"},
    #              {"RMD": "2018-11-14"}, {"HII": "2017-01-10"}, {"SPR": "2018-08-08"}, {"BHC": "2019-03-14"},
    #              {"ROL": "2019-04-10"},
    #              {"GLD": "2008-09-03"}, {"VIPSX": "2010-04-23"}, {"JPS": "2012-06-21"}, {"EMD": "2013-09-11"},
    #              {"NUV": "2013-04-10"}]
    # companies = [{"MSFT":"t"}]
    companies = [{"NVDA": "NSDQ"}, {"RECN": "NSDQ"}, {"SDLP": "NYSE"}, {"MDLZ": "NSDQ"}, {"KL": "NYSE"},
                 {"TMUS": "NSDQ"}, {"KHC": "NSDQ"}, {"TEVA": "NYSE"}, {"M": "NYSE"}, {"WF": "NYSE"}, {"L": "NYSE"},
                 {"LOW": "NYSE"}, {"AAPL": "NSDQ"}, {"CAT": "NYSE"}, {"MSFT": "NSDQ"},
                 {"IBM": "NYSE"}, {"GOLD": "NYSE"}, {"DHI": "NYSE"}, {"SLB": "NYSE"}]
    deltas = [2]
    print(x[0], x[1])
    for deltt in deltas:
      tot_cap = 0
      for company in companies:
        try:
          # guid = self.mapping_accessor.query_symbol_exchange_mappings(list(company.keys())[0])[0]['guid']
          values = mo.acceleration_test_September(x,list(company.keys())[0], list(company.values())[0],
                                 start_flag=True,
                                 # end_day="2018-12-31", delta_t=deltt)
                                 end_day=None, delta_t=deltt, prices=self.prices[list(company.keys())[0]], sign=-1)
          tot_cap += values
        except KeyError:
          print("Company not supported")
        except IndexError:
          print("Error")
    print(tot_cap)
    return tot_cap

  def create_model_stats_table(self, model_id=None, data=None):
    print(
      ' MOMENTUM: CREATING STATS TABLE IN PG...')
    RESULT_TABLENAME_PREFIX = "development_sbt_models"
    tic = datetime.datetime.now()
    model_id = "".join(model_id.lower().split("_"))
    # rating stats table
    TABLE_NAME = "{}_{}_rating_stats".format(RESULT_TABLENAME_PREFIX,
                                             model_id
                                             )
    # get the min/max for the model's rank (:= total number of points),
    # which is the most important result for CE
    df_stats = pd.DataFrame(
      (x for x in data),
      columns=['rating', 'score']).groupby(by='rating') \
      .agg({"score": [min, max, "count"]})
    # rename columns
    df_stats.columns = ['minRank', 'maxRank', 'total']
    # save rating stats
    df_stats.to_sql(TABLE_NAME,
                    self.pg._engine,
                    if_exists='replace',
                    index_label='rating'
                    )
    # rank stats table
    TABLE_NAME = "{}_{}_score_stats".format(RESULT_TABLENAME_PREFIX,
                                            model_id
                                            )
    data = pd.DataFrame(data)
    model_stat_df = data.agg({'score': [min, max, 'count']}).T
    # rename columns
    model_stat_df.columns = ['minscore', 'maxscore', 'total']
    # stats per model (total within each rank bin)

    # The below was changed from 0 to -999 due to a change in the UI ignoring b0. Now moving strong sells to b1
    model_stat_score_bin_df = pd.DataFrame(data.groupby(
      pd.cut(data['score'], [-1000, -999, 20, 40, 60, 80, 100])
    )['score'].count()).T
    # rename columns
    model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
    # create final df
    model_score_stat_df = pd.concat(
      [model_stat_df, model_stat_score_bin_df], axis=1)
    # save rank stats
    model_score_stat_df.to_sql(TABLE_NAME,
                               self.pg._engine,
                               if_exists='replace'
                               )
    print(
      ' MOMENTUM: MOMENTUM TABLE CREATED IN Dt = {}'.format(
        datetime.datetime.now() - tic)
    )

  def load_data(self):
    # config = SbtGlobalCommon.get_sbt_config()
    # mod = ModelAccessor()
    # symbols = sba.get_model_rankings("MOMENTUM")
    # mp = MappingAccessor()

    symbols = self.dd._scan_table_with_filter_str("SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
    # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
    s = []
    for sy in symbols:
      if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
        # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
        s.append(sy['symbol'])

    # s = ["CAT"]

    # s = ["SPY"]
    pct_dif_returns = []
    tot_cap = 0
    tot_buy_hold = 0
    for company in s:
      try:
        values = self.acceleration_test_September([-0.04832031, 0.3065332], company, start_flag=True,
                              # end_day="2018-12-31", delta_t=deltt)
                              end_day=None, delta_t=5)
        pct_dif_returns.append(values[0])
        tot_cap += values[1]
        tot_buy_hold += values[2]
        item = values[3]
        timeseries = values[4]
        if timeseries:
          self.dd._delete('mm_model', 'symbol', item['symbol'])
          self.dd._save("mm_model", item)
          self.dd._batch_save('mm_momentum_timeseries', timeseries)

      except KeyError as e:
        print(e)
        print("Company not supported")
    init_investment = 1000 * len(s)
    print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
    print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)

  def load_data_1(self):
    # config = SbtGlobalCommon.get_sbt_config()
    # mod = ModelAccessor()
    # symbols = sba.get_model_rankings("MOMENTUM")
    # mp = MappingAccessor()
    # symbols = self.dd._scan_table_with_filter_str("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
    # # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
    # s = []
    # for sy in symbols:
    #   if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
    #     # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
    #     s.append(sy['symbol'])

    # s = ["AATP"]

    s = self.symbols_data['composite_pk_id'].tolist()

    s = sorted(s)
    num = len(s)
    s = s[:int(num/4)]
    pct_dif_returns = []
    tot_cap = 0
    tot_buy_hold = 0
    for i, company in enumerate(s):
      self._logger.info("momentum load pt. 1: " + str(i) + "/" + str(len(s)))
      try:
        start = time.time()
        company = company.split(':')
        values = self.acceleration_test_September([0.04832031, 0.3065332], company[0], company[1], start_flag=True,
                                          # end_day="2018-12-31", delta_t=deltt)
                                          end_day=None, delta_t=5)
        pct_dif_returns.append(values[0])
        tot_cap += values[1]
        tot_buy_hold += values[2]
        item = values[3]
        timeseries = values[4]
        symbol_info = values[5]
        if timeseries:
          # self.dd._delete('mm_model', 'symbol', item['symbol'])
          # self.dd._save("mm_model", item)
          self.save_data_to_pg(item, symbol_info)

          # self.dd._batch_save('mm_momentum_timeseries', timeseries)
        print(time.time() - start)

      except KeyError as e:
        print(e)
        print("Company not supported")
    init_investment = 1000 * len(s)
    print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
    print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)

    self.nuetrals()
    select = "SELECT * FROM development_sbt_models_mmmomentum;"
    data = self.pg._execute_query(select, [])
    self.create_model_stats_table("MMMOMENTUM", data)


  def load_data_2(self):
    # config = SbtGlobalCommon.get_sbt_config()
    # mod = ModelAccessor()
    # symbols = sba.get_model_rankings("MOMENTUM")
    # mp = MappingAccessor()

    # symbols = self.dd._scan_table_with_filter_str("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
    # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
    # s = []
    # for sy in symbols:
    #   if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
        # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
        # s.append(sy['symbol'])

    # s = ["AATP"]
    s = self.symbols_data['composite_pk_id'].tolist()
    s = sorted(s)
    num = len(s)
    s = s[int(num/4):int(num/2)]
    pct_dif_returns = []
    tot_cap = 0
    tot_buy_hold = 0
    for i, company in enumerate(s):
      self._logger.info("momentum load pt. 2: " + str(i) + "/" + str(len(s)))
      try:
        company = company.split(':')
        values = self.acceleration_test_September([0.04832031, 0.3065332], company[0], company[1], start_flag=True,
                                                  # end_day="2018-12-31", delta_t=deltt)
                                                  end_day=None, delta_t=5)
        pct_dif_returns.append(values[0])
        tot_cap += values[1]
        tot_buy_hold += values[2]
        item = values[3]
        timeseries = values[4]
        symbol_info = values[5]
        if timeseries:
          # self.dd._delete('mm_model', 'symbol', item['symbol'])
          # self.dd._save("mm_model", item)
          self.save_data_to_pg(item, symbol_info)

          # self.dd._batch_save('mm_momentum_timeseries', timeseries)

      except KeyError as e:
        print(e)
        print("Company not supported")
    init_investment = 1000 * len(s)
    print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
    print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)

    self.nuetrals()
    select = "SELECT * FROM development_sbt_models_mmmomentum;"
    data = self.pg._execute_query(select, [])
    self.create_model_stats_table("MM_MOMENTUM", data)


  def load_data_3(self):
    # config = SbtGlobalCommon.get_sbt_config()
    # mod = ModelAccessor()
    # symbols = sba.get_model_rankings("MOMENTUM")
    # mp = MappingAccessor()

    # symbols = self.dd._scan_table_with_filter_str("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
    # # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
    # s = []
    # for sy in symbols:
    #   if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
    #     # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
    #     s.append(sy['symbol'])

    # s = ["AATP"]
    s = self.symbols_data['composite_pk_id'].tolist()

    s = sorted(s)
    num = len(s)
    s = s[int(num/2):int(num*(3/4))]
    pct_dif_returns = []
    tot_cap = 0
    tot_buy_hold = 0
    for i, company in enumerate(s):
      self._logger.info("momentum load pt. 3: " + str(i) + "/" + str(len(s)))
      try:
        company = company.split(':')
        values = self.acceleration_test_September([0.04832031, 0.3065332], company[0], company[1], start_flag=True,
                                                  # end_day="2018-12-31", delta_t=deltt)
                                                  end_day=None, delta_t=5)
        pct_dif_returns.append(values[0])
        tot_cap += values[1]
        tot_buy_hold += values[2]
        item = values[3]
        timeseries = values[4]
        symbol_info = values[5]
        if timeseries:
          # self.dd._delete('mm_model', 'symbol', item['symbol'])
          # self.dd._save("mm_model", item)
          self.save_data_to_pg(item, symbol_info)

          # self.dd._batch_save('mm_momentum_timeseries', timeseries)

      except KeyError as e:
        print(e)
        print("Company not supported")
    init_investment = 1000 * len(s)
    print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
    print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)

    self.nuetrals()
    select = "SELECT * FROM development_sbt_models_mmmomentum;"
    data = self.pg._execute_query(select, [])
    self.create_model_stats_table("MM_MOMENTUM", data)


  def load_data_4(self):
    # config = SbtGlobalCommon.get_sbt_config()
    # mod = ModelAccessor()
    # symbols = sba.get_model_rankings("MOMENTUM")
    # mp = MappingAccessor()

    # symbols = self.dd._scan_table_with_filter_str("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
    # # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
    # s = []
    # for sy in symbols:
    #   if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
    #     # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
    #     s.append(sy['symbol'])

    # s = ["AATP"]
    s = self.symbols_data['composite_pk_id'].tolist()

    s = sorted(s)
    num = len(s)
    s = s[int(num*(3/4)):]
    pct_dif_returns = []
    tot_cap = 0
    tot_buy_hold = 0
    for i, company in enumerate(s):
      self._logger.info("momentum load pt. 4: " + str(i) + "/" + str(len(s)))
      try:
        company = company.split(':')
        values = self.acceleration_test_September([-0.04832031, 0.3065332], company[0], company[1], start_flag=True,
                                                  # end_day="2018-12-31", delta_t=deltt)
                                                  end_day=None, delta_t=5)
        pct_dif_returns.append(values[0])
        tot_cap += values[1]
        tot_buy_hold += values[2]
        item = values[3]
        timeseries = values[4]
        symbol_info = values[5]
        if timeseries:
          # self.dd._delete('mm_model', 'symbol', item['symbol'])
          # self.dd._save("mm_model", item)
          self.save_data_to_pg(item, symbol_info)

          # self.dd._batch_save('mm_momentum_timeseries', timeseries)

      except KeyError as e:
        print(e)
        print("Company not supported")
    init_investment = 1000 * len(s)
    print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
    print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)

    self.nuetrals()
    select = "SELECT * FROM development_sbt_models_mmmomentum;"
    data = self.pg._execute_query(select, [])
    self.create_model_stats_table("MM_MOMENTUM", data)


  def load_data_short(self):
    # config = SbtGlobalCommon.get_sbt_config()
    # mod = ModelAccessor()
    # symbols = sba.get_model_rankings("MOMENTUM")
    # mp = MappingAccessor()
    # symbols = self.dd._scan_table_with_filter_str("DEV_SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
    # # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
    # s = []
    # for sy in symbols:
    #   if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
    #     # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
    #     s.append(sy['symbol'])

    # s = ["AATP"]

    s = self.symbols_data['composite_pk_id'].tolist()

    s = sorted(s)
    num = len(s)
    # s = s[:int(num/4)]
    # s = [{"MSFT": "NSDQ"}, {"FSMEX": "NSDQ"}, {"BRK.B":"NYSE"}, {"MTCH":"NSDQ"},
    #              {"CBRE": "NYSE"}, {"AMZN": "NSDQ"}, {"IR": "NYSE"}, {"GOOGL": "NSDQ"},
    #              {"PEY": "NSDQ"}, {"JPM": "NYSE"}, {"PBP":"NYSE"},{"LMT":"NYSE"},
    # {"MSI":"NYSE"},
    #              {"RMD":"NYSE"},{"HII":"NYSE"},{"SPR":"NYSE"},{"BHC":"NYSE"},
    # {"ROL":"NYSE"},
    #              {"GLD":"NYSE"},{"VIPSX":"NSDQ"},{"JPS":"NYSE"},{"EMD":"NYSE"},
    # {"NUV":"NYSE"}]
    # # s = [{"NVDA": "NSDQ"}, {"RECN": "NSDQ"}, {"SDLP": "NYSE"}, {"MDLZ": "NSDQ"}, {"KL": "NYSE"},
    #            {"TMUS": "NSDQ"}, {"KHC": "NSDQ"}, {"TEVA": "NYSE"}, {"M": "NYSE"}, {"WF": "NYSE"}, {"L": "NYSE"},
    #            {"LOW": "NYSE"}, {"AAPL": "NSDQ"}, {"CAT": "NYSE"}, {"MSFT": "NSDQ"},
    #            {"IBM": "NYSE"}, {"GOLD": "NYSE"}, {"DHI": "NYSE"}, {"SLB": "NYSE"}]
    #


    pct_dif_returns = []
    tot_cap = 0
    tot_buy_hold = 0
    for i, company in enumerate(s):
      self._logger.info("momentum load pt. 1: " + str(i) + "/" + str(len(s)))
      try:
        start = time.time()
        print(company)
        company = company.split(':')
        values = self.acceleration_test_September([0.01832031, 0.3065332], company[0], company[1], start_flag=True,
                                          # end_day="2018-12-31", delta_t=deltt)
                                          end_day=None, delta_t=2)
        pct_dif_returns.append(values[0])
        tot_cap += values[1]
        tot_buy_hold += values[2]
        item = values[3]
        timeseries = values[4]
        symbol_info = values[5]
        init_investment = 1000 * i
        # print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
        # print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)

        if timeseries:
          # self.dd._delete('mm_model', 'symbol', item['symbol'])
          # self.dd._save("mm_model", item)
          self.save_data_to_pg(item, symbol_info)

          # self.dd._batch_save('mm_momentum_timeseries', timeseries)
        print(time.time() - start)

      except KeyError as e:
        print(e)
        print("Company not supported")
      except IndexError as e:
        print(e)
    init_investment = 1000 * len(s)
    print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
    print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)

    # self.nuetrals()
    # select = "SELECT * FROM development_sbt_models_mmmomentum;"
    # data = self.pg._execute_query(select, [])
    # self.create_model_stats_table("MMMOMENTUM", data)

  def calc_o3(self, symbol):
    self._logger.info(symbol)

    adj_close_df = self.get_prices("barchart", symbol)


    adj_close_df['price_means'] = self.kalman_filter(adj_close_df['close'])
    adj_close_df['datetimes'] = [dt.datetime.strptime(date, '%Y-%m-%d').date() for date in adj_close_df.index.values]


    guid = self.dd._query_table("SBT_SYMBOL_EXCHANGE_MAPPING", "symbol", symbol, range_name="exchange", range_value="NYSE")
    if not guid:
      guid = self.dd._query_table("SBT_SYMBOL_EXCHANGE_MAPPING", "symbol", symbol, range_name="exchange", range_value="NSDQ")
    if guid:
      guid = guid[0]['guid']
    else:
      return -1


    volatility = self.dd._query_table(
      'SBT_HISTORICAL_VOLATILITY_BARCHART',
      'guid', guid)

    hv_lst = [float(volatility[x]['values']['value']) for x in range(len(volatility))]
    hv_df = pd.DataFrame([x['values']['value'] for x in volatility], [x['date'] for x in volatility])
    if hv_lst and len(hv_lst) > 521:
      adj_close_lst = adj_close_df["close"].values.tolist()
      try:
        o3 = self.buy_sell.o3(adj_close_lst, hv_lst)
      except IndexError:
        return -1
      percent = 0
      if adj_close_lst[-1] < o3[0]:
        # print('red')
        percent = (1-((o3[0] - adj_close_lst[-1]) /o3[0])) * (1/3)
      elif adj_close_lst[-1] < o3[1]:
        # print('yellow')
        percent = ((adj_close_lst[-1]-o3[0]) / o3[0]) + (1/3)
      elif adj_close_lst[-1] > o3[1]:
        # print('green')
        percent = ((adj_close_lst[-1] - o3[1]) / o3[1]) + (2/3)
      return percent
    return -1

  def load_data_o3(self):

    symbols = self.dd._scan_table_with_filter_str("SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
    # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
    s = []
    for sy in symbols:
      if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
        # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
        s.append(sy['symbol'])

    # s = ["CAT"]

    for i, company in enumerate(s):
      self._logger.info("o3 load: " + str(i) + "/" + str(len(s)))
      try:
        value = self.calc_o3(company)
        if value >=0:
          self.dd._save("o3_indicator", {'symbol': company, 'value': value, 'model_id': 'O3_OSCILLATOR'})
      except KeyError as e:
        print(e)
        print("Company not supported")

  def save_data_to_pg(self, item, symbol_info):
    # upsert if composite_pk_id exists (guid will be updated)
    # N.B.: guid is mapped to composite_pk_id so either one is considered unique
    insert = "INSERT INTO {} (composite_pk_id, guid, model, score, rating, rank) " \
    "VALUES (%s, %s, %s, %s, %s, %s) ON CONFLICT (composite_pk_id) DO UPDATE SET guid=%s, model=%s, score=%s, rating=%s, rank=%s;".format(
      "development_sbt_models_mmmomentum")
    current_year_full = int(datetime.datetime.now().strftime('%Y'))
    last_trade_year = int(item["last_recommendation"]["date"].split("-")[0])
    diff = current_year_full - last_trade_year
    value = item['value']
    rec = item["last_recommendation"]["action"]
    if diff >= 3:
      print('nuetral', symbol_info['composite_pk_id'])
      value = 50
      rec = "NEUTRAL"
    model = json.dumps({
                            "model": {
                              'last_recommendation_date':
                                item["last_recommendation"]["date"],
                              'last_recommendation_action':
                                rec,
                              'score':
                                value,
                              'composite_pk_id':
                                symbol_info['composite_pk_id'],
                              'date_calculated':
                                datetime.datetime.now().strftime("%Y-%m-%d"),
                              'timeseries': ''
                              # item['timeseries']
                            }
                          })
    self.pg._execute_dml(insert,
                         [symbol_info['composite_pk_id'],
                          symbol_info['guid'],
                          model,
                          value,
                          rec,
                          None, symbol_info['guid'], model, value, rec, None]
                         )

  def transfer_data(self):
    qa_pgconfig = {"qa": self.config["qa"]['postgres']['datafactory']}
    qa_pg = PostgresAccessor(qa_pgconfig["qa"])
    prod_pgconfig = {"prod": self.config["prod"]['postgres']['datafactory']}
    prod_pg = PostgresAccessor(prod_pgconfig["prod"])
    select = "SELECT * FROM development_sbt_models_mmmomentum;"
    data = pd.read_sql_query(select,
                                   self.pg._engine,
                                   coerce_float=True
                                   )
    select = "SELECT * FROM development_sbt_models_mmmomentum_rating_stats;"
    rating = pd.read_sql_query(select,
                                   self.pg._engine,
                                   coerce_float=True
                                   )
    select = "SELECT * FROM development_sbt_models_mmmomentum_score_stats;"
    score = pd.read_sql_query(select,
                                   self.pg._engine,
                                   coerce_float=True
                                   )
    data.to_sql('development_sbt_models_mmmomentum', qa_pg._engine, if_exists='replace', dtype={'model': JSON,
                                                                                                 'score': FLOAT,
                                                                                                 'rank': FLOAT,
                                                                                                 'rating': VARCHAR,
                                                                                                 'composite_pk_id':
                                                                                                   VARCHAR
                                                                                                 }, index=False)
    data.to_sql('development_sbt_models_mmmomentum', prod_pg._engine, if_exists='replace', dtype={'model': JSON,
                                                                                                'score': FLOAT,
                                                                                                'rank': FLOAT,
                                                                                                'rating': VARCHAR,
                                                                                                'composite_pk_id':
                                                                                                  VARCHAR
                                                                                                }, index=False)
    rating.to_sql('development_sbt_models_mmmomentum_rating_stats', qa_pg._engine, if_exists='replace', dtype={
                                                                                                'minRank': FLOAT,
                                                                                                'maxRank': FLOAT,
                                                                                                'rating': VARCHAR,
                                                                                                'total':
                                                                                                  BIGINT
                                                                                                }, index=False)
    rating.to_sql('development_sbt_models_mmmomentum_rating_stats', prod_pg._engine, if_exists='replace', dtype={
                                                                                                'minRank': FLOAT,
                                                                                                'maxRank': FLOAT,
                                                                                                'rating': VARCHAR,
                                                                                                'total':
                                                                                                  BIGINT
                                                                                                  }, index=False)
    score.to_sql('development_sbt_models_mmmomentum_score_stats', qa_pg._engine, if_exists='replace', dtype={
                                                                                                  'index': VARCHAR,
                                                                                                  'minScore': FLOAT,
                                                                                                  'maxScore': FLOAT,
                                                                                                  'total': FLOAT,
                                                                                                  'b0': BIGINT,
                                                                                                  'b1': BIGINT,
                                                                                                  'b2': BIGINT,
                                                                                                  'b3': BIGINT,
                                                                                                  'b4': BIGINT,
                                                                                                  'b5': BIGINT
                                                                                                  }, index=False)
    score.to_sql('development_sbt_models_mmmomentum_score_stats', prod_pg._engine, if_exists='replace', dtype={
                                                                                                  'index': VARCHAR,
                                                                                                  'minScore': FLOAT,
                                                                                                  'maxScore': FLOAT,
                                                                                                  'total': FLOAT,
                                                                                                  'b0': BIGINT,
                                                                                                  'b1': BIGINT,
                                                                                                  'b2': BIGINT,
                                                                                                  'b3': BIGINT,
                                                                                                  'b4': BIGINT,
                                                                                                  'b5': BIGINT
                                                                                                  }, index=False)

    sql = 'ALTER TABLE development_sbt_models_mmmomentum ADD PRIMARY KEY (composite_pk_id);'
    qa_pg._execute_dml(sql, [])
    prod_pg._execute_dml(sql, [])
    # for d in data:
    #   insert = "INSERT INTO {} (composite_pk_id, guid, model, score, rating, rank) " \
    #            "VALUES (%s, %s, %s, %s, %s, %s) ON CONFLICT (composite_pk_id) DO UPDATE SET guid=%s, model=%s, score=%s, rating=%s, rank=%s;".format(
    #     "development_sbt_models_mmmomentum")
    #   d['rank'] = None
    #   qa_pg._execute_dml(insert,
    #                      [d['composite_pk_id'],
    #                       d['guid'],
    #                       json.dumps(d['model']),
    #                       d["score"],
    #                       d["rating"],
    #                       d['rank'], d['guid'], json.dumps(d['model']), d["score"], d["rating"], d['rank']]
    #                      )
    #   prod_pg._execute_dml(insert,
    #                      [d['composite_pk_id'],
    #                       d['guid'],
    #                       json.dumps(d['model']),
    #                       d["score"],
    #                       d["rating"],
    #                       d['rank'], d['guid'], json.dumps(d['model']), d["score"], d["rating"], d['rank']]
    #                      )
    #   print(d['composite_pk_id'])

  def do_rankings(self):
    try:
      qa_pgconfig = {"qa": self.config["qa"]['postgres']['datafactory']}
      qa_pg = PostgresAccessor(qa_pgconfig["qa"])
      prod_pgconfig = {"prod": self.config["prod"]['postgres']['datafactory']}
      prod_pg = PostgresAccessor(prod_pgconfig["prod"])

      base_sql_query = """
            SELECT * FROM {}
        """.format('development_sbt_models_mmmomentum')

      # if guid is not None:
      #   sql_query = base_sql_query + " WHERE guid = '{}'".format(guid)
      #
      # if limit is not None:
      #   sql_query = base_sql_query + " LIMIT {}".format(limit)
      # else:
        # return only the top 10 results

      base_sql_query = base_sql_query + """
                WHERE rating = 'BUY'
                ORDER BY model -> 'model' ->> 'last_recommendation_date' desc
            """
      sql_query = base_sql_query

      rankings = pd.read_sql_query(sql_query,
                                   self.pg._engine,
                                   coerce_float=True
                                   )

      base_sql_query = """
                  SELECT * FROM {}
              """.format('development_sbt_models_mmmomentum')
      base_sql_query_sell = base_sql_query + """
                      WHERE rating = 'SHORT'
                  """
      sells = pd.read_sql_query(base_sql_query_sell,
                                   self.pg._engine,
                                   coerce_float=True
                                   )

      rankings['rank'] = None
      sells['rank'] = None
      ret = pd.concat([rankings, sells], sort=False)
      ret.to_sql('development_sbt_models_mmmomentum', self.pg._engine, if_exists='replace', dtype={'model': JSON,
                   'score': FLOAT,
                   'rank': FLOAT,
                   'rating': VARCHAR,
                   'composite_pk_id': VARCHAR
                   }, index=False)
      sql = 'ALTER TABLE development_sbt_models_mmmomentum ADD PRIMARY KEY (composite_pk_id);'
      self.pg._execute_dml(sql, [])

      ret.to_sql('development_sbt_models_mmmomentum', qa_pg._engine, if_exists='replace', dtype={'model': JSON,
                                                                                                   'score': FLOAT,
                                                                                                   'rank': FLOAT,
                                                                                                   'rating': VARCHAR,
                                                                                                   'composite_pk_id':
                                                                                                     VARCHAR
                                                                                                   }, index=False)
      sql = 'ALTER TABLE development_sbt_models_mmmomentum ADD PRIMARY KEY (composite_pk_id);'
      qa_pg._execute_dml(sql, [])

      ret.to_sql('development_sbt_models_mmmomentum', prod_pg._engine, if_exists='replace', dtype={'model': JSON,
                                                                                                 'score': FLOAT,
                                                                                                 'rank': FLOAT,
                                                                                                 'rating': VARCHAR,
                                                                                                 'composite_pk_id':
                                                                                                   VARCHAR
                                                                                                 }, index=False)
      sql = 'ALTER TABLE development_sbt_models_mmmomentum ADD PRIMARY KEY (composite_pk_id);'
      prod_pg._execute_dml(sql, [])

      # add SYM & EXCH
      # rankings['symbol'] = [sym.split(':')[0]
      #                       for sym in rankings['composite_pk_id']]
      # rankings['exchange'] = [sym.split(':')[1]
      #                         for sym in rankings['composite_pk_id']]
      #
      # rankings.pop('composite_pk_id')
      # rankings.pop('model')
      #
      # result = rankings.to_dict(orient='records')

      # return rankings
    except Exception as e:
      print(e)

  def nuetrals(self):
    try:
      base_sql_query = """
            SELECT * FROM {}
        """.format('development_sbt_models_mmmomentum')

      base_sql_query = base_sql_query + """
                WHERE rating = 'NEUTRAL'
            """
      sql_query = base_sql_query

      rankings = pd.read_sql_query(sql_query,
                                   self.pg._engine,
                                   coerce_float=True
                                   )

      for row in rankings.iterrows():
        insert = "UPDATE {} SET guid=%s, model=%s, score=%s, rating=%s, rank=%s WHERE composite_pk_id = %s;".format(
          "development_sbt_models_mmmomentum")

        row[1]['rank'] = None
        hist = self.barchart_accessor.get_history(None, "daily", 0, "19000101", None,
                                           row[1]['composite_pk_id'].split(',')[0])
        now = datetime.datetime.now()
        then = datetime.datetime.strptime(hist[-1]['tradingDay'], '%Y-%m-%d')
        if now - then <= datetime.timedelta(10):
          if (hist[-1]['close']/hist[-32]['close'])-1 >= .02:
            print(row[1]['composite_pk_id'], "BUY")
            row[1]['model']['last_recommendation_action'] = "BUY"
            row[1]['model']['score'] = 100
            row[1]['score'] = 100
            row[1]['rating'] = "BUY"
          elif (hist[-1]['close']/hist[-32]['close'])-1 <= -.015:
            print(row[1]['composite_pk_id'], "SHORT")
            row[1]['model']['last_recommendation_action'] = "SHORT"
            row[1]['model']['score'] = 0
            row[1]['score'] = 0
            row[1]['rating'] = "SHORT"
          else:
            print(row[1]['composite_pk_id'], "NEUTRAL")

          model = row[1]['model']
          self.pg._execute_dml(insert,
                          [row[1]['guid'], json.dumps(model), row[1]["score"], row[1]["rating"], row[1]['rank'], row[1]['composite_pk_id']]
                          )
        else:
          self.pg._execute_dml("DELETE FROM development_sbt_models_mmmomentum WHERE composite_pk_id = '{}'".format(
            row[1]['composite_pk_id']),
                               []
                               )
      print()

    except Exception as e:
      print(e)


  def nuetrals_alt(self):
    try:
      base_sql_query = """
            SELECT * FROM {}
        """.format('development_sbt_models_mmmomentum')

      # base_sql_query = base_sql_query + """
      #           WHERE rating = 'NEUTRAL'
      #       """
      sql_query = base_sql_query

      rankings = pd.read_sql_query(sql_query,
                                   self.pg._engine,
                                   coerce_float=True
                                   )
      current_year_full = int(datetime.datetime.now().strftime('%Y'))

      for row in rankings.iterrows():
        try:
          last_trade_year = int(row[1]['model']['model']["last_recommendation_date"].split("-")[0])
          diff = current_year_full - last_trade_year
          # value = row[1]['value']
          rec = row[1]['model']['model']["last_recommendation_action"]
          if diff >= 3:
            value = 50
            rec = "NEUTRAL"


            insert = "UPDATE {} SET guid=%s, model=%s, score=%s, rating=%s, rank=%s WHERE composite_pk_id = %s;".format(
              "development_sbt_models_mmmomentum")

            row[1]['rank'] = None
            hist = self.barchart_accessor.get_history(None, "daily", 0, "19000101", None,
                                               row[1]['composite_pk_id'].split(',')[0])
            now = datetime.datetime.now()
            then = datetime.datetime.strptime(hist[-1]['tradingDay'], '%Y-%m-%d')
            if now - then <= datetime.timedelta(10):
              if (hist[-1]['close']/hist[-32]['close'])-1 >= .02:
                print(row[1]['composite_pk_id'], "BUY")
                row[1]['model']['model']['last_recommendation_action'] = "BUY"
                row[1]['model']['model']['score'] = 100
                row[1]['score'] = 100
                row[1]['rating'] = "BUY"
              elif (hist[-1]['close']/hist[-32]['close'])-1 <= -.02:
                print(row[1]['composite_pk_id'], "SHORT")
                row[1]['model']['model']['last_recommendation_action'] = "SHORT"
                row[1]['model']['model']['score'] = 0
                row[1]['score'] = 0
                row[1]['rating'] = "SHORT"
              else:
                print(row[1]['composite_pk_id'], "NEUTRAL")
                row[1]['model']['model']['last_recommendation_action'] = "NEUTRAL"
                row[1]['model']['model']['score'] = 50
                row[1]['score'] = 50
                row[1]['rating'] = "NEUTRAL"

              model = row[1]['model']['model']
              self.pg._execute_dml(insert,
                              [row[1]['guid'], json.dumps(model), row[1]["score"], row[1]["rating"], row[1]['rank'], row[1]['composite_pk_id']]
                              )
            else:
              self.pg._execute_dml("DELETE FROM development_sbt_models_mmmomentum WHERE composite_pk_id = '{}'".format(row[1]['composite_pk_id']),
                                   []
                                   )
        except Exception as e:
          pass
      print()

    except Exception as e:
      print(e)
      pass

if __name__ == '__main__':
  # # companies = [{"GOLDPMGBD228NLBM": "2008-09-03"}, {"GOLDAMGBD228NLBM": "2009-04-01"}, {"DCOILBRENTEU": "2017-12-12"}, {"DCOILWTICO": "2017-12-12"}, {"DGS10": "2010-11-11"}]
  # companies = [{"GOLDPMGBD228NLBM": ""}, {"DCOILBRENTEU": "2019-07-22"}, {"DGS10": "2019-07-22"}]
  # # companies = [{"GOLDPMGBD228NLBM": ""}]
  # cluster_key = {"DGS10": {"BUY": [4], "SHORT":  [2], "CLUSTERS": 12}, "GOLDPMGBD228NLBM": {"BUY": [4,0], "SHORT":  [2], "CLUSTERS": 16}, "GOLDAMGBD228NLBM": {"BUY": [0], "SHORT":  [2], "CLUSTERS": 15}, "DCOILBRENTEU": {"BUY": [10], "SHORT":  [5], "CLUSTERS": 12}, "DCOILWTICO": {"BUY": [1], "SHORT":  [6], "CLUSTERS": 15}}
  mo = MMMomentum()
  # mo.load_data_short()
  # mo.transfer_data()
  # mo.transfer_data()
  # mo.load_data_1()
  # mo.load_data_2()
  # mo.load_data_3()
  # mo.load_data_4()
  # mo.nuetrals_alt()

  # config = SbtGlobalCommon.raw_sbt_config
  # ENV = SbtGlobalCommon.get_sbt_config_env()
  # pgconfig = {ENV: config[ENV]['postgres']['datafactory']}
  # pg = PostgresAccessor(pgconfig[ENV])
  # select = "SELECT * FROM development_sbt_models_mmmomentum;"
  # data = pg._execute_query(select, [])
  # mo.create_model_stats_table('mmmomentum', data)

  # mo.do_rankings()
  mo.transfer_data()
  # # mp = MappingAccessor()
  # # deltas = [5]
  # # for deltt in deltas:
  # #   pct_dif_returns = []
  # #   tot_cap = 0
  # #   tot_buy_hold = 0
  # #   company_succeeded = 0
  # #   for company in companies:
  # #     guid = mp.query_symbol_exchange_mappings(list(company.keys())[0])[0]['guid']
  # #     # try:
  # #     values = mo.commodity_vol_strat([-0.04832031, -0.3765332], list(company.keys())[0], guid, cluster_key, zero_day=list(company.values())[0], start_flag=True,
  # #                           # end_day="2019-07-31", delta_t=deltt)
  # #                           end_day=None, delta_t=deltt)
  # #     pct_dif_returns.append(values[0])
  # #     tot_cap += values[1]
  # #     tot_buy_hold += values[2]
  # #     company_succeeded += 1
  # #     print(values[1], values[2])
  # #     print(values[3])
  # #     # except Exception as e:
  # #     #   print(e)
  # #     #   print("Company not supported")
  # #   print(deltt)
  # #   # print("Mean: ", np.mean(pct_dif_returns))
  # #   print("Median: ", np.median(pct_dif_returns))
  # #   # print("Total Trading Strat Capital:", tot_cap)
  # #   # print("Total Buy and Hold Capital:", tot_buy_hold)
  # #   # print("% Diff:", (tot_cap-tot_buy_hold)/tot_buy_hold*100)
  # #   init_investment = 1000*company_succeeded
  # #   print("Algo % Return:", ((tot_cap-init_investment)/init_investment)*100)
  # #   print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)
  # # mo = MMMomentum()
  # # mo.load_data_1()
  # # config = SbtGlobalCommon.get_sbt_config()
  # # mod = ModelAccessor()
  # # mo = MMMomentum()
  # # # symbols = sba.get_model_rankings("MOMENTUM")
  # # mp = MappingAccessor()
  # # symbols = mp.scan_symbol_exchange_mapping_for_sb_portfolios()
  # # s = []
  # # for sy in symbols:
  # #   if sy['exchange_country'] == "USA":
  # #     s.append(mod.query_company_model("MOMENTUM", sy['symbol']))
  # #
  # #
  # # deltas = [50]
  # # for deltt in deltas:
  # #   pct_dif_returns = []
  # #   tot_cap = 0
  # #   tot_buy_hold = 0
  # #   for company in s:
  # #     try:
  # #       values = mo.strategy_1([-0.28552734, 0.3065332], 63, 0, company['symbol'], zero_day=list(company.values())[0], start_flag=True,
  # #                             # end_day="2018-12-31", delta_t=deltt)
  # #                             end_day=None, delta_t=deltt)
  # #       if values[3] == "long" and company['display_value'] < 50:
  # #         print(company['display_value'], values[3])
  # #       elif values[3] == "short" and company['display_value'] >= 50:
  # #         print(company['display_value'], values[3])
  # #       else:
  # #         print("Models in agreement")
  # #       pct_dif_returns.append(values[0])
  # #       tot_cap += values[1]
  # #       tot_buy_hold += values[2]
  # #     except KeyError:
  # #       print("Company not supported")
  # #   print(deltt)
  # #   # print("Mean: ", np.mean(pct_dif_returns))
  # #   # print("Median: ", np.median(pct_dif_returns))
  # #   # print("Total Trading Strat Capital:", tot_cap)
  # #   # print("Total Buy and Hold Capital:", tot_buy_hold)
  # #   # print("% Diff:", (tot_cap-tot_buy_hold)/tot_buy_hold*100)
  # #   init_investment = 1000*len(s)
  # #   print("Algo % Return:", ((tot_cap-init_investment)/init_investment)*100)
  # #   print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)
  #
  #
  #
  # # companies = [{"SPY": "2009-04-01"}, {"MSFT": "2010-11-11"}, {"AAPL": "2008-09-03"}, {"FB": "2017-12-12"},
  # #              {"V": "2016-02-09"}, {"JPM": "2017-05-09"}, {"T": "2018-04-12"}, {"HD": ""}, {"INTC": ""}, {"BA": ""},
  # #              {"NKE": ""}]
  # # tot_cap = 0
  # # tot_buy_hold = 0
  # # for company in companies:
  # #   try:
  # #     values = mo.credit_spread_strat(list(company.keys())[0], delta_t=15)
  # #     tot_cap += values[1]
  # #     tot_buy_hold += values[2]
  # #     # init_investment = 1000
  # #     # print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
  # #     # print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)
  # #   except IndexError:
  # #     print("Company not supported")
  # # init_investment = 1000 * len(companies)
  # # print("Algo % Return:", ((tot_cap - init_investment) / init_investment) * 100)
  # # print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)
  #
  # companies = [{"NVDA": "NSDQ"}, {"RECN": "NSDQ"},{"SDLP": "NYSE"},{"MDLZ": "NSDQ"},{"KL": "NYSE"},{"TMUS": "NSDQ"}, {"KHC": "NSDQ"}, {"TEVA": "NYSE"}, {"M": "NYSE"}, {"WF": "NYSE"}, {"L": "NYSE"}, {"LOW": "NYSE"}, {"AAPL": "NSDQ"}, {"CAT": "NYSE"}, {"MSFT": "NSDQ"},
  #              {"IBM": "NYSE"},  {"GOLD": "NYSE"}, {"DHI": "NYSE"}, {"SLB": "NYSE"}]
  # # companies = [{"MSFT": "2010-11-11"}, {"FSMEX": "2008-09-03"}, {"BRK.B":"2009-04-01"}, {"MTCH":"2017-12-12"},
  # #              {"CBRE": "2016-02-09"}, {"AMZN": "2017-05-09"}, {"IR": "2018-04-12"}, {"GOOGL": "2016-12-13"},
  # #              {"PEY": "2016-04-12"}, {"JPM": "2017-04-11"}, {"PBP":"2013-12-11"},{"LMT":"2017-07-11"},{"MSI":"2018-12-13"},
  # #              {"RMD":"2018-11-14"},{"HII":"2017-01-10"},{"SPR":"2018-08-08"},{"BHC":"2019-03-14"},{"ROL":"2019-04-10"},
  # #              {"GLD":"2008-09-03"},{"VIPSX":"2010-04-23"},{"JPS":"2012-06-21"},{"EMD":"2013-09-11"},{"NUV":"2013-04-10"}]
  # # # #
  # # # companies = [{"SPY": "2014-06-26"}]
  # # # # # #
  # # # # mo = MMMomentum()
  # # # # mp = MappingAccessor()
  # # # # deltas = [5]
  # # # # for deltt in deltas:
  # # # #   pct_dif_returns = []
  # # # #   tot_cap = 0
  # # # #   tot_buy_hold = 0
  # # # #   company_succeeded = 0
  # # # #   for company in companies:
  # # # #     guid = mp.query_symbol_exchange_mappings(list(company.keys())[0])[0]['guid']
  # # # #     try:
  # # # #       values = mo.vol_strategy_2([-0.04832031, -0.3765332], list(company.keys())[0], guid, zero_day=list(company.values())[0], start_flag=True,
  # # # #                             # end_day="2018-12-31", delta_t=deltt)
  # # # #                             end_day=None, delta_t=deltt)
  # # # #       pct_dif_returns.append(values[0])
  # # # #       tot_cap += values[1]
  # # # #       tot_buy_hold += values[2]
  # # # #       company_succeeded += 1
  # # # #       print(values[1], values[2])
  # # # #       print(values[3])
  # # # #     except Exception as e:
  # # # #       print(e)
  # # # #       print("Company not supported")
  # # # #   print(deltt)
  # # # #   # print("Mean: ", np.mean(pct_dif_returns))
  # # # #   print("Median: ", np.median(pct_dif_returns))
  # # # #   # print("Total Trading Strat Capital:", tot_cap)
  # # # #   # print("Total Buy and Hold Capital:", tot_buy_hold)
  # # # #   # print("% Diff:", (tot_cap-tot_buy_hold)/tot_buy_hold*100)
  # # # #   init_investment = 1000*company_succeeded
  # # # #   print("Algo % Return:", ((tot_cap-init_investment)/init_investment)*100)
  # # # #   print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)
  # # # #
  # # # # #
  # companies = [{"AAPL": "2014-06-26"}]
  # # # # # # # #
  # # # # # # # # companies = [{"CBRE": "2018-03-28"}]
  # # # # # # # #
  # # # # # # # # # deltas = [5,4,3,2]
  # # # # # # # # # deltas = [5, 10, 15, 20, 25]
  # mo = MMMomentum()
  #
  # production = ["NVDA", "MDLZ", "KHC", "TEVA", "M", "L", "MSFT", "IBM", "MTCH", "CBRE", "AMZN", "GOOGL",
  #               "PBP", "LMT", "SPR", "GLD", "NUV"]
  # new_accel = ["RECN", "SDLP", "KL", "TMUS", "WF", "LOW", "AAPL", "CAT", "GOLD", "DHI", "SLB", "BRK.B",
  #              "IR", "PEY", "JPM", "MSI", "RMD", "HII", "BHC", "ROL", "JPS", "EMD"]
  # companies = production+new_accel
  # print(companies)
  # deltas = [5]
  # for deltt in deltas:
  #   pct_dif_returns = []
  #   tot_cap = 0
  #   tot_buy_hold = 0
  #   company_succeeded = 0
  #   for company in companies:
  #     try:
  #       if company in production:
  #         values = mo.production_strategy([-0.04832031, -0.3765332], company,
  #                                                 start_flag=True,
  #                                                 # end_day="2016-05-03", delta_t=deltt)
  #                                                 end_day=None, delta_t=deltt)
  #         pct_dif_returns.append(values[0])
  #         tot_cap += values[1]
  #         tot_buy_hold += values[2]
  #         company_succeeded += 1
  #         print(values[1], values[2])
  #       elif company in new_accel:
  #         values = mo.acceleration_test_September([-0.04832031, -0.3765332], company, start_flag=True,
  #                               # end_day="2016-05-03", delta_t=deltt)
  #                               end_day=None, delta_t=deltt)
  #         pct_dif_returns.append(values[0])
  #         tot_cap += values[1]
  #         tot_buy_hold += values[2]
  #         company_succeeded += 1
  #         print(values[1], values[2])
  #       # print(values[3])
  #     except Exception as e:
  #       print(e)
  #       print("Company not supported")
  #   print(deltt)
  #   # print("Mean: ", np.mean(pct_dif_returns))
  #   print("Median: ", np.median(pct_dif_returns))
  #   # print("Total Trading Strat Capital:", tot_cap)
  #   # print("Total Buy and Hold Capital:", tot_buy_hold)
  #   # print("% Diff:", (tot_cap-tot_buy_hold)/tot_buy_hold*100)
  #   init_investment = 1000*company_succeeded
  #   print("Algo % Return:", ((tot_cap-init_investment)/init_investment)*100)
  #   print("Baseline % Return:", ((tot_buy_hold - init_investment) / init_investment) * 100)
  companies = [{"NVDA": "NSDQ"}, {"RECN": "NSDQ"}, {"SDLP": "NYSE"}, {"MDLZ": "NSDQ"}, {"KL": "NYSE"},
               {"TMUS": "NSDQ"}, {"KHC": "NSDQ"}, {"TEVA": "NYSE"}, {"M": "NYSE"}, {"WF": "NYSE"}, {"L": "NYSE"},
               {"LOW": "NYSE"}, {"AAPL": "NSDQ"}, {"CAT": "NYSE"}, {"MSFT": "NSDQ"},
               {"IBM": "NYSE"}, {"GOLD": "NYSE"}, {"DHI": "NYSE"}, {"SLB": "NYSE"}]

  # mo = MMMomentum(companies)
  # result = optimize.fmin(mo.optimize_params, np.array([-.5]))
  # result = optimize.fmin_powell(mo.optimize_params, np.array([-.3, .3]))
  # print(result)

  # dd = DynamoAccessor()
  # symbols = dd._scan_table_with_filter_str("SBT_SYMBOL_EXCHANGE_MAPPING", "exchange_type eq STOCK")
  # # symbols = mp.scan_symbol_exchange_mapping(exchange_type="STOCK")
  # companies = []
  # for sy in symbols:
  #   if 'NYSE' in sy['exchange'] or 'NSDQ' in sy['exchange']:
  #     # if sy['exchange_country'] == "USA" and sy['exchange'] != 'OTC':
  #     companies.append(sy['symbol'])
  # mo = MMMomentum()
  # deltas = [5]
  # with open('best_performer.txt', 'a') as f:
  #   # companies =['AAPL']
  #   for deltt in deltas:
  #     pct_dif_returns = []
  #     tot_cap = 0
  #     tot_buy_hold = 0
  #     company_succeeded = 0
  #     for company in companies:
  #       try:
  #         values = mo.acceleration_test_September([-0.04832031, -0.3765332], company,
  #                                                 start_flag=True,
  #                                                 # end_day="2016-05-03", delta_t=deltt)
  #                                                 end_day=None, delta_t=deltt)
  #         tot_cap = values[1]
  #         values = mo.production_strategy([-0.04832031, -0.3765332], company,
  #                                                 start_flag=True,
  #                                                 # end_day="2016-05-03", delta_t=deltt)
  #                                                 end_day=None, delta_t=deltt)
  #         if values[1] > tot_cap:
  #           f.write(company + ' production')
  #         else:
  #           f.write(company + ' accel_Sept')
  #       except Exception as e:
  #         print(e)
  #         print("Company not supported")

