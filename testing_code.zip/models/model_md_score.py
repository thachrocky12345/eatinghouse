from datetime import datetime
from decimal import Decimal

import numpy as np
import pandas as pd
import sqlalchemy

from dd_accessor import DynamoAccessor
from fs_accessor import FinancialAccessor, FinancialVendors
from sbt_common import SbtGlobalCommon
from pg_accessor import PostgresAccessor
from sqlalchemy.types import JSON, VARCHAR, FLOAT
from snp_accessor import SNPAccessor

g_logger = SbtGlobalCommon.get_global_logger()

# environment to update
env = 'models'

# get the config
config = SbtGlobalCommon.raw_sbt_config[env]['postgres']['datafactory']
# create an instance of the PG accessor
pg = PostgresAccessor(config)

# prefix to add to the name of the tables that will contain the results
RESULT_TABLENAME_PREFIX = 'development_sbt_models'

# # table name to read the symbols from
SYMBOL_MAPPING_TABLENAME = 'DEV_SBT_SYMBOL_EXCHANGE_MAPPING'


class MdScore(DynamoAccessor):

    def __init__(self):
        super().__init__()
        self.financial = FinancialAccessor(
            FinancialVendors.STANDARD_AND_POORS.value
        )
        # self.all_symbols = SbtGlobalCommon.all_symbols
        g_logger.critical(" MDSCORE: READING SYMBOL EXCHANGE MAPPING TABLE...")
        tic = datetime.now()
        # scan
        self.all_symbols_list = self._scan_table_with_filter_str(
           SYMBOL_MAPPING_TABLENAME , 'symbol ne mairan'
        )
        # query by GUID
        # self.all_symbols_list = self._query_table(
        #     SYMBOL_MAPPING_TABLENAME,
        #     'guid', 'e57e18f1-dd2b-433e-8378-6905df730dcb',
        #     index_name='GUIDidx'
        # )
        g_logger.critical(" MDSCORE: READING TABLE FINISHED IN Dt = {}.".format(
            datetime.now() - tic
        ))
        # converting to a dataframe
        self.all_symbols = pd.DataFrame(self.all_symbols_list)
        # list of indices to be excluded from the model calculations
        # # TODO: utilize 'index' = True/False instead of this list
        # self.LIST_OF_INDICES = ['COMPQ:NSDQ', 'DJA:NYSE', 'DJI:NYSE',
        #                         'NDX:NSDQ', 'SPX:NYSE', 'TRAN:NYSE',
        #                         'UTIL:NYSE']

        pgconfig = SbtGlobalCommon.get_sbt_config()['postgres'][
            'snpcompanyfinancials']
        # create an instance of the PG accessor
        __PG_HOST = pgconfig['host']
        __PG_CREDENTIALS = pgconfig['credentials']
        __PG_USER = pgconfig['user']
        __PG_DBNAME = pgconfig['database']
        # dialect+driver://username:password@host:port/database
        self._PG_ENGINE1 = sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=__PG_USER, password=__PG_CREDENTIALS,
                host=__PG_HOST, db=__PG_DBNAME
            )
        )

        pgconfig = SbtGlobalCommon.get_sbt_config()['postgres']['snpsource']
        # create an instance of the PG accessor
        __PG_HOST = pgconfig['host']
        __PG_CREDENTIALS = pgconfig['credentials']
        __PG_USER = pgconfig['user']
        __PG_DBNAME = pgconfig['database']
        # dialect+driver://username:password@host:port/database
        self._PG_ENGINE2 = sqlalchemy.create_engine(
            'postgresql+psycopg2://{user}:{password}@{host}/{db}'.format(
                user=__PG_USER, password=__PG_CREDENTIALS,
                host=__PG_HOST, db=__PG_DBNAME
            )
        )

    def _query_all_data(self, symbol, symbol_id, parameter_dict,
                        period_type_str, sort_order):
        g_logger.critical(" QUERYING ALL DATA FOR GUID = {}".format(symbol))
        # company_type
        # company_type = SNPAccessor._snp_warehouse_accessor._reporting_templates[symbol_type]
        company_type = 'TBI'
        # period definitions
        period_type = SNPAccessor._snp_fiscal_period_lookup.get(
            period_type_str)
        period_prefix = SNPAccessor._fiscal_period_prefix.get(period_type_str)
        period_suffix = SNPAccessor._fiscal_period_suffix.get(period_type_str)

        # get vendor data item id for the column names used in the terminal
        _SQL_STATEMENT1 = """
        SELECT snp_data_item_id, sbt_data_item_id FROM public.snp_data_item 
        WHERE sbt_data_item_id in ('{}')
        """.format("', '".join([str(x) for x in parameter_dict]))

        parameter_df = pd.read_sql_query(_SQL_STATEMENT1,
                                         self._PG_ENGINE1,
                                         coerce_float=True
                                         )
        parameter_dict = {int(y): x
                          for x, y in zip(parameter_df.sbt_data_item_id.values,
                                          parameter_df.snp_data_item_id.values
                                          )
                          }

        # get data from the latest financial statement
        _SQL_STATEMENT = """
        SELECT c.companyname, c.reportingtemplatetypeid,
        lp.filingdate, lp.fiscalyear, pt.periodtypeid, pt.periodtypename, 
        lp.fiscalquarter, lp.calendaryear, lp.calendarquarter, 
        lp.periodenddate, un.unittypeid, un.unittypename, di.dataitemid, 
        di.dataitemname, di.dataitemdescription, fd.dataitemvalue 
        FROM public.ciqfinancialdata fd 
        JOIN public.ciqlatestinstancefinperiod lp USING("financialperiodid") 
        JOIN public.ciqcompany c ON lp.companyid = c.companyid 
        JOIN public.ciqdataitem di ON fd.dataitemid = di.dataitemid 
        JOIN public.ciqfinunittype un ON un.unittypeid = fd.unittypeid 
        JOIN public.ciqperiodtype pt ON pt.periodtypeid = lp.periodtypeid 
        WHERE lp.companyid = {} 
            AND lp.periodtypeid = {}
            AND di.dataitemid in ({})
        ORDER BY lp.fiscalyear {}, lp.fiscalquarter {}
        """.format(symbol_id,
                   period_type,
                   ", ".join([str(k) for k, v in parameter_dict.items()]),
                   sort_order, sort_order
                   )

        results = pd.read_sql_query(_SQL_STATEMENT,
                                    self._PG_ENGINE2,
                                    coerce_float=True
                                    )

        # format object to be returned (grouped by parameter list)
        rval = {parameter_dict.get(x[0]): {
            'ticker': symbol.split(':')[0],
            'data_tag': parameter_dict.get(x[0]),
            'data': [
                {'date': d.strftime("%Y-%m-%d"),
                 'timestamp': int(d.timestamp()),
                 'fiscal_id': '{}Q{}{}'.format(fy, fq, period_suffix),
                 'fiscal_year': fy,
                 'fiscal_period': 'Q{}{}'.format(fq, period_suffix),
                 'value': v} for d, fy, fq, p, v in
                zip(x[1]['periodenddate'], x[1]['fiscalyear'],
                    x[1]['fiscalquarter'], x[1]['periodtypename'],
                    x[1]['dataitemvalue'])
            ],
            'category': '',
            'company_type': '',
            'description': x[1].get('dataitemname').iloc[0]
        } for x in results.groupby(by='dataitemid')}

        # # create zero object (financial parameters that are zero)
        # for x in parameter_dict.values():
        #     if x not in list(rval.keys()):
        #         rval[x] = {
        #             'ticker': symbol.split(':')[0],
        #             'data_tag': x,
        #             'data': [],
        #             'category': '',
        #             'company_type': '',
        #             'description':
        #         }

        # check if we have data for all the parameters
        # necessary to calculate the company's ranking
        is_all_parameters_present = len(rval) == len(parameter_dict)

        g_logger.critical(" - DONE QUERYING ALL DATA FOR GUID = {}".format(
            symbol)
        )
        return rval #if is_all_parameters_present else None

    def _get_all_data(self, params, period_type, symbols, symbol_ids,
                      # symbols_type,
                      raw_data_labels):

        # TODO: call self._query_all_data() here and
        #   transform data to the current format
        #
        # _query_all_data(symbol_id, params, 4, 'desc') => {
        #                                                    {param1: res1},
        #                                                    {param1: res1},
        #                                                    ...,
        #                                                    {paramN: resN}
        #                                                  }
        #

        # retrieve all data (
        all_data = {sym: self._query_all_data(sym[0], sym_id,
                                              params,
                                              period_type, 'desc'
                                              )
                    for sym, sym_id in zip(symbols.items(), symbol_ids)
                    }

        # all_data = {symbol: {par: (self.financial.query_history_data(symbol,
        #                                                              par,
        #                                                              't',
        #                                                              'desc'
        #                                                              )
        #                            ) for par in params
        #                      } for symbol in symbols
        #             }

        # add raw data to the dict
        # drop items without the necessary data
        all_data = {k: v for k, v in all_data.items() if v is not None}

        # add financial parameters that were not returned by the query (zero)
        for symbol in symbols.items():
            for k, v in raw_data_labels.items():
                if k not in all_data[symbol].keys():
                    now = datetime.now()
                    all_data[symbol][k] = {
                        'ticker': symbol[1].split(':')[0],
                        'data_tag': k,
                        'data': [
                            {'date': now.strftime("%Y-%m-%d"),
                             'timestamp': int(now.timestamp()),
                             'fiscal_id': '',
                             'fiscal_year': '',
                             'fiscal_period': '',
                             'value': 0}
                        ],
                        'category': '',
                        'company_type': '',
                        'description': v
                    }
        raw_data = {}
        for k, v in all_data.items():
            g_logger.critical(" TRANSFORMING RAW DATA FOR GUID = {}".format(k[0]))
            for x, y in v.items():
                if x in raw_data_labels.keys() and 'data' in y.keys():
                    # g_logger.critical(" - x = {}, y = {}".format(x, y))
                    my_dict = {
                        k[0]: {'model':
                                {'raw_data':
                                     {x: y['data']
                                      for x, y in v.items()
                                      if x in raw_data_labels.keys()
                                      },
                                 'composite_pk_id': k[1]
                                 }
                            }
                        for k, v in all_data.items()
                    }
                    raw_data.update(my_dict)
                else:
                    g_logger.critical(
                        " - {} NOT IN raw_data_labels.".format(x))

        # add descriptions to the raw data
        [v['model']['raw_data'].update(
            descriptions=[{'field': f, 'description': d}
                          for f, d in raw_data_labels.items()
                          ]
        ) for k, v in raw_data.items()]

        # converting all data into a dict
        all_data_dict = {'guid': [k[0] for k in all_data.keys()],
                         'composite_pk_id': [k[1] for k in all_data.keys()]
                         }
        all_data_updates = {par: [all_data[(guid, cpkid)][par]['data'][0]['value']
                                  if len(all_data[(guid,cpkid)][par]['data']) > 0
                                  else None
                                  for guid, cpkid in zip(all_data_dict['guid'],
                                                         all_data_dict['composite_pk_id']
                                                         )]
                            for par in params
                            }
        all_data_dict.update(all_data_updates)
        # from dict to df
        df = pd.DataFrame.from_dict(all_data_dict)
        # set the df index to symbols
        df.set_index('guid', drop=True, inplace=True)

        # return the full df and raw data
        return df, raw_data

    def _save_model_results(self, ranked_results, model_calculations, raw_data,
                            model_calculations_labels, model_id,
                            calculation_id=None):
        model_id = model_id.lower()
        calculation_id = calculation_id.lower() if calculation_id is not None \
            else None
        # SAVING MODEL RESULTS
        g_logger.critical(' MD SCORE {}: SAVING RESULTS INTO PG...'.format(
            calculation_id.upper())
        )
        tic = datetime.now()
        # ranked results
        val_rank_ok = ranked_results
        # model specific calculations
        val = model_calculations
        # raw data
        data = raw_data
        # model-specific calculated data labels
        calculated_data_labels = model_calculations_labels

        # export to csv
        val_rank_ok.to_csv('~/RESULT_{}_{}.csv'.format(model_id.upper(),
                                                       calculation_id.upper()
                                                       )
                           )
        val.to_csv('~/RAW_DATA_{}_{}.csv'.format(model_id.upper(),
                                                 calculation_id.upper()
                                                 )
                   )

        # create df containing the score and the rank for the model
        d = {'score': val_rank_ok['average'],
             'rank': val_rank_ok['rank']
             }
        rank_score_df = pd.DataFrame(data=d)

        # only save data that has a score
        data = {k: v for k, v in data.items()
                if k in rank_score_df.index
                }

        # adding calculated data
        [data[symbol]['model'].update(
            calculated_data={
                x: {
                    'value':
                        val[x][symbol] if symbol in val[x] else None,
                    'calculation':
                        val[x][symbol] if symbol in val[x] else None,
                    'date_calculated':
                        datetime.now().strftime("%Y-%m-%d"),
                    'rank':
                        val[x][symbol] if symbol in val[x] else None,
                    'description': calculated_data_labels[x]['label'],
                    'display_value_as': calculated_data_labels[x]['display_value_as']
                } for x in val if x in calculated_data_labels.keys()
            }
        ) for symbol in data.keys()]

        # add other attributes
        [data[symbol]['model'].update(
            date_calculated = datetime.now().strftime("%Y-%m-%d"),
            guid=symbol,
            score=rank_score_df['score'][symbol] if symbol in rank_score_df[
                'score'] else None,
            value=rank_score_df['score'][symbol] if symbol in rank_score_df[
                'score'] else None,
            rank=rank_score_df['rank'][symbol] if symbol in rank_score_df[
                'score'] else None,
            # get the rating based on the rank (not the score)
            rating=self.rate(model_id,
                             rank_score_df['rank'][symbol])
            if symbol in rank_score_df['score'] else None,
        ) for symbol in data.keys()]

        # create final dict containing the results for the model
        data = {k: {'model': v,
                    'score': v['model']['score'],
                    'rank': v['model']['rank'],
                    'rating': v['model']['rating'],
                    'composite_pk_id': v['model']['composite_pk_id']
                    } for k, v in data.items()
                }

        # create final df containing everything for each company
        res = pd.DataFrame(data).T
        res.sort_values(by=['score'], ascending=False, inplace=True)

        # save to PG
        res.to_sql(
            "{}_mdscore_{}".format(
                RESULT_TABLENAME_PREFIX,
                calculation_id
            ),
            pg._engine,
            if_exists='replace',
            index_label='guid',
            dtype={'model': JSON,
                   'score': FLOAT,
                   'rank': FLOAT,
                   'rating': VARCHAR,
                   'composite_pk_id': VARCHAR
                   }
        )

        g_logger.critical(' MD SCORE {} RESULTS SAVED IN Dt = {}'.format(
            calculation_id, datetime.now() - tic)
        )

        return res

    def _create_model_stats_table(self, model_id=None,
                                  calculation_id=None, data=None):
        g_logger.critical(' MD SCORE {} CREATING STATS TABLE IN PG...'.format(
            calculation_id.upper())
        )
        tic = datetime.now()
        model_id = "".join(model_id.lower().split("_"))
        calculation_id = calculation_id.lower() if calculation_id is not None \
            else None
        # rating stats table
        TABLE_NAME = "{}_{}_{}_rating_stats".format(RESULT_TABLENAME_PREFIX,
                                                    model_id,
                                                    calculation_id
                                                    ) \
            if calculation_id is not None \
            else "{}_{}_rating_stats".format(RESULT_TABLENAME_PREFIX, model_id)
        # get the min/max for the model's score
        df_stats = pd.DataFrame(
            ((x[1]['model']['rating'],
              x[1]['model']['score']) for x in data.values),
            columns=['rating', 'score']).groupby(by='rating')\
            .agg({"score": [min, max, "count"]})

        # rename columns
        df_stats.columns = ['minscore', 'maxscore', 'total']
        # save rating stats
        df_stats.to_sql(TABLE_NAME,
                        pg._engine,
                        if_exists='replace',
                        index_label='rating'
                        )

        # score stats table
        TABLE_NAME = "{}_{}_{}_score_stats".format(RESULT_TABLENAME_PREFIX,
                                                   model_id,
                                                   calculation_id
                                                   )
        model_stat_df = data.agg({'score': [min, max, 'count']}).T
        # rename columns
        model_stat_df.columns = ['minscore', 'maxscore', 'total']
        # stats per model (total within each score bin)
        model_stat_score_bin_df = pd.DataFrame(data.groupby(
            pd.cut(data['score'], [-1000, 0, 0.20, 0.40, 0.60, 0.80, 1.00])
        )['score'].count()).T
        # rename columns
        model_stat_score_bin_df.columns = ['b0', 'b1', 'b2', 'b3', 'b4', 'b5']
        # create final df
        model_score_stat_df = pd.concat(
            [model_stat_df, model_stat_score_bin_df], axis=1)
        # save score stats
        model_score_stat_df.to_sql(TABLE_NAME,
                                   pg._engine,
                                   if_exists='replace'
                                   )

        g_logger.critical(
            ' MD SCORE {} TABLE CREATED IN Dt = {}'.format(
                calculation_id, datetime.now() - tic)
        )

    @staticmethod
    def rate(model_id, value):
        model_id = model_id.lower()
        # appending the A-F rating (replacement for the star rating)
        if model_id == 'momentum':
            # breakdown as suggested by Brett
            # http://wiki.cloudsna.com:8090/display/TERM/Breakdown+of+Momentum+Model
            # N.B.: 'rank_value' is the model score, which is a natural number.
            x = 100 * value
            if x >= 86:
                grade = 'A'
            elif (x >= 66) and (x <= 85):
                grade = 'B'
            elif (x >= 50) and (x <= 65):
                grade = 'C'
            elif (x >= 25) and (x <= 49):
                grade = 'D'
            elif x <= 24:
                grade = 'F'
            else:
                grade = 'N/A'

            return grade

        if "".join(model_id.split('_')) == 'mdscore':
            # based on the model conception, we can organized the model score
            # into 5 regularly separated ratings category
            # N.B.: 'rank_value' is the percentile rank from the MD score
            # (i.e., its score) model, so it is a rational number.
            x = value * 100
            if x >= 80:
                grade = 'A'
            elif (x >= 60) and (x < 80):
                grade = 'B'
            elif (x >= 40) and (x < 60):
                grade = 'C'
            elif (x >= 20) and (x < 40):
                grade = 'D'
            elif x < 20:
                grade = 'F'
            else:
                grade = 'N/A'

            return grade

        if model_id == 'capital_efficiency':
            # CE grading is based on a point system for each metric used
            # in the model
            # points = [get_points_ce_model({x['calculation_id']: x})
            #           for x in [calculated_data]]
            # x = sum(points)
            x = 100 * value
            if (x >= 80) and (x <= 100):
                grade = 'A'
            elif (x >= 70) and (x < 80):
                grade = 'B'
            elif (x >= 40) and (x < 70):
                grade = 'C'
            elif (x >= 20) and (x < 40):
                grade = 'D'
            elif x <= 20:
                grade = 'F'
            else:
                grade = 'N/A'

            return grade

    def _new_peratio_calculation(self, table_name, symbol, attribute):
        # data from the corresponding DynamoDB table
        data = self._query_table(table_name,
                                 'ticker', symbol)
        # fiscal_id corresponding to the DynamoDB table
        fiscal_ids_to_update = [data[i]['fiscal_id'] for i in range(len(data))
                                if (data[i]['fiscal_id'].startswith(
                ('2017', '2018')))]
        if len(fiscal_ids_to_update) > 0:
            # sorting to match the fiscal_id list from S&P
            fiscal_ids_to_update.sort(reverse=True)

            expression_attribute_names = {"#{}".format(attribute): attribute}

            # get old P/E ratio
            old_peratio = self.financial.query_history_data(
                symbol, attribute, 't', 'desc'
            )

            # get fiscal_id from old P/E ratio dataset
            fiscal_ids_existent = [x['fiscal_id'] for x in old_peratio['data']
                                   if (x['fiscal_id'].startswith(
                    ('2017', '2018')))]

            # get data for new calculation
            ebit = self.financial.query_history_data(
                symbol, 'ebit', 't', 'desc'
            )
            price = self.financial.query_history_data(
                symbol, 'periodlaststockprice', 't', 'desc'
            )
            shares_outstanding = self.financial.query_history_data(
                symbol, 'totalsharesoutstanding', 't', 'desc'
            )

            # updating only 2017 and 2018 data
            ebit = [x for x in ebit['data']
                    if x['fiscal_id'].startswith(('2017', '2018'))]
            price = [x for x in price['data']
                     if x['fiscal_id'].startswith(('2017', '2018'))]
            shares = [x for x in shares_outstanding['data']
                      if x['fiscal_id'].startswith(('2017', '2018'))]
            # calculating the new P/E ratio
            new_values = [Decimal(str(p['value'] / (e['value'] / s['value'])))
                          for p, e, s in zip(price, ebit, shares)]

            # group by Q (#, TTM, YTD, FY) and update with the same P/E ratio
            new_list = [[{y: x, 'value': new_values[i]}
                         for i, x in enumerate(fiscal_ids_existent)
                         if (x.startswith(y[:6]) |
                             (y.endswith('FY') & (x.startswith(y[:4]))))]
                        for y in fiscal_ids_to_update]
            # removing empty lists (date incompatibility between providers)
            new_list = [x[0] for x in new_list if len(x) > 0]

            # transform list of dict into a plain list
            new_values_extended = []
            [new_values_extended.append(x['value']) for x in new_list]
            new_fiscal_ids_to_update = []
            [new_fiscal_ids_to_update.append(list(x.keys())[0]) for x in
             new_list]

            # do the updating
            [self._update(table_name=table_name,
                          attributes_to_update=[attribute],
                          attribute_values=[new_value],
                          key={'ticker': symbol, 'fiscal_id': fiscal_id},
                          expression_attribute_names=expression_attribute_names)
             for fiscal_id, new_value
             in zip(new_fiscal_ids_to_update, new_values_extended)]

            print("DONE")
        else:
            print("Nothing to update for {}.".format(symbol))

    def apply_correction(self):
        '''
        Apply 'correction' to the P/E ratio provided by S&P for 2017 and 2018 due
        to changes in tax policy.
        :return:
        '''
        attribute_to_update = 'pricetoearnings'

        # symbol_list = self.symbols.keys()
        symbol_list = ['GS',
                       'IBM',
                       'TRV',
                       'AXP',
                       'WMT',
                       'DIS',
                       'VZ',
                       'JPM',
                       'GE',
                       'AAPL',
                       'PG',
                       'CSCO',
                       'PFE',
                       'CAT',
                       'INTC',
                       'XOM',
                       'BA',
                       'UTX',
                       'UNH',
                       'HD',
                       'JNJ',
                       'MRK',
                       'CVX',
                       'DWDP',
                       'MCD',
                       'MMM',
                       'KO',
                       'MSFT',
                       'NKE',
                       'V']

        # get table name for each symbol (INDU or FIN)
        table_list = [self._find_table_name(t, attribute_to_update)
                      for t in symbol_list]
        # apply correction
        [self._new_peratio_calculation(table, symbol, attribute_to_update)
         for table, symbol in zip(table_list, symbol_list)]

        print("DONE.")

    def do_valuation(self):
        g_logger.critical(" RUNNING VALUATION NOW...")
        model_id = "MD_SCORE"
        calculation_id = "VALUATION"
        # # VALUATION aspect
        tic = datetime.now()
        # get only USA STOCKS traded in NYYSE* or NSDQ*
        symbols_data = self.all_symbols[
            (self.all_symbols.exchange_type == 'STOCK')
            & (self.all_symbols.exchange_country == 'USA')
            & ((self.all_symbols.exchange.str.startswith('NYSE'))
               | (self.all_symbols.exchange.str.startswith('NSDQ'))
               )
            ]
        # get all composite_pk_id, snp_id, and index info
        # (ignore snp_id = NaN)
        symbols_data = [(x, int(y), z)
                        for x, y, z in zip(symbols_data['guid'],
                                           symbols_data['snp_id'],
                                           symbols_data['composite_pk_id'],
                                           # symbols_data['snp_type']
                                           ) if not np.math.isnan(y)
                        ]

        # keep GUID and SYMBOL:EXCHANGE
        symbols = {x[0]: x[2] for x in symbols_data}
        symbols_id = [x[1] for x in symbols_data]
        # symbols_type = [x[3] for x in symbols_data if not x[2]]

        # restrict local calculations to the first 100 items
        # symbols, symbols_id = symbols[:100], \
        #                       symbols_id[:100]
        # symbols_type[:100]
        # symbols = {k: v for i, (k, v) in enumerate(symbols.items())
        #            if i + 1 <= 10
        #            }
        # symbols_id = symbols_id[:10]

        #
        # RAW PARAMETERS NEEDED (MODEL SPECIFIC)
        raw_data_labels = {
            'ebitda': 'EBITDA',
            'evtoebitda': 'EV To EBITDA',
            'pricetoearnings': 'Price To Earnings',
            'marketcap': 'Market Cap',
            'paymentofdividends': 'Paid Dividends',
            'repurchaseofcommonequity': 'Repurchase Of Common Equity',
            'issuanceofcommonequity': 'Issuance Of Common Equity',
            'enterprisevalue': 'Enterprise value',
            'freecashflow': 'Free cash flow',
            'periodlaststockprice': 'Last period stock price',
            'salespershare': 'Sales per share'
        }
        params = [k for k in raw_data_labels.keys()]

        #
        # DESCRIPTIONS TO BE DISPLAYED IN THE UI (MODEL SPECIFIC)
        #
        # CALCULATED PARAMETERS
        calculated_data_labels = {
            'evtoebitda': {'label': 'EV To EBITDA',
                           'display_value_as': 'ratio'
                           },
            'pricetoearnings': {'label': 'Price To Earnings',
                                'display_value_as': 'ratio'
                                },
            'pricetosales': {'label': 'Price To Sales',
                             'display_value_as': 'ratio'
                             },
            'shy': {'label': 'Shareholder Yield',
                    'display_value_as': 'percentage'
                    },
            'evtofcf': {'label': 'EV to Free Cash Flow',
                        'display_value_as': 'ratio'
                        }
        }

        # GET DF WITH ALL THE DATA/LABELS AS WELL AS THE RAW DATA
        period_type = 't'
        df, raw_data = self._get_all_data(params, period_type,
                                          symbols, symbols_id,
                                          # symbols_type,
                                          raw_data_labels
                                          )

        g_logger.critical(' MD SCORE VALUATION CALCULATED IN Dt = {}'.format(
            datetime.now() - tic)
        )

        # ### MODEL CALCULATIONS (MODEL SPECIFIC)
        # removing invalid values (divisor in the calculations)
        df = df.where(
            (df.freecashflow > 0)
            & (df.salespershare > 0)
            & (df.marketcap > 0)
        ).dropna()

        # #### calculations
        # #### calculation of shareholder yield
        # (({dividends} * -1) + (
        #           {issuance_of_common_equity} - {repurchase_of_common_equity})) / {
        # market_cap} * 100
        df['shy'] = (df.repurchaseofcommonequity
                     + df.issuanceofcommonequity
                     + df.paymentofdividends) * (-1) \
                    / df.marketcap * 100
        # #### calculation of Price-to-sales ratio
        # {period_last_stock_price} / {sales_per_share}
        df['pricetosales'] = df.periodlaststockprice / df.salespershare
        df['evtofcf'] = df.enterprisevalue / df.freecashflow

        # removing NaN and inf in place
        df = df.replace([np.inf, -np.inf], np.nan).dropna()

        # removing invalid values
        df = df.where(
            (df.evtoebitda > 0)
            & (df.pricetoearnings > 0)
            & (df.evtofcf > 0)
        ).dropna()

        # ### RANKING (MODEL SPECIFIC)
        # h: better
        df['shy_rank'] = df.shy.rank(pct=True)
        # l: better
        df['ps_rank'] = df.pricetosales.rank(pct=True,
                                             ascending=False
                                             )
        # l: better
        df['pe_rank'] = df.pricetoearnings.rank(pct=True,
                                                ascending=False
                                                )
        # l: better
        df['evtoebitda_rank'] = df.evtoebitda.rank(pct=True,
                                                   ascending=False
                                                   )
        # l: better
        df['evtofcf_rank'] = df.evtofcf.rank(pct=True,
                                             ascending=False
                                             )
        df_rank = df[
            ['shy_rank',
             'ps_rank',
             'pe_rank',
             'evtoebitda_rank',
             'evtofcf_rank']
        ]

        # average percentile rank (score)
        # select companies with at most 2 NaN metrics (to fulfill m=3)
        df_rank_ok = df_rank.loc[df_rank.isnull().sum(axis=1) <= 2]
        df_rank_ok['average'] = df_rank_ok.mean(axis=1)
        df_rank_ok['rank'] = df_rank_ok.average.rank(pct=True)

        # # Composite rank (l: better)
        # val_rank_ok['overall_rank'] = val_rank_ok.average.rank(pct=True,
        #                                                        ascending=False)

        # sorting the companies by their average percentile rank
        df_rank_ok.sort_values(by=['average'],
                               ascending=False,
                               na_position='last',
                               inplace=True
                               )

        # SAVE THE RESULTS IN PG
        res = self._save_model_results(df_rank_ok,
                                       df,
                                       raw_data,
                                       calculated_data_labels,
                                       model_id,
                                       calculation_id
                                       )

        self._create_model_stats_table(model_id=model_id,
                                       calculation_id=calculation_id,
                                       data=res
                                       )

        g_logger.critical(' MD SCORE VALUATION FINISHED.')

        return res

    def do_financial(self):
        g_logger.critical(" RUNNING FINANCIAL NOW...")
        model_id = "MD_SCORE"
        calculation_id = "FINANCIAL"
        # # FINANCIAL aspect
        tic = datetime.now()
        # get only USA STOCKS traded in NYYSE* or NSDQ*
        symbols_data = self.all_symbols[
            (self.all_symbols.exchange_type == 'STOCK')
            & (self.all_symbols.exchange_country == 'USA')
            & ((self.all_symbols.exchange.str.startswith('NYSE'))
               | (self.all_symbols.exchange.str.startswith('NSDQ'))
               )
            ]
        # get all composite_pk_id, snp_id, and index info
        # (ignore snp_id = NaN)
        symbols_data = [(x, int(y), z)
                        for x, y, z in zip(symbols_data['guid'],
                                           symbols_data['snp_id'],
                                           symbols_data['composite_pk_id'],
                                           # symbols_data['snp_type']
                                           ) if not np.math.isnan(y)
                        ]

        # keep GUID and SYMBOL:EXCHANGE
        symbols = {x[0]: x[2] for x in symbols_data}
        symbols_id = [x[1] for x in symbols_data]
        # symbols_type = [x[3] for x in symbols_data if not x[2]]

        # restrict local calculations to the first 100 items
        # symbols, symbols_id = symbols[:100], \
        #                       symbols_id[:100]
        # symbols_type[:100]
        # symbols = {k: v for i, (k, v) in enumerate(symbols.items())
        #            if i + 1 <= 10
        #            }
        # symbols_id = symbols_id[:10]

        # RAW PARAMETERS NEEDED (MODEL SPECIFIC):
        raw_data_labels = {
            'freecashflow': 'FCF',
            'netdebt': 'Net debt',
            'debttoequity': 'Debt-to-equity',
            'issuanceofcommonequity': 'Issuance of common equity',
            'issuanceofdebt': 'Issuance of debt',
            'totalassets': 'Total assets',
            'debt': 'Debt'
        }
        params = [k for k in raw_data_labels.keys()]

        #
        # DESCRIPTIONS TO BE DISPLAYED IN THE UI (MODEL SPECIFIC)
        #
        # CALCULATED PARAMETERS
        calculated_data_labels = {
            'debttocf': {'label': 'Debt-to-cash-flow ratio',
                         'display_value_as': 'ratio'
                         },
            'externalfinancing': {'label': 'External financing',
                                  'display_value_as': 'percentage'
                                  },
            'changedebt': {'label': 'One-year change in debt',
                           'display_value_as': 'percentage'
                           }
        }

        # GET DF WITH ALL THE DATA/LABELS AS WELL AS THE RAW DATA
        period_type = 't'
        df, raw_data = self._get_all_data(params, period_type,
                                          symbols, symbols_id,
                                          # symbols_type,
                                          raw_data_labels
                                          )

        g_logger.critical(' MD SCORE FINANCIAL CALCULATED IN Dt = {}'.format(
            datetime.now() - tic)
        )

        # ### MODEL CALCULATIONS (MODEL SPECIFIC)
        # removing invalid values (divisor in the calculations)
        df = df.where(
            (df.freecashflow > 0)
            & (df.totalassets > 0)
        ).dropna()

        # #### calculations
        df['debttocf'] = df.netdebt / df.freecashflow
        df['externalfinancing'] = (df.issuanceofcommonequity
                                   + df.issuanceofdebt) / df.totalassets
        # 1-yr change in debt is defined as current_debt / past_year_debt - 1
        df['changedebt'] = [v['model']['raw_data']['debt'][0]['value']
                            / v['model']['raw_data']['debt'][4]['value'] - 1.0
                            if (len(v['model']['raw_data']['debt']) >= 5
                                and v['model']['raw_data']['debt'][4][
                                    'value'] != 0)
                            else np.nan for k, v in raw_data.items() if k in df.index.values.tolist()]

        # removing NaN and inf in place
        df = df.replace([np.inf, -np.inf], np.nan).dropna()

        # removing invalid values
        # df = df.where(
        #     (df.evtoebitda > 0)
        #     & (df.pricetoearnings > 0)
        #     & (df.evtofcf > 0)
        # ).dropna()

        # ### Ranking
        df['debttocf_rank'] = df.debttocf.rank(pct=True, ascending=False)
        df['debttoequity_rank'] = df.debttoequity.rank(pct=True,
                                                       ascending=False)
        df['externalfinancing_rank'] = df.externalfinancing.rank(pct=True,
                                                                 ascending=False)
        df['changedebt_rank'] = df.changedebt.rank(pct=True,
                                                   ascending=False)

        df_rank = df[
            ['debttocf_rank',
             'debttoequity_rank',
             'externalfinancing_rank',
             'changedebt_rank']
        ]

        # average percentile rank (score)
        # select companies with at most 2 NaN metrics (to fulfill m=2)
        df_rank_ok = df_rank.loc[df_rank.isnull().sum(axis=1) <= 2]
        df_rank_ok['average'] = df_rank_ok.mean(axis=1)
        df_rank_ok['rank'] = df_rank_ok.average.rank(pct=True)

        # # Composite rank (l: better)
        # val_rank_ok['overall_rank'] = val_rank_ok.average.rank(pct=True,
        #                                                        ascending=False)

        # sorting the companies by their average percentile rank
        df_rank_ok.sort_values(by=['average'],
                               ascending=False,
                               na_position='last',
                               inplace=True
                               )

        # SAVE THE RESULTS IN PG
        res = self._save_model_results(df_rank_ok,
                                       df,
                                       raw_data,
                                       calculated_data_labels,
                                       model_id,
                                       calculation_id
                                       )

        self._create_model_stats_table(model_id=model_id,
                                       calculation_id=calculation_id,
                                       data=res
                                       )

        g_logger.critical(' MD SCORE FINANCIAL FINISHED.')

        return res

    # def do_earnings(self):
    #     # # EARNINGS aspect
    #
    #     tic = datetime.now()
    #     # list provided by Matt
    #     symbols = ['GS',
    #                'IBM',
    #                'TRV',
    #                'AXP',
    #                'WMT',
    #                'DIS',
    #                'VZ',
    #                'JPM',
    #                'GE',
    #                'AAPL',
    #                'PG',
    #                'CSCO',
    #                'PFE',
    #                'CAT',
    #                'INTC',
    #                'XOM',
    #                'BA',
    #                'UTX',
    #                'UNH',
    #                'HD',
    #                'JNJ',
    #                'MRK',
    #                'CVX',
    #                'DWDP',
    #                'MCD',
    #                'MMM',
    #                'KO',
    #                'MSFT',
    #                'NKE',
    #                'V']
    #
    #     # PARAMETERS NEEDED:
    #     params = [
    #         'netcashfromoperatingactivities',
    #         'netincome',
    #         'totalassets',
    #         'capex',
    #         'depreciationandamortization',
    #         'cashandequivalents',
    #         'debt',
    #         'totalliabilities',
    #         'totalcurrentassets',
    #         'totalcurrentliabilities'
    #     ]
    #
    #     # retrieve all data
    #     all_data = {symbol: {par: (self.financial.query_history_data(
    #         symbol, par, 't', 'desc'))
    #         for par in params} for symbol in symbols}
    #     # converting all data into a dict
    #     all_data_dict = {'ticker': [k for k in all_data.keys()]}
    #     all_data_dict.update(
    #         {par: [all_data[x][par]['data'][0]['value'] if len(
    #             all_data[x][par]['data']) > 0 else None for x in v] for k, v in
    #          all_data_dict.items() for par in params})
    #     # from dict to df
    #     df = pd.DataFrame.from_dict(all_data_dict)
    #     # set the index to symbols
    #     df.set_index('ticker', drop=True, inplace=True)
    #
    #     print('Dt = {}'.format(datetime.now() - tic))
    #
    #     ear = df
    #     ear.head()
    #     ear.describe()
    #
    #     # #### calculations
    #     ear['current_accruals_to_assets'] = (
    #                                                 ear.netincome - ear.netcashfromoperatingactivities) / ear.totalassets
    #     ear[
    #         'depreciation_to_capex'] = ear.depreciationandamortization / ear.capex
    #     # ( ( {assets}-{cash} ) - ( {liabilities}-{debt} ) ) -
    #     # ( ( {past_assets}-{past_cash} ) - ( {past_liabilities}-{past_debt} ) )
    #     ear['change_noa'] = [
    #         ((v['totalassets']['data'][0]['value'] -
    #           v['cashandequivalents']['data'][0]['value']) -
    #          (v['totalliabilities']['data'][0]['value'] - v['debt']['data'][0][
    #              'value'])) -
    #         ((v['totalassets']['data'][4]['value'] -
    #           v['cashandequivalents']['data'][4]['value']) -
    #          (v['totalliabilities']['data'][4]['value'] - v['debt']['data'][4][
    #              'value']))
    #         for k, v in all_data.items()]
    #     # ({total_current_assets}-{total_current_liabilities}-{cash})/{total_assets}
    #     ear['total_accruals_to_assets'] = (
    #                                               ear.totalcurrentassets - ear.totalcurrentliabilities - ear.cashandequivalents) / ear.totalassets
    #
    #     # ### Ranking
    #     ear[
    #         'current_accruals_to_assets_rank'] = ear.current_accruals_to_assets.rank(
    #         pct=True, ascending=False)
    #     ear['depreciation_to_capex_rank'] = ear.depreciation_to_capex.rank(
    #         pct=True, ascending=False)
    #     ear['change_noa_rank'] = 1. - ear.change_noa.rank(pct=True)
    #     ear[
    #         'total_accruals_to_assets_rank'] = ear.total_accruals_to_assets.rank(
    #         pct=True, ascending=False)
    #
    #     ear_rank = ear[
    #         ['current_accruals_to_assets_rank', 'depreciation_to_capex_rank',
    #          'change_noa_rank', 'total_accruals_to_assets_rank']]
    #
    #     # Average (m=2)
    #     # select companies with at most 3 NaN metrics
    #     ear_rank_ok = ear_rank.loc[ear_rank.isnull().sum(axis=1) <= 3]
    #     ear_rank_ok['average'] = ear_rank_ok.mean(axis=1)
    #
    #     # Composite rank (h: better?)
    #     ear_rank_ok['overall_rank'] = ear_rank_ok.average.rank(pct=True)
    #
    #     # sorting by overall rank
    #     ear_rank_ok.sort_values(by=['overall_rank'], na_position='last')
    #
    #     # export to csv
    #     ear_rank_ok.to_csv('~/Google Drive/SB_MODELS/MD/MATT_SP_EAR.csv')
    #     ear.to_csv('~/Google Drive/SB_MODELS/MD/MATT_SP_EAR_RAWDATA_RANK.csv')
    #
    #     df = pd.DataFrame([ear_rank_ok.average, ear_rank_ok.overall_rank]).T
    #
    #     res = df.sort_values(by=['overall_rank'], na_position='last')
    #
    #     return res


if __name__ == "__main__":
    model = MdScore()
    # model.apply_correction()

    model_val = model.do_valuation()
    model_fin = model.do_financial()
    # model_ear = model.do_earnings()

    # # average of ranks
    # model_avg_rank = pd.concat([model_val['overall_rank'],
    #                             model_fin['overall_rank'],
    #                             model_ear['overall_rank']], axis=1).mean(
    #     axis=1)
    # # average of averages
    # model_avg_avg = pd.concat([model_val['average'],
    #                            model_fin['average'],
    #                            model_ear['average']], axis=1).mean(axis=1)
    # # create final df
    # model_avg = pd.concat([model_avg_avg.rename('average'),
    #                        model_avg_rank.rename('overall_rank')], axis=1)
    #
    # # export to csv
    # model_avg.to_csv('~/Google Drive/SB_MODELS/MD/MATT_SP_AVG.csv')

    print("Done.")
