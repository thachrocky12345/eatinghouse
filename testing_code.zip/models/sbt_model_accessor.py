import pandas as pd
from boto3.dynamodb.conditions import Key, Attr
from dd_accessor import DynamoAccessor
from pg_accessor import PostgresAccessor
from mp_accessor import MappingAccessor
from sbt_common import SingletonAccessorManager, SbtGlobalCommon
from sbt_common import SimpleJsonDateTimeEncoder
from redis_manager import RedisManager
import simplejson as json
import numpy as np
import time
import math
import decimal
import datetime

# get the config
config = SbtGlobalCommon.get_sbt_config()['postgres']['datafactory']
# create an instance of the PG accessor
pg = PostgresAccessor(config)
# get the engine
engine = pg._engine


class ModelAccessor(DynamoAccessor, metaclass=SingletonAccessorManager):
    """
      ModelAccessor class is used to access the model data within the database.
    """
    _model_id_column = 'model_id'
    _elastic_cache_validity = 60 * 60 * 24

    def __init__(self):
        super().__init__(aws_profile_name=None,
                         aws_region_name=None,
                         aws_end_point_url=None)

        self._mp_accessor = MappingAccessor()
        self._vendor = 'intrinio'
        env_conf = self._sbtcommon.get_sbt_config()
        if 'financials' in env_conf and 'vendor' in env_conf['financials']:
            self._vendor = env_conf['financials']['vendor']

        self._elastic_cache_manager = RedisManager()

        if self._elastic_cache_manager and \
                not self._elastic_cache_manager.ping_cache():
            self._elastic_cache_manager = None

        self._env = self._sbtcommon.get_sbt_config_env()
        self._cache_base_key = self._env + '.ModelAccessor.'

        self._logger.info('ModelAccessor vendor : ' + self._vendor)

        self._set_table_names()
        self._delete_all_cached_keys()

    def _set_table_names(self):
        self._model_rankings_segments_table = \
            self._get_environment_table_name('SBT_MODEL_RANKING_SEGMENTS')
        self._model_rankings_table = \
            self._get_environment_table_name('SBT_MODEL_RANKING')
        self._model_table = \
            self._get_environment_table_name('SBT_MODEL')
        self._model_calculation_table = \
            self._get_environment_table_name('SBT_MODEL_CALCULATION')
        self._model_exception_table = \
            self._get_environment_table_name('SBT_MODEL_EXCEPTION')
        self._model_dataload_table = \
            self._get_environment_table_name('SBT_MODEL_DATALOAD')
        self._company_table = \
            self._get_environment_table_name('INTRINIO_US_COMPANY')
        self._log_table = \
            self._get_environment_table_name('SBT_LOG')
        self._symbol_exchange_mapping = \
            self._get_environment_table_name('SBT_SYMBOL_EXCHANGE_MAPPING')

    def save_model_dataload(self, dataload_entries):
        self._batch_save(self._model_dataload_table, dataload_entries)

    def save_model_exception(self, guid, model_id, symbol,
                             exception, exchange=None,
                             exception_code=None):
        model_exception = {}
        model_exception['guid'] = guid
        model_exception['model_id'] = model_id
        model_exception['symbol'] = symbol
        model_exception['exception'] = exception

        if exchange:
            model_exception['exchange'] = exchange
        else:
            model_exception['exchange'] = 'N/A'

        if exception_code:
            model_exception['exception_code'] = exception_code
        else:
            model_exception['exception_code'] = 'N/A'

        model_exception[
            'created_timestamp'] = '{:%m-%d-%Y %H:%M:%S GMT}'.format(
            datetime.datetime.utcnow())

        self._delete(self._model_table, 'guid', guid, range_name='model_id',
                     range_value=model_id)

        self._save(self._model_exception_table, model_exception)

    def save_log(self, **kargs):
        log_entry = {}
        log_entry['id'] = str(int(time.time()))
        log_entry['category'] = kargs['category']
        log_entry['message_type'] = kargs['message_type']
        log_entry['action'] = kargs['action']
        log_entry['message'] = kargs['message']
        log_entry['process_id'] = kargs['process_id']
        log_entry['guid'] = kargs['guid']
        log_entry['symbol'] = kargs['symbol']
        log_entry['created_timestamp'] = '{:%m-%d-%Y %H:%M:%S GMT}'.format(
            datetime.datetime.utcnow())

        self._save(self._log_table, log_entry)

    def reset_to_pending_model_datalaod(self, model_id):
        if model_id == 'MOMENTUM':
            self._sbp_reset_to_pending_model_datalaod(model_id)
        else:
            self._other_reset_to_pending_model_datalaod(model_id)

    def reset_all_to_pending_model_datalaod(self, model_id):

        filters = []

        filters.append(
            self._create_filter_expression('model_id', 'eq', model_id))

        load_data = self._scan_table(self._model_dataload_table,
                                     self._build_filter_expression(filters))

        for data in load_data:
            data['load_timestamp'] = '00-00-0000 00:00:00 GMT'

        self._batch_save(self._model_dataload_table, load_data)

    def query_pending_model_datalaod(self, model_id):

        filters = []

        filters.append(
            self._create_filter_expression('model_id', 'eq', model_id))
        filters.append(
            self._create_filter_expression('load_timestamp', 'eq',
                                           '00-00-0000 00:00:00 GMT'))

        return self._scan_table(self._model_dataload_table,
                                self._build_filter_expression(filters))

    def query_model_ranking(self, model_id):
        ret_ranks = self._get_cached_value('query_model_ranking', model_id)

        if ret_ranks:
            return ret_ranks

        ret_ranks = [{'model_id': model_id, "ranking_date": "0000-00-00",
                      "rankings": []}]

        rankings = self._query_table(self._model_rankings_segments_table,
                                     "model_id", model_id)

        if not rankings:
            old_rankings = self._query_table(self._model_rankings_table,
                                             "model_id", model_id)
            if old_rankings:
                return old_rankings
            else:
                return ret_ranks

        sorted_rankings = sorted(rankings,
                                 key=lambda x: (x['segment']))

        for rank in sorted_rankings:
            if ret_ranks[0]['ranking_date'] == '0000-00-00':
                ret_ranks[0]['ranking_date'] = rank['ranking_date']

            ret_ranks[0]['rankings'].extend(rank['rankings'])

        self._set_cached_value('query_model_ranking', model_id, ret_ranks)

        return ret_ranks

    def query_log(self, process_id):
        filter_ex = Attr("process_id").eq(process_id)
        return self._scan_table(self._log_table, filter_ex)

    def query_symbol_exchage_mapping_for_symbol(self, symbol):
        return_data = self._query_table(self._symbol_exchange_mapping,
                                        'symbol',
                                        symbol)

        return return_data

    def query_symbol_exchage_mapping(self):
        return_data = []
        mappings = self._scan_table(self._symbol_exchange_mapping, None)
        for mapping in mappings:
            if 'central_index_key' in mapping.keys() and \
                    self._sbtcommon.stringutil.is_not_empty(
                        mapping['central_index_key']):
                return_data.append(mapping)

        return return_data

    def save_model_rankings(self, model_rankings):
        if not model_rankings:
            self._logger.error('model_rankings not provided for ' +
                               'save_model_rankings method')
            return

        model_id = model_rankings.get('model_id', None)

        if model_id is None:
            self._logger.error(
                'Model ID not provided for save_model_rankings ' +
                'method')
            return

        cur_rankings = self._query_table(self._model_rankings_segments_table,
                                         'model_id', model_id)

        for cur in cur_rankings:
            self._delete(self._model_rankings_segments_table, 'model_id',
                         model_id, range_name='segment',
                         range_value=cur['segment'])

        item_limit = 1000
        ranking_list = model_rankings['rankings']
        ranking_list_len = len(ranking_list)

        if 'rankings' in model_rankings and \
                ranking_list_len > item_limit:
            # converting from float to Decimal
            [[x.update({k: decimal.Decimal('{:.2f}'.format(v))})
              for k, v in x.items() if
              type(v) == np.float64 or type(v) == float]
             for x in model_rankings['rankings']]
            # determining how many segments we need to create
            N = int(math.ceil(len(model_rankings['rankings']) / item_limit))
            for index in list(range(N)):
                i = index * item_limit
                j = (index + 1) * item_limit
                j = j if j < ranking_list_len else ranking_list_len
                model_rankings.update({"rankings": ranking_list[i:j],
                                       "segment": index,
                                       "seg_start": i, "seg_end": j - 1})
                self._save(self._model_rankings_segments_table, model_rankings)
        else:
            model_rankings.update({"rankings": ranking_list,
                                   "segment": 0,
                                   "seg_start": 0,
                                   "seg_end": ranking_list_len - 1})
            self._save(self._model_rankings_segments_table, model_rankings)

        self._delete_all_cached_keys()

        self._logger.critical('SAVED MODEL RANKINGS TO {}'
                              .format(self._model_rankings_segments_table))

    def save_models(self, model_data, exclude_exception_delete=False):
        if not exclude_exception_delete:
            for model in model_data:
                self._delete(self._model_exception_table, 'guid',
                             model['guid'],
                             range_name='model_id',
                             range_value=model['model_id'])

        ret_value = self._batch_save(self._model_table, model_data)

        self._delete_all_cached_keys()

        return ret_value

    def query_company_models(self, model_id):
        filter_ex = Attr("model_id").eq(model_id)
        return self._scan_table(self._model_table, filter_ex)

    def query_all_company_models(self, company):
        # is_c_key = self._is_composite_pk_id(self._model_table)
        # key = company
        # if isinstance(company, dict):
        #     if is_c_key and 'composite_pk_id' in company:
        #         key = company['composite_pk_id']
        #     elif not is_c_key and 'guid' in company:
        #         key = company['guid']
        #
        # if not isinstance(key, str):
        #     return []
        #
        # ret_data = self._get_cached_value('query_all_company_models', key)
        #
        # if ret_data:
        #     return ret_data
        #
        # if self._is_composite_pk_id(self._model_table):
        #     ret_data = self._query_table(self._model_table,
        #                                  'composite_pk_id',
        #                                  key)
        #     ret_data = ret_data + self._query_table("mm_model", "symbol", guid['symbol'])
        #     ret_data = ret_data + self._query_table("o3_indicator", "symbol", guid['symbol'])
        # else:
        #     ret_data = self._query_table(self._model_table, 'guid',
        #                                  key)
        #     ret_data = ret_data + self._query_table("mm_model", "symbol", guid['symbol'])
        #     ret_data = ret_data + self._query_table("o3_indicator", "symbol", guid['symbol'])
        #
        # if ret_data:
        #     self._set_cached_value('query_all_company_models', key,
        #                            ret_data)

        # models only accept GUID
        guid = company.get("composite_pk_id")
        query = """
            SELECT 
                ce.rank as capitalefficiency, 
                val.score as mdscore, 
                fin.score as mdscorefin,
                mom.score as mm_momentum,
                div.score as dividend,
                comp.score as composite
            FROM sbt_indicator_capeff as ce
            FULL JOIN development_sbt_models_dcf as val 
                using ("composite_pk_id")
            FULL JOIN development_sbt_models_merton as fin 
                using ("composite_pk_id")
            FULL JOIN sbt_indicator_mmmomentum as mom 
                using ("composite_pk_id")
            FULL JOIN development_sbt_models_dividend_rankings as div 
                using ("composite_pk_id")
            FULL JOIN sbt_indicator_composite as comp 
                using ("composite_pk_id")
            WHERE composite_pk_id = '{}'""".format(guid)

        df = pd.read_sql_query(query, engine)

        if len(df):
            ret_data = [{k: v[0]}
                        for k, v in df.to_dict().items() if v[0] is not None
                        ]
            if ret_data:
                self._set_cached_value('query_all_company_models',
                                       guid, ret_data
                                       )
        else:
            ret_data = []

        return ret_data

    def query_company_model(self, model_id, symbol, exchange=None):
        data = {}
        model = None

        mapping = self._mp_accessor.unique_stock_symbol_exchange_mapping(
            symbol,
            exchange=exchange)
        key = None
        if mapping:
            if self._is_composite_pk_id(self._model_table):
                key = mapping['composite_pk_id']
            else:
                key = mapping['guid']

        if key is not None:
            if self._is_composite_pk_id(self._model_table):
                model = self._unique_item(self._model_table,
                                          'composite_pk_id',
                                          key,
                                          self._model_id_column,
                                          model_id)

            else:
                model = self._unique_item(self._model_table,
                                          self._model_id_column,
                                          model_id,
                                          'guid',
                                          key)
            if model is not None:
                data = model

        return data

    def query_model_calculation(self, model_id):
        return self._query_table(self._model_calculation_table,
                                 self._model_id_column, model_id)

    def _sbp_reset_to_pending_model_datalaod(self, model_id):
        # Pull just the primary symbols to avoid issues with duplicates
        # and to make sure the appropriate stick prices are pulled.
        symbols = \
            self._mp_accessor.scan_symbol_exchange_mapping_for_sb_portfolios(
                primary_only=True)

        updates = []
        guids = []
        for symbol in symbols:
            if symbol['guid'] in guids:
                continue

            guids.append(symbol['guid'])
            load = self._unique_item(self._model_dataload_table,
                                     'guid',
                                     symbol['guid'],
                                     range_name='model_id',
                                     range_value=model_id)

            if load is None:
                load = {}
                load['guid'] = symbol['guid']
                load['model_id'] = model_id
                load['latest_filing_date'] = 'N/A'
                load['symbol'] = symbol['symbol']
                load['exchange'] = symbol['exchange']
                self._logger.info('New symbol ' + symbol['symbol'])

                # Exchange is required to pull the correct stock price.
            if load.get('exchange', 'NA') != symbol['exchange']:
                load['exchange'] = symbol['exchange']

            # This is done to make sure all the symbols
            # match the primary symbol now.
            if load['symbol'] != symbol['symbol']:
                load['symbol'] = symbol['symbol']

            load['load_timestamp'] = '00-00-0000 00:00:00 GMT'

            updates.append(load)

        if len(updates) > 0:
            self._batch_save(self._model_dataload_table, updates)

    def _intrinio_other_reset_to_pending_model_datalaod(self, model_id):
        companies = self._scan_table(self._company_table, None)

        updates = []
        for company in companies:
            ticker = company['ticker']
            load = self._unique_item(self._model_dataload_table,
                                     'symbol',
                                     ticker,
                                     range_name='model_id',
                                     range_value=model_id,
                                     index_name='SYMBOL_MODEL_IDidx')

            if load is not None:
                if company['latest_filing_date'] is not None and \
                        company['latest_filing_date'] != 'N/A' and \
                        company['latest_filing_date'] != '0000-00-00' and \
                        load['latest_filing_date'] != company[
                    'latest_filing_date']:
                    load['load_timestamp'] = '00-00-0000 00:00:00 GMT'
                    load['latest_filing_date'] = company['latest_filing_date']
                    self._logger.info('Reload symbol ' + ticker)
                    updates.append(load)
            elif company['latest_filing_date'] is not None and \
                    company['latest_filing_date'] != 'N/A' and \
                    company['latest_filing_date'] != '0000-00-00' and \
                    'guid' in company.keys():

                load = {}
                load['guid'] = company['guid']
                load['model_id'] = model_id
                load['latest_filing_date'] = company['latest_filing_date']
                load['symbol'] = ticker
                load['load_timestamp'] = '00-00-0000 00:00:00 GMT'
                self._logger.info('New symbol ' + ticker)
                updates.append(load)

        if len(updates) > 0:
            self._batch_save(self._model_dataload_table, updates)

    def _snp_other_reset_to_pending_model_datalaod(self, model_id):
        compare_date = self._sbtcommon.dateutil.add_months(
            self._sbtcommon.dateutil.get_current_timestamp(),
            -12)
        expressions = []
        expressions.append(self._create_filter_expression('snp_id', 'exists',
                                                          None))
        expressions.append(
            self._create_filter_expression('snp_latest_filing_date',
                                           'gte',
                                           compare_date.strftime('%Y-%m-%d')))
        expressions.append(
            self._create_filter_expression('snp_latest_filing_date',
                                           'ne', 'N/A'))
        expressions.append(self._create_filter_expression('primary',
                                                          'eq',
                                                          True))
        exp = self._build_filter_expression(expressions)
        companies = self._scan_table(self._symbol_exchange_mapping, exp)

        updates = []
        guids = set()
        for company in companies:
            if company['guid'] in guids:
                continue

            guids.add(company['guid'])
            ticker = company['symbol']
            load = self._unique_item(self._model_dataload_table,
                                     'symbol',
                                     ticker,
                                     range_name='model_id',
                                     range_value=model_id,
                                     index_name='SYMBOL_MODEL_IDidx')

            if load is not None:
                if company['snp_latest_filing_date'] is not None and \
                        company['snp_latest_filing_date'] != 'N/A' and \
                        company['snp_latest_filing_date'] != '0000-00-00' and \
                        load['latest_filing_date'] != company[
                    'snp_latest_filing_date']:
                    load['load_timestamp'] = '00-00-0000 00:00:00 GMT'
                    load['latest_filing_date'] = company[
                        'snp_latest_filing_date']
                    self._baseline_symbol_and_exchange(load, company)
                    self._logger.info('Reload symbol ' + ticker)
                    updates.append(load)
            elif company['snp_latest_filing_date'] is not None and \
                    company['snp_latest_filing_date'] != 'N/A' and \
                    company['snp_latest_filing_date'] != '0000-00-00' and \
                    'guid' in company.keys():

                load = {}
                load['guid'] = company['guid']
                load['model_id'] = model_id
                load['latest_filing_date'] = company['snp_latest_filing_date']
                load['symbol'] = ticker
                load['exchange'] = company['exchange']
                load['load_timestamp'] = '00-00-0000 00:00:00 GMT'
                self._logger.info('New symbol ' + ticker)
                updates.append(load)

        if len(updates) > 0:
            self._batch_save(self._model_dataload_table, updates)

    def _baseline_symbol_and_exchange(self, load, company):
        # This is done to make sure all the symbols
        # match the primary symbol now.
        if load['symbol'] != company['symbol']:
            load['symbol'] = company['symbol']

            # Exchange is required to pull the correct stock price.
        if load.get('exchange', 'NA') != company['exchange']:
            load['exchange'] = company['exchange']

    def _other_reset_to_pending_model_datalaod(self, model_id):
        if self._vendor == 'snp':
            self._snp_other_reset_to_pending_model_datalaod(model_id)
        else:
            self._intrinio_other_reset_to_pending_model_datalaod(model_id)

    def _is_composite_pk_id(self, table_name):
        is_com = False
        table = self._get_table(table_name)

        if table and table.attribute_definitions:
            for k in table.attribute_definitions:
                if k['AttributeName'] == 'composite_pk_id':
                    is_com = True
                    break

        return is_com

    def _get_elastic_cache_key(self, method_name, param_string):
        if not method_name or not param_string:
            self._logger.error('No method name or param string provided for ' +
                               'get elastic cache key.')
            return None

        key = self._cache_base_key + method_name + '.' + param_string
        self._logger.info('Elastic Cache Key = "' + key + '"')
        return key

    def _get_cached_value(self, method_name, param_string):
        value = None

        if not self._elastic_cache_manager:
            self._logger.warn('Method _get_cached_value : ' +
                              'Elastic cache manager not set.')
            return value

        key = self._get_elastic_cache_key(method_name, param_string)

        if not key:
            self._logger.warn('Key cannot be generated for set cached')
            return value

        self._logger.info('Get value for "' + key + ' from elastic cache.')
        string_value = self._elastic_cache_manager.get_string_value(key)
        if string_value:
            self._logger.info('Convert cache value to json ' + string_value)
            try:
                value = json.loads(string_value, use_decimal=True)
            except Exception as e:
                self._logger.error('Encountered exception ' + str(e) +
                                   ' getting cached value for : ' +
                                   key + ' json : ' + string_value)

        return value

    def _set_cached_value(self, method_name, param_string, value):
        if not self._elastic_cache_manager:
            self._logger.warn('Method _set_cached_value : ' +
                              'Elastic cache manager not set.')
            return

        if not value:
            self._logger.warn('No value provided for set cached')
            return

        key = self._get_elastic_cache_key(method_name, param_string)

        if not key:
            self._logger.warn('Key cannot be generated for set cached')
            return

        seconds = self._elastic_cache_validity

        self._logger.info('Set cache for ' + key
                          + ' elastic cache (expires in ' +
                          str(seconds) + ').')

        try:
            value_string = json.dumps(value, cls=SimpleJsonDateTimeEncoder)
            self._elastic_cache_manager.set_value(key, value_string,
                                                  ex=seconds)
        except Exception as e:
            self._logger.error('Encountered exception ' + str(e) +
                               ' setting cached value for : ' +
                               key + ' json : ' + str(value))

    def _delete_cached_value(self, method_name, param_string):
        value = None

        if not self._elastic_cache_manager:
            self._logger.warn('Method _delete_cached_value : ' +
                              'Elastic cache manager not set.')
            return value

        key = self._get_elastic_cache_key(method_name, param_string)

        if not key:
            self._logger.warn('Key cannot be generated for set cached')
            return value

        self._elastic_cache_manager.delete(key)

    def _delete_all_cached_keys(self):
        if self._elastic_cache_manager:
            keys = self._elastic_cache_manager.get_cache_keys(
                self._cache_base_key + '*')
            for key in keys:
                if isinstance(key, bytes):
                    str_key = key.decode('utf-8')
                else:
                    str_key = key
                self._logger.warn('Deleting cache key ' + str_key)
                self._elastic_cache_manager.delete(str_key)
        else:
            self._logger.warn('Cannot delete cache keys.')
