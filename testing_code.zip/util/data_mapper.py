import json
import time
from collections import OrderedDict
from threading import Lock
from sbt_common import SbtCommon
from sbt_common import DecimalStringEncoder

class SbtDataMapper : 
  """"
    Maps data across all vendors
  """  
  _timeseries_categories = {}
  _timeseries_guid_category_exceptions = {}
  
  def __init__(self):
    """
      Constructor
    """
    self._sbtcommon = SbtCommon()
    self._logger = self._sbtcommon.get_global_logger()
    
  def get_formatted_financial_data (self, 
                                    symbol_exchange_mapping, 
                                    metadata,
                                    data,
                                    associated_metadata = None):
    """
      Converts data into a standardized timeseries data format.
      
      Args :
        symbol_exchange_mapping (dict) : Symbol Exchange mapping
        metadata (dict) : Metadata 
        data (list) : Source data requiring formatting
        
      Returns :
        dictionary : Standardized financial data format.
    """   
    return_data = OrderedDict()
    
    if metadata is None :
      metadata = {}

    if data is None :
      data = []
    
    currency_code = None
      
    if self._sbtcommon.collectionsutil.is_not_empty(symbol_exchange_mapping) :    
      return_data['guid'] = symbol_exchange_mapping['guid']
      return_data['symbol'] = symbol_exchange_mapping['symbol']
      return_data['company_name'] = symbol_exchange_mapping['entity_name']
      currency_code = return_data.get('currency_code', None)
      if 'entity_description' in symbol_exchange_mapping:
        return_data['entity_description'] = symbol_exchange_mapping['entity_description']
      else:
        return_data['entity_description'] = ''
    else:
      return_data['guid'] = 'N/A'
      return_data['symbol'] = 'N/A'
      return_data['company_name'] = 'N/A'
      return_data['entity_description'] = 'N/A'
    
    if currency_code is None and data and isinstance(data, list) and \
    isinstance(data[0], dict) and \
    data[0].get('currency_code', 'USD') != 'USD' :
      currency_code = data[0].get('currency_code', 'USD')     
    else :
      currency_code = 'USD'
        
    if 'currency_code' not in metadata :    
      metadata['currency_code'] = currency_code
      
    return_data['metadata'] = metadata    
    
    if associated_metadata :
      return_data['associated_metadata'] = associated_metadata 
    else :
      return_data['associated_metadata'] = {}  
      
          
    return_data['results'] = data          
          
    return return_data     
    
  def get_converted_timeseries_data (self, symbol_exchange_mapping, 
                           category_name,
                           data):
    """
      Converts data into a standardized timeseries data format.
      
      Args :
        symbol_exchange_mapping (dict) : Symbol Exchange mapping
        category_name (str) : Specifies the default layout that needs to 
                              be converted
        data (list) : Source data requiring conversion
        
      Returns :
        dictionary : Standardized timeseries format.
        
      Exceptions :
        Throws an exception if the symbol mapping or category_name is empty.
    """
    if symbol_exchange_mapping is None or len(symbol_exchange_mapping) == 0 :
      raise Exception('Symbol mapping must be provided')
    
    if self._sbtcommon.stringutil.is_empty(category_name) : 
      raise Exception('Category name must be provided')
    
    guid = symbol_exchange_mapping['guid']
    return_data = {}
    currency_code = None
    
    return_data['guid'] = symbol_exchange_mapping['guid']
    return_data['symbol'] = symbol_exchange_mapping['symbol']
    return_data['company_name'] = symbol_exchange_mapping['entity_name']
    return_data['entity_description'] = ''
    
    if currency_code is None and data and isinstance(data, list) and \
    isinstance(data[0], dict) and \
    data[0].get('currency_code', 'USD') != 'USD' :
      currency_code = data[0].get('currency_code', 'USD')     
    else :
      currency_code = 'USD'
        
    final_category = self._get_timeseries_guid_category_exception(guid)
    if self._sbtcommon.stringutil.is_empty(final_category) :
      final_category = category_name 
    
    metadata = {}
    metadata['category_name'] = final_category

    if 'currency_code' not in metadata :    
      metadata['currency_code'] = currency_code
    
    t_cat = self._get_timeseries_categories()
    category_mapping = []
    if final_category in t_cat.keys() :
      category_mapping = t_cat[final_category]
    
    metadata['mappings'] = category_mapping
    return_data['metadata'] = metadata
    return_data['results'] = \
      self._create_timeseries_results(category_mapping, data,
                                      symbol_exchange_mapping['guid'],
                                      currency_code)
    
    return return_data    

  def _create_timeseries_results (self, category_mapping, data,
                                  guid, currency_code):
    """
      Converts the data and creates the results.
      
      Args :
        category_name (str) : Specifies the layout that needs to be converted
        data (list) : Source data requiring conversion
        
      Returns :
        list : Standardized results.
    """    
    converted_list = []
    if len(category_mapping) == 0 :
      return converted_list
    
    for d in data :
      c_dict = {}
      
      d_date = d.get('date', d.get('tradingDay', None))
        
      if not self._is_valid_timeseries_date(d_date):
        continue 
      
      c_dict['guid'] = guid
      c_dict['currency_code'] = currency_code
      c_dict['date'] = d_date 
      if 'timestamp' not in d.keys() or \
      not isinstance(d.get('timestamp', ''), int) :
        pattern = '%Y-%m-%d %H:%M:%S'            
        c_dict['timestamp'] = int(time.mktime(time.strptime(d_date + ' 00:00:00', pattern)))        
      else :
        c_dict['timestamp'] = d['timestamp']     
      
      d_keys = d.keys()
      v_dict = {}
      for c_map in category_mapping : 
        if c_map['id'] in d_keys :
          v_dict[c_map['id']] = d[c_map['id']]
        else :
          v_dict[c_map['id']] = 0
        
      c_dict['values'] = v_dict
      converted_list.append(c_dict)
        
    return sorted(converted_list, key=lambda k: k['date'])
  
  def _get_timeseries_categories (self):
    """
      Returns the list of all timeseries categories.   
    
      Returns :
        list : Categories
    """     
    
    if len(self._timeseries_categories) == 0 :
      self._set_timeseries_config() 
    
    return self._timeseries_categories

  def _get_timeseries_guid_category_exception (self, guid):
    """
      If the guid requires a special category mapping this method
      returns that category.   
    
      Returns :
        str : Mapping that needs to be overridden
    """     
    
    category = None
    
    if len(self._timeseries_guid_category_exceptions) == 0 :
      self._set_timeseries_config() 
    
    if guid in self._timeseries_guid_category_exceptions.keys() :
      category = self._timeseries_guid_category_exceptions[guid]

    return category

  def _is_valid_timeseries_date (self, date):
    """
      Checks to make the date is supported by the mapper.
      
      Args :
        date(str) : Date string to be validated (yyyy-mm-dd).
    """
    return date is not None and len(date) == 10 and \
    int(date[:4]) > 1969

  def _set_timeseries_config (self):
    """
      Loads the timeseries configurations from the configuration file.
    """
    with Lock() :
      if len(self._timeseries_categories) == 0 or \
      len(self._timeseries_guid_mapping_exceptions) == 0 :
        t_config = self._sbtcommon.get_config("sbt_data_mapper_conf.json")
        self.__class__._timeseries_categories = \
          t_config['timeseries']['categories']   
          
        self.__class__._timeseries_guid_category_exceptions = \
          t_config['timeseries']['guid_category_exceptions']
          
class IntrinioDataMapper (SbtDataMapper):
  """"
    Maps Intrinio data to display appropriate output information
  """     
  _company_fields = [
    {"sbt": "comp_desc", "intrinio": "short_description"},
    {"sbt": "exchange", "intrinio": "stock_exchange"},
    {"sbt": "comp_url", "intrinio": "company_url"},
    {"sbt": "phone_nbr", "intrinio": "business_phone_no"},
  ]


  _fiscal_quarter_calulation_fields = [
    {"sbt": "market_val", "intrinio": "marketcap"},
    {"sbt": "pe_ratio_12m", "intrinio": "pricetoearnings"}
  ]

  _fiscal_year_calulation_fields = [
    {"sbt": "held_by_insiders_pct", "intrinio": "held_by_insiders_pct"},
    {"sbt": "held_by_institutions_pct", "intrinio": "held_by_institutions_pct"},
    {"sbt": "peg_ratio", "intrinio": "peg_ratio"},
    {"sbt": "enterprisevalue", "intrinio": "enterprisevalue"},
    {"sbt": "evtoebitda", "intrinio": "evtoebitda"},
    {"sbt": "pricetobook", "intrinio": "pricetobook"},
    {"sbt": "pricetorevenue", "intrinio": "pricetorevenue"},
    {"sbt": "roe", "intrinio": "roe"},
    {"sbt": "roa", "intrinio": "roa"},
    {"sbt": "dividendyield", "intrinio": "dividendyield"}    
  ]

  def __init__(self):
    """
      Constructor
    """
    super().__init__()

  def finance_converter(self, typ, finance_data,
                        group_by_year=False, strip_metadata=True):
    """
      Returns a dictionary representation of the Intrinio financial data.
      This is used to make sure the feed is backwards compatible with QUANDL.
  
      Args :
        typ (str)            : Fiscal Period (a - annual, q - quarterly)
        finance_data (list)  : List of financial information from intrinio
        group_by_year(bool)  : True if data should be grouped by financial year
        strip_metadata(bool) : True if financial metadata should be stripped
  
      Returns :
        dict : Financial Information
    """
    converted_fin_data = {}

    fiscal_year = None

    if finance_data is None or len(finance_data) == 0:
      return converted_fin_data

    for fin in finance_data:
      if 'fiscal_year' in fin.keys():
        fiscal_year = fin['fiscal_year']

        fiscal_period = self._get_converted_fiscal_period(typ,
                                                          fiscal_year,
                                                          fin['fiscal_period'])

        if strip_metadata:
          fin.pop('fiscal_year')
          fin.pop('fiscal_period')
          fin.pop('months')
          fin.pop('start_date')
          fin.pop('end_date')
          fin.pop('ticker')
          fin.pop('company_cik')
          fin.pop('fiscal_id')

        self._load_converted_fin_data(typ, converted_fin_data,
                                      json.dumps(fin, cls=DecimalStringEncoder),
                                      fiscal_year, fiscal_period, group_by_year)

    if fiscal_year is not None and group_by_year == False \
            and typ.lower() != 'a' and len(converted_fin_data) == 1:
      converted_fin_data = converted_fin_data[fiscal_year]

    return converted_fin_data

  def company_converter(self, companies,
                        current_fiscal_year_income=None,
                        current_fiscal_quarter_income=None,
                        current_fiscal_year_calc=None,
                        current_fiscal_quarter_calc=None):
    """
      Loads data into existing company objects.
  
      Args :
        companies (list)                     : List of company data
        current_fiscal_year_income (list)    : Fiscal year income
        current_fiscal_quarter_income(list)  : Quarterly income
        current_fiscal_year_calc(list)       : Yearly calculations      
  
    """
    if companies is None or len(companies) == 0:
      return

    for comp in companies:
      if 'volatility' not in comp :
        comp['volatility'] = 0
      if 'ebitda' not in comp :
        comp['ebitda'] = 0        
      if 'tot_revenue_ttm' not in comp :
        comp['tot_revenue_ttm'] = 0  
      if 'net_income_ttm' not in comp :
        comp['net_income_ttm'] = 0          
      self._laod_company_fields(comp) 
      self._load_company_address(comp)
      self._load_financials_into_company(comp,
                                         current_fiscal_year_income,
                                         current_fiscal_quarter_income,
                                         current_fiscal_year_calc,
                                         current_fiscal_quarter_calc)

  def metadata_converter(self, metadata):
    """
      Returns a list representation of the Intrinio financial meta data.
      This is used to make sure the feed is backwards compatible with QUANDL.
  
      Args :
        metadata (list)  : List of financial metadata from Intrinio
  
      Returns :
        list : Financial Metatdata
    """
    converted_metadata = []

    if metadata is None or len(metadata) == 0:
      return converted_metadata

    for md in metadata:
      convmeta = {}
      convmeta['Category'] = self._get_metadata_category_desc(md['category'])
      convmeta['Data_Tag'] = md['column']
      convmeta['Description'] = md['name']
      if md['column'] == 'months' or md['column'] == 'start_date' \
              or md['column'] == 'end_date':
        convmeta['Filter'] = 'N'
      else:
        convmeta['Filter'] = 'Y'
      if md['column'] == 'ticker' or md['column'] == 'fiscal_period' \
              or md['column'] == 'fiscal_year':
        convmeta['Primary Key'] = 'Y'
      else:
        convmeta['Primary Key'] = 'N'
      convmeta['Metadata ID'] = str(md['intrinio_id'])
      convmeta['Sequence Code'] = self._get_metadata_seq_code(md['category'])
      convmeta['Name'] = md['name']
      convmeta['type'] = md['data_type']
      convmeta['Unit of Measure'] = md['units']
      converted_metadata.append(convmeta)

    return converted_metadata

  def _laod_company_fields (self, comp):
    """
      Loads/converts data into a company dictionary.
  
      Args :
        comp (dict)  : Dictionary of company data   
  
    """     
    for c_field in self._company_fields:
      if c_field['intrinio'] in comp.keys():
        comp[c_field['sbt']] = str(comp[c_field['intrinio']])
      else :
        comp[c_field['sbt']] = 'None'  

    hq_country = 'USA'
    
    if 'hq_country' in comp.keys() and \
    self._sbtcommon.stringutil.is_not_empty(comp['hq_country']) :     
      if comp['hq_country'] == 'United States of America':
        hq_country = 'USA'
      else:
        hq_country = comp['hq_country']
    else :
      hq_country = 'None'
       
    comp['country_code'] = hq_country
        
  def _load_company_address(self, comp):
    """
      Loads address data in a company dictionary.
  
      Args :
        comp (dict)  : Dictionary of company data   
  
    """    
    address1 = "None"
    address2 = "None"
    city = "None"
    state = "None"
    postal_code = "None"
    
    if 'business_address' in comp.keys() and \
    self._sbtcommon.stringutil.is_not_empty(comp['business_address']) :    
      address_parts = comp['business_address'].split(",")
      if len(address_parts) < 3 and len(address_parts) > 4:
        address1 = comp['business_address']
      elif len(address_parts) == 3:
        address1 = address_parts[0]
        city = address_parts[1]
        state_zip = address_parts[2].split()
        if len(state_zip) == 2:
          state = state_zip[0]
          postal_code = state_zip[1]
        else:
          state = address_parts[2]
      elif len(address_parts) == 4:
        address1 = address_parts[0]
        address2 = address_parts[1]
        city = address_parts[2]
        state_zip = address_parts[3].split()
        if len(state_zip) == 2:
          state = state_zip[0]
          postal_code = state_zip[1]
        else:
          state = address_parts[2]
    comp['address_line_1'] = address1.strip()
    comp['address_line_2'] = address2.strip()
    comp['city'] = city.strip()
    comp['state_code'] = state.strip()
    comp['post_code'] = postal_code.strip()

  def _load_financials_into_company(self,
                                    comp,
                                    current_fiscal_year_income=None,
                                    current_fiscal_quarter_income=None,
                                    current_fiscal_year_calc=None,
                                    current_fiscal_quarter_calc=None):
    """
      Loads financial data into the company dictionary.
  
      Args :
        comp (dict)                          : Dictionary of company data
        current_fiscal_year_income (list)    : Fiscal year income
        current_fiscal_quarter_income(list)  : Quarterly income
        current_fiscal_year_calc(list)       : Yearly calculations      
  
    """
    if current_fiscal_year_calc is not None and \
                    len(current_fiscal_year_calc) == 1:
      self._load_fiscal_year_calculation(comp,
                                         current_fiscal_year_calc[0])

    if current_fiscal_quarter_calc is not None and \
                    len(current_fiscal_quarter_calc) == 1:
      self._load_fiscal_quarter_calculation(comp,
                                         current_fiscal_quarter_calc[0])

    if current_fiscal_year_income is not None and \
                    len(current_fiscal_year_income) == 1:
      self._load_fiscal_year_income(comp,
                                    current_fiscal_year_income[0])

    if current_fiscal_quarter_income is not None and \
                    len(current_fiscal_quarter_income) == 1:
      self._load_fiscal_quarterly_income(comp,
                                         current_fiscal_quarter_income[0])

  def _load_fiscal_quarter_calculation(self, comp, qcalc):
    """
      Loads calculations for fiscal year into the company.
  
      Args :
        comp (dict)     : Dictionary of company data
        qcalc(list)     : Quarterly calculations      
  
    """      
    
    for q_field in self._fiscal_quarter_calulation_fields :
      if q_field['intrinio'] in qcalc.keys():
        comp[q_field['sbt']] = str(qcalc[q_field['intrinio']])
      else :
        comp[q_field['sbt']] = '0.00' 

  def _load_fiscal_year_calculation(self, comp, cfycalc):
    """
      Loads calculations for fiscal year into the company.
  
      Args :
        comp (dict)     : Dictionary of company data
        cfycalc(list)   : Yearly calculations      
  
    """   
    for f_field in self._fiscal_year_calulation_fields:
      if f_field['intrinio'] in cfycalc.keys():
        comp[f_field['sbt']] = str(cfycalc[f_field['intrinio']])
      else :
        comp[f_field['sbt']] = '0.00'     

  def _load_fiscal_year_income(self, comp, cfyi):
    """
      Loads income for fiscal year into the company.
  
      Args :
        comp (dict)     : Dictionary of company data
        cfyi(list)      : Yearly income      
  
    """
    if 'netincome' in cfyi.keys():
      comp['net_income_f0'] = str(cfyi['netincome'])
    if 'totalrevenue' in cfyi.keys():
      comp['tot_revenue_f0'] = str(cfyi['totalrevenue'])
    if 'weightedavedilutedsharesos' in cfyi.keys():
      comp['shares_out'] = str(cfyi['weightedavedilutedsharesos'])

  def _load_fiscal_quarterly_income(self, comp, cfqi):
    """
      Loads income for fiscal year into the company.
  
      Args :
        comp (dict)     : Dictionary of company data
        cfqi(list)      : Quarterly income      
  
    """
    if 'basiceps' in cfqi.keys():
      comp['eps_mean_est_qr0'] = str(cfqi['basiceps'])
    net_margin = 0
    if 'totalgrossprofit' in cfqi.keys():
      net_margin = cfqi['totalgrossprofit']
    if 'totaloperatingexpenses' in cfqi.keys():
      net_margin = net_margin - cfqi['totaloperatingexpenses']
    if 'totalinterestexpense' in cfqi.keys():
      net_margin = net_margin - cfqi['totalinterestexpense']
    if 'incometaxexpense' in cfqi.keys():
      net_margin = net_margin - cfqi['incometaxexpense']
    comp['net_margin_q0'] = str(net_margin)

  def _load_converted_fin_data(self, typ, converted_fin_data, str_fin,
                               fiscal_year, fiscal_period, group_by_year):
    """
      Added string financial data to converted financial data.
  
      Args :
        typ (str)                  : Fiscal Period (a - annual, q - quarterly)
        converted_fin_data (dict)  : Converted financial values to be populated
        str_fin (dict)             : Existing Financial data
        fiscal_year (int)          : Fiscal year
        fiscal_period (str)        : Fiscal period
        group_by_year(bool)        : True if data should be grouped by FY
  
    """
    if fiscal_period is not None:
      if typ.lower() == 'a' and group_by_year == False:
        converted_fin_data[fiscal_period] = json.loads(str_fin)
      else:
        if fiscal_year not in converted_fin_data.keys():
          converted_fin_data[fiscal_year] = {}
        converted_fin_data[fiscal_year][str(fiscal_period)] = \
          json.loads(str_fin)

  def _get_converted_fiscal_period(self, typ, fiscal_year, fiscal_period):
    """
      Determines fiscal period based on the parameters that are passed in.
  
      Args :
        typ (str)                  : Fiscal Period (a - annual, q - quarterly)
        fiscal_year (int)          : Fiscal year
        fiscal_period (str)        : Fiscal period
  
    """
    converted_fiscal_period = fiscal_year
    if typ.lower() != 'a' and len(fiscal_period) == 2 and \
            fiscal_period.startswith('Q'):
      converted_fiscal_period = str(fiscal_year) + '0' + fiscal_period[1:]

    return converted_fiscal_period

  def _get_metadata_category_desc(self, category):
    """
      Returns metadata category description base on category name
  
      Args :
        category (str)  : Category Name
  
      Returns :
        str : Category Description
    """
    desc = category
    if category.upper() == 'INCOME':
      desc = 'Income Statement'
    elif category.upper() == 'CASH':
      desc = 'Cash Flow Statement'
    elif category.upper() == 'BALANCE':
      desc = 'Balance Sheet'

    return desc

  def _get_metadata_seq_code(self, category):
    """
      Returns metadata seq code base on category name
  
      Args :
        category (str)  : Category Name
  
      Returns :
        str : Seq Code
    """
    seq_code = '6'
    if category.upper() == 'INCOME':
      seq_code = '2'
    elif category.upper() == 'CASH':
      seq_code = '4'
    elif category.upper() == 'BALANCE':
      seq_code = '3'

    return seq_code
